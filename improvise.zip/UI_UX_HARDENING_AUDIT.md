# UI/UX STRUCTURAL FAILURE ANALYSIS

## Critical Bugs Identified

### 1. Z-Index Hierarchy Violations ❌
**Current State:**
- Hero canvas: `z-0` ✓
- Hero content: `z-10` ✓
- Navigation: **MISSING** explicit z-index (defaults to `auto`)
- Mobile overlay: **MISSING** explicit z-index
- CTA buttons: `z-10` inside relative containers (stacking context trap)

**Fix Required:**
- Navigation: `z-40`
- Mobile overlay: `z-50`
- Add `isolation: isolate` to section containers

### 2. Mobile Viewport Height Bug ❌
**Current State:**
- Hero uses `min-h-screen` → CSS override exists but not applied to hero
- Mobile browser UI collapse breaks layout

**Fix Required:**
- Replace `min-h-screen` with `min-h-[100dvh]` in hero.php

### 3. Grid Overflow on Mobile ❌
**Current State:**
- No `overflow-x-hidden` on body
- `container-sovereign` has `overflow-x: hidden` only on mobile
- Grid borders may double-stack on mobile collapse

**Fix Required:**
- Add global `overflow-x: hidden` to body
- Verify border collapse behavior on mobile

### 4. Typography Scaling Issues ⚠️
**Current State:**
- Fixed breakpoint scaling: `text-6xl md:text-7xl lg:text-8xl`
- CSS has `clamp()` utilities but not applied to hero

**Fix Required:**
- Apply fluid typography classes to hero headings

### 5. Hover State Z-Index Conflicts ⚠️
**Current State:**
- Matrix items use `border-l-2` transitions
- No `isolation: isolate` on parent containers

**Fix Required:**
- Add `isolation: isolate` to section wrappers

### 6. Motion Engine Issues ❌
**Current State:**
- No ScrollTrigger.refresh() after font load
- Animations removed (Lenis only)

**Fix Required:**
- Add font-load listener with ScrollTrigger.refresh()
- Verify Lenis easing curve

## Fixes to Implement

1. **header.php**: Add `z-40` to nav, `z-50` to mobile overlay
2. **hero.php**: Replace `min-h-screen` with `min-h-[100dvh]`
3. **styles.css**: Add global `overflow-x: hidden` to body
4. **All sections**: Add `isolation: isolate` to prevent z-index bleed
5. **animations.js**: Add ScrollTrigger.refresh() on font load
