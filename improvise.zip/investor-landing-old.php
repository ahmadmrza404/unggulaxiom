<?php
/**
 * ============================================
 * INVESTOR LANDING PAGE - HIGH CONVERSION VERSION
 * ============================================
 * Purpose: Strategic institutional investment page
 * Architecture: Data room aesthetic with conversion focus
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Investor Landing';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- ============================================ -->
<!-- HERO SECTION -->
<!-- ============================================ -->
<section class="min-h-[70vh] flex items-center justify-center bg-obsidian-950 py-40">
    <div class="container-sovereign">
        <div class="max-w-5xl">
            <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
                INSTITUTIONAL INVESTMENT OPPORTUNITY
            </span>
            <h1 class="font-serif text-6xl md:text-7xl lg:text-8xl text-platinum-50 tracking-editorial leading-none mb-12" data-gsap-fade-up data-gsap-delay="0.2">
                Unggul Axiom Group
            </h1>
            <div class="w-32 h-px bg-champagne-500 mb-12" data-gsap-line-draw data-gsap-delay="0.4"></div>
            <p class="text-xl md:text-2xl text-platinum-200 leading-institutional max-w-4xl mb-8" data-gsap-fade-up data-gsap-delay="0.5">
                Emerging Halal Infrastructure Platform
            </p>
            <p class="text-xl md:text-2xl text-platinum-200 leading-institutional max-w-4xl" data-gsap-fade-up data-gsap-delay="0.6">
                Backed by South Korean Government Technology Transfer
            </p>
        </div>
    </div>
</section>

<!-- ============================================ -->
<!-- CORE SECTION -->
<!-- ============================================ -->
<section class="py-32 bg-platinum-50 text-obsidian-950">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-12 block" data-gsap-fade-up>
            CORE
        </span>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
            <div data-gsap-fade-up>
                <h2 class="text-3xl font-serif text-obsidian-950 mb-4">Platform: UHIC</h2>
            </div>
            <div data-gsap-fade-up>
                <h2 class="text-3xl font-serif text-obsidian-950 mb-4">Pilot: CIPU</h2>
            </div>
        </div>

        <div class="max-w-4xl" data-gsap-fade-up>
            <p class="text-2xl text-obsidian-800 leading-institutional mb-8">
                Expansion: Malaysia → Regional
            </p>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- FINANCIAL SNAPSHOT -->
<!-- ============================================ -->
<section class="py-32 bg-obsidian-950 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-12 block" data-gsap-fade-up>
            FINANCIAL SNAPSHOT
        </span>

        <div class="space-y-6 max-w-3xl">
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-3 h-3 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-xl text-platinum-200">3.6M chickens/year (per node)</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-3 h-3 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-xl text-platinum-200">RM19.8M base net profit</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-3 h-3 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-xl text-platinum-200">Scalable infrastructure model</p>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- CAPITAL ENTRY -->
<!-- ============================================ -->
<section class="py-32 bg-platinum-50 text-obsidian-950">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-12 block" data-gsap-fade-up>
            CAPITAL ENTRY
        </span>

        <div class="space-y-6 max-w-3xl">
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-3 h-3 bg-champagne-600 rounded-full mr-4"></span>
                <p class="text-xl text-obsidian-800">Equity participation</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-3 h-3 bg-champagne-600 rounded-full mr-4"></span>
                <p class="text-xl text-obsidian-800">Joint ventures</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-3 h-3 bg-champagne-600 rounded-full mr-4"></span>
                <p class="text-xl text-obsidian-800">Infrastructure financing</p>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- FILTER -->
<!-- ============================================ -->
<section class="py-32 bg-obsidian-900 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-12 block" data-gsap-fade-up>
            FILTER
        </span>

        <div class="max-w-4xl" data-gsap-fade-up>
            <p class="text-3xl font-serif text-platinum-50 leading-tight">
                Institutional engagement only
            </p>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- FAQ SECTION -->
<!-- ============================================ -->
<section class="py-32 bg-platinum-50 text-obsidian-950">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-12 block" data-gsap-fade-up>
            FAQ SECTION (VERY IMPORTANT FOR TRUST)
        </span>

        <div class="max-w-4xl space-y-12">

            <div data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-obsidian-950 mb-4">What stage is the project?</h3>
                <p class="text-lg text-obsidian-800 leading-institutional">
                    CIPU is in pilot development phase.
                </p>
                <p class="text-lg text-obsidian-800 leading-institutional mt-2">
                    UHIC platform is under structured development.
                </p>
            </div>

            <div data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-obsidian-950 mb-4">Is this already operational?</h3>
                <p class="text-lg text-obsidian-800 leading-institutional">
                    Pilot implementation is in progress.
                </p>
            </div>

            <div data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-obsidian-950 mb-4">How can investors participate?</h3>
                <p class="text-lg text-obsidian-800 leading-institutional">
                    Through structured institutional participation frameworks.
                </p>
            </div>

            <div data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-obsidian-950 mb-4">Where will expansion happen?</h3>
                <p class="text-lg text-obsidian-800 leading-institutional">
                    Initial focus includes Peninsular Malaysia, Sabah, and Sarawak.
                </p>
            </div>

        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- DATA ROOM STRUCTURE -->
<!-- ============================================ -->
<section class="py-32 bg-obsidian-950 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-12 block" data-gsap-fade-up>
            DATA ROOM STRUCTURE (WHAT INVESTORS WILL ASK NEXT)
        </span>

        <div class="mb-12" data-gsap-fade-up>
            <h3 class="text-2xl font-serif text-platinum-50 mb-8">Folder Structure</h3>
        </div>

        <div class="space-y-4 max-w-3xl">
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-2 h-2 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-lg text-platinum-200">Corporate Documents</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-2 h-2 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-lg text-platinum-200">CIPU Project Details</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-2 h-2 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-lg text-platinum-200">Financial Model</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-2 h-2 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-lg text-platinum-200">Land / Location</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-2 h-2 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-lg text-platinum-200">Operations Plan</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-2 h-2 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-lg text-platinum-200">Regulatory / Halal Compliance</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-2 h-2 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-lg text-platinum-200">Capital Structure</p>
            </div>
            <div class="flex items-center" data-gsap-fade-up>
                <span class="w-2 h-2 bg-champagne-500 rounded-full mr-4"></span>
                <p class="text-lg text-platinum-200">Expansion Strategy</p>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- FINAL POSITIONING -->
<!-- ============================================ -->
<section class="py-32 bg-platinum-50 text-obsidian-950">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-12 block" data-gsap-fade-up>
            FINAL POSITIONING (USE EVERYWHERE)
        </span>

        <div class="max-w-4xl space-y-8" data-gsap-fade-up>
            <p class="text-2xl font-serif text-obsidian-950 leading-tight">
                You are now:
            </p>
            <p class="text-3xl font-serif text-obsidian-950 leading-tight">
                An emerging halal infrastructure platform (UHIC)
            </p>
            <p class="text-2xl text-obsidian-800 leading-institutional">
                with
            </p>
            <p class="text-3xl font-serif text-obsidian-950 leading-tight">
                a pilot execution node (CIPU)
            </p>
            <p class="text-2xl text-obsidian-800 leading-institutional">
                designed for
            </p>
            <p class="text-3xl font-serif text-obsidian-950 leading-tight">
                scalable regional deployment (Malaysia → beyond)
            </p>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- FINAL TRUTH -->
<!-- ============================================ -->
<section class="py-32 bg-obsidian-950 text-platinum-50">
    <div class="container-sovereign">

        <div class="mb-12" data-gsap-fade-up>
            <h2 class="text-4xl font-serif text-champagne-500 mb-8">⚡ FINAL TRUTH (VERY IMPORTANT)</h2>
        </div>

        <div class="max-w-4xl space-y-8">
            <p class="text-2xl text-platinum-200 leading-institutional" data-gsap-fade-up>
                At this point:
            </p>
            <div class="space-y-4">
                <div class="flex items-center" data-gsap-fade-up>
                    <span class="w-3 h-3 bg-champagne-500 rounded-full mr-4"></span>
                    <p class="text-xl text-platinum-200">Narrative = COMPLETE</p>
                </div>
                <div class="flex items-center" data-gsap-fade-up>
                    <span class="w-3 h-3 bg-champagne-500 rounded-full mr-4"></span>
                    <p class="text-xl text-platinum-200">Website = COMPLETE</p>
                </div>
                <div class="flex items-center" data-gsap-fade-up>
                    <span class="w-3 h-3 bg-champagne-500 rounded-full mr-4"></span>
                    <p class="text-xl text-platinum-200">Investor materials = COMPLETE</p>
                </div>
            </div>
        </div>

        <div class="mt-20 max-w-4xl" data-gsap-fade-up>
            <h3 class="text-3xl font-serif text-champagne-500 mb-8">🚀 What unlocks real funding now:</h3>
            <p class="text-2xl text-platinum-200 leading-institutional mb-6">
                Only 3 things:
            </p>
            <div class="space-y-4">
                <div class="flex items-center">
                    <span class="w-3 h-3 bg-champagne-500 rounded-full mr-4"></span>
                    <p class="text-xl text-platinum-200">Execution proof (even small)</p>
                </div>
                <div class="flex items-center">
                    <span class="w-3 h-3 bg-champagne-500 rounded-full mr-4"></span>
                    <p class="text-xl text-platinum-200">Numbers validation (basic)</p>
                </div>
                <div class="flex items-center">
                    <span class="w-3 h-3 bg-champagne-500 rounded-full mr-4"></span>
                    <p class="text-xl text-platinum-200">Strategic conversations (targeted)</p>
                </div>
            </div>
        </div>

        <div class="mt-20 max-w-4xl border-l-4 border-champagne-500 pl-12 py-8" data-gsap-fade-up>
            <p class="text-2xl text-platinum-200 leading-institutional mb-8">
                If you want next, I can build:
            </p>
            <div class="space-y-4">
                <div class="flex items-center">
                    <span class="text-3xl mr-4">👉</span>
                    <p class="text-xl text-platinum-200">Real investor target list in Malaysia (who to approach)</p>
                </div>
                <div class="flex items-center">
                    <span class="text-3xl mr-4">👉</span>
                    <p class="text-xl text-platinum-200">Full CIPU operational plan</p>
                </div>
                <div class="flex items-center">
                    <span class="text-3xl mr-4">👉</span>
                    <p class="text-xl text-platinum-200">Government grant strategy (KKDW / MAFI / etc.)</p>
                </div>
            </div>
        </div>

    </div>
</section>

<?php
require_once INCLUDES_PATH . '/footer.php';
?>
