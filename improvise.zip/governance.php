<?php
/**
 * ============================================
 * GOVERNANCE - FRAMEWORK DOCUMENTATION
 * ============================================
 * Purpose: Institutional governance framework
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Governance Framework';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- VANGUARD SECTION -->
<section class="py-32 bg-obsidian-950 border-b border-champagne-500/20 isolate">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto">
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-tight leading-none">
                GOVERNANCE FRAMEWORK
            </h1>
            <p class="text-lg text-platinum-200 leading-institutional mb-4">
                UNGGUL BRONTO SDN. BHD. (Registration No: 202301027920)
            </p>
            <p class="text-base text-sovereign-400 leading-institutional">
                Institutional governance structure for infrastructure operations and capital deployment
            </p>
        </div>
    </div>
</section>

<!-- GOVERNANCE DOCUMENT -->
<section class="py-32 bg-obsidian-900 isolate">
    <div class="container-sovereign">
        <div class="reveal-mask max-w-6xl mx-auto">

            <div class="grid grid-cols-12 gap-8 border-b border-obsidian-950/20 pb-12 mb-12">
                <div class="col-span-3">
                    <p class="font-mono text-xs text-champagne-600 tracking-wider">SECTION 1.0</p>
                </div>
                <div class="col-span-9">
                    <h2 class="font-serif text-3xl text-platinum-50 mb-6 tracking-tight">Corporate Governance Structure</h2>
                    <p class="text-base text-platinum-200 leading-relaxed mb-4">
                        Unggul Axiom Group maintains structured governance framework with clearly defined roles, responsibilities, and accountability mechanisms. Board composition reflects appropriate expertise across infrastructure development, operational management, financial oversight, and regulatory compliance.
                    </p>
                    <p class="text-base text-platinum-200 leading-relaxed">
                        Governance structure encompasses board oversight, executive management authority, internal control systems, and stakeholder engagement protocols designed to ensure institutional accountability and operational transparency.
                    </p>
                </div>
            </div>

            <div class="grid grid-cols-12 gap-8 border-b border-obsidian-950/20 pb-12 mb-12">
                <div class="col-span-3">
                    <p class="font-mono text-xs text-champagne-600 tracking-wider">SECTION 2.0</p>
                </div>
                <div class="col-span-9">
                    <h2 class="font-serif text-3xl text-platinum-50 mb-6 tracking-tight">Board Oversight</h2>
                    <p class="text-base text-platinum-200 leading-relaxed mb-4">
                        Board of Directors provides strategic oversight and governance direction for all organizational activities. Board responsibilities include strategic planning approval, capital deployment authorization, risk management oversight, and regulatory compliance monitoring.
                    </p>
                    <p class="text-base text-platinum-200 leading-relaxed">
                        Board committees address specialized oversight functions including audit and risk management, investment evaluation, governance and nomination, and compensation review. Committee charters define scope, authority, and reporting obligations.
                    </p>
                </div>
            </div>

            <div class="grid grid-cols-12 gap-8 border-b border-obsidian-950/20 pb-12 mb-12">
                <div class="col-span-3">
                    <p class="font-mono text-xs text-champagne-600 tracking-wider">SECTION 3.0</p>
                </div>
                <div class="col-span-9">
                    <h2 class="font-serif text-3xl text-platinum-50 mb-6 tracking-tight">Management Structure</h2>
                    <p class="text-base text-platinum-200 leading-relaxed mb-4">
                        Executive management operates under delegated authority from the Board with clear reporting lines and accountability frameworks. Management committees coordinate cross-functional operations, strategic initiative execution, and operational performance monitoring.
                    </p>
                    <p class="text-base text-platinum-200 leading-relaxed">
                        Command structure encompasses infrastructure systems coordination, sector integration management, capital deployment oversight, and institutional engagement protocols.
                    </p>
                </div>
            </div>

            <div class="grid grid-cols-12 gap-8">
                <div class="col-span-3">
                    <p class="font-mono text-xs text-champagne-600 tracking-wider">SECTION 4.0</p>
                </div>
                <div class="col-span-9">
                    <h2 class="font-serif text-3xl text-platinum-50 mb-6 tracking-tight">Stakeholder Engagement</h2>
                    <p class="text-base text-platinum-200 leading-relaxed mb-4">
                        Governance framework includes structured stakeholder engagement protocols for institutional investors, strategic partners, regulatory authorities, and operational stakeholders. Engagement mechanisms ensure transparency, accountability, and alignment with institutional standards.
                    </p>
                    <p class="text-base text-platinum-200 leading-relaxed">
                        Communication protocols address financial reporting, operational updates, regulatory disclosures, and strategic initiative announcements through appropriate institutional channels.
                    </p>
                </div>
            </div>

        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
