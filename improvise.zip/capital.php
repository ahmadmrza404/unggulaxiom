<?php
/**
 * ============================================
 * CAPITAL - INSTITUTIONAL DEPLOYMENT TERMINAL
 * ============================================
 * Purpose: Secure capital deployment data room
 * ============================================
 */

require_once __DIR__ . '/config.php';

$_capital = json_decode(file_get_contents(DATA_PATH . '/capital.json'), true);
$page_title = 'Capital Architecture';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- VANGUARD SECTION -->
<section class="min-h-[70vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/20 isolate">
    <div class="container-sovereign py-32">
        <div class="max-w-6xl mx-auto text-center">
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-[0.15em] leading-tight uppercase">
                <?= htmlspecialchars($_capital['hero']['title']) ?>
            </h1>
            <p class="text-lg text-sovereign-400 tracking-institutional max-w-4xl mx-auto mb-6">
                <?= htmlspecialchars($_capital['hero']['tagline']) ?>
            </p>
            <?php if (isset($_capital['hero']['subtitle'])): ?>
            <p class="text-base text-sovereign-500 tracking-institutional max-w-5xl mx-auto">
                <?= htmlspecialchars($_capital['hero']['subtitle']) ?>
            </p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- OVERVIEW SECTION -->
<?php if (isset($_capital['overview'])): ?>
<section class="py-24 bg-obsidian-900 border-b border-champagne-500/20 isolate">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto">
            <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                <?= htmlspecialchars($_capital['overview']['section_label']) ?>
            </p>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 mb-8 tracking-tight">
                <?= htmlspecialchars($_capital['overview']['headline']) ?>
            </h2>
            <p class="text-lg text-platinum-200 leading-institutional mb-12 max-w-5xl">
                <?= htmlspecialchars($_capital['overview']['description']) ?>
            </p>

            <!-- Key Metrics Grid -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <?php foreach ($_capital['overview']['key_metrics'] as $metric): ?>
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-6">
                    <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3">
                        <?= htmlspecialchars($metric['label']) ?>
                    </p>
                    <p class="text-4xl font-serif text-platinum-50 mb-2">
                        <?= htmlspecialchars($metric['value']) ?>
                    </p>
                    <p class="text-sm text-sovereign-400">
                        <?= htmlspecialchars($metric['description']) ?>
                    </p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- PARTICIPATION STRUCTURES -->
<section class="py-32 bg-obsidian-950 isolate">
    <div class="container-sovereign">

        <div class="mb-16 text-center">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4">
                <?= htmlspecialchars($_capital['participation_structures']['section_label']) ?>
            </h2>
            <div class="w-16 h-px bg-champagne-500 mx-auto"></div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-0 border-t border-champagne-500/20 mb-16">
            <?php foreach ($_capital['participation_structures']['structures'] as $idx => $struct):
                $border_class = $idx < count($_capital['participation_structures']['structures']) - 1 ? 'border-r border-champagne-500/20' : '';
            ?>
            <div class="matrix-item group <?= $border_class ?> py-16 px-8 text-center transition-all duration-300 hover:bg-platinum-50/5">
                <div class="border-t-2 border-champagne-500/50 w-16 mx-auto mb-8"></div>
                <p class="font-mono text-xs text-champagne-500 tracking-wider mb-6"><?= htmlspecialchars($struct['code']) ?></p>
                <h3 class="text-2xl text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300 tracking-institutional mb-6">
                    <?= htmlspecialchars($struct['name']) ?>
                </h3>
                <p class="text-sm text-sovereign-500 leading-institutional mb-8">
                    <?= htmlspecialchars($struct['description']) ?>
                </p>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Detailed Structure Breakdown -->
        <div class="max-w-6xl mx-auto space-y-12">
            <?php foreach ($_capital['participation_structures']['structures'] as $struct): ?>
            <div class="border border-champagne-500/20 bg-obsidian-900/50 p-8">
                <div class="flex items-center gap-4 mb-6">
                    <span class="font-mono text-xs text-champagne-500 tracking-wider"><?= htmlspecialchars($struct['code']) ?></span>
                    <h3 class="text-2xl font-serif text-platinum-50"><?= htmlspecialchars($struct['name']) ?></h3>
                </div>

                <?php if (isset($struct['details'])): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <?php foreach ($struct['details'] as $key => $value): ?>
                    <div class="border-l-2 border-champagne-500/20 pl-4">
                        <p class="text-xs text-champagne-500 tracking-wide uppercase mb-2">
                            <?= htmlspecialchars(str_replace('_', ' ', $key)) ?>
                        </p>
                        <p class="text-base text-platinum-200">
                            <?= htmlspecialchars($value) ?>
                        </p>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if (isset($struct['use_cases'])): ?>
                <div>
                    <p class="text-sm text-champagne-500 tracking-wide uppercase mb-3">Use Cases</p>
                    <ul class="space-y-2">
                        <?php foreach ($struct['use_cases'] as $use_case): ?>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1">→</span>
                            <span class="text-sm text-platinum-200"><?= htmlspecialchars($use_case) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- CAPITAL ALLOCATION MODEL -->
<?php if (isset($_capital['capital_allocation'])): ?>
<section class="py-24 bg-obsidian-900 border-t border-champagne-500/20 isolate">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto">
            <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                <?= htmlspecialchars($_capital['capital_allocation']['section_label']) ?>
            </p>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 mb-8 tracking-tight">
                <?= htmlspecialchars($_capital['capital_allocation']['title']) ?>
            </h2>
            <p class="text-lg text-platinum-200 leading-institutional mb-12">
                <?= htmlspecialchars($_capital['capital_allocation']['description']) ?>
            </p>

            <!-- Phases Grid -->
            <div class="space-y-8">
                <?php foreach ($_capital['capital_allocation']['phases'] as $idx => $phase): ?>
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <div>
                            <h3 class="text-2xl font-serif text-platinum-50 mb-4">
                                <?= htmlspecialchars($phase['phase']) ?>
                            </h3>
                            <div class="space-y-3 mb-6">
                                <div class="flex justify-between">
                                    <span class="text-sm text-sovereign-400">Capital Requirement</span>
                                    <span class="text-lg text-champagne-500 font-semibold">
                                        <?= htmlspecialchars($phase['capital_requirement']) ?>
                                    </span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-sm text-sovereign-400">Timeline</span>
                                    <span class="text-base text-platinum-200">
                                        <?= htmlspecialchars($phase['timeline']) ?>
                                    </span>
                                </div>
                            </div>

                            <div>
                                <p class="text-xs text-champagne-500 tracking-wide uppercase mb-3">Key Milestones</p>
                                <ul class="space-y-2">
                                    <?php foreach ($phase['milestones'] as $milestone): ?>
                                    <li class="flex items-start gap-2">
                                        <span class="text-champagne-500 text-xs mt-1">✓</span>
                                        <span class="text-sm text-platinum-200"><?= htmlspecialchars($milestone) ?></span>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>

                        <div>
                            <p class="text-xs text-champagne-500 tracking-wide uppercase mb-4">Capital Allocation</p>
                            <canvas id="allocationChart<?= $idx ?>" style="max-height: 250px;"></canvas>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- RETURNS ANALYSIS -->
<?php if (isset($_capital['returns_analysis'])): ?>
<section class="py-24 bg-obsidian-950 border-t border-champagne-500/20 isolate">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto">
            <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                <?= htmlspecialchars($_capital['returns_analysis']['section_label']) ?>
            </p>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 mb-8 tracking-tight">
                <?= htmlspecialchars($_capital['returns_analysis']['title']) ?>
            </h2>
            <p class="text-lg text-platinum-200 leading-institutional mb-12">
                <?= htmlspecialchars($_capital['returns_analysis']['description']) ?>
            </p>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                    <canvas id="returnsChart" style="max-height: 300px;"></canvas>
                </div>

                <div class="space-y-6">
                    <?php foreach ($_capital['returns_analysis']['scenarios'] as $scenario): ?>
                    <div class="border border-champagne-500/20 bg-obsidian-900/50 p-6">
                        <h3 class="text-xl font-serif text-platinum-50 mb-4">
                            <?= htmlspecialchars($scenario['scenario']) ?>
                        </h3>
                        <div class="grid grid-cols-2 gap-4 mb-4">
                            <div>
                                <p class="text-xs text-sovereign-400 mb-1">IRR</p>
                                <p class="text-2xl text-champagne-500 font-semibold">
                                    <?= htmlspecialchars($scenario['irr']) ?>
                                </p>
                            </div>
                            <div>
                                <p class="text-xs text-sovereign-400 mb-1">Multiple</p>
                                <p class="text-2xl text-platinum-200 font-semibold">
                                    <?= htmlspecialchars($scenario['multiple']) ?>
                                </p>
                            </div>
                        </div>
                        <p class="text-sm text-sovereign-400">
                            <?= htmlspecialchars($scenario['assumptions']) ?>
                        </p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- RISK FRAMEWORK -->
<?php if (isset($_capital['risk_mitigation'])): ?>
<section class="py-24 bg-obsidian-900 border-t border-champagne-500/20 isolate">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto">
            <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                <?= htmlspecialchars($_capital['risk_mitigation']['section_label']) ?>
            </p>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 mb-12 tracking-tight">
                <?= htmlspecialchars($_capital['risk_mitigation']['title']) ?>
            </h2>

            <div class="space-y-4">
                <?php foreach ($_capital['risk_mitigation']['categories'] as $risk): ?>
                <div class="grid grid-cols-1 md:grid-cols-12 gap-0 border border-champagne-500/20 hover:border-champagne-500/40 transition-colors">
                    <div class="md:col-span-2 bg-obsidian-950/50 p-6 flex items-center justify-center">
                        <span class="text-xs font-semibold tracking-wide text-center text-platinum-300">
                            <?= htmlspecialchars($risk['risk']) ?>
                        </span>
                    </div>
                    <div class="md:col-span-8 p-6 border-l border-champagne-500/20">
                        <p class="text-sm text-platinum-200 leading-institutional">
                            <?= htmlspecialchars($risk['mitigation']) ?>
                        </p>
                    </div>
                    <div class="md:col-span-2 p-6 border-l border-champagne-500/20 flex items-center justify-center">
                        <?php
                        $residual = strtolower($risk['residual']);
                        $badge_color = str_contains($residual, 'low') && !str_contains($residual, 'medium')
                            ? 'text-green-400 border-green-400/30 bg-green-400/5'
                            : (str_contains($residual, 'medium')
                                ? 'text-champagne-400 border-champagne-400/30 bg-champagne-400/5'
                                : 'text-red-400 border-red-400/30 bg-red-400/5');
                        ?>
                        <span class="text-xs font-semibold tracking-wide px-3 py-1 border <?= $badge_color ?>">
                            <?= htmlspecialchars($risk['residual']) ?>
                        </span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- GOVERNANCE FRAMEWORK -->
<?php if (isset($_capital['governance'])): ?>
<section class="py-24 bg-obsidian-950 border-t border-champagne-500/20 isolate">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto">
            <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                <?= htmlspecialchars($_capital['governance']['section_label']) ?>
            </p>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 mb-8 tracking-tight">
                <?= htmlspecialchars($_capital['governance']['title']) ?>
            </h2>
            <p class="text-lg text-platinum-200 leading-institutional mb-12">
                <?= htmlspecialchars($_capital['governance']['description']) ?>
            </p>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php foreach ($_capital['governance']['mechanisms'] as $mechanism): ?>
                <div class="border border-champagne-500/20 bg-obsidian-900/50 p-6 hover:border-champagne-500/40 transition-colors">
                    <h3 class="text-lg font-serif text-platinum-50 mb-3">
                        <?= htmlspecialchars($mechanism['mechanism']) ?>
                    </h3>
                    <p class="text-sm text-sovereign-400 leading-institutional">
                        <?= htmlspecialchars($mechanism['description']) ?>
                    </p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- GATEKEEPER CTA -->
<section class="py-24 bg-obsidian-900 border-t border-champagne-500/20 isolate">
    <div class="container-sovereign">
        <div class="max-w-4xl mx-auto text-center">
            <p class="text-base text-sovereign-400 mb-8 tracking-institutional">
                <?= htmlspecialchars($_capital['cta']['text']) ?>
            </p>
            <a href="<?php echo htmlspecialchars($_capital['cta']['button_url']); ?>"
               class="group inline-flex items-center gap-4 px-12 py-5 border border-champagne-500/60 bg-transparent text-champagne-500 text-xs font-bold uppercase tracking-[0.2em] transition-all duration-300 hover:border-champagne-400 hover:bg-champagne-500/5">
                <span><?= htmlspecialchars($_capital['cta']['button_text']) ?></span>
                <span class="opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">→</span>
            </a>
        </div>
    </div>
</section>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const C = {
        gold:    '#C9A961',
        gold2:   '#D4B876',
        gold3:   '#DFCA9B',
        gold4:   '#EAD9B8',
        slate:   '#607A92',
        dark:    '#0F1E33',
        light:   '#F5F7F9',
        gridLine:'rgba(201,169,97,0.08)'
    };

    const defaultTooltip = {
        backgroundColor: C.dark,
        titleColor: C.light,
        bodyColor: C.light,
        borderColor: C.gold,
        borderWidth: 1,
        padding: 12,
        displayColors: false
    };

    const phases = <?php
        echo json_encode(array_map(function($p) {
            return ['alloc' => $p['allocation'], 'capital' => $p['capital_requirement']];
        }, $_capital['capital_allocation']['phases']));
    ?>;

    phases.forEach(function(phase, idx) {
        const ctx = document.getElementById('allocationChart' + idx);
        if (!ctx) return;
        const alloc = phase.alloc;
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Infrastructure', 'Working Capital', 'Technology', 'Contingency'],
                datasets: [{
                    data: [alloc.infrastructure, alloc.working_capital, alloc.technology, alloc.contingency],
                    backgroundColor: [C.gold, C.gold2, C.gold3, C.slate],
                    borderWidth: 0,
                    hoverOffset: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                cutout: '65%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: C.slate,
                            padding: 16,
                            font: { size: 11 },
                            boxWidth: 12
                        }
                    },
                    tooltip: Object.assign({}, defaultTooltip, { displayColors: true,
                        callbacks: {
                            label: function(c) { return c.label + ': ' + c.parsed + '%'; }
                        }
                    })
                }
            }
        });
    });

    const returnsCtx = document.getElementById('returnsChart');
    if (returnsCtx) {
        new Chart(returnsCtx, {
            type: 'bar',
            data: {
                labels: ['Downside Case', 'Base Case', 'Upside Case'],
                datasets: [
                    {
                        label: 'IRR (%)',
                        data: [18, 28, 35],
                        backgroundColor: [C.slate, C.gold, C.gold2],
                        borderWidth: 0,
                        borderRadius: 4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Return Multiple',
                        data: [2.1, 3.2, 4.1],
                        type: 'line',
                        borderColor: C.gold3,
                        backgroundColor: 'transparent',
                        borderWidth: 2,
                        pointRadius: 6,
                        pointBackgroundColor: C.gold3,
                        pointBorderColor: C.dark,
                        pointBorderWidth: 2,
                        tension: 0.3,
                        yAxisID: 'y2'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        labels: { color: C.slate, font: { size: 11 } }
                    },
                    tooltip: Object.assign({}, defaultTooltip, { displayColors: true })
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 45,
                        grid: { color: C.gridLine },
                        ticks: {
                            color: C.slate,
                            callback: function(v) { return v + '%'; }
                        },
                        title: {
                            display: true,
                            text: 'IRR (%)',
                            color: C.slate,
                            font: { size: 11 }
                        }
                    },
                    y2: {
                        beginAtZero: true,
                        max: 5,
                        position: 'right',
                        grid: { display: false },
                        ticks: {
                            color: C.slate,
                            callback: function(v) { return v + 'x'; }
                        },
                        title: {
                            display: true,
                            text: 'Return Multiple',
                            color: C.slate,
                            font: { size: 11 }
                        }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: C.slate }
                    }
                }
            }
        });
    }
});
</script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
