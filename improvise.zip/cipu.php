<?php
/**
 * ============================================
 * CIPU - FLAGSHIP ASSET DOSSIER
 * ============================================
 */

require_once __DIR__ . '/config.php';
$_cipu = json_decode(file_get_contents(DATA_PATH . '/cipu.json'), true);
$page_title = 'CIPU - Central Integrated Poultry Unggul';
require_once INCLUDES_PATH . '/header.php';
?>

<style>
@keyframes pulse-status {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
}
.status-indicator {
    animation: pulse-status 2s ease-in-out infinite;
}
</style>

<!-- VANGUARD SECTION -->
<section class="py-32 bg-obsidian-950 border-b border-obsidian-950/10 isolate">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto">
            <div class="mb-8">
                <p class="font-mono text-xs text-champagne-600 tracking-[0.15em] uppercase">
                    <?= htmlspecialchars($_cipu['hero']['classification']) ?>
                </p>
            </div>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-tight leading-none">
                <?= htmlspecialchars($_cipu['hero']['title']) ?>
            </h1>
            <div class="flex items-center gap-3">
                <div class="w-3 h-3 bg-champagne-500 rounded-full status-indicator"></div>
                <p class="font-mono text-sm text-platinum-50 tracking-wider uppercase">
                    <?= htmlspecialchars($_cipu['hero']['status']) ?>
                </p>
            </div>
        </div>
    </div>
</section>

<!-- CONTENT SECTIONS -->
<section class="py-20 bg-obsidian-900">
    <div class="container-sovereign">
        <div class="max-w-4xl mx-auto space-y-16">
            <?php foreach ($_cipu['sections'] as $section): ?>
            <div class="border-l-2 border-champagne-500/30 pl-8">
                <h2 class="font-serif text-3xl text-platinum-50 tracking-editorial mb-6">
                    <?= htmlspecialchars($section['title']) ?>
                </h2>

                <?php if (!empty($section['subsections'])): ?>
                    <?php if (!empty($section['content'])): ?>
                        <div class="space-y-4 text-platinum-200 leading-institutional mb-6">
                            <?php foreach ($section['content'] as $para): ?>
                                <p><?= htmlspecialchars($para) ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <div class="space-y-6 text-platinum-200 leading-institutional">
                        <?php foreach ($section['subsections'] as $sub): ?>
                        <div>
                            <h3 class="text-xl text-champagne-400 mb-3 tracking-institutional"><?= htmlspecialchars($sub['subtitle']) ?></h3>
                            <p><?= htmlspecialchars($sub['text']) ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="space-y-4 text-platinum-200 leading-institutional">
                        <?php foreach ($section['content'] as $para): ?>
                            <p><?= htmlspecialchars($para) ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
