<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/systems-enhanced.json';
$data = json_decode(file_get_contents($data_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['hero']['title'] = $_POST['title'] ?? '';
    $data['hero']['tagline'] = $_POST['tagline'] ?? '';

    $data['dashboard']['enabled'] = isset($_POST['dashboard_enabled']);
    $data['dashboard']['title'] = $_POST['dashboard_title'] ?? '';
    $data['dashboard']['kpi_cards'] = [];

    if (!empty($_POST['kpi_id'])) {
        foreach ($_POST['kpi_id'] as $i => $id) {
            if (!empty($id)) {
                $data['dashboard']['kpi_cards'][] = [
                    'id' => $id,
                    'label' => $_POST['kpi_label'][$i] ?? '',
                    'value' => $_POST['kpi_value'][$i] ?? '',
                    'unit' => $_POST['kpi_unit'][$i] ?? '',
                    'trend' => $_POST['kpi_trend'][$i] ?? 'stable',
                    'trend_value' => $_POST['kpi_trend_value'][$i] ?? '0',
                    'visible' => isset($_POST['kpi_visible'][$i]),
                    'color' => $_POST['kpi_color'][$i] ?? 'neutral'
                ];
            }
        }
    }

    $data['systems'] = [];
    if (!empty($_POST['system_id'])) {
        foreach ($_POST['system_id'] as $idx => $id) {
            if (!empty($id)) {
                $system = [
                    'id' => $id,
                    'name' => $_POST['system_name'][$idx] ?? '',
                    'description' => $_POST['system_description'][$idx] ?? '',
                    'details' => $_POST['system_details'][$idx] ?? '',
                    'status' => [
                        'health' => $_POST['system_health'][$idx] ?? 'operational',
                        'health_label' => $_POST['system_health_label'][$idx] ?? 'Operational',
                        'uptime' => $_POST['system_uptime'][$idx] ?? '99.9',
                        'last_updated' => $_POST['system_last_updated'][$idx] ?? date('Y-m-d'),
                        'visible' => isset($_POST['system_status_visible'][$idx])
                    ],
                    'metrics' => [],
                    'charts' => [],
                    'widgets' => []
                ];

                $metric_prefix = "metric_{$idx}_";
                if (!empty($_POST["{$metric_prefix}id"])) {
                    foreach ($_POST["{$metric_prefix}id"] as $mi => $metric_id) {
                        if (!empty($metric_id)) {
                            $metric = [
                                'id' => $metric_id,
                                'label' => $_POST["{$metric_prefix}label"][$mi] ?? '',
                                'value' => $_POST["{$metric_prefix}value"][$mi] ?? '',
                                'unit' => $_POST["{$metric_prefix}unit"][$mi] ?? '',
                                'trend' => $_POST["{$metric_prefix}trend"][$mi] ?? 'stable',
                                'trend_value' => $_POST["{$metric_prefix}trend_value"][$mi] ?? '0',
                                'visible' => isset($_POST["{$metric_prefix}visible"][$mi]),
                                'chart_enabled' => isset($_POST["{$metric_prefix}chart_enabled"][$mi]),
                                'threshold_warning' => floatval($_POST["{$metric_prefix}threshold_warning"][$mi] ?? 0),
                                'threshold_critical' => floatval($_POST["{$metric_prefix}threshold_critical"][$mi] ?? 0)
                            ];

                            // Add history if provided
                            if (!empty($_POST["{$metric_prefix}history_labels"][$mi]) && !empty($_POST["{$metric_prefix}history_values"][$mi])) {
                                $labels = array_map('trim', explode(',', $_POST["{$metric_prefix}history_labels"][$mi]));
                                $values = array_map('floatval', array_map('trim', explode(',', $_POST["{$metric_prefix}history_values"][$mi])));
                                $metric['history'] = [
                                    'labels' => $labels,
                                    'values' => $values
                                ];
                            }

                            $system['metrics'][] = $metric;
                        }
                    }
                }

                $chart_prefix = "chart_{$idx}_";
                if (!empty($_POST["{$chart_prefix}id"])) {
                    foreach ($_POST["{$chart_prefix}id"] as $ci => $chart_id) {
                        if (!empty($chart_id)) {
                            $system['charts'][] = [
                                'id' => $chart_id,
                                'type' => $_POST["{$chart_prefix}type"][$ci] ?? 'line',
                                'title' => $_POST["{$chart_prefix}title"][$ci] ?? '',
                                'visible' => isset($_POST["{$chart_prefix}visible"][$ci]),
                                'data_source' => $_POST["{$chart_prefix}data_source"][$ci] ?? '',
                                'config' => [
                                    'color_primary' => $_POST["{$chart_prefix}color_primary"][$ci] ?? '#D4AF37',
                                    'color_secondary' => $_POST["{$chart_prefix}color_secondary"][$ci] ?? '#E5E7EB',
                                    'show_grid' => isset($_POST["{$chart_prefix}show_grid"][$ci]),
                                    'show_legend' => isset($_POST["{$chart_prefix}show_legend"][$ci]),
                                    'height' => intval($_POST["{$chart_prefix}height"][$ci] ?? 300)
                                ]
                            ];
                        }
                    }
                }

                $data['systems'][] = $system;
            }
        }
    }

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    $success = 'Content updated successfully';
}

$page_title = 'Systems Architecture (Enhanced)';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">Systems Architecture (Enhanced)</h2>
        <p class="admin-sticky-header-subtitle">Data-rich infrastructure systems with metrics & visualizations</p>
    </div>
    <div class="flex items-center space-x-3">
        <a href="../systems-enhanced.php" target="_blank" class="admin-btn-secondary">Preview Page</a>
        <button type="submit" form="systems-form" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" id="systems-form" class="space-y-8">

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Hero Section</h3>
                <p class="admin-card-subtitle">Page header content</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Page Title</label>
                    <input type="text" name="title" value="<?= htmlspecialchars($data['hero']['title']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Tagline</label>
                    <input type="text" name="tagline" value="<?= htmlspecialchars($data['hero']['tagline']) ?>" class="admin-input">
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Dashboard Overview</h3>
                <p class="admin-card-subtitle">Top-level KPI cards displayed above all systems</p>
            </div>

            <div class="admin-form-section">
                <div class="flex items-center space-x-3">
                    <input type="checkbox" name="dashboard_enabled" id="dashboard_enabled" <?= $data['dashboard']['enabled'] ? 'checked' : '' ?> class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded focus:ring-champagne-500">
                    <label for="dashboard_enabled" class="admin-label mb-0">Enable Dashboard</label>
                </div>

                <div>
                    <label class="admin-label">Dashboard Title</label>
                    <input type="text" name="dashboard_title" value="<?= htmlspecialchars($data['dashboard']['title']) ?>" class="admin-input">
                </div>
            </div>

            <div class="border-t border-champagne-500/10 pt-6 mt-6">
                <h4 class="text-sm font-semibold text-platinum-200 mb-4">KPI Cards</h4>
                <div id="kpi-container" class="space-y-6">
                    <?php foreach ($data['dashboard']['kpi_cards'] as $ki => $kpi): ?>
                    <div class="kpi-item border border-champagne-500/10 rounded-lg p-4 bg-obsidian-900/50">
                        <div class="flex items-center justify-between mb-4">
                            <span class="text-xs font-semibold text-champagne-400">KPI #<?= $ki + 1 ?></span>
                            <button type="button" onclick="this.closest('.kpi-item').remove()" class="admin-btn-danger">Remove</button>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="admin-label">ID</label>
                                <input type="text" name="kpi_id[]" value="<?= htmlspecialchars($kpi['id']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Label</label>
                                <input type="text" name="kpi_label[]" value="<?= htmlspecialchars($kpi['label']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Value</label>
                                <input type="text" name="kpi_value[]" value="<?= htmlspecialchars($kpi['value']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Unit</label>
                                <input type="text" name="kpi_unit[]" value="<?= htmlspecialchars($kpi['unit']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Trend</label>
                                <select name="kpi_trend[]" class="admin-input">
                                    <option value="up" <?= $kpi['trend'] === 'up' ? 'selected' : '' ?>>Up</option>
                                    <option value="down" <?= $kpi['trend'] === 'down' ? 'selected' : '' ?>>Down</option>
                                    <option value="stable" <?= $kpi['trend'] === 'stable' ? 'selected' : '' ?>>Stable</option>
                                </select>
                            </div>
                            <div>
                                <label class="admin-label">Trend Value</label>
                                <input type="text" name="kpi_trend_value[]" value="<?= htmlspecialchars($kpi['trend_value']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Color</label>
                                <select name="kpi_color[]" class="admin-input">
                                    <option value="success" <?= $kpi['color'] === 'success' ? 'selected' : '' ?>>Success (Green)</option>
                                    <option value="warning" <?= $kpi['color'] === 'warning' ? 'selected' : '' ?>>Warning (Amber)</option>
                                    <option value="critical" <?= $kpi['color'] === 'critical' ? 'selected' : '' ?>>Critical (Red)</option>
                                    <option value="neutral" <?= $kpi['color'] === 'neutral' ? 'selected' : '' ?>>Neutral (Gray)</option>
                                </select>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" name="kpi_visible[<?= $ki ?>]" <?= $kpi['visible'] ? 'checked' : '' ?> class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded">
                                <label class="ml-2 text-sm text-platinum-300">Visible</label>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <button type="button" onclick="addKPI()" class="admin-btn-add mt-4">
                    + Add KPI Card
                </button>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Systems</h3>
                <p class="admin-card-subtitle">Infrastructure systems with metrics, charts, and widgets</p>
            </div>

            <div id="systems-container" class="space-y-8">
                <?php foreach ($data['systems'] as $idx => $sys): ?>
                <div class="system-item border-t-2 border-champagne-500/20 pt-8">
                    <div class="flex items-center justify-between mb-6">
                        <h4 class="text-lg font-semibold text-platinum-100">System #<?= $idx + 1 ?>: <?= htmlspecialchars($sys['name']) ?></h4>
                        <button type="button" onclick="this.closest('.system-item').remove()" class="admin-btn-danger">Remove System</button>
                    </div>

                    <div class="bg-obsidian-900/50 border border-champagne-500/10 rounded-lg p-6 mb-6">
                        <h5 class="text-sm font-semibold text-champagne-400 mb-4">Basic Information</h5>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label class="admin-label">System ID</label>
                                <input type="text" name="system_id[]" value="<?= htmlspecialchars($sys['id']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">System Name</label>
                                <input type="text" name="system_name[]" value="<?= htmlspecialchars($sys['name']) ?>" class="admin-input">
                            </div>
                        </div>
                        <div class="space-y-4">
                            <div>
                                <label class="admin-label">Description</label>
                                <textarea name="system_description[]" rows="2" class="admin-textarea"><?= htmlspecialchars($sys['description']) ?></textarea>
                            </div>
                            <div>
                                <label class="admin-label">Details</label>
                                <textarea name="system_details[]" rows="2" class="admin-textarea"><?= htmlspecialchars($sys['details']) ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="bg-obsidian-900/50 border border-champagne-500/10 rounded-lg p-6 mb-6">
                        <h5 class="text-sm font-semibold text-champagne-400 mb-4">System Status</h5>
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div>
                                <label class="admin-label">Health Status</label>
                                <select name="system_health[]" class="admin-input">
                                    <option value="operational" <?= $sys['status']['health'] === 'operational' ? 'selected' : '' ?>>Operational</option>
                                    <option value="degraded" <?= $sys['status']['health'] === 'degraded' ? 'selected' : '' ?>>Degraded</option>
                                    <option value="maintenance" <?= $sys['status']['health'] === 'maintenance' ? 'selected' : '' ?>>Maintenance</option>
                                    <option value="offline" <?= $sys['status']['health'] === 'offline' ? 'selected' : '' ?>>Offline</option>
                                </select>
                            </div>
                            <div>
                                <label class="admin-label">Health Label</label>
                                <input type="text" name="system_health_label[]" value="<?= htmlspecialchars($sys['status']['health_label']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Uptime (%)</label>
                                <input type="text" name="system_uptime[]" value="<?= htmlspecialchars($sys['status']['uptime']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Last Updated</label>
                                <input type="date" name="system_last_updated[]" value="<?= htmlspecialchars($sys['status']['last_updated']) ?>" class="admin-input">
                            </div>
                        </div>
                        <div class="mt-4 flex items-center">
                            <input type="checkbox" name="system_status_visible[<?= $idx ?>]" <?= $sys['status']['visible'] ? 'checked' : '' ?> class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded">
                            <label class="ml-2 text-sm text-platinum-300">Show Status Card</label>
                        </div>
                    </div>
                    <div class="bg-obsidian-900/50 border border-champagne-500/10 rounded-lg p-6 mb-6">
                        <h5 class="text-sm font-semibold text-champagne-400 mb-4">System Metrics</h5>
                        <div id="metrics-container-<?= $idx ?>" class="space-y-4">
                            <?php foreach ($sys['metrics'] as $mi => $metric): ?>
                            <div class="metric-item border border-champagne-500/10 rounded p-4 bg-obsidian-950/50">
                                <div class="flex items-center justify-between mb-3">
                                    <span class="text-xs font-semibold text-champagne-400">Metric #<?= $mi + 1 ?></span>
                                    <button type="button" onclick="this.closest('.metric-item').remove()" class="text-xs text-red-400 hover:text-red-300">Remove</button>
                                </div>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    <div><label class="admin-label">Metric ID</label><input type="text" name="metric_<?= $idx ?>_id[]" value="<?= htmlspecialchars($metric['id']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Label</label><input type="text" name="metric_<?= $idx ?>_label[]" value="<?= htmlspecialchars($metric['label']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Value</label><input type="text" name="metric_<?= $idx ?>_value[]" value="<?= htmlspecialchars($metric['value']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Unit</label><input type="text" name="metric_<?= $idx ?>_unit[]" value="<?= htmlspecialchars($metric['unit']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Trend</label><select name="metric_<?= $idx ?>_trend[]" class="admin-input"><option value="up" <?= $metric['trend'] === 'up' ? 'selected' : '' ?>>Up</option><option value="down" <?= $metric['trend'] === 'down' ? 'selected' : '' ?>>Down</option><option value="stable" <?= $metric['trend'] === 'stable' ? 'selected' : '' ?>>Stable</option></select></div>
                                    <div><label class="admin-label">Trend Value</label><input type="text" name="metric_<?= $idx ?>_trend_value[]" value="<?= htmlspecialchars($metric['trend_value']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Warning Threshold</label><input type="number" step="0.1" name="metric_<?= $idx ?>_threshold_warning[]" value="<?= htmlspecialchars($metric['threshold_warning']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Critical Threshold</label><input type="number" step="0.1" name="metric_<?= $idx ?>_threshold_critical[]" value="<?= htmlspecialchars($metric['threshold_critical']) ?>" class="admin-input"></div>
                                    <div class="md:col-span-3">
                                        <label class="admin-label">History Labels (comma-separated)</label>
                                        <input type="text" name="metric_<?= $idx ?>_history_labels[]" value="<?= isset($metric['history']) ? htmlspecialchars(implode(', ', $metric['history']['labels'])) : 'Jan, Feb, Mar, Apr, May, Jun' ?>" class="admin-input" placeholder="Jan, Feb, Mar, Apr, May, Jun">
                                    </div>
                                    <div class="md:col-span-3">
                                        <label class="admin-label">History Values (comma-separated)</label>
                                        <input type="text" name="metric_<?= $idx ?>_history_values[]" value="<?= isset($metric['history']) ? htmlspecialchars(implode(', ', $metric['history']['values'])) : '' ?>" class="admin-input" placeholder="82, 84, 85, 86, 87, 87.5">
                                    </div>
                                    <div class="flex items-center space-x-4">
                                        <div class="flex items-center"><input type="checkbox" name="metric_<?= $idx ?>_visible[<?= $mi ?>]" <?= $metric['visible'] ? 'checked' : '' ?> class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Visible</label></div>
                                        <div class="flex items-center"><input type="checkbox" name="metric_<?= $idx ?>_chart_enabled[<?= $mi ?>]" <?= $metric['chart_enabled'] ? 'checked' : '' ?> class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Chart</label></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" onclick="addMetric(<?= $idx ?>)" class="text-xs text-champagne-400 hover:text-champagne-300 mt-3">+ Add Metric</button>
                    </div>

                    <div class="bg-obsidian-900/50 border border-champagne-500/10 rounded-lg p-6 mb-6">
                        <h5 class="text-sm font-semibold text-champagne-400 mb-4">Visualization Charts</h5>
                        <div id="charts-container-<?= $idx ?>" class="space-y-4">
                            <?php foreach ($sys['charts'] as $ci => $chart): ?>
                            <div class="chart-item border border-champagne-500/10 rounded p-4 bg-obsidian-950/50">
                                <div class="flex items-center justify-between mb-3">
                                    <span class="text-xs font-semibold text-champagne-400">Chart #<?= $ci + 1 ?></span>
                                    <button type="button" onclick="this.closest('.chart-item').remove()" class="text-xs text-red-400 hover:text-red-300">Remove</button>
                                </div>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    <div><label class="admin-label">Chart ID</label><input type="text" name="chart_<?= $idx ?>_id[]" value="<?= htmlspecialchars($chart['id']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Chart Type</label><select name="chart_<?= $idx ?>_type[]" class="admin-input"><option value="line" <?= $chart['type'] === 'line' ? 'selected' : '' ?>>Line Chart</option><option value="bar" <?= $chart['type'] === 'bar' ? 'selected' : '' ?>>Bar Chart</option><option value="radial" <?= $chart['type'] === 'radial' ? 'selected' : '' ?>>Radial Progress</option><option value="gauge" <?= $chart['type'] === 'gauge' ? 'selected' : '' ?>>Gauge</option><option value="area" <?= $chart['type'] === 'area' ? 'selected' : '' ?>>Area Chart</option></select></div>
                                    <div><label class="admin-label">Chart Title</label><input type="text" name="chart_<?= $idx ?>_title[]" value="<?= htmlspecialchars($chart['title']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Data Source (Metric ID)</label><input type="text" name="chart_<?= $idx ?>_data_source[]" value="<?= htmlspecialchars($chart['data_source']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Primary Color</label><input type="color" name="chart_<?= $idx ?>_color_primary[]" value="<?= htmlspecialchars($chart['config']['color_primary']) ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Secondary Color</label><input type="color" name="chart_<?= $idx ?>_color_secondary[]" value="<?= htmlspecialchars($chart['config']['color_secondary'] ?? '#E5E7EB') ?>" class="admin-input"></div>
                                    <div><label class="admin-label">Height (px)</label><input type="number" name="chart_<?= $idx ?>_height[]" value="<?= htmlspecialchars($chart['config']['height']) ?>" class="admin-input"></div>
                                    <div class="flex items-center space-x-4">
                                        <div class="flex items-center"><input type="checkbox" name="chart_<?= $idx ?>_visible[<?= $ci ?>]" <?= $chart['visible'] ? 'checked' : '' ?> class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Visible</label></div>
                                        <div class="flex items-center"><input type="checkbox" name="chart_<?= $idx ?>_show_grid[<?= $ci ?>]" <?= ($chart['config']['show_grid'] ?? false) ? 'checked' : '' ?> class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Grid</label></div>
                                        <div class="flex items-center"><input type="checkbox" name="chart_<?= $idx ?>_show_legend[<?= $ci ?>]" <?= ($chart['config']['show_legend'] ?? false) ? 'checked' : '' ?> class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Legend</label></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" onclick="addChart(<?= $idx ?>)" class="text-xs text-champagne-400 hover:text-champagne-300 mt-3">+ Add Chart</button>
                    </div>

                </div>
                <?php endforeach; ?>
            </div>

            <button type="button" onclick="addSystem()" class="admin-btn-add mt-6">+ Add System</button>
        </div>

    </form>

    <div class="h-24"></div>
</div>

<script>
let systemCount = <?= count($data['systems']) ?>;

function addKPI() {
    const container = document.getElementById('kpi-container');
    const count = container.querySelectorAll('.kpi-item').length + 1;
    const html = `
        <div class="kpi-item border border-champagne-500/10 rounded-lg p-4 bg-obsidian-900/50">
            <div class="flex items-center justify-between mb-4">
                <span class="text-xs font-semibold text-champagne-400">KPI #${count}</span>
                <button type="button" onclick="this.closest('.kpi-item').remove()" class="admin-btn-danger">Remove</button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div><label class="admin-label">ID</label><input type="text" name="kpi_id[]" class="admin-input"></div>
                <div><label class="admin-label">Label</label><input type="text" name="kpi_label[]" class="admin-input"></div>
                <div><label class="admin-label">Value</label><input type="text" name="kpi_value[]" class="admin-input"></div>
                <div><label class="admin-label">Unit</label><input type="text" name="kpi_unit[]" class="admin-input"></div>
                <div><label class="admin-label">Trend</label><select name="kpi_trend[]" class="admin-input"><option value="up">Up</option><option value="down">Down</option><option value="stable" selected>Stable</option></select></div>
                <div><label class="admin-label">Trend Value</label><input type="text" name="kpi_trend_value[]" value="0" class="admin-input"></div>
                <div><label class="admin-label">Color</label><select name="kpi_color[]" class="admin-input"><option value="success">Success</option><option value="warning">Warning</option><option value="critical">Critical</option><option value="neutral" selected>Neutral</option></select></div>
                <div class="flex items-center"><input type="checkbox" name="kpi_visible[${count-1}]" checked class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-sm text-platinum-300">Visible</label></div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addSystem() {
    const container = document.getElementById('systems-container');
    const idx = systemCount++;
    const html = `
        <div class="system-item border-t-2 border-champagne-500/20 pt-8">
            <div class="flex items-center justify-between mb-6">
                <h4 class="text-lg font-semibold text-platinum-100">System #${idx + 1}</h4>
                <button type="button" onclick="this.closest('.system-item').remove()" class="admin-btn-danger">Remove System</button>
            </div>
            <div class="bg-obsidian-900/50 border border-champagne-500/10 rounded-lg p-6 mb-6">
                <h5 class="text-sm font-semibold text-champagne-400 mb-4">Basic Information</h5>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div><label class="admin-label">System ID</label><input type="text" name="system_id[]" class="admin-input"></div>
                    <div><label class="admin-label">System Name</label><input type="text" name="system_name[]" class="admin-input"></div>
                </div>
                <div class="space-y-4">
                    <div><label class="admin-label">Description</label><textarea name="system_description[]" rows="2" class="admin-textarea"></textarea></div>
                    <div><label class="admin-label">Details</label><textarea name="system_details[]" rows="2" class="admin-textarea"></textarea></div>
                </div>
            </div>
            <div class="bg-obsidian-900/50 border border-champagne-500/10 rounded-lg p-6 mb-6">
                <h5 class="text-sm font-semibold text-champagne-400 mb-4">System Status</h5>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div><label class="admin-label">Health Status</label><select name="system_health[]" class="admin-input"><option value="operational" selected>Operational</option><option value="degraded">Degraded</option><option value="maintenance">Maintenance</option><option value="offline">Offline</option></select></div>
                    <div><label class="admin-label">Health Label</label><input type="text" name="system_health_label[]" value="Operational" class="admin-input"></div>
                    <div><label class="admin-label">Uptime (%)</label><input type="text" name="system_uptime[]" value="99.9" class="admin-input"></div>
                    <div><label class="admin-label">Last Updated</label><input type="date" name="system_last_updated[]" value="<?= date('Y-m-d') ?>" class="admin-input"></div>
                </div>
                <div class="mt-4 flex items-center"><input type="checkbox" name="system_status_visible[${idx}]" checked class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-sm text-platinum-300">Show Status Card</label></div>
            </div>
            <div class="bg-obsidian-900/50 border border-champagne-500/10 rounded-lg p-6 mb-6">
                <h5 class="text-sm font-semibold text-champagne-400 mb-4">System Metrics</h5>
                <div id="metrics-container-${idx}" class="space-y-4"></div>
                <button type="button" onclick="addMetric(${idx})" class="text-xs text-champagne-400 hover:text-champagne-300 mt-3">+ Add Metric</button>
            </div>
            <div class="bg-obsidian-900/50 border border-champagne-500/10 rounded-lg p-6 mb-6">
                <h5 class="text-sm font-semibold text-champagne-400 mb-4">Visualization Charts</h5>
                <div id="charts-container-${idx}" class="space-y-4"></div>
                <button type="button" onclick="addChart(${idx})" class="text-xs text-champagne-400 hover:text-champagne-300 mt-3">+ Add Chart</button>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addMetric(sysIdx) {
    const container = document.getElementById(`metrics-container-${sysIdx}`);
    const count = container.querySelectorAll('.metric-item').length;
    const html = `
        <div class="metric-item border border-champagne-500/10 rounded p-4 bg-obsidian-950/50">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold text-champagne-400">Metric #${count + 1}</span>
                <button type="button" onclick="this.closest('.metric-item').remove()" class="text-xs text-red-400 hover:text-red-300">Remove</button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div><label class="admin-label">Metric ID</label><input type="text" name="metric_${sysIdx}_id[]" class="admin-input"></div>
                <div><label class="admin-label">Label</label><input type="text" name="metric_${sysIdx}_label[]" class="admin-input"></div>
                <div><label class="admin-label">Value</label><input type="text" name="metric_${sysIdx}_value[]" class="admin-input"></div>
                <div><label class="admin-label">Unit</label><input type="text" name="metric_${sysIdx}_unit[]" class="admin-input"></div>
                <div><label class="admin-label">Trend</label><select name="metric_${sysIdx}_trend[]" class="admin-input"><option value="up">Up</option><option value="down">Down</option><option value="stable" selected>Stable</option></select></div>
                <div><label class="admin-label">Trend Value</label><input type="text" name="metric_${sysIdx}_trend_value[]" value="0" class="admin-input"></div>
                <div><label class="admin-label">Warning Threshold</label><input type="number" step="0.1" name="metric_${sysIdx}_threshold_warning[]" value="0" class="admin-input"></div>
                <div><label class="admin-label">Critical Threshold</label><input type="number" step="0.1" name="metric_${sysIdx}_threshold_critical[]" value="0" class="admin-input"></div>
                <div class="md:col-span-3"><label class="admin-label">History Labels (comma-separated)</label><input type="text" name="metric_${sysIdx}_history_labels[]" value="Jan, Feb, Mar, Apr, May, Jun" class="admin-input" placeholder="Jan, Feb, Mar, Apr, May, Jun"></div>
                <div class="md:col-span-3"><label class="admin-label">History Values (comma-separated)</label><input type="text" name="metric_${sysIdx}_history_values[]" class="admin-input" placeholder="82, 84, 85, 86, 87, 87.5"></div>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center"><input type="checkbox" name="metric_${sysIdx}_visible[${count}]" checked class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Visible</label></div>
                    <div class="flex items-center"><input type="checkbox" name="metric_${sysIdx}_chart_enabled[${count}]" class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Chart</label></div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addChart(sysIdx) {
    const container = document.getElementById(`charts-container-${sysIdx}`);
    const count = container.querySelectorAll('.chart-item').length;
    const html = `
        <div class="chart-item border border-champagne-500/10 rounded p-4 bg-obsidian-950/50">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold text-champagne-400">Chart #${count + 1}</span>
                <button type="button" onclick="this.closest('.chart-item').remove()" class="text-xs text-red-400 hover:text-red-300">Remove</button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div><label class="admin-label">Chart ID</label><input type="text" name="chart_${sysIdx}_id[]" class="admin-input"></div>
                <div><label class="admin-label">Chart Type</label><select name="chart_${sysIdx}_type[]" class="admin-input"><option value="line" selected>Line Chart</option><option value="bar">Bar Chart</option><option value="radial">Radial Progress</option><option value="gauge">Gauge</option><option value="area">Area Chart</option></select></div>
                <div><label class="admin-label">Chart Title</label><input type="text" name="chart_${sysIdx}_title[]" class="admin-input"></div>
                <div><label class="admin-label">Data Source (Metric ID)</label><input type="text" name="chart_${sysIdx}_data_source[]" class="admin-input"></div>
                <div><label class="admin-label">Primary Color</label><input type="color" name="chart_${sysIdx}_color_primary[]" value="#D4AF37" class="admin-input"></div>
                <div><label class="admin-label">Secondary Color</label><input type="color" name="chart_${sysIdx}_color_secondary[]" value="#E5E7EB" class="admin-input"></div>
                <div><label class="admin-label">Height (px)</label><input type="number" name="chart_${sysIdx}_height[]" value="300" class="admin-input"></div>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center"><input type="checkbox" name="chart_${sysIdx}_visible[${count}]" checked class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Visible</label></div>
                    <div class="flex items-center"><input type="checkbox" name="chart_${sysIdx}_show_grid[${count}]" checked class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Grid</label></div>
                    <div class="flex items-center"><input type="checkbox" name="chart_${sysIdx}_show_legend[${count}]" checked class="w-4 h-4 text-champagne-500 bg-obsidian-950 border-champagne-500/30 rounded"><label class="ml-2 text-xs text-platinum-300">Legend</label></div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}
</script>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
