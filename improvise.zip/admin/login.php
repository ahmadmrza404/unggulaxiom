<?php
// Security headers
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

// Secure session configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']) ? 1 : 0);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.use_strict_mode', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_lifetime', 0);

session_start();

// Session timeout (30 minutes)
$session_timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    session_unset();
    session_destroy();
    session_start();
    $error = 'Session expired. Please login again.';
}
$_SESSION['last_activity'] = time();

// IP validation
if (isset($_SESSION['user_ip']) && $_SESSION['user_ip'] !== ($_SERVER['REMOTE_ADDR'] ?? 'unknown')) {
    session_unset();
    session_destroy();
    session_start();
    $error = 'Session hijacking detected.';
}

// Rate limiting with exponential backoff
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['last_attempt_time'] = time();
    $_SESSION['lockout_duration'] = 900;
}

if (time() - $_SESSION['last_attempt_time'] > $_SESSION['lockout_duration']) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['lockout_duration'] = 900;
}

// Progressive lockout: 3 attempts = 15min, 6 = 30min, 9 = 1hr, 12+ = 24hr
if ($_SESSION['login_attempts'] >= 3) {
    $lockout_map = [3 => 900, 6 => 1800, 9 => 3600, 12 => 86400];
    foreach ($lockout_map as $attempts => $duration) {
        if ($_SESSION['login_attempts'] >= $attempts) {
            $_SESSION['lockout_duration'] = $duration;
        }
    }

    $wait_time = $_SESSION['lockout_duration'] - (time() - $_SESSION['last_attempt_time']);
    if ($wait_time > 0) {
        $hours = floor($wait_time / 3600);
        $minutes = ceil(($wait_time % 3600) / 60);
        $time_msg = $hours > 0 ? "$hours hour(s)" : "$minutes minute(s)";
        $error = "Account locked. Try again in $time_msg.";
        $_SESSION['blocked'] = true;
    } else {
        $_SESSION['login_attempts'] = 0;
        $_SESSION['blocked'] = false;
        $_SESSION['lockout_duration'] = 900;
    }
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/includes/users.php';

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: index.php');
    exit;
}

$error = $error ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Honeypot field
    if (!empty($_POST['website'])) {
        sleep(3);
        $error = 'Invalid request';
        $_SESSION['login_attempts'] += 5;
        $_SESSION['last_attempt_time'] = time();
    } elseif (isset($_SESSION['blocked']) && $_SESSION['blocked']) {
        $error = "Account locked. Please wait.";
    } else {
        // CSRF protection
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $error = 'Invalid request. Please refresh and try again.';
            $_SESSION['login_attempts']++;
            $_SESSION['last_attempt_time'] = time();
        } else {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';

            // Input sanitization
            $username = htmlspecialchars(trim($username), ENT_QUOTES, 'UTF-8');

            if (strlen($username) > 50 || strlen($password) > 100) {
                $error = 'Invalid input length';
                $_SESSION['login_attempts']++;
                $_SESSION['last_attempt_time'] = time();
            } elseif (empty($username) || empty($password)) {
                $error = 'All fields required';
                $_SESSION['login_attempts']++;
                $_SESSION['last_attempt_time'] = time();
            } else {
                // Validate credentials using multi-user system
                if (validate_admin_credentials($username, $password)) {
                    session_regenerate_id(true);

                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_username'] = $username;
                    $_SESSION['login_time'] = time();
                    $_SESSION['login_attempts'] = 0;
                    $_SESSION['user_ip'] = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                    $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
                    $_SESSION['lockout_duration'] = 900;

                    error_log(sprintf(
                        "[LOGIN SUCCESS] User: %s | IP: %s | Time: %s",
                        $username,
                        $_SESSION['user_ip'],
                        date('Y-m-d H:i:s')
                    ));

                    header('Location: index.php');
                    exit;
                } else {
                    $_SESSION['login_attempts']++;
                    $_SESSION['last_attempt_time'] = time();

                    error_log(sprintf(
                        "[LOGIN FAILED] User: %s | IP: %s | Attempts: %d | Time: %s",
                        $username,
                        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                        $_SESSION['login_attempts'],
                        date('Y-m-d H:i:s')
                    ));

                    $error = 'Invalid credentials';

                    $delay = min(2 + $_SESSION['login_attempts'], 10);
                    sleep($delay);
                }
            }
        }
    }
}

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:;">
    <title>Admin Login - Unggul Axiom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    </style>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        obsidian: { 800: '#1a1a1a', 900: '#141414', 950: '#0a0a0a' },
                        champagne: { 400: '#d4af37', 500: '#c5a028', 600: '#b69121' },
                        platinum: { 50: '#f5f5f5', 100: '#e8e8e8', 200: '#d1d1d1', 300: '#b0b0b0' }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-obsidian-950 min-h-screen flex items-center justify-center">
    <div class="absolute inset-0 bg-gradient-to-br from-champagne-500/5 via-transparent to-transparent"></div>

    <div class="w-full max-w-md px-6 relative z-10">
        <div class="bg-obsidian-900 backdrop-blur-sm border border-champagne-500/20 rounded-2xl p-10 shadow-2xl">
            <div class="text-center mb-10">
                <div class="inline-block mb-6">
                    <div class="w-16 h-16 mx-auto bg-champagne-500/10 border border-champagne-500/30 rounded-xl flex items-center justify-center">
                        <svg class="w-8 h-8 text-champagne-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                        </svg>
                    </div>
                </div>
                <h1 class="text-3xl font-bold text-platinum-100 mb-2">Admin Access</h1>
                <p class="text-sm text-platinum-400">Content Management System</p>
            </div>

            <?php if ($error): ?>
            <div class="bg-red-900/20 border border-red-500/50 text-red-200 px-4 py-3 rounded-lg mb-6 text-sm flex items-center gap-3">
                <svg class="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                </svg>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
            <?php endif; ?>

            <form method="POST" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <input type="text" name="website" style="display:none" tabindex="-1" autocomplete="off">

                <div class="mb-6">
                    <label class="block text-sm text-platinum-300 mb-2 font-medium">Username</label>
                    <input type="text" name="username" required autofocus maxlength="50" autocomplete="username"
                           pattern="[a-zA-Z0-9_-]+" title="Alphanumeric characters, underscore, and hyphen only"
                           class="w-full bg-obsidian-800 border border-champagne-500/30 text-platinum-100 px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-champagne-500/50 focus:border-champagne-500 transition-all">
                </div>

                <div class="mb-8">
                    <label class="block text-sm text-platinum-300 mb-2 font-medium">Password</label>
                    <input type="password" name="password" required maxlength="100" autocomplete="current-password"
                           class="w-full bg-obsidian-800 border border-champagne-500/30 text-platinum-100 px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-champagne-500/50 focus:border-champagne-500 transition-all">
                </div>

                <button type="submit" <?= isset($_SESSION['blocked']) && $_SESSION['blocked'] ? 'disabled' : '' ?>
                        class="w-full bg-champagne-400 hover:bg-champagne-500 text-obsidian-950 font-semibold py-3 rounded-lg transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none">
                    Sign In
                </button>
            </form>

            <div class="mt-8 pt-6 border-t border-champagne-500/10 text-center">
                <a href="../index.php" class="text-sm text-champagne-400 hover:text-champagne-300 inline-flex items-center gap-2 transition-colors">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Return to Site
                </a>
            </div>
        </div>
    </div>
</body>
</html>
