<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$leadership_file = __DIR__ . '/../data/leadership.json';
$leadership_data = json_decode(file_get_contents($leadership_file), true);

$all_groups = ['board_of_directors', 'executives', 'senior_management', 'department_heads',
               'operations', 'finance', 'legal_compliance', 'human_resources',
               'technology', 'marketing_communications', 'business_development', 'advisors'];

$stats = ['executives' => 0, 'management' => 0, 'advisors' => 0, 'total' => 0];

foreach ($all_groups as $group) {
    $count = count($leadership_data[$group] ?? []);
    $stats['total'] += $count;
    if (in_array($group, ['board_of_directors', 'executives'])) {
        $stats['executives'] += $count;
    } elseif (in_array($group, ['senior_management', 'department_heads', 'operations', 'finance',
                                 'legal_compliance', 'human_resources', 'technology',
                                 'marketing_communications', 'business_development'])) {
        $stats['management'] += $count;
    } elseif ($group === 'advisors') {
        $stats['advisors'] += $count;
    }
}

$profiles_dir = __DIR__ . '/../data/profiles/';
$profile_count = 0;
if (is_dir($profiles_dir)) {
    $profile_count = count(glob($profiles_dir . '*.json'));
}

$page_title = 'Dashboard';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="bg-obsidian-900 border-b border-champagne-500/20 px-8 py-8">
    <div class="max-w-7xl mx-auto">
        <h2 class="text-3xl font-semibold text-platinum-100 mb-2">Dashboard</h2>
        <p class="text-platinum-400">Content management overview</p>
    </div>
</div>

<div class="max-w-7xl mx-auto px-8 py-12">

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
        <div class="bg-obsidian-900 border border-champagne-500/20 rounded-xl p-6">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm text-platinum-300 font-medium">Total Members</span>
                <svg class="w-5 h-5 text-champagne-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
            </div>
            <p class="text-4xl font-semibold text-platinum-100"><?= $stats['total'] ?></p>
        </div>

        <div class="bg-obsidian-900 border border-champagne-500/20 rounded-xl p-6">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm text-platinum-300 font-medium">Executives</span>
                <svg class="w-5 h-5 text-champagne-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/>
                </svg>
            </div>
            <p class="text-4xl font-semibold text-platinum-100"><?= $stats['executives'] ?></p>
        </div>

        <div class="bg-obsidian-900 border border-champagne-500/20 rounded-xl p-6">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm text-platinum-300 font-medium">Management</span>
                <svg class="w-5 h-5 text-champagne-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                </svg>
            </div>
            <p class="text-4xl font-semibold text-platinum-100"><?= $stats['management'] ?></p>
        </div>

        <div class="bg-obsidian-900 border border-champagne-500/20 rounded-xl p-6">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm text-platinum-300 font-medium">Profiles</span>
                <svg class="w-5 h-5 text-champagne-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
            </div>
            <p class="text-4xl font-semibold text-platinum-100"><?= $profile_count ?></p>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php
        $pages = [
            ['url' => 'homepage.php', 'title' => 'Homepage', 'desc' => 'Edit homepage sections', 'icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'],
            ['url' => 'capital.php', 'title' => 'Capital', 'desc' => 'Institutional capital architecture', 'icon' => 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z'],
            ['url' => 'systems.php', 'title' => 'Systems', 'desc' => 'Infrastructure systems', 'icon' => 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z'],
            ['url' => 'cipu.php', 'title' => 'CIPU', 'desc' => 'Flagship asset dossier', 'icon' => 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4'],
            ['url' => 'ecosystem.php', 'title' => 'Ecosystem', 'desc' => 'Platform overview', 'icon' => 'M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z'],
            ['url' => 'ecosystem-entities.php', 'title' => 'Entities', 'desc' => 'Vertical entity pages', 'icon' => 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10'],
            ['url' => 'leadership.php', 'title' => 'Leadership', 'desc' => 'Team member management', 'icon' => 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'],
            ['url' => 'governance.php', 'title' => 'Governance', 'desc' => 'Governance content', 'icon' => 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z'],
            ['url' => 'careers.php', 'title' => 'Careers', 'desc' => 'Careers page content', 'icon' => 'M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'],
        ];

        foreach ($pages as $page):
        ?>
        <a href="<?= $page['url'] ?>" class="group bg-obsidian-900 border border-champagne-500/20 rounded-xl p-8 hover:border-champagne-500/50 hover:bg-obsidian-900/80 transition-all">
            <div class="flex items-start gap-4">
                <div class="w-12 h-12 bg-champagne-500/10 border border-champagne-500/30 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:bg-champagne-500/20 transition-colors">
                    <svg class="w-6 h-6 text-champagne-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?= $page['icon'] ?>"/>
                    </svg>
                </div>
                <div class="flex-1">
                    <h3 class="text-lg font-semibold text-platinum-100 mb-2 group-hover:text-champagne-400 transition-colors"><?= $page['title'] ?></h3>
                    <p class="text-sm text-platinum-400 leading-relaxed"><?= $page['desc'] ?></p>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
