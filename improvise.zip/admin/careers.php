<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/careers.json';
$data = json_decode(file_get_contents($data_file), true);
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['careers']['title'] = $_POST['title'] ?? '';
    $data['careers']['location'] = $_POST['location'] ?? '';
    $data['careers']['headline'] = $_POST['headline'] ?? '';
    $data['careers']['mission'] = $_POST['mission'] ?? '';

    $data['careers']['core_values'] = [];
    if (!empty($_POST['value_name'])) {
        foreach ($_POST['value_name'] as $i => $name) {
            if (!empty($name)) {
                $data['careers']['core_values'][] = [
                    'name' => $name,
                    'description' => $_POST['value_description'][$i] ?? ''
                ];
            }
        }
    }

    $opportunities = array_filter(array_map('trim', explode("\n", $_POST['opportunities'] ?? '')));
    $data['careers']['opportunities'] = $opportunities;

    $data['careers']['benefits'] = [];
    if (!empty($_POST['benefit_category'])) {
        foreach ($_POST['benefit_category'] as $i => $category) {
            if (!empty($category)) {
                $data['careers']['benefits'][] = [
                    'category' => $category,
                    'description' => $_POST['benefit_description'][$i] ?? ''
                ];
            }
        }
    }

    $data['careers']['application_form'] = [
        'section_title' => $_POST['form_title'] ?? '',
        'section_description' => $_POST['form_description'] ?? '',
        'availability_options' => array_filter(array_map('trim', explode("\n", $_POST['availability_options'] ?? ''))),
        'experience_options' => array_filter(array_map('trim', explode("\n", $_POST['experience_options'] ?? ''))),
        'education_options' => array_filter(array_map('trim', explode("\n", $_POST['education_options'] ?? '')))
    ];

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Content updated successfully';
}

$current_data = $data['careers'] ?? [];
$page_title = 'Careers';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">Careers Page</h2>
        <p class="admin-sticky-header-subtitle">Job opportunities and company culture</p>
    </div>
    <div class="flex items-center space-x-3">
        <a href="../careers.php" target="_blank" class="admin-btn-secondary">Preview Page</a>
        <button type="submit" form="careers-form" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" id="careers-form" class="space-y-8">

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Page Header</h3>
                <p class="admin-card-subtitle">Main career page information</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Location</label>
                    <input type="text" name="location" value="<?= htmlspecialchars($current_data['location']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Headline</label>
                    <input type="text" name="headline" value="<?= htmlspecialchars($current_data['headline']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Mission Statement</label>
                    <textarea name="mission" rows="3" class="admin-textarea"><?= htmlspecialchars($current_data['mission']) ?></textarea>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Core Values</h3>
                <p class="admin-card-subtitle">Company values and principles</p>
            </div>
            <div id="values-container" class="space-y-4">
                <?php foreach ($current_data['core_values'] as $idx => $value): ?>
                <div class="value-item border-t border-champagne-500/10 pt-4">
                    <div class="flex items-center justify-between mb-4">
                        <h4 class="text-sm font-semibold text-platinum-200">Value #<?= $idx + 1 ?></h4>
                        <button type="button" onclick="this.closest('.value-item').remove()" class="admin-btn-danger">Remove</button>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="admin-label">Value Name</label>
                            <input type="text" name="value_name[]" value="<?= htmlspecialchars($value['name']) ?>" class="admin-input">
                        </div>
                        <div>
                            <label class="admin-label">Description</label>
                            <input type="text" name="value_description[]" value="<?= htmlspecialchars($value['description']) ?>" class="admin-input">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" onclick="addValue()" class="admin-btn-add mt-6">+ Add Value</button>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Career Opportunities</h3>
                <p class="admin-card-subtitle">Available positions <span class="admin-label-hint">(one per line)</span></p>
            </div>
            <textarea name="opportunities" rows="8" placeholder="One position per line" class="admin-textarea"><?= htmlspecialchars(implode("\n", $current_data['opportunities'])) ?></textarea>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Benefits</h3>
                <p class="admin-card-subtitle">Employee benefits and perks</p>
            </div>
            <div id="benefits-container" class="space-y-4">
                <?php foreach ($current_data['benefits'] as $idx => $benefit): ?>
                <div class="benefit-item border-t border-champagne-500/10 pt-4">
                    <div class="flex items-center justify-between mb-4">
                        <h4 class="text-sm font-semibold text-platinum-200">Benefit #<?= $idx + 1 ?></h4>
                        <button type="button" onclick="this.closest('.benefit-item').remove()" class="admin-btn-danger">Remove</button>
                    </div>
                    <div class="space-y-4">
                        <div>
                            <label class="admin-label">Category</label>
                            <input type="text" name="benefit_category[]" value="<?= htmlspecialchars($benefit['category']) ?>" class="admin-input">
                        </div>
                        <div>
                            <label class="admin-label">Description</label>
                            <textarea name="benefit_description[]" rows="2" class="admin-textarea"><?= htmlspecialchars($benefit['description']) ?></textarea>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" onclick="addBenefit()" class="admin-btn-add mt-6">+ Add Benefit</button>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Application Form Section</h3>
                <p class="admin-card-subtitle">Customize the application form header</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Title</label>
                    <input type="text" name="form_title" value="<?= htmlspecialchars($current_data['application_form']['section_title'] ?? 'JOIN OUR TEAM') ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Section Description</label>
                    <textarea name="form_description" rows="2" class="admin-textarea"><?= htmlspecialchars($current_data['application_form']['section_description'] ?? '') ?></textarea>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Form Dropdown Options</h3>
                <p class="admin-card-subtitle">Customize dropdown selections <span class="admin-label-hint">(one per line)</span></p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Availability Options</label>
                    <textarea name="availability_options" rows="5" placeholder="Immediate&#10;2 weeks notice&#10;1 month notice" class="admin-textarea"><?= htmlspecialchars(implode("\n", $current_data['application_form']['availability_options'] ?? ['Immediate', '2 weeks notice', '1 month notice', '2+ months'])) ?></textarea>
                </div>
                <div>
                    <label class="admin-label">Years of Experience Options</label>
                    <textarea name="experience_options" rows="5" placeholder="0-2 years&#10;3-5 years" class="admin-textarea"><?= htmlspecialchars(implode("\n", $current_data['application_form']['experience_options'] ?? ['0-2 years', '3-5 years', '6-10 years', '10+ years'])) ?></textarea>
                </div>
                <div>
                    <label class="admin-label">Education Level Options</label>
                    <textarea name="education_options" rows="6" placeholder="Diploma&#10;Bachelor's Degree" class="admin-textarea"><?= htmlspecialchars(implode("\n", $current_data['application_form']['education_options'] ?? ['Diploma', "Bachelor's Degree", "Master's Degree", 'PhD', 'Other'])) ?></textarea>
                </div>
            </div>
        </div>

    </form>

    <div class="h-24"></div>
</div>

<script>
function addValue() {
    const container = document.getElementById('values-container');
    const count = container.querySelectorAll('.value-item').length + 1;
    const html = `
        <div class="value-item border-t border-champagne-500/10 pt-4">
            <div class="flex items-center justify-between mb-4">
                <h4 class="text-sm font-semibold text-platinum-200">Value #${count}</h4>
                <button type="button" onclick="this.closest('.value-item').remove()" class="admin-btn-danger">Remove</button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="admin-label">Value Name</label>
                    <input type="text" name="value_name[]" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Description</label>
                    <input type="text" name="value_description[]" class="admin-input">
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addBenefit() {
    const container = document.getElementById('benefits-container');
    const count = container.querySelectorAll('.benefit-item').length + 1;
    const html = `
        <div class="benefit-item border-t border-champagne-500/10 pt-4">
            <div class="flex items-center justify-between mb-4">
                <h4 class="text-sm font-semibold text-platinum-200">Benefit #${count}</h4>
                <button type="button" onclick="this.closest('.benefit-item').remove()" class="admin-btn-danger">Remove</button>
            </div>
            <div class="space-y-4">
                <div>
                    <label class="admin-label">Category</label>
                    <input type="text" name="benefit_category[]" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="benefit_description[]" rows="2" class="admin-textarea"></textarea>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}
</script>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
