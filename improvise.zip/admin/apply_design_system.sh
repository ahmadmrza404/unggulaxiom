#!/bin/bash
# Batch apply unified design system to all admin files

cd admin

# List of files to update (excluding already updated and special files)
FILES=(
    "careers.php"
    "cipu-financials.php"
    "contact-partnerships.php"
    "governance.php"
    "homepage.php"
    "investor-landing.php"
    "leadership.php"
    "legal-pages.php"
    "profile-edit.php"
    "replication.php"
    "sectors-cipu-capital.php"
)

echo "Applying unified design system to ${#FILES[@]} admin files..."

for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "Processing: $file"

        # Backup original
        cp "$file" "${file}.bak"

        # Apply replacements
        sed -i 's/bg-obsidian-900 rounded-xl border border-champagne-500\/20 p-8/admin-card/g' "$file"
        sed -i 's/bg-obsidian-900 border border-champagne-500\/20 p-6/admin-card-compact/g' "$file"
        sed -i 's/text-lg font-semibold text-platinum-100/admin-card-title/g' "$file"
        sed -i 's/text-sm text-platinum-400 mt-1/admin-card-subtitle/g' "$file"
        sed -i 's/block text-sm font-medium text-platinum-200 mb-2/admin-label/g' "$file"
        sed -i 's/w-full px-4 py-3 text-base bg-obsidian-800 border border-champagne-500\/30 rounded-lg text-platinum-100 placeholder-platinum-500 focus:outline-none focus:ring-2 focus:ring-champagne-500\/50 focus:border-champagne-500 transition-all/admin-input/g' "$file"
        sed -i 's/bg-champagne-500 hover:bg-champagne-600 text-obsidian-950 font-semibold px-8 py-3/admin-btn-primary/g' "$file"
        sed -i 's/px-5 py-2.5 text-sm font-medium text-obsidian-950 bg-champagne-400 rounded-lg hover:bg-champagne-500 transition-colors shadow-sm/admin-btn-primary/g' "$file"
        sed -i 's/bg-obsidian-900 text-platinum-300 border border-champagne-500\/20 px-8 py-3/admin-btn-secondary/g' "$file"
        sed -i 's/px-5 py-2.5 text-sm font-medium text-platinum-300 bg-obsidian-800 border border-champagne-500\/30 rounded-lg hover:bg-obsidian-800\/80 hover:border-champagne-500\/50 transition-all/admin-btn-secondary/g' "$file"
        sed -i 's/bg-champagne-500\/10 border border-champagne-500\/30 text-champagne-400 px-6 py-4 rounded-lg mb-8/admin-alert admin-alert-success/g' "$file"
        sed -i 's/bg-green-900\/20 border border-green-500\/50 text-green-200 px-4 py-3 mb-6/admin-alert admin-alert-success/g' "$file"
        sed -i 's/bg-red-900\/20 border border-red-500\/50 text-red-200 px-4 py-3 mb-6/admin-alert admin-alert-error/g' "$file"
        sed -i 's/max-w-6xl mx-auto px-8 py-12/admin-container/g' "$file"
        sed -i 's/sticky top-0 z-10 bg-obsidian-900 border-b border-champagne-500\/20 px-8 py-5 flex items-center justify-between shadow-lg/admin-sticky-header/g' "$file"

        echo "✓ Updated: $file"
    else
        echo "✗ Not found: $file"
    fi
done

echo ""
echo "Batch update complete!"
echo "Backups saved with .bak extension"
