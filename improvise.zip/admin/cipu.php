<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/cipu.json';
$data = json_decode(file_get_contents($data_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['hero']['classification'] = $_POST['classification'] ?? '';
    $data['hero']['title'] = $_POST['title'] ?? '';
    $data['hero']['status'] = $_POST['status'] ?? '';

    $data['sections'] = [];
    if (!empty($_POST['section_title'])) {
        foreach ($_POST['section_title'] as $i => $title) {
            if (!empty($title)) {
                $section = ['title' => $title];

                if (!empty($_POST['has_subsections'][$i])) {
                    $section['subsections'] = [];
                    if (!empty($_POST['sub_subtitle'][$i])) {
                        foreach ($_POST['sub_subtitle'][$i] as $j => $subtitle) {
                            if (!empty($subtitle)) {
                                $section['subsections'][] = [
                                    'subtitle' => $subtitle,
                                    'text' => $_POST['sub_text'][$i][$j] ?? ''
                                ];
                            }
                        }
                    }
                } else {
                    $section['content'] = array_filter(array_map('trim', explode('|||', $_POST['section_content'][$i] ?? '')));
                    $section['content'] = array_values($section['content']);
                }

                $data['sections'][] = $section;
            }
        }
    }

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    $success = 'Content updated successfully';
}

$page_title = 'CIPU Flagship Asset';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">CIPU Flagship Asset</h2>
        <p class="admin-sticky-header-subtitle">Central Integrated Poultry Unggul dossier</p>
    </div>
    <div class="flex items-center space-x-3">
        <a href="../cipu.php" target="_blank" class="admin-btn-secondary">Preview Page</a>
        <button type="submit" form="cipu-form" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" id="cipu-form" class="space-y-8">

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Hero Section</h3>
                <p class="admin-card-subtitle">Flagship asset header</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Classification</label>
                    <input type="text" name="classification" value="<?= htmlspecialchars($data['hero']['classification']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="title" value="<?= htmlspecialchars($data['hero']['title']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Status</label>
                    <input type="text" name="status" value="<?= htmlspecialchars($data['hero']['status']) ?>" class="admin-input">
                </div>
            </div>
        </div>

        <?php foreach ($data['sections'] as $i => $section): ?>
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Section: <?= htmlspecialchars($section['title']) ?></h3>
                <p class="admin-card-subtitle">Content section #<?= $i + 1 ?></p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Title</label>
                    <input type="text" name="section_title[]" value="<?= htmlspecialchars($section['title']) ?>" class="admin-input">
                </div>

                <?php if (!empty($section['subsections'])): ?>
                    <input type="hidden" name="has_subsections[<?= $i ?>]" value="1">

                    <div class="space-y-4">
                        <label class="admin-label">Subsections</label>
                        <?php foreach ($section['subsections'] as $j => $sub): ?>
                        <div class="admin-card-compact">
                            <div class="space-y-4">
                                <div>
                                    <label class="admin-label">Subtitle</label>
                                    <input type="text" name="sub_subtitle[<?= $i ?>][]" value="<?= htmlspecialchars($sub['subtitle']) ?>" class="admin-input">
                                </div>
                                <div>
                                    <label class="admin-label">Text</label>
                                    <textarea name="sub_text[<?= $i ?>][]" rows="4" class="admin-textarea"><?= htmlspecialchars($sub['text']) ?></textarea>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div>
                        <label class="admin-label">Content Paragraphs <span class="admin-label-hint">(separate with |||)</span></label>
                        <textarea name="section_content[]" rows="6" class="admin-textarea"><?= htmlspecialchars(implode('|||', $section['content'] ?? [])) ?></textarea>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>

    </form>

    <div class="h-24"></div>
</div>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
