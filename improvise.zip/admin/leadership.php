<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$leadership_file = __DIR__ . '/../data/leadership.json';
$leadership_data = json_decode(file_get_contents($leadership_file), true);

$success = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'reorder') {
        $group = $_POST['group'] ?? '';
        $order = json_decode($_POST['order'] ?? '[]', true);

        if (!empty($group) && !empty($order)) {
            $reordered = [];
            foreach ($order as $id) {
                foreach ($leadership_data[$group] as $member) {
                    if ($member['id'] === $id) {
                        $reordered[] = $member;
                        break;
                    }
                }
            }
            $leadership_data[$group] = $reordered;
            file_put_contents($leadership_file, json_encode($leadership_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
            echo json_encode(['success' => true]);
            exit;
        }
    }

    if ($action === 'add') {
        $group = $_POST['group'] ?? '';
        $new_member = [
            'id' => $_POST['id'] ?? '',
            'name' => $_POST['name'] ?? '',
            'title' => $_POST['title'] ?? '',
            'description' => $_POST['description'] ?? '',
            'image' => $_POST['image'] ?? '',
            'email' => $_POST['email'] ?? '',
            'linkedin' => $_POST['linkedin'] ?? ''
        ];

        if (!empty($group) && !empty($new_member['id'])) {
            $leadership_data[$group][] = $new_member;
            file_put_contents($leadership_file, json_encode($leadership_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
            $success = 'Member added successfully';
        }
    }

    if ($action === 'delete') {
        $group = $_POST['group'] ?? '';
        $id = $_POST['id'] ?? '';

        if (!empty($group) && !empty($id)) {
            foreach ($leadership_data[$group] as $key => $member) {
                if ($member['id'] === $id) {
                    unset($leadership_data[$group][$key]);
                    $leadership_data[$group] = array_values($leadership_data[$group]);

                    $profile_file = __DIR__ . '/../data/profiles/' . $id . '.json';
                    if (file_exists($profile_file)) {
                        unlink($profile_file);
                    }

                    file_put_contents($leadership_file, json_encode($leadership_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
                    $success = 'Member deleted successfully';
                    break;
                }
            }
        }
    }

    if ($action === 'update_basic') {
        $group = $_POST['group'] ?? '';
        $id = $_POST['id'] ?? '';

        if (!empty($group) && !empty($id)) {
            foreach ($leadership_data[$group] as $key => $member) {
                if ($member['id'] === $id) {
                    $leadership_data[$group][$key] = [
                        'id' => $id,
                        'name' => $_POST['name'] ?? '',
                        'title' => $_POST['title'] ?? '',
                        'description' => $_POST['description'] ?? '',
                        'image' => $_POST['image'] ?? '',
                        'email' => $_POST['email'] ?? '',
                        'linkedin' => $_POST['linkedin'] ?? ''
                    ];
                    file_put_contents($leadership_file, json_encode($leadership_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
                    $success = 'Member updated successfully';
                    break;
                }
            }
        }
    }
}

$page_title = 'Leadership Management';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="bg-obsidian-900 border-b border-champagne-500/20 px-8 py-8">
    <div class="max-w-7xl mx-auto">
        <h2 class="text-3xl font-semibold text-platinum-100 mb-2">Leadership Management</h2>
        <p class="text-platinum-400">Manage team members and organizational structure</p>
    </div>
</div>

<div class="max-w-7xl mx-auto px-8 py-12">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success mb-8">
        <svg class="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="admin-alert admin-alert-error mb-8">
        <svg class="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($error) ?></span>
    </div>
    <?php endif; ?>

    <!-- Add New Member -->
    <div class="admin-card mb-12">
        <div class="admin-card-header">
            <h3 class="admin-card-title">Add New Member</h3>
        </div>
        <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <input type="hidden" name="action" value="add">

            <div>
                <label class="admin-label admin-label-required">Group</label>
                <select name="group" required class="admin-select">
                    <option value="">Select Group</option>
                    <option value="board_of_directors">Board of Directors</option>
                    <option value="executives">Executive Command</option>
                    <option value="senior_management">Senior Management</option>
                    <option value="department_heads">Department Heads</option>
                    <option value="operations">Operations</option>
                    <option value="finance">Finance</option>
                    <option value="legal_compliance">Legal & Compliance</option>
                    <option value="human_resources">Human Resources</option>
                    <option value="technology">Technology</option>
                    <option value="marketing_communications">Marketing & Communications</option>
                    <option value="business_development">Business Development</option>
                    <option value="advisors">Advisory Board</option>
                </select>
            </div>

            <div>
                <label class="admin-label admin-label-required">ID <span class="admin-label-hint">(e.g., DIR_06, MGR_02)</span></label>
                <input type="text" name="id" required placeholder="DIR_06" class="admin-input">
            </div>

            <div>
                <label class="admin-label admin-label-required">Full Name</label>
                <input type="text" name="name" required placeholder="Ahmad Razif" class="admin-input">
            </div>

            <div>
                <label class="admin-label admin-label-required">Position Title</label>
                <input type="text" name="title" required placeholder="Chief Executive Officer" class="admin-input">
            </div>

            <div class="md:col-span-2">
                <label class="admin-label admin-label-required">Role Description</label>
                <textarea name="description" rows="3" required placeholder="Strategic oversight of infrastructure coordination..." class="admin-textarea"></textarea>
            </div>

            <div>
                <label class="admin-label">Profile Image Path</label>
                <input type="text" name="image" placeholder="assets/images/team/photo.jpg" class="admin-input">
            </div>

            <div>
                <label class="admin-label">Email Address</label>
                <input type="email" name="email" placeholder="email@unggulaxiom.com" class="admin-input">
            </div>

            <div class="md:col-span-2">
                <label class="admin-label">LinkedIn Profile URL</label>
                <input type="url" name="linkedin" placeholder="https://linkedin.com/in/profile" class="admin-input">
            </div>

            <div class="md:col-span-2">
                <button type="submit" class="admin-btn-primary">
                    <svg class="w-5 h-5 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                    </svg>
                    Add Member
                </button>
            </div>
        </form>
    </div>

    <!-- Existing Members -->
    <?php
    $group_titles = [
        'board_of_directors' => 'Board of Directors',
        'executives' => 'Executive Command',
        'senior_management' => 'Senior Management',
        'department_heads' => 'Department Heads',
        'operations' => 'Operations',
        'finance' => 'Finance',
        'legal_compliance' => 'Legal & Compliance',
        'human_resources' => 'Human Resources',
        'technology' => 'Technology',
        'marketing_communications' => 'Marketing & Communications',
        'business_development' => 'Business Development',
        'advisors' => 'Advisory Board'
    ];

    foreach ($group_titles as $group => $title): ?>
        <?php if (!empty($leadership_data[$group])): ?>
        <div class="mb-12">
            <div class="flex items-center gap-3 mb-6">
                <h2 class="text-2xl font-semibold text-platinum-100"><?= $title ?></h2>
                <span class="text-sm text-platinum-400 font-mono px-2 py-1 bg-obsidian-800 rounded"><?= count($leadership_data[$group]) ?></span>
                <button onclick="toggleReorderMode('<?= $group ?>')" class="ml-auto text-sm text-champagne-500 hover:text-champagne-400 flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                    Reorder
                </button>
            </div>
            <div id="group-<?= $group ?>" class="space-y-4 sortable-container" data-group="<?= $group ?>">
                <?php foreach ($leadership_data[$group] as $member): ?>
                <div class="admin-card-compact hover:border-champagne-500/40 transition-all sortable-item" data-id="<?= htmlspecialchars($member['id']) ?>">
                    <div class="sortable-handle hidden cursor-move p-2 -ml-2 text-platinum-400 hover:text-champagne-500">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8h16M4 16h16"/>
                        </svg>
                    </div>
                    <div class="flex justify-between items-start gap-6 flex-1">
                        <div class="flex-1">
                            <div class="flex items-center gap-4 mb-3">
                                <?php if (!empty($member['image']) && file_exists(__DIR__ . '/../' . $member['image'])): ?>
                                <img src="../<?= htmlspecialchars($member['image']) ?>" alt="<?= htmlspecialchars($member['name']) ?>" class="w-12 h-12 rounded-full object-cover border border-champagne-500/30">
                                <?php else: ?>
                                <div class="w-12 h-12 bg-champagne-500/10 border border-champagne-500/30 rounded-full flex items-center justify-center">
                                    <span class="font-mono text-xs text-champagne-500"><?= htmlspecialchars($member['id']) ?></span>
                                </div>
                                <?php endif; ?>
                                <div>
                                    <h3 class="text-lg font-semibold text-platinum-100"><?= htmlspecialchars($member['name']) ?></h3>
                                    <p class="text-champagne-400 text-sm"><?= htmlspecialchars($member['title']) ?></p>
                                </div>
                            </div>
                            <p class="text-sm text-platinum-300 mb-3 leading-relaxed"><?= htmlspecialchars($member['description']) ?></p>
                            <div class="flex gap-4 text-xs text-platinum-400">
                                <span class="font-mono"><?= htmlspecialchars($member['id']) ?></span>
                                <?php if (!empty($member['email'])): ?>
                                <span><?= htmlspecialchars($member['email']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="flex gap-2 flex-shrink-0 action-buttons">
                            <a href="profile-edit.php?id=<?= urlencode($member['id']) ?>" class="admin-btn-secondary text-sm">Edit Profile</a>
                            <button onclick="toggleEdit('<?= htmlspecialchars($member['id']) ?>')" class="admin-btn-ghost text-sm">Quick Edit</button>
                            <form method="POST" onsubmit="return confirm('Delete <?= htmlspecialchars($member['name']) ?>?');" class="inline">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="group" value="<?= $group ?>">
                                <input type="hidden" name="id" value="<?= htmlspecialchars($member['id']) ?>">
                                <button type="submit" class="admin-btn-danger">Delete</button>
                            </form>
                        </div>
                    </div>

                    <div id="edit-<?= htmlspecialchars($member['id']) ?>" class="hidden mt-6 pt-6 border-t border-champagne-500/20">
                        <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <input type="hidden" name="action" value="update_basic">
                            <input type="hidden" name="group" value="<?= $group ?>">
                            <input type="hidden" name="id" value="<?= htmlspecialchars($member['id']) ?>">
                            <div>
                                <label class="admin-label">Name</label>
                                <input type="text" name="name" value="<?= htmlspecialchars($member['name']) ?>" required class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Title</label>
                                <input type="text" name="title" value="<?= htmlspecialchars($member['title']) ?>" required class="admin-input">
                            </div>
                            <div class="md:col-span-2">
                                <label class="admin-label">Description</label>
                                <textarea name="description" rows="2" required class="admin-textarea"><?= htmlspecialchars($member['description']) ?></textarea>
                            </div>
                            <div>
                                <label class="admin-label">Email</label>
                                <input type="email" name="email" value="<?= htmlspecialchars($member['email']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">LinkedIn</label>
                                <input type="url" name="linkedin" value="<?= htmlspecialchars($member['linkedin']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Image Path</label>
                                <input type="text" name="image" value="<?= htmlspecialchars($member['image']) ?>" class="admin-input">
                            </div>
                            <div class="flex gap-2">
                                <button type="submit" class="admin-btn-primary">Save</button>
                                <button type="button" onclick="toggleEdit('<?= htmlspecialchars($member['id']) ?>')" class="admin-btn-secondary">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div id="reorder-actions-<?= $group ?>" class="hidden mt-4 flex gap-3">
                <button onclick="saveOrder('<?= $group ?>')" class="admin-btn-primary">Save Order</button>
                <button onclick="cancelReorder('<?= $group ?>')" class="admin-btn-secondary">Cancel</button>
            </div>
        </div>
        <?php endif; ?>
    <?php endforeach; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<script>
const sortableInstances = {};

function toggleEdit(id) {
    const editForm = document.getElementById('edit-' + id);
    if (editForm.classList.contains('hidden')) {
        editForm.classList.remove('hidden');
    } else {
        editForm.classList.add('hidden');
    }
}

function toggleReorderMode(group) {
    const container = document.getElementById('group-' + group);
    const handles = container.querySelectorAll('.sortable-handle');
    const actions = container.querySelectorAll('.action-buttons');
    const reorderActions = document.getElementById('reorder-actions-' + group);

    if (sortableInstances[group]) {
        sortableInstances[group].destroy();
        delete sortableInstances[group];
        handles.forEach(h => h.classList.add('hidden'));
        actions.forEach(a => a.classList.remove('hidden'));
        reorderActions.classList.add('hidden');
    } else {
        sortableInstances[group] = Sortable.create(container, {
            animation: 150,
            handle: '.sortable-handle',
            ghostClass: 'opacity-50'
        });
        handles.forEach(h => h.classList.remove('hidden'));
        actions.forEach(a => a.classList.add('hidden'));
        reorderActions.classList.remove('hidden');
    }
}

function saveOrder(group) {
    const container = document.getElementById('group-' + group);
    const items = container.querySelectorAll('.sortable-item');
    const order = Array.from(items).map(item => item.dataset.id);

    fetch('leadership.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=reorder&group=' + encodeURIComponent(group) + '&order=' + encodeURIComponent(JSON.stringify(order))
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    });
}

function cancelReorder(group) {
    location.reload();
}
</script>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
