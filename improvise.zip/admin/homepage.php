<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/homepage.json';
$data = json_decode(file_get_contents($data_file), true);

$section = $_GET['section'] ?? 'hero';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $section = $_POST['section'] ?? 'hero';

    if ($section === 'hero') {
        $data['hero']['title'] = $_POST['title'] ?? '';
        $data['hero']['subtitle'] = $_POST['subtitle'] ?? '';
        $data['hero']['tagline'] = $_POST['tagline'] ?? '';
        $data['hero']['cta_primary']['text'] = $_POST['cta_primary_text'] ?? '';
        $data['hero']['cta_primary']['url'] = $_POST['cta_primary_url'] ?? '';
        $data['hero']['cta_secondary']['text'] = $_POST['cta_secondary_text'] ?? '';
        $data['hero']['cta_secondary']['url'] = $_POST['cta_secondary_url'] ?? '';
    } elseif ($section === 'positioning') {
        $data['positioning']['position_label'] = $_POST['position_label'] ?? '';
        $data['positioning']['position_text_1'] = $_POST['position_text_1'] ?? '';
        $data['positioning']['position_text_2'] = $_POST['position_text_2'] ?? '';
        $data['positioning']['principle_label'] = $_POST['principle_label'] ?? '';
        $data['positioning']['principle_statement'] = $_POST['principle_statement'] ?? '';
    } elseif ($section === 'market') {
        $data['market']['section_label'] = $_POST['section_label'] ?? '';
        $data['market']['headline'] = $_POST['headline'] ?? '';
        $data['market']['market_size'] = $_POST['market_size'] ?? '';
        $data['market']['market_size_label'] = $_POST['market_size_label'] ?? '';

        $data['market']['data_points'] = [];
        if (!empty($_POST['data_point'])) {
            foreach ($_POST['data_point'] as $point) {
                if (!empty(trim($point))) {
                    $data['market']['data_points'][] = trim($point);
                }
            }
        }

        $data['market']['market_reality_label'] = $_POST['market_reality_label'] ?? '';
        $data['market']['market_reality_text'] = $_POST['market_reality_text'] ?? '';
        $data['market']['positioning_statement'] = $_POST['positioning_statement'] ?? '';
    } elseif ($section === 'framework') {
        $data['framework']['section_label'] = $_POST['section_label'] ?? '';
        $data['framework']['title'] = $_POST['title'] ?? '';
        $data['framework']['description'] = $_POST['description'] ?? '';

        $data['framework']['pillars'] = [];
        if (!empty($_POST['pillar_number'])) {
            foreach ($_POST['pillar_number'] as $i => $number) {
                if (!empty($number)) {
                    $data['framework']['pillars'][] = [
                        'number' => $number,
                        'name' => $_POST['pillar_name'][$i] ?? '',
                        'description' => $_POST['pillar_description'][$i] ?? ''
                    ];
                }
            }
        }
    } elseif ($section === 'ecosystem') {
        $data['ecosystem']['section_label'] = $_POST['section_label'] ?? '';
        $data['ecosystem']['title'] = $_POST['title'] ?? '';
        $data['ecosystem']['description'] = $_POST['description'] ?? '';

        $data['ecosystem']['entities'] = [];
        if (!empty($_POST['entity_name'])) {
            foreach ($_POST['entity_name'] as $i => $name) {
                if (!empty($name)) {
                    $data['ecosystem']['entities'][] = [
                        'name' => $name,
                        'description' => $_POST['entity_description'][$i] ?? '',
                        'url' => $_POST['entity_url'][$i] ?? ''
                    ];
                }
            }
        }
    } elseif ($section === 'uhic') {
        $data['uhic']['section_label'] = $_POST['section_label'] ?? '';
        $data['uhic']['title'] = $_POST['title'] ?? '';
        $data['uhic']['intro_text'] = $_POST['intro_text'] ?? '';
        $data['uhic']['description'] = $_POST['description'] ?? '';
        $data['uhic']['objectives_label'] = $_POST['objectives_label'] ?? '';

        $objectives = array_filter(array_map('trim', explode("\n", $_POST['objectives'] ?? '')));
        $data['uhic']['objectives'] = $objectives;

        $data['uhic']['modules_title'] = $_POST['modules_title'] ?? '';

        $data['uhic']['modules'] = [];
        if (!empty($_POST['module_name'])) {
            foreach ($_POST['module_name'] as $i => $name) {
                if (!empty($name)) {
                    $data['uhic']['modules'][] = [
                        'name' => $name,
                        'description' => $_POST['module_description'][$i] ?? '',
                        'tech_stack' => $_POST['module_tech'][$i] ?? ''
                    ];
                }
            }
        }

        $data['uhic']['deployment_title'] = $_POST['deployment_title'] ?? '';
        $data['uhic']['deployment_description'] = $_POST['deployment_description'] ?? '';

        $data['uhic']['deployment_sectors'] = [];
        if (!empty($_POST['sector_name'])) {
            foreach ($_POST['sector_name'] as $i => $name) {
                if (!empty($name)) {
                    $data['uhic']['deployment_sectors'][] = [
                        'name' => $name,
                        'status' => $_POST['sector_status'][$i] ?? ''
                    ];
                }
            }
        }
    } elseif ($section === 'cipu_pilot') {
        $data['cipu_pilot']['section_label'] = $_POST['section_label'] ?? '';
        $data['cipu_pilot']['title'] = $_POST['title'] ?? '';
        $data['cipu_pilot']['subtitle'] = $_POST['subtitle'] ?? '';
        $data['cipu_pilot']['status'] = $_POST['status'] ?? '';
        $data['cipu_pilot']['function'] = $_POST['function'] ?? '';
        $data['cipu_pilot']['location'] = $_POST['location'] ?? '';
        $data['cipu_pilot']['capacity'] = $_POST['capacity'] ?? '';
    }

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    $success = 'Content updated successfully';
}

$current_data = $data[$section] ?? [];
$page_title = 'Homepage Content';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="bg-obsidian-900 border-b border-champagne-500/20 px-8 py-8">
    <div class="max-w-7xl mx-auto">
        <h2 class="text-3xl font-semibold text-platinum-100 mb-2">Homepage Content</h2>
        <p class="text-platinum-400">Manage homepage sections and content</p>
    </div>
</div>

<div class="max-w-7xl mx-auto px-8 py-12">
    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success mb-8">
        <svg class="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <div class="flex gap-3 mb-8 overflow-x-auto pb-2">
        <a href="?section=hero" class="<?= $section === 'hero' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-5 py-2.5 rounded-lg transition-colors whitespace-nowrap font-medium">Hero</a>
        <a href="?section=positioning" class="<?= $section === 'positioning' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-5 py-2.5 rounded-lg transition-colors whitespace-nowrap font-medium">Positioning</a>
        <a href="?section=market" class="<?= $section === 'market' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-5 py-2.5 rounded-lg transition-colors whitespace-nowrap font-medium">Market</a>
        <a href="?section=framework" class="<?= $section === 'framework' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-5 py-2.5 rounded-lg transition-colors whitespace-nowrap font-medium">Framework</a>
        <a href="?section=ecosystem" class="<?= $section === 'ecosystem' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-5 py-2.5 rounded-lg transition-colors whitespace-nowrap font-medium">Ecosystem</a>
        <a href="?section=uhic" class="<?= $section === 'uhic' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-5 py-2.5 rounded-lg transition-colors whitespace-nowrap font-medium">UHIC</a>
        <a href="?section=cipu_pilot" class="<?= $section === 'cipu_pilot' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-5 py-2.5 rounded-lg transition-colors whitespace-nowrap font-medium">CIPU Pilot</a>
    </div>

    <form method="POST" class="space-y-6">
        <input type="hidden" name="section" value="<?= htmlspecialchars($section) ?>">

        <?php include __DIR__ . '/partials/homepage/' . $section . '-form.php'; ?>

        <div class="flex gap-4 pt-6">
            <button type="submit" class="admin-btn-primary">Save Changes</button>
            <a href="index.php" class="admin-btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
