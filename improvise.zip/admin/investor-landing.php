<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/investor-landing.json';
$data = json_decode(file_get_contents($data_file), true);
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['investor_landing']['title'] = $_POST['title'] ?? '';
    $data['investor_landing']['overview'] = $_POST['overview'] ?? '';

    $data['investor_landing']['technology']['government_support'] = $_POST['government_support'] ?? '';
    $data['investor_landing']['technology']['technology_transfer'] = $_POST['technology_transfer'] ?? '';

    $performance = array_filter(array_map('trim', explode("\n", $_POST['performance_metrics'] ?? '')));
    $data['investor_landing']['technology']['performance_metrics'] = $performance;

    $data['investor_landing']['financial_metrics']['annual_capacity'] = $_POST['annual_capacity'] ?? '';
    $data['investor_landing']['financial_metrics']['base_profit'] = $_POST['base_profit'] ?? '';
    $data['investor_landing']['financial_metrics']['target_irr'] = $_POST['target_irr'] ?? '';
    $data['investor_landing']['financial_metrics']['exit_timeline'] = $_POST['exit_timeline'] ?? '';

    $data['investor_landing']['investment_structures'] = [];
    if (!empty($_POST['structure_name'])) {
        foreach ($_POST['structure_name'] as $i => $name) {
            if (!empty($name)) {
                $data['investor_landing']['investment_structures'][] = [
                    'name' => $name,
                    'description' => $_POST['structure_description'][$i] ?? ''
                ];
            }
        }
    }

    $data['investor_landing']['expansion_strategy']['target'] = $_POST['expansion_target'] ?? '';

    $data['investor_landing']['expansion_strategy']['phases'] = [];
    if (!empty($_POST['phase_name'])) {
        foreach ($_POST['phase_name'] as $i => $name) {
            if (!empty($name)) {
                $data['investor_landing']['expansion_strategy']['phases'][] = [
                    'name' => $name,
                    'description' => $_POST['phase_description'][$i] ?? ''
                ];
            }
        }
    }

    $data['investor_landing']['investment_process'] = $_POST['investment_process'] ?? '';

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Content updated successfully';
}

$current_data = $data['investor_landing'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investor Landing - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="includes/admin-design-system.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { serif: ['Cormorant Garamond', 'serif'], sans: ['Inter', 'sans-serif'] },
                    colors: {
                        obsidian: { 900: '#0a0a0a', 950: '#050505' },
                        champagne: { 400: '#d4af37', 500: '#c5a028', 600: '#b69121' },
                        platinum: { 50: '#f5f5f5', 200: '#d1d1d1', 300: '#b0b0b0', 400: '#909090' }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-obsidian-950 text-platinum-50 font-sans">
    <nav class="bg-obsidian-900 border-b border-champagne-500/20 px-6 py-4 sticky top-0 z-50 backdrop-blur-sm bg-obsidian-900/95">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex gap-6 items-center">
                <a href="index.php" class="text-champagne-500 hover:text-champagne-400 transition-colors flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Dashboard
                </a>
                <h1 class="text-xl font-serif text-platinum-50">Investor Landing</h1>
            </div>
            <a href="logout.php" class="text-sm text-platinum-300 hover:text-champagne-400 transition-colors">Logout</a>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-6 py-8">
        <?php if ($success): ?>
        <div class="admin-alert admin-alert-success">
            <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            <span><?= htmlspecialchars($success) ?></span>
        </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <div class="admin-card-compact">
                <h2 class="admin-card-title mb-4">Page Header</h2>
                <div class="admin-form-section">
                    <div>
                        <label class="admin-label">Title</label>
                        <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="admin-input">
                    </div>
                    <div>
                        <label class="admin-label">Overview</label>
                        <textarea name="overview" rows="3" class="admin-textarea"><?= htmlspecialchars($current_data['overview']) ?></textarea>
                    </div>
                </div>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Technology & Government Support</h2>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm text-platinum-300 mb-2">Government Support</label>
                        <textarea name="government_support" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['technology']['government_support']) ?></textarea>
                    </div>
                    <div>
                        <label class="block text-sm text-platinum-300 mb-2">Technology Transfer</label>
                        <textarea name="technology_transfer" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['technology']['technology_transfer']) ?></textarea>
                    </div>
                    <div>
                        <label class="block text-sm text-platinum-300 mb-2">Performance Metrics (one per line)</label>
                        <textarea name="performance_metrics" rows="4" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['technology']['performance_metrics'])) ?></textarea>
                    </div>
                </div>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Financial Metrics</h2>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm text-platinum-300 mb-2">Annual Capacity</label>
                        <input type="text" name="annual_capacity" value="<?= htmlspecialchars($current_data['financial_metrics']['annual_capacity']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-platinum-300 mb-2">Base Profit</label>
                        <input type="text" name="base_profit" value="<?= htmlspecialchars($current_data['financial_metrics']['base_profit']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-platinum-300 mb-2">Target IRR</label>
                        <input type="text" name="target_irr" value="<?= htmlspecialchars($current_data['financial_metrics']['target_irr']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-platinum-300 mb-2">Exit Timeline</label>
                        <input type="text" name="exit_timeline" value="<?= htmlspecialchars($current_data['financial_metrics']['exit_timeline']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
                    </div>
                </div>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Investment Structures</h2>
                <div id="structures-container" class="space-y-4">
                    <?php foreach ($current_data['investment_structures'] as $structure): ?>
                    <div class="structure-item border border-champagne-500/20 p-4 space-y-3">
                        <input type="text" name="structure_name[]" value="<?= htmlspecialchars($structure['name']) ?>" placeholder="Structure Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        <textarea name="structure_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars($structure['description']) ?></textarea>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" onclick="addStructure()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add Structure</button>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Expansion Strategy</h2>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm text-platinum-300 mb-2">Target</label>
                        <input type="text" name="expansion_target" value="<?= htmlspecialchars($current_data['expansion_strategy']['target']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-platinum-300 mb-2">Phases</label>
                        <div id="phases-container" class="space-y-3">
                            <?php foreach ($current_data['expansion_strategy']['phases'] as $phase): ?>
                            <div class="phase-item border border-champagne-500/20 p-3 space-y-2">
                                <input type="text" name="phase_name[]" value="<?= htmlspecialchars($phase['name']) ?>" placeholder="Phase Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                                <textarea name="phase_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars($phase['description']) ?></textarea>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" onclick="addPhase()" class="mt-2 text-sm text-champagne-500 hover:text-champagne-400">+ Add Phase</button>
                    </div>
                </div>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Investment Process</h2>
                <textarea name="investment_process" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['investment_process']) ?></textarea>
            </div>

            <div class="flex gap-4">
                <button type="submit" class="bg-champagne-500 hover:bg-champagne-600 text-obsidian-950 font-semibold px-8 py-3">Save Changes</button>
                <a href="index.php" class="bg-obsidian-900 text-platinum-300 border border-champagne-500/20 px-8 py-3 inline-block">Cancel</a>
            </div>
        </form>
    </div>

    <script>
        function addStructure() {
            document.getElementById('structures-container').insertAdjacentHTML('beforeend', '<div class="structure-item border border-champagne-500/20 p-4 space-y-3"><input type="text" name="structure_name[]" placeholder="Structure Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><textarea name="structure_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></textarea></div>');
        }
        function addPhase() {
            document.getElementById('phases-container').insertAdjacentHTML('beforeend', '<div class="phase-item border border-champagne-500/20 p-3 space-y-2"><input type="text" name="phase_name[]" placeholder="Phase Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><textarea name="phase_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></textarea></div>');
        }
    </script>
</body>
</html>
