<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$governance_file = __DIR__ . '/../data/governance.json';
$governance_data = json_decode(file_get_contents($governance_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $governance_data['header']['label'] = $_POST['header_label'] ?? '';
    $governance_data['header']['company_name'] = $_POST['company_name'] ?? '';
    $governance_data['header']['country'] = $_POST['country'] ?? '';
    $governance_data['header']['description'] = $_POST['header_description'] ?? '';
    $governance_data['quote'] = $_POST['quote'] ?? '';

    $governance_data['value_propositions'] = [];
    if (!empty($_POST['vp_label'])) {
        foreach ($_POST['vp_label'] as $i => $label) {
            if (!empty($label)) {
                $governance_data['value_propositions'][] = [
                    'label' => $label,
                    'title' => $_POST['vp_title'][$i] ?? '',
                    'description' => $_POST['vp_description'][$i] ?? ''
                ];
            }
        }
    }

    $governance_data['investment_proposition']['title'] = $_POST['investment_title'] ?? '';
    $governance_data['investment_proposition']['growth_trajectory']['label'] = $_POST['growth_label'] ?? '';

    $growth_points = array_filter(array_map('trim', explode("\n", $_POST['growth_points'] ?? '')));
    $governance_data['investment_proposition']['growth_trajectory']['points'] = $growth_points;

    $governance_data['investment_proposition']['competitive_advantages']['label'] = $_POST['competitive_label'] ?? '';

    $competitive_points = array_filter(array_map('trim', explode("\n", $_POST['competitive_points'] ?? '')));
    $governance_data['investment_proposition']['competitive_advantages']['points'] = $competitive_points;

    file_put_contents($governance_file, json_encode($governance_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Governance data updated successfully';
}

$page_title = 'Governance';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">Governance Content</h2>
        <p class="admin-sticky-header-subtitle">Corporate governance and value propositions</p>
    </div>
    <div class="flex items-center space-x-3">
        <a href="../governance.php" target="_blank" class="admin-btn-secondary">Preview Page</a>
        <button type="submit" form="governance-form" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">
    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" id="governance-form" class="space-y-8">

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Header Section</h3>
                <p class="admin-card-subtitle">Company identification</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Label</label>
                    <input type="text" name="header_label" value="<?= htmlspecialchars($governance_data['header']['label']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Company Name</label>
                    <input type="text" name="company_name" value="<?= htmlspecialchars($governance_data['header']['company_name']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Country</label>
                    <input type="text" name="country" value="<?= htmlspecialchars($governance_data['header']['country']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="header_description" rows="3" class="admin-textarea"><?= htmlspecialchars($governance_data['header']['description']) ?></textarea>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Quote</h3>
                <p class="admin-card-subtitle">Featured statement</p>
            </div>
            <input type="text" name="quote" value="<?= htmlspecialchars($governance_data['quote']) ?>" class="admin-input">
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Value Propositions</h3>
                <p class="admin-card-subtitle">Key differentiators</p>
            </div>
            <div id="vp-container" class="space-y-6">
                <?php foreach ($governance_data['value_propositions'] as $vp): ?>
                <div class="vp-item admin-card-compact">
                    <input type="text" name="vp_label[]" value="<?= htmlspecialchars($vp['label']) ?>" placeholder="PROVEN MODEL" class="admin-input mb-3">
                    <input type="text" name="vp_title[]" value="<?= htmlspecialchars($vp['title']) ?>" placeholder="Title" class="admin-input mb-3">
                    <textarea name="vp_description[]" rows="3" placeholder="Description" class="admin-textarea"><?= htmlspecialchars($vp['description']) ?></textarea>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" onclick="addVP()" class="admin-btn-add mt-4">+ Add Value Proposition</button>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Investment Value Proposition</h3>
                <p class="admin-card-subtitle">Growth and competitive advantages</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="investment_title" value="<?= htmlspecialchars($governance_data['investment_proposition']['title']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Growth Trajectory Label</label>
                    <input type="text" name="growth_label" value="<?= htmlspecialchars($governance_data['investment_proposition']['growth_trajectory']['label']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Growth Points <span class="admin-label-hint">(one per line)</span></label>
                    <textarea name="growth_points" rows="4" class="admin-textarea"><?= htmlspecialchars(implode("\n", $governance_data['investment_proposition']['growth_trajectory']['points'])) ?></textarea>
                </div>

                <div>
                    <label class="admin-label">Competitive Advantages Label</label>
                    <input type="text" name="competitive_label" value="<?= htmlspecialchars($governance_data['investment_proposition']['competitive_advantages']['label']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Competitive Points <span class="admin-label-hint">(one per line)</span></label>
                    <textarea name="competitive_points" rows="4" class="admin-textarea"><?= htmlspecialchars(implode("\n", $governance_data['investment_proposition']['competitive_advantages']['points'])) ?></textarea>
                </div>
            </div>
        </div>

    </form>

    <div class="h-24"></div>
</div>

<script>
function addVP() {
    document.getElementById('vp-container').insertAdjacentHTML('beforeend', '<div class="vp-item admin-card-compact"><input type="text" name="vp_label[]" placeholder="LABEL" class="admin-input mb-3"><input type="text" name="vp_title[]" placeholder="Title" class="admin-input mb-3"><textarea name="vp_description[]" rows="3" placeholder="Description" class="admin-textarea"></textarea></div>');
}
</script>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
