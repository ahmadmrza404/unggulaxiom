<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/includes/csrf.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/about-systems.json';
$data = json_decode(file_get_contents($data_file), true);

$page = $_GET['page'] ?? 'about';
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please refresh and try again.';
    } else {
        $page = $_POST['page'] ?? 'about';

    if ($page === 'about') {
        $data['about']['title'] = $_POST['title'] ?? '';
        $data['about']['overview']['tagline'] = $_POST['tagline'] ?? '';
        $data['about']['overview']['focus'] = $_POST['focus'] ?? '';
        $data['about']['overview']['headquarters'] = $_POST['headquarters'] ?? '';

        $data['about']['core_structure']['parent_entity'] = $_POST['parent_entity'] ?? '';
        $data['about']['core_structure']['registration'] = $_POST['registration'] ?? '';
        $data['about']['core_structure']['type'] = $_POST['company_type'] ?? '';

        $sectors = array_filter(array_map('trim', explode("\n", $_POST['sectors'] ?? '')));
        $data['about']['core_structure']['sectors'] = $sectors;

        $activities = array_filter(array_map('trim', explode("\n", $_POST['activities'] ?? '')));
        $data['about']['business_activities'] = $activities;

        $data['about']['strategic_mandate'] = $_POST['strategic_mandate'] ?? '';

        $governance = array_filter(array_map('trim', explode("\n", $_POST['governance'] ?? '')));
        $data['about']['governance_highlights'] = $governance;
    } elseif ($page === 'systems') {
        $data['systems']['title'] = $_POST['title'] ?? '';
        $data['systems']['tagline'] = $_POST['tagline'] ?? '';

        $data['systems']['systems'] = [];
        if (!empty($_POST['system_name'])) {
            foreach ($_POST['system_name'] as $i => $name) {
                if (!empty($name)) {
                    $features = array_filter(array_map('trim', explode("\n", $_POST['system_features'][$i] ?? '')));
                    $data['systems']['systems'][] = [
                        'name' => $name,
                        'description' => $_POST['system_description'][$i] ?? '',
                        'features' => $features
                    ];
                }
            }
        }
    }

        file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        $success = 'Content updated successfully';
    }
}

$current_data = $data[$page] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About & Systems - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="includes/admin-design-system.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'] },
                    colors: {
                        obsidian: { 900: '#0a0a0a', 950: '#050505' },
                        champagne: { 400: '#d4af37', 500: '#c5a028', 600: '#b69121' },
                        platinum: { 50: '#f5f5f5', 200: '#d1d1d1', 300: '#b0b0b0', 400: '#909090' }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-obsidian-950 text-platinum-50 font-sans">
    <nav class="bg-obsidian-900 border-b border-champagne-500/20 px-6 py-4 sticky top-0 z-50 backdrop-blur-sm bg-obsidian-900/95">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex gap-6 items-center">
                <a href="index.php" class="text-champagne-500 hover:text-champagne-400 transition-colors flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Dashboard
                </a>
                <h1 class="text-xl font-serif text-platinum-50">About & Systems</h1>
            </div>
            <a href="logout.php" class="text-sm text-platinum-300 hover:text-champagne-400 transition-colors">Logout</a>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-6 py-8">
        <?php if ($error): ?>
        <div class="admin-alert admin-alert-error">
            <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
            </svg>
            <span><?= htmlspecialchars($error) ?></span>
        </div>
        <?php endif; ?>

        <?php if ($success): ?>
        <div class="admin-alert admin-alert-success">
            <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            <span><?= htmlspecialchars($success) ?></span>
        </div>
        <?php endif; ?>

        <div class="admin-card mb-6">
            <h2 class="admin-card-title mb-4">Select Page</h2>
            <div class="grid grid-cols-2 gap-3">
                <a href="?page=about" class="<?= $page === 'about' ? 'admin-btn-primary' : 'admin-btn-secondary' ?> text-center">About Page</a>
                <a href="?page=systems" class="<?= $page === 'systems' ? 'admin-btn-primary' : 'admin-btn-secondary' ?> text-center">Systems Page</a>
            </div>
        </div>

        <form method="POST" class="space-y-6">
            <?= csrf_field() ?>
            <input type="hidden" name="page" value="<?= htmlspecialchars($page) ?>">

            <?php if ($page === 'about'): ?>
                <?php include __DIR__ . '/partials/about-form.php'; ?>
            <?php else: ?>
                <?php include __DIR__ . '/partials/systems-form.php'; ?>
            <?php endif; ?>

            <div class="flex gap-4">
                <button type="submit" class="admin-btn-primary">Save Changes</button>
                <a href="index.php" class="admin-btn-secondary inline-block">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>
