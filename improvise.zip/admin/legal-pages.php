<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$legal_file = __DIR__ . '/../data/legal-pages.json';
$legal_data = json_decode(file_get_contents($legal_file), true);

$page = $_GET['page'] ?? 'shariah_governance';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $page = $_POST['page'] ?? 'shariah_governance';

    if ($page === 'shariah_governance') {
        $legal_data['shariah_governance']['title'] = $_POST['title'] ?? '';
        $legal_data['shariah_governance']['intro'] = $_POST['intro'] ?? '';
        $legal_data['shariah_governance']['core_statement'] = $_POST['core_statement'] ?? '';
        $legal_data['shariah_governance']['contact_email'] = $_POST['contact_email'] ?? '';

        $legal_data['shariah_governance']['sections'] = [];
        if (!empty($_POST['section_title'])) {
            foreach ($_POST['section_title'] as $i => $title) {
                if (!empty($title)) {
                    $legal_data['shariah_governance']['sections'][] = [
                        'title' => $title,
                        'content' => $_POST['section_content'][$i] ?? ''
                    ];
                }
            }
        }
    } elseif ($page === 'compliance') {
        $legal_data['compliance']['title'] = $_POST['title'] ?? '';
        $legal_data['compliance']['company_info']['name'] = $_POST['company_name'] ?? '';
        $legal_data['compliance']['company_info']['registration'] = $_POST['registration'] ?? '';
        $legal_data['compliance']['company_info']['description'] = $_POST['company_desc'] ?? '';
        $legal_data['compliance']['business_scope'] = $_POST['business_scope'] ?? '';
        $legal_data['compliance']['governance'] = $_POST['governance'] ?? '';
        $legal_data['compliance']['financial_standards'] = $_POST['financial_standards'] ?? '';
        $legal_data['compliance']['ethics'] = $_POST['ethics'] ?? '';
        $legal_data['compliance']['risk_management'] = $_POST['risk_management'] ?? '';
        $legal_data['compliance']['contact_email'] = $_POST['contact_email'] ?? '';

        $compliance_areas = array_filter(array_map('trim', explode("\n", $_POST['compliance_areas'] ?? '')));
        $legal_data['compliance']['compliance_areas'] = $compliance_areas;
    } elseif ($page === 'terms_of_service') {
        $legal_data['terms_of_service']['title'] = $_POST['title'] ?? '';
        $legal_data['terms_of_service']['last_updated'] = $_POST['last_updated'] ?? '';
        $legal_data['terms_of_service']['company']['name'] = $_POST['company_name'] ?? '';
        $legal_data['terms_of_service']['company']['registration'] = $_POST['registration'] ?? '';

        $legal_data['terms_of_service']['sections'] = [];
        if (!empty($_POST['section_title'])) {
            foreach ($_POST['section_title'] as $i => $title) {
                if (!empty($title)) {
                    $legal_data['terms_of_service']['sections'][] = [
                        'title' => $title,
                        'content' => $_POST['section_content'][$i] ?? ''
                    ];
                }
            }
        }
    } elseif ($page === 'privacy_policy') {
        $legal_data['privacy_policy']['title'] = $_POST['title'] ?? '';
        $legal_data['privacy_policy']['last_updated'] = $_POST['last_updated'] ?? '';
        $legal_data['privacy_policy']['company']['name'] = $_POST['company_name'] ?? '';
        $legal_data['privacy_policy']['company']['registration'] = $_POST['registration'] ?? '';
        $legal_data['privacy_policy']['contact_email'] = $_POST['contact_email'] ?? '';

        $legal_data['privacy_policy']['sections'] = [];
        if (!empty($_POST['section_title'])) {
            foreach ($_POST['section_title'] as $i => $title) {
                if (!empty($title)) {
                    $legal_data['privacy_policy']['sections'][] = [
                        'title' => $title,
                        'content' => $_POST['section_content'][$i] ?? ''
                    ];
                }
            }
        }
    }

    file_put_contents($legal_file, json_encode($legal_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Content updated successfully';
}

$current_data = $legal_data[$page] ?? [];
$page_title = 'Legal Pages';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="bg-obsidian-900 border-b border-champagne-500/20 px-8 py-8">
    <div class="max-w-7xl mx-auto">
        <h2 class="text-3xl font-semibold text-platinum-100 mb-2">Legal Pages</h2>
        <p class="text-platinum-400">Manage legal documentation and compliance content</p>
    </div>
</div>

<div class="max-w-7xl mx-auto px-8 py-12">
    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success mb-8">
        <svg class="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <div class="admin-card mb-8">
        <h3 class="text-lg font-semibold text-platinum-100 mb-4">Select Page</h3>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
            <a href="?page=shariah_governance" class="<?= $page === 'shariah_governance' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-4 py-3 text-center rounded-lg transition-colors font-medium">Shariah Governance</a>
            <a href="?page=compliance" class="<?= $page === 'compliance' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-4 py-3 text-center rounded-lg transition-colors font-medium">Compliance</a>
            <a href="?page=terms_of_service" class="<?= $page === 'terms_of_service' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-4 py-3 text-center rounded-lg transition-colors font-medium">Terms of Service</a>
            <a href="?page=privacy_policy" class="<?= $page === 'privacy_policy' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-4 py-3 text-center rounded-lg transition-colors font-medium">Privacy Policy</a>
        </div>
    </div>

    <form method="POST" class="space-y-6">
        <input type="hidden" name="page" value="<?= htmlspecialchars($page) ?>">

        <?php if ($page === 'shariah_governance'): ?>
            <?php include __DIR__ . '/partials/shariah-form.php'; ?>
        <?php elseif ($page === 'compliance'): ?>
            <?php include __DIR__ . '/partials/compliance-form.php'; ?>
        <?php elseif ($page === 'terms_of_service'): ?>
            <?php include __DIR__ . '/partials/terms-form.php'; ?>
        <?php elseif ($page === 'privacy_policy'): ?>
            <?php include __DIR__ . '/partials/privacy-form.php'; ?>
        <?php endif; ?>

        <div class="flex gap-4 pt-6">
            <button type="submit" class="admin-btn-primary">Save Changes</button>
            <a href="index.php" class="admin-btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
