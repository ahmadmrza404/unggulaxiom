<?php
/**
 * Admin Panel Security Layer
 * Comprehensive security utilities for input validation, sanitization, and protection
 */

// Prevent direct access
if (!defined('ADMIN_SECURITY_LOADED')) {
    define('ADMIN_SECURITY_LOADED', true);
}

/**
 * Validate and sanitize email addresses
 */
function validate_email($email) {
    $email = trim($email);
    if (empty($email)) return '';
    return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : '';
}

/**
 * Validate and sanitize URLs
 */
function validate_url($url) {
    $url = trim($url);
    if (empty($url)) return '';
    return filter_var($url, FILTER_VALIDATE_URL) ? $url : '';
}

/**
 * Sanitize text input with length limit
 */
function sanitize_text($text, $max_length = 1000) {
    $text = trim($text);
    $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    return mb_substr($text, 0, $max_length);
}

/**
 * Sanitize textarea/long text with length limit
 */
function sanitize_textarea($text, $max_length = 10000) {
    $text = trim($text);
    $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    return mb_substr($text, 0, $max_length);
}

/**
 * Validate numeric input
 */
function validate_number($value, $min = null, $max = null) {
    if (!is_numeric($value)) return null;
    $num = floatval($value);
    if ($min !== null && $num < $min) return null;
    if ($max !== null && $num > $max) return null;
    return $num;
}

/**
 * Sanitize array of strings
 */
function sanitize_array($array, $max_items = 100) {
    if (!is_array($array)) return [];
    $array = array_slice($array, 0, $max_items);
    return array_map(function($item) {
        return sanitize_text($item, 500);
    }, $array);
}

/**
 * Create backup of JSON file before modification
 */
function backup_json_file($file_path) {
    if (!file_exists($file_path)) return false;

    $backup_dir = dirname($file_path) . '/backups';
    if (!is_dir($backup_dir)) {
        mkdir($backup_dir, 0755, true);
    }

    $filename = basename($file_path);
    $timestamp = date('Y-m-d_H-i-s');
    $backup_path = $backup_dir . '/' . $filename . '.' . $timestamp . '.bak';

    // Keep only last 5 backups
    $backups = glob($backup_dir . '/' . $filename . '.*.bak');
    if (count($backups) >= 5) {
        sort($backups);
        unlink($backups[0]);
    }

    return copy($file_path, $backup_path);
}

/**
 * Rate limiting check
 */
function check_rate_limit($action, $max_attempts = 10, $window = 60) {
    if (!isset($_SESSION['rate_limit'])) {
        $_SESSION['rate_limit'] = [];
    }

    $key = $action . '_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    $now = time();

    if (!isset($_SESSION['rate_limit'][$key])) {
        $_SESSION['rate_limit'][$key] = ['count' => 0, 'reset' => $now + $window];
    }

    $limit = &$_SESSION['rate_limit'][$key];

    if ($now > $limit['reset']) {
        $limit['count'] = 0;
        $limit['reset'] = $now + $window;
    }

    $limit['count']++;

    return $limit['count'] <= $max_attempts;
}

/**
 * Log security events
 */
function log_security_event($event, $details = []) {
    $log_file = __DIR__ . '/../logs/security.log';
    $log_dir = dirname($log_file);

    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $entry = sprintf(
        "[%s] %s | User: %s | IP: %s | Details: %s\n",
        date('Y-m-d H:i:s'),
        $event,
        $_SESSION['admin_username'] ?? 'unknown',
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        json_encode($details)
    );

    file_put_contents($log_file, $entry, FILE_APPEND | LOCK_EX);
}

/**
 * Validate file path to prevent directory traversal
 */
function validate_file_path($path, $allowed_dir) {
    $real_path = realpath($path);
    $real_allowed = realpath($allowed_dir);

    if ($real_path === false || $real_allowed === false) {
        return false;
    }

    return strpos($real_path, $real_allowed) === 0;
}

/**
 * Session timeout check
 */
function check_session_timeout($timeout = 1800) {
    if (!isset($_SESSION['last_activity'])) {
        $_SESSION['last_activity'] = time();
        return true;
    }

    if (time() - $_SESSION['last_activity'] > $timeout) {
        session_unset();
        session_destroy();
        return false;
    }

    $_SESSION['last_activity'] = time();
    return true;
}

/**
 * Validate session integrity
 */
function validate_session_integrity() {
    $current_ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $current_ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

    if (!isset($_SESSION['user_ip'])) {
        $_SESSION['user_ip'] = $current_ip;
        $_SESSION['user_agent'] = $current_ua;
        return true;
    }

    if ($_SESSION['user_ip'] !== $current_ip) {
        log_security_event('SESSION_HIJACK_ATTEMPT', [
            'expected_ip' => $_SESSION['user_ip'],
            'actual_ip' => $current_ip
        ]);
        return false;
    }

    return true;
}
