<?php
/**
 * Admin Security Wrapper
 * Include this at the top of every admin file for comprehensive security
 */

// Prevent direct access
if (basename($_SERVER['PHP_SELF']) == 'admin-security-wrapper.php') {
    die('Direct access not permitted');
}

// Load security utilities
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/security.php';

// Session timeout check (30 minutes)
if (!check_session_timeout(1800)) {
    header('Location: login.php?timeout=1');
    exit;
}

// Session integrity validation
if (!validate_session_integrity()) {
    session_unset();
    session_destroy();
    header('Location: login.php?error=session_invalid');
    exit;
}

// Update last activity timestamp
$_SESSION['last_activity'] = time();

// Generate CSRF token if not exists
generate_csrf_token();
