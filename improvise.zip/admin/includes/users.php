<?php
/**
 * Admin Users Configuration
 * Simple plaintext password validation
 */

if (!defined('ADMIN_USERS_LOADED')) {
    define('ADMIN_USERS_LOADED', true);
}

/**
 * Admin users array
 * Format: 'username' => 'password'
 */
$admin_users = [
    'mirza' => '396500',
    'daus' => 'unggulbronto'
];

/**
 * Validate admin credentials
 */
function validate_admin_credentials($username, $password) {
    global $admin_users;

    if (!isset($admin_users[$username])) {
        return false;
    }

    return $admin_users[$username] === $password;
}

/**
 * Get all admin usernames
 */
function get_admin_usernames() {
    global $admin_users;
    return array_keys($admin_users);
}

/**
 * Check if username exists
 */
function admin_user_exists($username) {
    global $admin_users;
    return isset($admin_users[$username]);
}
