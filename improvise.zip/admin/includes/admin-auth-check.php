<?php
/**
 * Centralized Admin Authentication & Security Check
 * Include this at the top of every admin file (after session_start)
 */

// Prevent direct access
if (basename($_SERVER['PHP_SELF']) == 'admin-auth-check.php') {
    die('Direct access not permitted');
}

// Authentication check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Load security utilities
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/security.php';

// Session timeout check (30 minutes)
if (!check_session_timeout(1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?timeout=1');
    exit;
}

// Session integrity validation (IP check)
if (!validate_session_integrity()) {
    log_security_event('SESSION_HIJACK_ATTEMPT', [
        'expected_ip' => $_SESSION['user_ip'] ?? 'unknown',
        'actual_ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);
    session_unset();
    session_destroy();
    header('Location: login.php?error=session_invalid');
    exit;
}

// Update last activity timestamp
$_SESSION['last_activity'] = time();

// Generate CSRF token if not exists
generate_csrf_token();
