<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'Admin Panel' ?> - Unggul Axiom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="includes/admin-design-system.css?v=<?= time() ?>" rel="stylesheet">
    <style>
        body { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
        html { scroll-behavior: smooth; }
        .focus-ring:focus {
            outline: none;
            box-shadow: 0 0 0 3px rgba(197, 160, 40, 0.15);
            border-color: #d4af37;
        }
        .collapsible-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
        }
        .collapsible-content.open {
            max-height: 5000px;
            transition: max-height 0.5s ease-in;
        }
    </style>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        obsidian: { 800: '#1a1a1a', 900: '#141414', 950: '#0a0a0a' },
                        champagne: { 400: '#d4af37', 500: '#c5a028', 600: '#b69121' },
                        platinum: { 50: '#f5f5f5', 100: '#e8e8e8', 200: '#d1d1d1', 300: '#b0b0b0' }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-obsidian-950 text-platinum-100 antialiased">

    <div class="min-h-screen flex">

        <!-- Sidebar Navigation -->
        <aside class="w-72 bg-obsidian-900 border-r border-champagne-500/20 flex-shrink-0 fixed h-screen overflow-y-auto">
            <div class="p-8">
                <h1 class="text-xl font-bold text-champagne-400">Admin Panel</h1>
                <p class="text-sm text-platinum-300 mt-2">Content Manager</p>
            </div>

            <nav class="px-5 space-y-2 pb-32">
                <?php
                $current_page = basename($_SERVER['PHP_SELF']);
                $nav_items = [
                    ['file' => 'index.php', 'label' => 'Dashboard', 'icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'],
                    ['file' => 'homepage.php', 'label' => 'Homepage', 'icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'],
                    ['file' => 'capital.php', 'label' => 'Capital', 'icon' => 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z'],
                    ['file' => 'systems.php', 'label' => 'Systems', 'icon' => 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z'],
                    ['file' => 'cipu.php', 'label' => 'CIPU', 'icon' => 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4'],
                    ['file' => 'ecosystem.php', 'label' => 'Ecosystem', 'icon' => 'M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z'],
                    ['file' => 'ecosystem-entities.php', 'label' => 'Entities', 'icon' => 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10'],
                    ['file' => 'leadership.php', 'label' => 'Leadership', 'icon' => 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'],
                    ['file' => 'governance.php', 'label' => 'Governance', 'icon' => 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z'],
                    ['file' => 'careers.php', 'label' => 'Careers', 'icon' => 'M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'],
                    ['file' => 'partnerships.php', 'label' => 'Partnerships', 'icon' => 'M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1'],
                    ['file' => 'form-settings.php', 'label' => 'Form Settings', 'icon' => 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'],
                    ['file' => 'smtp-settings.php', 'label' => 'SMTP Settings', 'icon' => 'M3 19v-8.93a2 2 0 01.89-1.664l7-4.666a2 2 0 012.22 0l7 4.666A2 2 0 0121 10.07V19M3 19a2 2 0 002 2h14a2 2 0 002-2M3 19l6.75-4.5M21 19l-6.75-4.5M3 10l6.75 4.5M21 10l-6.75 4.5m0 0l-3.59 2.394a2 2 0 01-2.22 0L3.75 14.5'],
                ];

                foreach ($nav_items as $item):
                    $is_active = $current_page === $item['file'];
                    $active_class = $is_active ? 'text-champagne-400 bg-champagne-500/10 border-l-2 border-champagne-400' : 'text-platinum-300 hover:bg-obsidian-800 hover:text-platinum-100 border-l-2 border-transparent';
                ?>
                <a href="<?= $item['file'] ?>" class="flex items-center px-4 py-3.5 text-sm font-medium <?= $active_class ?> rounded-r-lg transition-all">
                    <svg class="w-5 h-5 mr-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?= $item['icon'] ?>"/>
                    </svg>
                    <?= $item['label'] ?>
                </a>
                <?php endforeach; ?>
            </nav>

            <div class="absolute bottom-0 w-72 p-6 border-t border-champagne-500/20 bg-obsidian-900">
                <div class="flex items-center">
                    <div class="w-11 h-11 rounded-full bg-champagne-500/20 border border-champagne-500/30 flex items-center justify-center">
                        <span class="text-sm font-semibold text-champagne-400">
                            <?= strtoupper(substr($_SESSION['admin_username'] ?? 'AD', 0, 2)) ?>
                        </span>
                    </div>
                    <div class="ml-3.5">
                        <p class="text-sm font-medium text-platinum-100"><?= htmlspecialchars($_SESSION['admin_username'] ?? 'Admin') ?></p>
                        <a href="logout.php" class="text-xs text-platinum-400 hover:text-champagne-400 transition-colors">Logout</a>
                    </div>
                </div>
            </div>
        </aside>

        <!-- Main Content Area -->
        <main class="flex-1 overflow-y-auto ml-72">
