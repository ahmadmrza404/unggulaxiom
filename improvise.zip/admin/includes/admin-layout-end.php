
        </main>
    </div>

    <script>
        function toggleCollapsible(id) {
            const content = document.getElementById(id);
            const icon = document.getElementById(id + '-icon');
            if (content && icon) {
                content.classList.toggle('open');
                icon.classList.toggle('rotate-180');
            }
        }
    </script>
</body>
</html>
