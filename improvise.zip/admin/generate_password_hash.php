<?php
/**
 * Password Hash Generator
 * Run this file once to generate bcrypt hash for new admin user
 * Then copy the hash to admin/includes/users.php
 */

$password = 'unggulbronto';
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

echo "Password: $password\n";
echo "Bcrypt Hash (cost 12):\n";
echo "$hash\n\n";
echo "Copy this hash to admin/includes/users.php for user 'daus'\n";
