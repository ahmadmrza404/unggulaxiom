<?php
// Test password verification
$password_mirza = '396500';
$password_daus = 'unggulbronto';

$hash_mirza = '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5ND0jClLm3WKi';
$hash_daus = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

echo "Testing mirza (396500): ";
echo password_verify($password_mirza, $hash_mirza) ? "✓ VALID\n" : "✗ INVALID\n";

echo "Testing daus (unggulbronto): ";
echo password_verify($password_daus, $hash_daus) ? "✓ VALID\n" : "✗ INVALID\n";

echo "\n--- Generating fresh hash for daus ---\n";
$new_hash = password_hash($password_daus, PASSWORD_BCRYPT, ['cost' => 12]);
echo "New hash: $new_hash\n";
echo "Verify new hash: ";
echo password_verify($password_daus, $new_hash) ? "✓ VALID\n" : "✗ INVALID\n";
