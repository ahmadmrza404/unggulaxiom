<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/partnerships.json';
$data = json_decode(file_get_contents($data_file), true);
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Hero
    $data['partnerships']['hero'] = [
        'label'    => $_POST['hero_label'] ?? '',
        'title'    => $_POST['hero_title'] ?? '',
        'subtitle' => $_POST['hero_subtitle'] ?? ''
    ];

    // Stats
    $data['partnerships']['stats'] = [];
    if (!empty($_POST['stat_value'])) {
        foreach ($_POST['stat_value'] as $i => $val) {
            if (trim($val) !== '') {
                $data['partnerships']['stats'][] = [
                    'value' => $val,
                    'label' => $_POST['stat_label'][$i] ?? ''
                ];
            }
        }
    }

    // Structures
    $data['partnerships']['structures'] = [];
    if (!empty($_POST['structure_title'])) {
        foreach ($_POST['structure_title'] as $i => $title) {
            if (trim($title) !== '') {
                $data['partnerships']['structures'][] = [
                    'title'       => $title,
                    'description' => $_POST['structure_description'][$i] ?? '',
                    'tags'        => $_POST['structure_tags'][$i] ?? ''
                ];
            }
        }
    }

    // Criteria
    $data['partnerships']['criteria'] = [
        'section_label' => $_POST['criteria_label'] ?? '',
        'institutional_profile' => [
            'heading' => $_POST['inst_heading'] ?? '',
            'items'   => array_values(array_filter(array_map('trim', explode("\n", $_POST['inst_items'] ?? ''))))
        ],
        'value_alignment' => [
            'heading' => $_POST['value_heading'] ?? '',
            'items'   => array_values(array_filter(array_map('trim', explode("\n", $_POST['value_items'] ?? ''))))
        ]
    ];

    // Inquiry form meta + dropdowns
    $data['partnerships']['inquiry_form'] = [
        'section_label'              => $_POST['form_label'] ?? '',
        'title'                      => $_POST['form_title'] ?? '',
        'description'                => $_POST['form_description'] ?? '',
        'partnership_type_options'   => array_values(array_filter(array_map('trim', explode("\n", $_POST['partnership_type_options'] ?? '')))),
        'investment_range_options'   => array_values(array_filter(array_map('trim', explode("\n", $_POST['investment_range_options'] ?? '')))),
        'organization_type_options'  => array_values(array_filter(array_map('trim', explode("\n", $_POST['organization_type_options'] ?? ''))))
    ];

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Partnerships page updated successfully';
}

$p = $data['partnerships'];
$page_title = 'Partnerships';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">Partnerships Page</h2>
        <p class="admin-sticky-header-subtitle">Strategic partnership structures and inquiry form</p>
    </div>
    <div class="flex items-center space-x-3">
        <a href="../partnerships.php" target="_blank" class="admin-btn-secondary">Preview Page</a>
        <button type="submit" form="partnerships-form" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" id="partnerships-form" class="space-y-8">

        <!-- ── HERO ── -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Hero Section</h3>
                <p class="admin-card-subtitle">Page header and introductory text</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label <span class="admin-label-hint">(small caps above title)</span></label>
                    <input type="text" name="hero_label" value="<?= htmlspecialchars($p['hero']['label']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Page Title</label>
                    <input type="text" name="hero_title" value="<?= htmlspecialchars($p['hero']['title']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Subtitle</label>
                    <textarea name="hero_subtitle" rows="2" class="admin-textarea"><?= htmlspecialchars($p['hero']['subtitle']) ?></textarea>
                </div>
            </div>
        </div>

        <!-- ── STATS BAR ── -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Stats Bar</h3>
                <p class="admin-card-subtitle">4 key figures displayed below the hero</p>
            </div>
            <div id="stats-container" class="space-y-4">
                <?php foreach ($p['stats'] as $idx => $stat): ?>
                <div class="stat-item border-t border-champagne-500/10 pt-4">
                    <div class="flex items-center justify-between mb-3">
                        <h4 class="text-sm font-semibold text-platinum-200">Stat #<?= $idx + 1 ?></h4>
                        <button type="button" onclick="this.closest('.stat-item').remove()" class="admin-btn-danger">Remove</button>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="admin-label">Value</label>
                            <input type="text" name="stat_value[]" value="<?= htmlspecialchars($stat['value']) ?>" class="admin-input" placeholder="e.g. RM 500M+">
                        </div>
                        <div>
                            <label class="admin-label">Label</label>
                            <input type="text" name="stat_label[]" value="<?= htmlspecialchars($stat['label']) ?>" class="admin-input" placeholder="e.g. Infrastructure Pipeline">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" onclick="addStat()" class="admin-btn-add mt-6">+ Add Stat</button>
        </div>

        <!-- ── PARTNERSHIP STRUCTURES ── -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Partnership Structures</h3>
                <p class="admin-card-subtitle">Cards shown in the structures grid</p>
            </div>
            <div id="structures-container" class="space-y-6">
                <?php foreach ($p['structures'] as $idx => $s): ?>
                <div class="structure-item border-t border-champagne-500/10 pt-5">
                    <div class="flex items-center justify-between mb-4">
                        <h4 class="text-sm font-semibold text-platinum-200">Structure #<?= $idx + 1 ?></h4>
                        <button type="button" onclick="this.closest('.structure-item').remove()" class="admin-btn-danger">Remove</button>
                    </div>
                    <div class="space-y-4">
                        <div>
                            <label class="admin-label">Title</label>
                            <input type="text" name="structure_title[]" value="<?= htmlspecialchars($s['title']) ?>" class="admin-input">
                        </div>
                        <div>
                            <label class="admin-label">Description</label>
                            <textarea name="structure_description[]" rows="2" class="admin-textarea"><?= htmlspecialchars($s['description']) ?></textarea>
                        </div>
                        <div>
                            <label class="admin-label">Tags <span class="admin-label-hint">(shown at bottom of card, e.g. Minority Stakes · Governance Rights)</span></label>
                            <input type="text" name="structure_tags[]" value="<?= htmlspecialchars($s['tags']) ?>" class="admin-input">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" onclick="addStructure()" class="admin-btn-add mt-6">+ Add Structure</button>
        </div>

        <!-- ── PARTNERSHIP CRITERIA ── -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Partnership Criteria</h3>
                <p class="admin-card-subtitle">Two-column criteria panel</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="criteria_label" value="<?= htmlspecialchars($p['criteria']['section_label']) ?>" class="admin-input">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="admin-label">Left Column Heading</label>
                        <input type="text" name="inst_heading" value="<?= htmlspecialchars($p['criteria']['institutional_profile']['heading']) ?>" class="admin-input">
                        <label class="admin-label mt-4">Left Column Items <span class="admin-label-hint">(one per line)</span></label>
                        <textarea name="inst_items" rows="5" class="admin-textarea"><?= htmlspecialchars(implode("\n", $p['criteria']['institutional_profile']['items'])) ?></textarea>
                    </div>
                    <div>
                        <label class="admin-label">Right Column Heading</label>
                        <input type="text" name="value_heading" value="<?= htmlspecialchars($p['criteria']['value_alignment']['heading']) ?>" class="admin-input">
                        <label class="admin-label mt-4">Right Column Items <span class="admin-label-hint">(one per line)</span></label>
                        <textarea name="value_items" rows="5" class="admin-textarea"><?= htmlspecialchars(implode("\n", $p['criteria']['value_alignment']['items'])) ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- ── INQUIRY FORM HEADER ── -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Inquiry Form Section</h3>
                <p class="admin-card-subtitle">Header text above the partnership inquiry form</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label <span class="admin-label-hint">(small caps)</span></label>
                    <input type="text" name="form_label" value="<?= htmlspecialchars($p['inquiry_form']['section_label']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Form Title</label>
                    <input type="text" name="form_title" value="<?= htmlspecialchars($p['inquiry_form']['title']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Form Description</label>
                    <textarea name="form_description" rows="2" class="admin-textarea"><?= htmlspecialchars($p['inquiry_form']['description']) ?></textarea>
                </div>
            </div>
        </div>

        <!-- ── FORM DROPDOWNS ── -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Form Dropdown Options</h3>
                <p class="admin-card-subtitle">Manage dropdown options for the inquiry form <span class="admin-label-hint">(one per line)</span></p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Partnership Structure Options</label>
                    <textarea name="partnership_type_options" rows="6" class="admin-textarea"><?= htmlspecialchars(implode("\n", $p['inquiry_form']['partnership_type_options'])) ?></textarea>
                </div>
                <div>
                    <label class="admin-label">Investment Range Options</label>
                    <textarea name="investment_range_options" rows="6" class="admin-textarea"><?= htmlspecialchars(implode("\n", $p['inquiry_form']['investment_range_options'])) ?></textarea>
                </div>
                <div>
                    <label class="admin-label">Organisation Type Options</label>
                    <textarea name="organization_type_options" rows="7" class="admin-textarea"><?= htmlspecialchars(implode("\n", $p['inquiry_form']['organization_type_options'])) ?></textarea>
                </div>
            </div>
        </div>

    </form>

    <div class="h-24"></div>
</div>

<script>
function addStat() {
    const c = document.getElementById('stats-container');
    const n = c.querySelectorAll('.stat-item').length + 1;
    c.insertAdjacentHTML('beforeend', `
        <div class="stat-item border-t border-champagne-500/10 pt-4">
            <div class="flex items-center justify-between mb-3">
                <h4 class="text-sm font-semibold text-platinum-200">Stat #${n}</h4>
                <button type="button" onclick="this.closest('.stat-item').remove()" class="admin-btn-danger">Remove</button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label class="admin-label">Value</label><input type="text" name="stat_value[]" class="admin-input" placeholder="e.g. RM 500M+"></div>
                <div><label class="admin-label">Label</label><input type="text" name="stat_label[]" class="admin-input" placeholder="e.g. Infrastructure Pipeline"></div>
            </div>
        </div>`);
}

function addStructure() {
    const c = document.getElementById('structures-container');
    const n = c.querySelectorAll('.structure-item').length + 1;
    c.insertAdjacentHTML('beforeend', `
        <div class="structure-item border-t border-champagne-500/10 pt-5">
            <div class="flex items-center justify-between mb-4">
                <h4 class="text-sm font-semibold text-platinum-200">Structure #${n}</h4>
                <button type="button" onclick="this.closest('.structure-item').remove()" class="admin-btn-danger">Remove</button>
            </div>
            <div class="space-y-4">
                <div><label class="admin-label">Title</label><input type="text" name="structure_title[]" class="admin-input"></div>
                <div><label class="admin-label">Description</label><textarea name="structure_description[]" rows="2" class="admin-textarea"></textarea></div>
                <div><label class="admin-label">Tags</label><input type="text" name="structure_tags[]" class="admin-input"></div>
            </div>
        </div>`);
}
</script>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
