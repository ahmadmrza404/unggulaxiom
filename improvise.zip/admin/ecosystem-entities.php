<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$entity = $_GET['entity'] ?? 'axiom-agro';
$allowed = ['axiom-agro', 'axiom-halaltech', 'axiom-logistics', 'axiom-global-trade', 'axiom-capital'];
if (!in_array($entity, $allowed)) $entity = 'axiom-agro';

$data_file = __DIR__ . '/../data/ecosystem-' . $entity . '.json';
$data = json_decode(file_get_contents($data_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $post_entity = $_POST['entity'] ?? $entity;
    if (!in_array($post_entity, $allowed)) $post_entity = 'axiom-agro';
    $data_file = __DIR__ . '/../data/ecosystem-' . $post_entity . '.json';
    $data = json_decode(file_get_contents($data_file), true);

    $data['hero']['label'] = $_POST['hero_label'] ?? '';
    $data['hero']['title'] = $_POST['hero_title'] ?? '';
    $data['hero']['tagline'] = $_POST['hero_tagline'] ?? '';

    $data['sections'] = [];
    if (!empty($_POST['section_title'])) {
        foreach ($_POST['section_title'] as $i => $sec_title) {
            if (empty(trim($sec_title))) continue;

            $section = [
                'title' => trim($sec_title),
                'paragraphs' => [],
                'subsections' => []
            ];

            $raw_paras = $_POST['section_paragraphs'][$i] ?? '';
            if (!empty(trim($raw_paras))) {
                $section['paragraphs'] = array_values(array_filter(array_map('trim', explode('|||', $raw_paras))));
            }

            if (!empty($_POST['sub_subtitle'][$i])) {
                foreach ($_POST['sub_subtitle'][$i] as $j => $subtitle) {
                    if (!empty(trim($subtitle))) {
                        $section['subsections'][] = [
                            'subtitle' => trim($subtitle),
                            'text' => trim($_POST['sub_text'][$i][$j] ?? '')
                        ];
                    }
                }
            }

            $data['sections'][] = $section;
        }
    }

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Content updated successfully';
    $entity = $post_entity;
    $data_file = __DIR__ . '/../data/ecosystem-' . $entity . '.json';
    $data = json_decode(file_get_contents($data_file), true);
}

$entity_labels = [
    'axiom-agro' => 'Axiom Agro',
    'axiom-halaltech' => 'Axiom HalalTech',
    'axiom-logistics' => 'Axiom Logistics',
    'axiom-global-trade' => 'Axiom Global Trade',
    'axiom-capital' => 'Axiom Capital'
];

$page_title = 'Ecosystem Entities';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">Ecosystem Entities</h2>
        <p class="admin-sticky-header-subtitle">Manage all vertical entity pages</p>
    </div>
    <div class="flex items-center space-x-3">
        <a href="../ecosystem-<?= $entity ?>.php" target="_blank" class="admin-btn-secondary">Preview Page</a>
        <button type="submit" form="entity-form" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <div class="admin-card mb-8">
        <div class="admin-card-header">
            <h3 class="admin-card-title">Select Entity</h3>
        </div>
        <div class="flex flex-wrap gap-3">
            <?php foreach ($entity_labels as $key => $label): ?>
                <a href="?entity=<?= $key ?>"
                   class="px-5 py-3 text-sm font-medium rounded-lg transition-all <?= $entity === $key ? 'bg-champagne-400 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 border border-champagne-500/30 hover:bg-obsidian-800/80 hover:border-champagne-500/50' ?>">
                    <?= htmlspecialchars($label) ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <form method="POST" id="entity-form" class="space-y-8">
        <input type="hidden" name="entity" value="<?= htmlspecialchars($entity) ?>">

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Hero Section</h3>
                <p class="admin-card-subtitle"><?= htmlspecialchars($entity_labels[$entity]) ?> header</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Label</label>
                    <input type="text" name="hero_label" value="<?= htmlspecialchars($data['hero']['label']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="hero_title" value="<?= htmlspecialchars($data['hero']['title']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Tagline</label>
                    <textarea name="hero_tagline" rows="2" class="admin-textarea"><?= htmlspecialchars($data['hero']['tagline']) ?></textarea>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Content Sections</h3>
                <p class="admin-card-subtitle">Page body content</p>
            </div>

            <div id="sections-container" class="space-y-6">
                <?php foreach ($data['sections'] as $i => $section): ?>
                <div class="section-block admin-card-compact">
                    <div class="flex justify-between items-start mb-4">
                        <span class="text-xs text-champagne-400 font-mono uppercase tracking-wider">Section <?= $i + 1 ?></span>
                        <button type="button" onclick="this.closest('.section-block').remove()" class="admin-btn-danger">Remove</button>
                    </div>

                    <div class="space-y-4">
                        <div>
                            <label class="admin-label">Section Title</label>
                            <input type="text" name="section_title[]" value="<?= htmlspecialchars($section['title']) ?>" class="admin-input">
                        </div>

                        <div>
                            <label class="admin-label">Paragraphs <span class="admin-label-hint">(separate with |||)</span></label>
                            <textarea name="section_paragraphs[]" rows="4" class="admin-textarea"><?= htmlspecialchars(implode('|||', $section['paragraphs'] ?? [])) ?></textarea>
                        </div>

                        <?php if (!empty($section['subsections'])): ?>
                        <div class="space-y-3 pt-4 border-t border-champagne-500/10">
                            <label class="admin-label">Subsections</label>
                            <?php foreach ($section['subsections'] as $j => $sub): ?>
                            <div class="admin-card-compact">
                                <div class="space-y-3">
                                    <div>
                                        <label class="admin-label">Subtitle</label>
                                        <input type="text" name="sub_subtitle[<?= $i ?>][]" value="<?= htmlspecialchars($sub['subtitle']) ?>" class="admin-input">
                                    </div>
                                    <div>
                                        <label class="admin-label">Text</label>
                                        <textarea name="sub_text[<?= $i ?>][]" rows="3" class="admin-textarea"><?= htmlspecialchars($sub['text']) ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </form>

    <div class="h-24"></div>
</div>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
