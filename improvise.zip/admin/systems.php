<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/systems.json';
$data = json_decode(file_get_contents($data_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Hero Section
    $data['hero']['title'] = $_POST['title'] ?? '';
    $data['hero']['tagline'] = $_POST['tagline'] ?? '';
    $data['hero']['subtitle'] = $_POST['subtitle'] ?? '';

    // Overview Section
    $data['overview']['section_label'] = $_POST['overview_section_label'] ?? '';
    $data['overview']['headline'] = $_POST['overview_headline'] ?? '';
    $data['overview']['description'] = $_POST['overview_description'] ?? '';

    $data['overview']['key_metrics'] = [];
    if (!empty($_POST['metric_label'])) {
        foreach ($_POST['metric_label'] as $i => $label) {
            if (!empty($label)) {
                $data['overview']['key_metrics'][] = [
                    'label' => $label,
                    'value' => $_POST['metric_value'][$i] ?? ''
                ];
            }
        }
    }

    // Systems
    $data['systems'] = [];
    if (!empty($_POST['system_id'])) {
        foreach ($_POST['system_id'] as $i => $id) {
            if (!empty($id)) {
                $system = [
                    'id' => $id,
                    'name' => $_POST['system_name'][$i] ?? '',
                    'classification' => $_POST['system_classification'][$i] ?? '',
                    'description' => $_POST['system_description'][$i] ?? '',
                    'details' => $_POST['system_details'][$i] ?? '',
                    'capabilities' => [],
                    'technical_specifications' => [
                        'deployment_model' => $_POST['system_deployment'][$i] ?? '',
                        'integration_points' => $_POST['system_integration'][$i] ?? '',
                        'scalability' => $_POST['system_scalability'][$i] ?? '',
                        'compliance' => $_POST['system_compliance'][$i] ?? ''
                    ]
                ];

                // Capabilities for this system
                if (!empty($_POST['capability_title_' . $i])) {
                    foreach ($_POST['capability_title_' . $i] as $j => $cap_title) {
                        if (!empty($cap_title)) {
                            $system['capabilities'][] = [
                                'title' => $cap_title,
                                'description' => $_POST['capability_desc_' . $i][$j] ?? ''
                            ];
                        }
                    }
                }

                $data['systems'][] = $system;
            }
        }
    }

    // Integration Section
    $data['integration']['section_label'] = $_POST['integration_section_label'] ?? '';
    $data['integration']['title'] = $_POST['integration_title'] ?? '';
    $data['integration']['description'] = $_POST['integration_description'] ?? '';

    $data['integration']['integration_points'] = [];
    if (!empty($_POST['integration_point_title'])) {
        foreach ($_POST['integration_point_title'] as $i => $title) {
            if (!empty($title)) {
                $data['integration']['integration_points'][] = [
                    'title' => $title,
                    'description' => $_POST['integration_point_desc'][$i] ?? ''
                ];
            }
        }
    }

    // Institutional Access Section
    $data['institutional_access']['section_label'] = $_POST['institutional_section_label'] ?? '';
    $data['institutional_access']['title'] = $_POST['institutional_title'] ?? '';
    $data['institutional_access']['description'] = $_POST['institutional_description'] ?? '';

    $data['institutional_access']['access_tiers'] = [];
    if (!empty($_POST['tier_name'])) {
        foreach ($_POST['tier_name'] as $i => $tier) {
            if (!empty($tier)) {
                $data['institutional_access']['access_tiers'][] = [
                    'tier' => $tier,
                    'description' => $_POST['tier_desc'][$i] ?? ''
                ];
            }
        }
    }

    $data['institutional_access']['cta']['text'] = $_POST['cta_text'] ?? '';
    $data['institutional_access']['cta']['url'] = $_POST['cta_url'] ?? '';

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Content updated successfully';
}

$page_title = 'Systems Architecture';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">Systems Architecture</h2>
        <p class="admin-sticky-header-subtitle">Infrastructure systems configuration</p>
    </div>
    <div class="flex items-center space-x-3">
        <a href="../systems.php" target="_blank" class="admin-btn-secondary">Preview Page</a>
        <button type="submit" form="systems-form" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" id="systems-form" class="space-y-8">

        <!-- HERO SECTION -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Hero Section</h3>
                <p class="admin-card-subtitle">Page header content</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Page Title</label>
                    <input type="text" name="title" value="<?= htmlspecialchars($data['hero']['title']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Tagline</label>
                    <input type="text" name="tagline" value="<?= htmlspecialchars($data['hero']['tagline']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Subtitle</label>
                    <textarea name="subtitle" rows="2" class="admin-textarea"><?= htmlspecialchars($data['hero']['subtitle'] ?? '') ?></textarea>
                </div>
            </div>
        </div>

        <!-- OVERVIEW SECTION -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Overview Section</h3>
                <p class="admin-card-subtitle">Infrastructure overview content</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="overview_section_label" value="<?= htmlspecialchars($data['overview']['section_label'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Headline</label>
                    <input type="text" name="overview_headline" value="<?= htmlspecialchars($data['overview']['headline'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="overview_description" rows="4" class="admin-textarea"><?= htmlspecialchars($data['overview']['description'] ?? '') ?></textarea>
                </div>

                <div>
                    <label class="admin-label">Key Metrics</label>
                    <div id="metrics-container" class="space-y-4">
                        <?php if (!empty($data['overview']['key_metrics'])): ?>
                            <?php foreach ($data['overview']['key_metrics'] as $idx => $metric): ?>
                            <div class="metric-item flex gap-4">
                                <input type="text" name="metric_label[]" value="<?= htmlspecialchars($metric['label']) ?>" placeholder="Label" class="admin-input flex-1">
                                <input type="text" name="metric_value[]" value="<?= htmlspecialchars($metric['value']) ?>" placeholder="Value" class="admin-input flex-1">
                                <button type="button" onclick="this.closest('.metric-item').remove()" class="admin-btn-danger">Remove</button>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" onclick="addMetric()" class="admin-btn-add mt-4">+ Add Metric</button>
                </div>
            </div>
        </div>

        <!-- SYSTEMS -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Systems</h3>
                <p class="admin-card-subtitle">Infrastructure system definitions</p>
            </div>

            <div id="systems-container" class="space-y-8">
                <?php foreach ($data['systems'] as $idx => $sys): ?>
                <div class="system-item border-t border-champagne-500/10 pt-6">
                    <div class="flex items-center justify-between mb-4">
                        <h4 class="text-sm font-semibold text-platinum-200">System #<?= $idx + 1 ?></h4>
                        <button type="button" onclick="this.closest('.system-item').remove()" class="admin-btn-danger">Remove System</button>
                    </div>

                    <div class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="admin-label">System ID</label>
                                <input type="text" name="system_id[]" value="<?= htmlspecialchars($sys['id']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">System Name</label>
                                <input type="text" name="system_name[]" value="<?= htmlspecialchars($sys['name']) ?>" class="admin-input">
                            </div>
                            <div>
                                <label class="admin-label">Classification</label>
                                <input type="text" name="system_classification[]" value="<?= htmlspecialchars($sys['classification'] ?? '') ?>" class="admin-input">
                            </div>
                        </div>

                        <div>
                            <label class="admin-label">Description</label>
                            <textarea name="system_description[]" rows="2" class="admin-textarea"><?= htmlspecialchars($sys['description']) ?></textarea>
                        </div>

                        <div>
                            <label class="admin-label">Details</label>
                            <textarea name="system_details[]" rows="2" class="admin-textarea"><?= htmlspecialchars($sys['details']) ?></textarea>
                        </div>

                        <!-- Capabilities -->
                        <div class="border-l-2 border-champagne-500/20 pl-4">
                            <label class="admin-label">Capabilities</label>
                            <div class="capabilities-container-<?= $idx ?> space-y-3">
                                <?php if (!empty($sys['capabilities'])): ?>
                                    <?php foreach ($sys['capabilities'] as $cap): ?>
                                    <div class="capability-item bg-obsidian-900/30 p-3 rounded">
                                        <input type="text" name="capability_title_<?= $idx ?>[]" value="<?= htmlspecialchars($cap['title']) ?>" placeholder="Capability Title" class="admin-input mb-2">
                                        <textarea name="capability_desc_<?= $idx ?>[]" rows="2" placeholder="Capability Description" class="admin-textarea"><?= htmlspecialchars($cap['description']) ?></textarea>
                                        <button type="button" onclick="this.closest('.capability-item').remove()" class="admin-btn-danger mt-2">Remove</button>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <button type="button" onclick="addCapability(<?= $idx ?>)" class="admin-btn-add mt-2">+ Add Capability</button>
                        </div>

                        <!-- Technical Specifications -->
                        <div class="border-l-2 border-champagne-500/20 pl-4">
                            <label class="admin-label">Technical Specifications</label>
                            <div class="space-y-3">
                                <div>
                                    <label class="admin-label text-xs">Deployment Model</label>
                                    <textarea name="system_deployment[]" rows="2" class="admin-textarea"><?= htmlspecialchars($sys['technical_specifications']['deployment_model'] ?? '') ?></textarea>
                                </div>
                                <div>
                                    <label class="admin-label text-xs">Integration Points</label>
                                    <textarea name="system_integration[]" rows="2" class="admin-textarea"><?= htmlspecialchars($sys['technical_specifications']['integration_points'] ?? '') ?></textarea>
                                </div>
                                <div>
                                    <label class="admin-label text-xs">Scalability</label>
                                    <textarea name="system_scalability[]" rows="2" class="admin-textarea"><?= htmlspecialchars($sys['technical_specifications']['scalability'] ?? '') ?></textarea>
                                </div>
                                <div>
                                    <label class="admin-label text-xs">Compliance</label>
                                    <textarea name="system_compliance[]" rows="2" class="admin-textarea"><?= htmlspecialchars($sys['technical_specifications']['compliance'] ?? '') ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <button type="button" onclick="addSystem()" class="admin-btn-add mt-6">+ Add System</button>
        </div>


        <!-- INTEGRATION SECTION -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Systems Integration Section</h3>
                <p class="admin-card-subtitle">Cross-platform integration content</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="integration_section_label" value="<?= htmlspecialchars($data['integration']['section_label'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="integration_title" value="<?= htmlspecialchars($data['integration']['title'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="integration_description" rows="3" class="admin-textarea"><?= htmlspecialchars($data['integration']['description'] ?? '') ?></textarea>
                </div>

                <div>
                    <label class="admin-label">Integration Points</label>
                    <div id="integration-points-container" class="space-y-4">
                        <?php if (!empty($data['integration']['integration_points'])): ?>
                            <?php foreach ($data['integration']['integration_points'] as $point): ?>
                            <div class="integration-point-item bg-obsidian-900/30 p-4 rounded">
                                <input type="text" name="integration_point_title[]" value="<?= htmlspecialchars($point['title']) ?>" placeholder="Integration Point Title" class="admin-input mb-2">
                                <textarea name="integration_point_desc[]" rows="2" placeholder="Description" class="admin-textarea"><?= htmlspecialchars($point['description']) ?></textarea>
                                <button type="button" onclick="this.closest('.integration-point-item').remove()" class="admin-btn-danger mt-2">Remove</button>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" onclick="addIntegrationPoint()" class="admin-btn-add mt-4">+ Add Integration Point</button>
                </div>
            </div>
        </div>

        <!-- INSTITUTIONAL ACCESS SECTION -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Institutional Access Section</h3>
                <p class="admin-card-subtitle">Investor engagement content</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="institutional_section_label" value="<?= htmlspecialchars($data['institutional_access']['section_label'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="institutional_title" value="<?= htmlspecialchars($data['institutional_access']['title'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="institutional_description" rows="3" class="admin-textarea"><?= htmlspecialchars($data['institutional_access']['description'] ?? '') ?></textarea>
                </div>

                <div>
                    <label class="admin-label">Access Tiers</label>
                    <div id="tiers-container" class="space-y-4">
                        <?php if (!empty($data['institutional_access']['access_tiers'])): ?>
                            <?php foreach ($data['institutional_access']['access_tiers'] as $tier): ?>
                            <div class="tier-item bg-obsidian-900/30 p-4 rounded">
                                <input type="text" name="tier_name[]" value="<?= htmlspecialchars($tier['tier']) ?>" placeholder="Tier Name" class="admin-input mb-2">
                                <textarea name="tier_desc[]" rows="2" placeholder="Tier Description" class="admin-textarea"><?= htmlspecialchars($tier['description']) ?></textarea>
                                <button type="button" onclick="this.closest('.tier-item').remove()" class="admin-btn-danger mt-2">Remove</button>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" onclick="addTier()" class="admin-btn-add mt-4">+ Add Tier</button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="admin-label">CTA Button Text</label>
                        <input type="text" name="cta_text" value="<?= htmlspecialchars($data['institutional_access']['cta']['text'] ?? '') ?>" class="admin-input">
                    </div>
                    <div>
                        <label class="admin-label">CTA Button URL</label>
                        <input type="text" name="cta_url" value="<?= htmlspecialchars($data['institutional_access']['cta']['url'] ?? '') ?>" class="admin-input">
                    </div>
                </div>
            </div>
        </div>

    </form>

    <div class="h-24"></div>
</div>

<script>
let systemCounter = <?= count($data['systems']) ?>;

function addMetric() {
    const container = document.getElementById('metrics-container');
    const html = `
        <div class="metric-item flex gap-4">
            <input type="text" name="metric_label[]" placeholder="Label" class="admin-input flex-1">
            <input type="text" name="metric_value[]" placeholder="Value" class="admin-input flex-1">
            <button type="button" onclick="this.closest('.metric-item').remove()" class="admin-btn-danger">Remove</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addCapability(systemIndex) {
    const container = document.querySelector('.capabilities-container-' + systemIndex);
    const html = `
        <div class="capability-item bg-obsidian-900/30 p-3 rounded">
            <input type="text" name="capability_title_${systemIndex}[]" placeholder="Capability Title" class="admin-input mb-2">
            <textarea name="capability_desc_${systemIndex}[]" rows="2" placeholder="Capability Description" class="admin-textarea"></textarea>
            <button type="button" onclick="this.closest('.capability-item').remove()" class="admin-btn-danger mt-2">Remove</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addSystem() {
    const container = document.getElementById('systems-container');
    const count = systemCounter++;
    const html = `
        <div class="system-item border-t border-champagne-500/10 pt-6">
            <div class="flex items-center justify-between mb-4">
                <h4 class="text-sm font-semibold text-platinum-200">System #${count + 1}</h4>
                <button type="button" onclick="this.closest('.system-item').remove()" class="admin-btn-danger">Remove System</button>
            </div>
            <div class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="admin-label">System ID</label>
                        <input type="text" name="system_id[]" class="admin-input">
                    </div>
                    <div>
                        <label class="admin-label">System Name</label>
                        <input type="text" name="system_name[]" class="admin-input">
                    </div>
                    <div>
                        <label class="admin-label">Classification</label>
                        <input type="text" name="system_classification[]" class="admin-input">
                    </div>
                </div>
                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="system_description[]" rows="2" class="admin-textarea"></textarea>
                </div>
                <div>
                    <label class="admin-label">Details</label>
                    <textarea name="system_details[]" rows="2" class="admin-textarea"></textarea>
                </div>
                <div class="border-l-2 border-champagne-500/20 pl-4">
                    <label class="admin-label">Capabilities</label>
                    <div class="capabilities-container-${count} space-y-3"></div>
                    <button type="button" onclick="addCapability(${count})" class="admin-btn-add mt-2">+ Add Capability</button>
                </div>
                <div class="border-l-2 border-champagne-500/20 pl-4">
                    <label class="admin-label">Technical Specifications</label>
                    <div class="space-y-3">
                        <div>
                            <label class="admin-label text-xs">Deployment Model</label>
                            <textarea name="system_deployment[]" rows="2" class="admin-textarea"></textarea>
                        </div>
                        <div>
                            <label class="admin-label text-xs">Integration Points</label>
                            <textarea name="system_integration[]" rows="2" class="admin-textarea"></textarea>
                        </div>
                        <div>
                            <label class="admin-label text-xs">Scalability</label>
                            <textarea name="system_scalability[]" rows="2" class="admin-textarea"></textarea>
                        </div>
                        <div>
                            <label class="admin-label text-xs">Compliance</label>
                            <textarea name="system_compliance[]" rows="2" class="admin-textarea"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addIntegrationPoint() {
    const container = document.getElementById('integration-points-container');
    const html = `
        <div class="integration-point-item bg-obsidian-900/30 p-4 rounded">
            <input type="text" name="integration_point_title[]" placeholder="Integration Point Title" class="admin-input mb-2">
            <textarea name="integration_point_desc[]" rows="2" placeholder="Description" class="admin-textarea"></textarea>
            <button type="button" onclick="this.closest('.integration-point-item').remove()" class="admin-btn-danger mt-2">Remove</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addTier() {
    const container = document.getElementById('tiers-container');
    const html = `
        <div class="tier-item bg-obsidian-900/30 p-4 rounded">
            <input type="text" name="tier_name[]" placeholder="Tier Name" class="admin-input mb-2">
            <textarea name="tier_desc[]" rows="2" placeholder="Tier Description" class="admin-textarea"></textarea>
            <button type="button" onclick="this.closest('.tier-item').remove()" class="admin-btn-danger mt-2">Remove</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}
</script>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
