<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/capital.json';
$data = json_decode(file_get_contents($data_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Hero Section
    $data['hero']['title'] = $_POST['title'] ?? '';
    $data['hero']['tagline'] = $_POST['tagline'] ?? '';
    $data['hero']['subtitle'] = $_POST['subtitle'] ?? '';

    // Overview Section
    $data['overview']['section_label'] = $_POST['overview_section_label'] ?? '';
    $data['overview']['headline'] = $_POST['overview_headline'] ?? '';
    $data['overview']['description'] = $_POST['overview_description'] ?? '';

    $data['overview']['key_metrics'] = [];
    if (!empty($_POST['metric_label'])) {
        foreach ($_POST['metric_label'] as $i => $label) {
            if (!empty($label)) {
                $data['overview']['key_metrics'][] = [
                    'label' => $label,
                    'value' => $_POST['metric_value'][$i] ?? '',
                    'description' => $_POST['metric_desc'][$i] ?? ''
                ];
            }
        }
    }

    // Participation Structures
    $data['participation_structures']['section_label'] = $_POST['section_label'] ?? '';

    $data['participation_structures']['structures'] = [];
    if (!empty($_POST['structure_code'])) {
        foreach ($_POST['structure_code'] as $i => $code) {
            if (!empty($code)) {
                $structure = [
                    'code' => $code,
                    'name' => $_POST['structure_name'][$i] ?? '',
                    'description' => $_POST['structure_description'][$i] ?? '',
                    'details' => [
                        'minimum_investment' => $_POST['struct_min_inv_' . $i][0] ?? '',
                        'ownership_range' => $_POST['struct_ownership_' . $i][0] ?? '',
                        'governance' => $_POST['struct_governance_' . $i][0] ?? '',
                        'return_mechanism' => $_POST['struct_return_' . $i][0] ?? '',
                        'exit_options' => $_POST['struct_exit_' . $i][0] ?? ''
                    ],
                    'use_cases' => []
                ];

                if (!empty($_POST['use_case_' . $i])) {
                    foreach ($_POST['use_case_' . $i] as $use_case) {
                        if (!empty($use_case)) {
                            $structure['use_cases'][] = $use_case;
                        }
                    }
                }

                $data['participation_structures']['structures'][] = $structure;
            }
        }
    }

    // Returns Analysis
    $data['returns_analysis']['section_label'] = $_POST['returns_section_label'] ?? '';
    $data['returns_analysis']['title'] = $_POST['returns_title'] ?? '';
    $data['returns_analysis']['description'] = $_POST['returns_description'] ?? '';

    $data['returns_analysis']['scenarios'] = [];
    if (!empty($_POST['scenario_name'])) {
        foreach ($_POST['scenario_name'] as $i => $name) {
            if (!empty($name)) {
                $data['returns_analysis']['scenarios'][] = [
                    'scenario' => $name,
                    'irr' => $_POST['scenario_irr'][$i] ?? '',
                    'multiple' => $_POST['scenario_multiple'][$i] ?? '',
                    'assumptions' => $_POST['scenario_assumptions'][$i] ?? ''
                ];
            }
        }
    }

    // Risk Mitigation
    $data['risk_mitigation']['section_label'] = $_POST['risk_section_label'] ?? '';
    $data['risk_mitigation']['title'] = $_POST['risk_title'] ?? '';

    $data['risk_mitigation']['categories'] = [];
    if (!empty($_POST['risk_name'])) {
        foreach ($_POST['risk_name'] as $i => $name) {
            if (!empty($name)) {
                $data['risk_mitigation']['categories'][] = [
                    'risk' => $name,
                    'mitigation' => $_POST['risk_mitigation'][$i] ?? '',
                    'residual' => $_POST['risk_residual'][$i] ?? ''
                ];
            }
        }
    }

    // Governance
    $data['governance']['section_label'] = $_POST['gov_section_label'] ?? '';
    $data['governance']['title'] = $_POST['gov_title'] ?? '';
    $data['governance']['description'] = $_POST['gov_description'] ?? '';

    $data['governance']['mechanisms'] = [];
    if (!empty($_POST['gov_mechanism'])) {
        foreach ($_POST['gov_mechanism'] as $i => $mechanism) {
            if (!empty($mechanism)) {
                $data['governance']['mechanisms'][] = [
                    'mechanism' => $mechanism,
                    'description' => $_POST['gov_mech_desc'][$i] ?? ''
                ];
            }
        }
    }

    // CTA
    $data['cta']['text'] = $_POST['cta_text'] ?? '';
    $data['cta']['button_text'] = $_POST['button_text'] ?? '';
    $data['cta']['button_url'] = $_POST['button_url'] ?? '';

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Content updated successfully';
}

$page_title = 'Capital Page';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">Capital Page Content</h2>
        <p class="admin-sticky-header-subtitle">Institutional capital architecture</p>
    </div>
    <div class="flex items-center space-x-3">
        <a href="../capital.php" target="_blank" class="admin-btn-secondary">Preview Page</a>
        <button type="submit" form="capital-form" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" id="capital-form" class="space-y-8">

        <!-- HERO SECTION -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Hero Section</h3>
                <p class="admin-card-subtitle">Main banner content</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Hero Title</label>
                    <input type="text" name="title" value="<?= htmlspecialchars($data['hero']['title']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Hero Tagline</label>
                    <textarea name="tagline" rows="2" class="admin-textarea"><?= htmlspecialchars($data['hero']['tagline']) ?></textarea>
                </div>

                <div>
                    <label class="admin-label">Hero Subtitle</label>
                    <textarea name="subtitle" rows="2" class="admin-textarea"><?= htmlspecialchars($data['hero']['subtitle'] ?? '') ?></textarea>
                </div>
            </div>
        </div>

        <!-- OVERVIEW SECTION -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Overview Section</h3>
                <p class="admin-card-subtitle">Capital framework overview</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="overview_section_label" value="<?= htmlspecialchars($data['overview']['section_label'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Headline</label>
                    <input type="text" name="overview_headline" value="<?= htmlspecialchars($data['overview']['headline'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="overview_description" rows="4" class="admin-textarea"><?= htmlspecialchars($data['overview']['description'] ?? '') ?></textarea>
                </div>

                <div>
                    <label class="admin-label">Key Metrics</label>
                    <div id="metrics-container" class="space-y-4">
                        <?php if (!empty($data['overview']['key_metrics'])): ?>
                            <?php foreach ($data['overview']['key_metrics'] as $metric): ?>
                            <div class="metric-item bg-obsidian-900/30 p-4 rounded">
                                <div class="grid grid-cols-3 gap-4">
                                    <input type="text" name="metric_label[]" value="<?= htmlspecialchars($metric['label']) ?>" placeholder="Label" class="admin-input">
                                    <input type="text" name="metric_value[]" value="<?= htmlspecialchars($metric['value']) ?>" placeholder="Value" class="admin-input">
                                    <input type="text" name="metric_desc[]" value="<?= htmlspecialchars($metric['description']) ?>" placeholder="Description" class="admin-input">
                                </div>
                                <button type="button" onclick="this.closest('.metric-item').remove()" class="admin-btn-danger mt-2">Remove</button>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" onclick="addMetric()" class="admin-btn-add mt-4">+ Add Metric</button>
                </div>
            </div>
        </div>

        <!-- PARTICIPATION STRUCTURES -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Participation Structures</h3>
                <p class="admin-card-subtitle">Investment structure options</p>
            </div>

            <div class="space-y-6">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="section_label" value="<?= htmlspecialchars($data['participation_structures']['section_label']) ?>" class="admin-input">
                </div>

                <div id="structures-container" class="space-y-8">
                    <?php foreach ($data['participation_structures']['structures'] as $idx => $struct): ?>
                    <div class="structure-item border-t border-champagne-500/10 pt-6">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="text-sm font-semibold text-platinum-200">Structure #<?= $idx + 1 ?></h4>
                            <button type="button" onclick="this.closest('.structure-item').remove()" class="admin-btn-danger">Remove</button>
                        </div>

                        <div class="space-y-4">
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                    <label class="admin-label">Code</label>
                                    <input type="text" name="structure_code[]" value="<?= htmlspecialchars($struct['code']) ?>" class="admin-input">
                                </div>
                                <div class="md:col-span-2">
                                    <label class="admin-label">Structure Name</label>
                                    <input type="text" name="structure_name[]" value="<?= htmlspecialchars($struct['name']) ?>" class="admin-input">
                                </div>
                            </div>

                            <div>
                                <label class="admin-label">Description</label>
                                <textarea name="structure_description[]" rows="2" class="admin-textarea"><?= htmlspecialchars($struct['description']) ?></textarea>
                            </div>

                            <!-- Details -->
                            <div class="border-l-2 border-champagne-500/20 pl-4">
                                <label class="admin-label">Investment Details</label>
                                <div class="space-y-3">
                                    <input type="text" name="struct_min_inv_<?= $idx ?>[]" value="<?= htmlspecialchars($struct['details']['minimum_investment'] ?? '') ?>" placeholder="Minimum Investment" class="admin-input">
                                    <input type="text" name="struct_ownership_<?= $idx ?>[]" value="<?= htmlspecialchars($struct['details']['ownership_range'] ?? '') ?>" placeholder="Ownership Range" class="admin-input">
                                    <textarea name="struct_governance_<?= $idx ?>[]" rows="2" placeholder="Governance" class="admin-textarea"><?= htmlspecialchars($struct['details']['governance'] ?? '') ?></textarea>
                                    <textarea name="struct_return_<?= $idx ?>[]" rows="2" placeholder="Return Mechanism" class="admin-textarea"><?= htmlspecialchars($struct['details']['return_mechanism'] ?? '') ?></textarea>
                                    <textarea name="struct_exit_<?= $idx ?>[]" rows="2" placeholder="Exit Options" class="admin-textarea"><?= htmlspecialchars($struct['details']['exit_options'] ?? '') ?></textarea>
                                </div>
                            </div>

                            <!-- Use Cases -->
                            <div class="border-l-2 border-champagne-500/20 pl-4">
                                <label class="admin-label">Use Cases</label>
                                <div class="use-cases-<?= $idx ?> space-y-2">
                                    <?php if (!empty($struct['use_cases'])): ?>
                                        <?php foreach ($struct['use_cases'] as $use_case): ?>
                                        <div class="flex gap-2">
                                            <input type="text" name="use_case_<?= $idx ?>[]" value="<?= htmlspecialchars($use_case) ?>" class="admin-input flex-1">
                                            <button type="button" onclick="this.parentElement.remove()" class="admin-btn-danger">Remove</button>
                                        </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                                <button type="button" onclick="addUseCase(<?= $idx ?>)" class="admin-btn-add mt-2">+ Add Use Case</button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <button type="button" onclick="addStructure()" class="admin-btn-add">+ Add Structure</button>
            </div>
        </div>

        <!-- RETURNS ANALYSIS -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Returns Analysis</h3>
                <p class="admin-card-subtitle">Investment return scenarios</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="returns_section_label" value="<?= htmlspecialchars($data['returns_analysis']['section_label'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="returns_title" value="<?= htmlspecialchars($data['returns_analysis']['title'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="returns_description" rows="3" class="admin-textarea"><?= htmlspecialchars($data['returns_analysis']['description'] ?? '') ?></textarea>
                </div>

                <div>
                    <label class="admin-label">Scenarios</label>
                    <div id="scenarios-container" class="space-y-4">
                        <?php if (!empty($data['returns_analysis']['scenarios'])): ?>
                            <?php foreach ($data['returns_analysis']['scenarios'] as $scenario): ?>
                            <div class="scenario-item bg-obsidian-900/30 p-4 rounded">
                                <div class="grid grid-cols-4 gap-4">
                                    <input type="text" name="scenario_name[]" value="<?= htmlspecialchars($scenario['scenario']) ?>" placeholder="Scenario Name" class="admin-input">
                                    <input type="text" name="scenario_irr[]" value="<?= htmlspecialchars($scenario['irr']) ?>" placeholder="IRR" class="admin-input">
                                    <input type="text" name="scenario_multiple[]" value="<?= htmlspecialchars($scenario['multiple']) ?>" placeholder="Multiple" class="admin-input">
                                    <input type="text" name="scenario_assumptions[]" value="<?= htmlspecialchars($scenario['assumptions']) ?>" placeholder="Assumptions" class="admin-input">
                                </div>
                                <button type="button" onclick="this.closest('.scenario-item').remove()" class="admin-btn-danger mt-2">Remove</button>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" onclick="addScenario()" class="admin-btn-add mt-4">+ Add Scenario</button>
                </div>
            </div>
        </div>

        <!-- RISK MITIGATION -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Risk Mitigation</h3>
                <p class="admin-card-subtitle">Risk categories and mitigation strategies</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="risk_section_label" value="<?= htmlspecialchars($data['risk_mitigation']['section_label'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="risk_title" value="<?= htmlspecialchars($data['risk_mitigation']['title'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Risk Categories</label>
                    <div id="risks-container" class="space-y-4">
                        <?php if (!empty($data['risk_mitigation']['categories'])): ?>
                            <?php foreach ($data['risk_mitigation']['categories'] as $risk): ?>
                            <div class="risk-item bg-obsidian-900/30 p-4 rounded">
                                <div class="grid grid-cols-3 gap-4 mb-2">
                                    <input type="text" name="risk_name[]" value="<?= htmlspecialchars($risk['risk']) ?>" placeholder="Risk Name" class="admin-input">
                                    <input type="text" name="risk_residual[]" value="<?= htmlspecialchars($risk['residual']) ?>" placeholder="Residual Level" class="admin-input">
                                </div>
                                <textarea name="risk_mitigation[]" rows="2" placeholder="Mitigation Strategy" class="admin-textarea"><?= htmlspecialchars($risk['mitigation']) ?></textarea>
                                <button type="button" onclick="this.closest('.risk-item').remove()" class="admin-btn-danger mt-2">Remove</button>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" onclick="addRisk()" class="admin-btn-add mt-4">+ Add Risk</button>
                </div>
            </div>
        </div>

        <!-- GOVERNANCE -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Governance Framework</h3>
                <p class="admin-card-subtitle">Institutional governance mechanisms</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="gov_section_label" value="<?= htmlspecialchars($data['governance']['section_label'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="gov_title" value="<?= htmlspecialchars($data['governance']['title'] ?? '') ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="gov_description" rows="3" class="admin-textarea"><?= htmlspecialchars($data['governance']['description'] ?? '') ?></textarea>
                </div>

                <div>
                    <label class="admin-label">Governance Mechanisms</label>
                    <div id="governance-container" class="space-y-4">
                        <?php if (!empty($data['governance']['mechanisms'])): ?>
                            <?php foreach ($data['governance']['mechanisms'] as $mech): ?>
                            <div class="governance-item bg-obsidian-900/30 p-4 rounded">
                                <input type="text" name="gov_mechanism[]" value="<?= htmlspecialchars($mech['mechanism']) ?>" placeholder="Mechanism Name" class="admin-input mb-2">
                                <textarea name="gov_mech_desc[]" rows="2" placeholder="Description" class="admin-textarea"><?= htmlspecialchars($mech['description']) ?></textarea>
                                <button type="button" onclick="this.closest('.governance-item').remove()" class="admin-btn-danger mt-2">Remove</button>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" onclick="addGovernance()" class="admin-btn-add mt-4">+ Add Mechanism</button>
                </div>
            </div>
        </div>

        <!-- CTA SECTION -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Call to Action</h3>
                <p class="admin-card-subtitle">Data room access section</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">CTA Text</label>
                    <textarea name="cta_text" rows="2" class="admin-textarea"><?= htmlspecialchars($data['cta']['text']) ?></textarea>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="admin-label">Button Text</label>
                        <input type="text" name="button_text" value="<?= htmlspecialchars($data['cta']['button_text']) ?>" class="admin-input">
                    </div>
                    <div>
                        <label class="admin-label">Button URL</label>
                        <input type="text" name="button_url" value="<?= htmlspecialchars($data['cta']['button_url']) ?>" class="admin-input">
                    </div>
                </div>
            </div>
        </div>

    </form>

    <div class="h-24"></div>
</div>

<script>
let structureCounter = <?= count($data['participation_structures']['structures']) ?>;

function addMetric() {
    const container = document.getElementById('metrics-container');
    const html = `
        <div class="metric-item bg-obsidian-900/30 p-4 rounded">
            <div class="grid grid-cols-3 gap-4">
                <input type="text" name="metric_label[]" placeholder="Label" class="admin-input">
                <input type="text" name="metric_value[]" placeholder="Value" class="admin-input">
                <input type="text" name="metric_desc[]" placeholder="Description" class="admin-input">
            </div>
            <button type="button" onclick="this.closest('.metric-item').remove()" class="admin-btn-danger mt-2">Remove</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addUseCase(idx) {
    const container = document.querySelector('.use-cases-' + idx);
    const html = `
        <div class="flex gap-2">
            <input type="text" name="use_case_${idx}[]" class="admin-input flex-1">
            <button type="button" onclick="this.parentElement.remove()" class="admin-btn-danger">Remove</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addStructure() {
    const container = document.getElementById('structures-container');
    const count = structureCounter++;
    const html = `
        <div class="structure-item border-t border-champagne-500/10 pt-6">
            <div class="flex items-center justify-between mb-4">
                <h4 class="text-sm font-semibold text-platinum-200">Structure #${count + 1}</h4>
                <button type="button" onclick="this.closest('.structure-item').remove()" class="admin-btn-danger">Remove</button>
            </div>
            <div class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="admin-label">Code</label>
                        <input type="text" name="structure_code[]" class="admin-input">
                    </div>
                    <div class="md:col-span-2">
                        <label class="admin-label">Structure Name</label>
                        <input type="text" name="structure_name[]" class="admin-input">
                    </div>
                </div>
                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="structure_description[]" rows="2" class="admin-textarea"></textarea>
                </div>
                <div class="border-l-2 border-champagne-500/20 pl-4">
                    <label class="admin-label">Investment Details</label>
                    <div class="space-y-3">
                        <input type="text" name="struct_min_inv_${count}[]" placeholder="Minimum Investment" class="admin-input">
                        <input type="text" name="struct_ownership_${count}[]" placeholder="Ownership Range" class="admin-input">
                        <textarea name="struct_governance_${count}[]" rows="2" placeholder="Governance" class="admin-textarea"></textarea>
                        <textarea name="struct_return_${count}[]" rows="2" placeholder="Return Mechanism" class="admin-textarea"></textarea>
                        <textarea name="struct_exit_${count}[]" rows="2" placeholder="Exit Options" class="admin-textarea"></textarea>
                    </div>
                </div>
                <div class="border-l-2 border-champagne-500/20 pl-4">
                    <label class="admin-label">Use Cases</label>
                    <div class="use-cases-${count} space-y-2"></div>
                    <button type="button" onclick="addUseCase(${count})" class="admin-btn-add mt-2">+ Add Use Case</button>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addScenario() {
    const container = document.getElementById('scenarios-container');
    const html = `
        <div class="scenario-item bg-obsidian-900/30 p-4 rounded">
            <div class="grid grid-cols-4 gap-4">
                <input type="text" name="scenario_name[]" placeholder="Scenario Name" class="admin-input">
                <input type="text" name="scenario_irr[]" placeholder="IRR" class="admin-input">
                <input type="text" name="scenario_multiple[]" placeholder="Multiple" class="admin-input">
                <input type="text" name="scenario_assumptions[]" placeholder="Assumptions" class="admin-input">
            </div>
            <button type="button" onclick="this.closest('.scenario-item').remove()" class="admin-btn-danger mt-2">Remove</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addRisk() {
    const container = document.getElementById('risks-container');
    const html = `
        <div class="risk-item bg-obsidian-900/30 p-4 rounded">
            <div class="grid grid-cols-3 gap-4 mb-2">
                <input type="text" name="risk_name[]" placeholder="Risk Name" class="admin-input">
                <input type="text" name="risk_residual[]" placeholder="Residual Level" class="admin-input">
            </div>
            <textarea name="risk_mitigation[]" rows="2" placeholder="Mitigation Strategy" class="admin-textarea"></textarea>
            <button type="button" onclick="this.closest('.risk-item').remove()" class="admin-btn-danger mt-2">Remove</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function addGovernance() {
    const container = document.getElementById('governance-container');
    const html = `
        <div class="governance-item bg-obsidian-900/30 p-4 rounded">
            <input type="text" name="gov_mechanism[]" placeholder="Mechanism Name" class="admin-input mb-2">
            <textarea name="gov_mech_desc[]" rows="2" placeholder="Description" class="admin-textarea"></textarea>
            <button type="button" onclick="this.closest('.governance-item').remove()" class="admin-btn-danger mt-2">Remove</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}
</script>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
