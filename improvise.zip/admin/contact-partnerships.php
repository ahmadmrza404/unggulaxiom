<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/contact-partnerships.json';
$data = json_decode(file_get_contents($data_file), true);

$page = $_GET['page'] ?? 'contact';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $page = $_POST['page'] ?? 'contact';

    if ($page === 'contact') {
        $data['contact']['title'] = $_POST['title'] ?? '';
        $data['contact']['location'] = $_POST['location'] ?? '';
        $data['contact']['email'] = $_POST['email'] ?? '';
        $data['contact']['response_time'] = $_POST['response_time'] ?? '';
        $data['contact']['description'] = $_POST['description'] ?? '';

        $inquiry_types = array_filter(array_map('trim', explode("\n", $_POST['inquiry_types'] ?? '')));
        $data['contact']['inquiry_types'] = $inquiry_types;
    } elseif ($page === 'partnerships') {
        $data['partnerships']['title'] = $_POST['title'] ?? '';
        $data['partnerships']['location'] = $_POST['location'] ?? '';
        $data['partnerships']['purpose'] = $_POST['purpose'] ?? '';
        $data['partnerships']['response_timeline'] = $_POST['response_timeline'] ?? '';

        $data['partnerships']['structures'] = [];
        if (!empty($_POST['structure_name'])) {
            foreach ($_POST['structure_name'] as $i => $name) {
                if (!empty($name)) {
                    $data['partnerships']['structures'][] = [
                        'name' => $name,
                        'description' => $_POST['structure_description'][$i] ?? ''
                    ];
                }
            }
        }

        $institutional = array_filter(array_map('trim', explode("\n", $_POST['institutional_requirements'] ?? '')));
        $data['partnerships']['criteria']['institutional_requirements'] = $institutional;

        $value = array_filter(array_map('trim', explode("\n", $_POST['value_requirements'] ?? '')));
        $data['partnerships']['criteria']['value_requirements'] = $value;

        $investment_ranges = array_filter(array_map('trim', explode("\n", $_POST['investment_ranges'] ?? '')));
        $data['partnerships']['investment_ranges'] = $investment_ranges;
    }

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Content updated successfully';
}

$current_data = $data[$page] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact & Partnerships - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="includes/admin-design-system.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { serif: ['Cormorant Garamond', 'serif'], sans: ['Inter', 'sans-serif'] },
                    colors: {
                        obsidian: { 900: '#0a0a0a', 950: '#050505' },
                        champagne: { 400: '#d4af37', 500: '#c5a028', 600: '#b69121' },
                        platinum: { 50: '#f5f5f5', 200: '#d1d1d1', 300: '#b0b0b0', 400: '#909090' }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-obsidian-950 text-platinum-50 font-sans">
    <nav class="bg-obsidian-900 border-b border-champagne-500/20 px-6 py-4 sticky top-0 z-50 backdrop-blur-sm bg-obsidian-900/95">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex gap-6 items-center">
                <a href="index.php" class="text-champagne-500 hover:text-champagne-400 transition-colors flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Dashboard
                </a>
                <h1 class="text-xl font-serif text-platinum-50">Contact & Partnerships</h1>
            </div>
            <a href="logout.php" class="text-sm text-platinum-300 hover:text-champagne-400 transition-colors">Logout</a>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-6 py-8">
        <?php if ($success): ?>
        <div class="admin-alert admin-alert-success">
            <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            <span><?= htmlspecialchars($success) ?></span>
        </div>
        <?php endif; ?>

        <div class="admin-card-compact mb-6">
            <h2 class="admin-card-title mb-4">Select Page</h2>
            <div class="grid grid-cols-2 gap-3">
                <a href="?page=contact" class="<?= $page === 'contact' ? 'admin-tab admin-tab-active' : 'admin-tab admin-tab-inactive' ?> text-center">Contact</a>
                <a href="?page=partnerships" class="<?= $page === 'partnerships' ? 'admin-tab admin-tab-active' : 'admin-tab admin-tab-inactive' ?> text-center">Partnerships</a>
            </div>
        </div>

        <form method="POST" class="space-y-6">
            <input type="hidden" name="page" value="<?= htmlspecialchars($page) ?>">

            <?php if ($page === 'contact'): ?>
                <?php include __DIR__ . '/partials/contact-form.php'; ?>
            <?php else: ?>
                <?php include __DIR__ . '/partials/partnerships-form.php'; ?>
            <?php endif; ?>

            <div class="flex gap-4">
                <button type="submit" class="admin-btn-primary">Save Changes</button>
                <a href="index.php" class="admin-btn-secondary inline-block">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>
