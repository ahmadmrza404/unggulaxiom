<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/sectors-cipu-capital.json';
$data = json_decode(file_get_contents($data_file), true);

$page = $_GET['page'] ?? 'sectors';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $page = $_POST['page'] ?? 'sectors';

    if ($page === 'sectors') {
        $data['sectors']['title'] = $_POST['title'] ?? '';
        $data['sectors']['tagline'] = $_POST['tagline'] ?? '';

        $data['sectors']['sectors'] = [];
        if (!empty($_POST['sector_name'])) {
            foreach ($_POST['sector_name'] as $i => $name) {
                if (!empty($name)) {
                    $features = array_filter(array_map('trim', explode("\n", $_POST['sector_features'][$i] ?? '')));
                    $data['sectors']['sectors'][] = [
                        'name' => $name,
                        'description' => $_POST['sector_description'][$i] ?? '',
                        'features' => $features
                    ];
                }
            }
        }
    } elseif ($page === 'cipu') {
        $data['cipu']['project_name'] = $_POST['project_name'] ?? '';
        $data['cipu']['status'] = $_POST['status'] ?? '';
        $data['cipu']['subtitle'] = $_POST['subtitle'] ?? '';
        $data['cipu']['location'] = $_POST['location'] ?? '';
        $data['cipu']['core_purpose'] = $_POST['core_purpose'] ?? '';
        $data['cipu']['strategic_role'] = $_POST['strategic_role'] ?? '';

        $infrastructure = array_filter(array_map('trim', explode("\n", $_POST['infrastructure'] ?? '')));
        $data['cipu']['infrastructure'] = $infrastructure;

        $standards = array_filter(array_map('trim', explode("\n", $_POST['standards'] ?? '')));
        $data['cipu']['standards'] = $standards;

        $production = array_filter(array_map('trim', explode("\n", $_POST['production_focus'] ?? '')));
        $data['cipu']['production_focus'] = $production;

        $technology = array_filter(array_map('trim', explode("\n", $_POST['technology'] ?? '')));
        $data['cipu']['technology'] = $technology;
    } elseif ($page === 'capital') {
        $data['capital']['title'] = $_POST['title'] ?? '';
        $data['capital']['tagline'] = $_POST['tagline'] ?? '';
        $data['capital']['intro'] = $_POST['intro'] ?? '';
        $data['capital']['cta_text'] = $_POST['cta_text'] ?? '';
        $data['capital']['disclaimer'] = $_POST['disclaimer'] ?? '';

        $data['capital']['structures'] = [];
        if (!empty($_POST['structure_name'])) {
            foreach ($_POST['structure_name'] as $i => $name) {
                if (!empty($name)) {
                    $features = array_filter(array_map('trim', explode("\n", $_POST['structure_features'][$i] ?? '')));
                    $data['capital']['structures'][] = [
                        'name' => $name,
                        'description' => $_POST['structure_description'][$i] ?? '',
                        'features' => $features
                    ];
                }
            }
        }
    }

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Content updated successfully';
}

$current_data = $data[$page] ?? [];
$page_title = 'Sectors, CIPU & Capital';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="bg-obsidian-900 border-b border-champagne-500/20 px-8 py-8">
    <div class="max-w-7xl mx-auto">
        <h2 class="text-3xl font-semibold text-platinum-100 mb-2">Sectors, CIPU & Capital</h2>
        <p class="text-platinum-400">Manage sector pages and capital structures</p>
    </div>
</div>

<div class="max-w-7xl mx-auto px-8 py-12">
    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success mb-8">
        <svg class="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <div class="admin-card mb-8">
        <h3 class="text-lg font-semibold text-platinum-100 mb-4">Select Page</h3>
        <div class="grid grid-cols-3 gap-3">
            <a href="?page=sectors" class="<?= $page === 'sectors' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-4 py-3 text-center rounded-lg transition-colors font-medium">Sectors</a>
            <a href="?page=cipu" class="<?= $page === 'cipu' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-4 py-3 text-center rounded-lg transition-colors font-medium">CIPU</a>
            <a href="?page=capital" class="<?= $page === 'capital' ? 'bg-champagne-500 text-obsidian-950' : 'bg-obsidian-800 text-platinum-300 hover:bg-obsidian-800/80' ?> px-4 py-3 text-center rounded-lg transition-colors font-medium">Capital</a>
        </div>
    </div>

    <form method="POST" class="space-y-6">
        <input type="hidden" name="page" value="<?= htmlspecialchars($page) ?>">

        <?php if ($page === 'sectors'): ?>
            <?php include __DIR__ . '/partials/sectors-form.php'; ?>
        <?php elseif ($page === 'cipu'): ?>
            <?php include __DIR__ . '/partials/cipu-form.php'; ?>
        <?php else: ?>
            <?php include __DIR__ . '/partials/capital-form.php'; ?>
        <?php endif; ?>

        <div class="flex gap-4 pt-6">
            <button type="submit" class="admin-btn-primary">Save Changes</button>
            <a href="index.php" class="admin-btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
