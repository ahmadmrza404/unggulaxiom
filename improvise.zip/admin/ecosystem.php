<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/ecosystem.json';
$data = json_decode(file_get_contents($data_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['hero']['section_label'] = $_POST['section_label'] ?? '';
    $data['hero']['title'] = $_POST['title'] ?? '';
    $data['hero']['description'] = $_POST['description'] ?? '';
    $data['overview'] = $_POST['overview'] ?? '';

    $data['verticals'] = [];
    if (!empty($_POST['vertical_name'])) {
        foreach ($_POST['vertical_name'] as $i => $name) {
            if (!empty($name)) {
                $data['verticals'][] = [
                    'number' => $_POST['vertical_number'][$i] ?? '',
                    'name' => $name,
                    'tagline' => $_POST['vertical_tagline'][$i] ?? '',
                    'description' => $_POST['vertical_description'][$i] ?? '',
                    'url' => $_POST['vertical_url'][$i] ?? ''
                ];
            }
        }
    }

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    $success = 'Content updated successfully';
}

$page_title = 'Ecosystem Platform';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">Ecosystem Platform</h2>
        <p class="admin-sticky-header-subtitle">Integrated verticals overview</p>
    </div>
    <div class="flex items-center space-x-3">
        <a href="../ecosystem.php" target="_blank" class="admin-btn-secondary">Preview Page</a>
        <button type="submit" form="ecosystem-form" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" id="ecosystem-form" class="space-y-8">

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Hero Section</h3>
                <p class="admin-card-subtitle">Platform header content</p>
            </div>

            <div class="admin-form-section">
                <div>
                    <label class="admin-label">Section Label</label>
                    <input type="text" name="section_label" value="<?= htmlspecialchars($data['hero']['section_label']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Title</label>
                    <input type="text" name="title" value="<?= htmlspecialchars($data['hero']['title']) ?>" class="admin-input">
                </div>

                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="description" rows="3" class="admin-textarea"><?= htmlspecialchars($data['hero']['description']) ?></textarea>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Platform Overview</h3>
                <p class="admin-card-subtitle">Ecosystem introduction paragraph</p>
            </div>

            <div>
                <label class="admin-label">Overview Text</label>
                <textarea name="overview" rows="4" class="admin-textarea"><?= htmlspecialchars($data['overview']) ?></textarea>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Verticals</h3>
                <p class="admin-card-subtitle">Platform divisions and entities</p>
            </div>

            <div id="verticals-container" class="space-y-6">
                <?php foreach ($data['verticals'] as $idx => $v): ?>
                <div class="vertical-item border-t border-champagne-500/10 pt-6">
                    <div class="flex items-center justify-between mb-4">
                        <h4 class="text-sm font-semibold text-platinum-200">Vertical #<?= $idx + 1 ?></h4>
                        <button type="button" onclick="this.closest('.vertical-item').remove()" class="admin-btn-danger">Remove</button>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div>
                            <label class="admin-label">Number</label>
                            <input type="text" name="vertical_number[]" value="<?= htmlspecialchars($v['number']) ?>" class="admin-input">
                        </div>
                        <div class="md:col-span-2">
                            <label class="admin-label">Name</label>
                            <input type="text" name="vertical_name[]" value="<?= htmlspecialchars($v['name']) ?>" class="admin-input">
                        </div>
                    </div>

                    <div class="space-y-4">
                        <div>
                            <label class="admin-label">Tagline</label>
                            <input type="text" name="vertical_tagline[]" value="<?= htmlspecialchars($v['tagline']) ?>" class="admin-input">
                        </div>
                        <div>
                            <label class="admin-label">Description</label>
                            <textarea name="vertical_description[]" rows="3" class="admin-textarea"><?= htmlspecialchars($v['description']) ?></textarea>
                        </div>
                        <div>
                            <label class="admin-label">URL</label>
                            <input type="text" name="vertical_url[]" value="<?= htmlspecialchars($v['url']) ?>" class="admin-input">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <button type="button" onclick="addVertical()" class="admin-btn-add mt-6">
                + Add Vertical
            </button>
        </div>

    </form>

    <div class="h-24"></div>
</div>

<script>
function addVertical() {
    const container = document.getElementById('verticals-container');
    const count = container.querySelectorAll('.vertical-item').length + 1;
    const html = `
        <div class="vertical-item border-t border-champagne-500/10 pt-6">
            <div class="flex items-center justify-between mb-4">
                <h4 class="text-sm font-semibold text-platinum-200">Vertical #${count}</h4>
                <button type="button" onclick="this.closest('.vertical-item').remove()" class="admin-btn-danger">Remove</button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                    <label class="admin-label">Number</label>
                    <input type="text" name="vertical_number[]" class="admin-input">
                </div>
                <div class="md:col-span-2">
                    <label class="admin-label">Name</label>
                    <input type="text" name="vertical_name[]" class="admin-input">
                </div>
            </div>
            <div class="space-y-4">
                <div>
                    <label class="admin-label">Tagline</label>
                    <input type="text" name="vertical_tagline[]" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Description</label>
                    <textarea name="vertical_description[]" rows="3" class="admin-textarea"></textarea>
                </div>
                <div>
                    <label class="admin-label">URL</label>
                    <input type="text" name="vertical_url[]" class="admin-input">
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}
</script>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
