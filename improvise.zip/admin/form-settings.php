<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$data_file = __DIR__ . '/../data/form-settings.json';
$data = json_decode(file_get_contents($data_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (['contact', 'careers', 'investment', 'partnership', 'media'] as $form) {
        $data[$form]['recipient_email'] = $_POST[$form . '_email'] ?? '';
        $data[$form]['submit_button_text'] = $_POST[$form . '_button'] ?? '';
        $data[$form]['success_message'] = $_POST[$form . '_success'] ?? '';
        $data[$form]['error_message'] = $_POST[$form . '_error'] ?? '';
    }

    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Form settings updated successfully';
}

$page_title = 'Form Settings';
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="admin-sticky-header">
    <div>
        <h2 class="admin-sticky-header-title">Form Settings</h2>
        <p class="admin-sticky-header-subtitle">Configure contact forms, emails, and submit buttons</p>
    </div>
    <div class="flex items-center space-x-3">
        <button type="submit" form="form-settings" class="admin-btn-primary">Save Changes</button>
    </div>
</div>

<div class="admin-container">

    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success">
        <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" id="form-settings" class="space-y-8">

        <!-- Contact Form -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Contact Form</h3>
                <p class="admin-card-subtitle">General contact inquiries</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label admin-label-required">Recipient Email</label>
                    <input type="email" name="contact_email" value="<?= htmlspecialchars($data['contact']['recipient_email']) ?>" class="admin-input" required>
                </div>
                <div>
                    <label class="admin-label">Submit Button Text</label>
                    <input type="text" name="contact_button" value="<?= htmlspecialchars($data['contact']['submit_button_text']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Success Message</label>
                    <textarea name="contact_success" rows="2" class="admin-textarea"><?= htmlspecialchars($data['contact']['success_message']) ?></textarea>
                </div>
                <div>
                    <label class="admin-label">Error Message</label>
                    <textarea name="contact_error" rows="2" class="admin-textarea"><?= htmlspecialchars($data['contact']['error_message']) ?></textarea>
                </div>
            </div>
        </div>

        <!-- Careers Form -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Careers Form</h3>
                <p class="admin-card-subtitle">Job applications</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label admin-label-required">Recipient Email</label>
                    <input type="email" name="careers_email" value="<?= htmlspecialchars($data['careers']['recipient_email']) ?>" class="admin-input" required>
                </div>
                <div>
                    <label class="admin-label">Submit Button Text</label>
                    <input type="text" name="careers_button" value="<?= htmlspecialchars($data['careers']['submit_button_text']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Success Message</label>
                    <textarea name="careers_success" rows="2" class="admin-textarea"><?= htmlspecialchars($data['careers']['success_message']) ?></textarea>
                </div>
                <div>
                    <label class="admin-label">Error Message</label>
                    <textarea name="careers_error" rows="2" class="admin-textarea"><?= htmlspecialchars($data['careers']['error_message']) ?></textarea>
                </div>
            </div>
        </div>

        <!-- Investment Form -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Investment Form</h3>
                <p class="admin-card-subtitle">Investor inquiries</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label admin-label-required">Recipient Email</label>
                    <input type="email" name="investment_email" value="<?= htmlspecialchars($data['investment']['recipient_email']) ?>" class="admin-input" required>
                </div>
                <div>
                    <label class="admin-label">Submit Button Text</label>
                    <input type="text" name="investment_button" value="<?= htmlspecialchars($data['investment']['submit_button_text']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Success Message</label>
                    <textarea name="investment_success" rows="2" class="admin-textarea"><?= htmlspecialchars($data['investment']['success_message']) ?></textarea>
                </div>
                <div>
                    <label class="admin-label">Error Message</label>
                    <textarea name="investment_error" rows="2" class="admin-textarea"><?= htmlspecialchars($data['investment']['error_message']) ?></textarea>
                </div>
            </div>
        </div>

        <!-- Partnership Form -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Partnership Form</h3>
                <p class="admin-card-subtitle">Partnership proposals</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label admin-label-required">Recipient Email</label>
                    <input type="email" name="partnership_email" value="<?= htmlspecialchars($data['partnership']['recipient_email']) ?>" class="admin-input" required>
                </div>
                <div>
                    <label class="admin-label">Submit Button Text</label>
                    <input type="text" name="partnership_button" value="<?= htmlspecialchars($data['partnership']['submit_button_text']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Success Message</label>
                    <textarea name="partnership_success" rows="2" class="admin-textarea"><?= htmlspecialchars($data['partnership']['success_message']) ?></textarea>
                </div>
                <div>
                    <label class="admin-label">Error Message</label>
                    <textarea name="partnership_error" rows="2" class="admin-textarea"><?= htmlspecialchars($data['partnership']['error_message']) ?></textarea>
                </div>
            </div>
        </div>

        <!-- Media Form -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Media Form</h3>
                <p class="admin-card-subtitle">Media and press inquiries</p>
            </div>
            <div class="admin-form-section">
                <div>
                    <label class="admin-label admin-label-required">Recipient Email</label>
                    <input type="email" name="media_email" value="<?= htmlspecialchars($data['media']['recipient_email']) ?>" class="admin-input" required>
                </div>
                <div>
                    <label class="admin-label">Submit Button Text</label>
                    <input type="text" name="media_button" value="<?= htmlspecialchars($data['media']['submit_button_text']) ?>" class="admin-input">
                </div>
                <div>
                    <label class="admin-label">Success Message</label>
                    <textarea name="media_success" rows="2" class="admin-textarea"><?= htmlspecialchars($data['media']['success_message']) ?></textarea>
                </div>
                <div>
                    <label class="admin-label">Error Message</label>
                    <textarea name="media_error" rows="2" class="admin-textarea"><?= htmlspecialchars($data['media']['error_message']) ?></textarea>
                </div>
            </div>
        </div>

    </form>

    <div class="h-24"></div>
</div>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
