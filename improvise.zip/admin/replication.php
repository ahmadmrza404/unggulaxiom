<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$replication_file = __DIR__ . '/../data/replication.json';
$replication_data = json_decode(file_get_contents($replication_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $replication_data['header']['label'] = $_POST['header_label'] ?? '';
    $replication_data['header']['title'] = $_POST['header_title'] ?? '';

    $replication_data['regions'] = [];
    if (!empty($_POST['region_name'])) {
        foreach ($_POST['region_name'] as $i => $name) {
            if (!empty($name)) {
                $features = array_filter(array_map('trim', explode("\n", $_POST['region_features'][$i] ?? '')));
                $replication_data['regions'][] = [
                    'name' => $name,
                    'features' => $features,
                    'target_sites' => $_POST['region_sites'][$i] ?? '',
                    'timeline' => $_POST['region_timeline'][$i] ?? ''
                ];
            }
        }
    }

    $replication_data['metrics'] = [];
    if (!empty($_POST['metric_value'])) {
        foreach ($_POST['metric_value'] as $i => $value) {
            if (!empty($value)) {
                $replication_data['metrics'][] = [
                    'value' => $value,
                    'label' => $_POST['metric_label'][$i] ?? ''
                ];
            }
        }
    }

    file_put_contents($replication_file, json_encode($replication_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Replication data updated successfully';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Replication - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="includes/admin-design-system.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { serif: ['Cormorant Garamond', 'serif'], sans: ['Inter', 'sans-serif'] },
                    colors: {
                        obsidian: { 900: '#0a0a0a', 950: '#050505' },
                        champagne: { 400: '#d4af37', 500: '#c5a028', 600: '#b69121' },
                        platinum: { 50: '#f5f5f5', 200: '#d1d1d1', 300: '#b0b0b0', 400: '#909090' }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-obsidian-950 text-platinum-50 font-sans">
    <nav class="bg-obsidian-900 border-b border-champagne-500/20 px-6 py-4 sticky top-0 z-50 backdrop-blur-sm bg-obsidian-900/95">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex gap-6 items-center">
                <a href="index.php" class="text-champagne-500 hover:text-champagne-400 transition-colors flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Dashboard
                </a>
                <h1 class="text-xl font-serif text-platinum-50">Replication Strategy</h1>
            </div>
            <a href="logout.php" class="text-sm text-platinum-300 hover:text-champagne-400 transition-colors">Logout</a>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-6 py-8">
        <?php if ($success): ?>
        <div class="admin-alert admin-alert-success">
            <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            <span><?= htmlspecialchars($success) ?></span>
        </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <div class="admin-card-compact">
                <h2 class="admin-card-title mb-4">Header</h2>
                <div class="admin-form-section">
                    <div>
                        <label class="admin-label">Label</label>
                        <input type="text" name="header_label" value="<?= htmlspecialchars($replication_data['header']['label']) ?>" class="admin-input">
                    </div>
                    <div>
                        <label class="admin-label">Title</label>
                        <textarea name="header_title" rows="2" class="admin-textarea"><?= htmlspecialchars($replication_data['header']['title']) ?></textarea>
                    </div>
                </div>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Regions</h2>
                <div id="regions-container" class="space-y-6">
                    <?php foreach ($replication_data['regions'] as $region): ?>
                    <div class="region-item border border-champagne-500/20 p-4 space-y-3">
                        <input type="text" name="region_name[]" value="<?= htmlspecialchars($region['name']) ?>" placeholder="Region Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        <textarea name="region_features[]" rows="3" placeholder="Features (one per line)" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars(implode("\n", $region['features'])) ?></textarea>
                        <div class="grid grid-cols-2 gap-3">
                            <input type="text" name="region_sites[]" value="<?= htmlspecialchars($region['target_sites']) ?>" placeholder="Target Sites (e.g., 3-5)" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                            <input type="text" name="region_timeline[]" value="<?= htmlspecialchars($region['timeline']) ?>" placeholder="Timeline (e.g., 2026-2028)" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" onclick="addRegion()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add Region</button>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Metrics</h2>
                <div id="metrics-container" class="space-y-3">
                    <?php foreach ($replication_data['metrics'] as $metric): ?>
                    <div class="grid grid-cols-2 gap-3">
                        <input type="text" name="metric_value[]" value="<?= htmlspecialchars($metric['value']) ?>" placeholder="Value (e.g., 7-11)" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        <input type="text" name="metric_label[]" value="<?= htmlspecialchars($metric['label']) ?>" placeholder="Label" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" onclick="addMetric()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add Metric</button>
            </div>

            <div class="flex gap-4">
                <button type="submit" class="admin-btn-primary">Save Changes</button>
                <a href="index.php" class="admin-btn-secondary inline-block">Cancel</a>
            </div>
        </form>
    </div>

    <script>
        function addRegion() {
            document.getElementById('regions-container').insertAdjacentHTML('beforeend', '<div class="region-item border border-champagne-500/20 p-4 space-y-3"><input type="text" name="region_name[]" placeholder="Region Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><textarea name="region_features[]" rows="3" placeholder="Features (one per line)" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></textarea><div class="grid grid-cols-2 gap-3"><input type="text" name="region_sites[]" placeholder="Target Sites" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><input type="text" name="region_timeline[]" placeholder="Timeline" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></div></div>');
        }
        function addMetric() {
            document.getElementById('metrics-container').insertAdjacentHTML('beforeend', '<div class="grid grid-cols-2 gap-3"><input type="text" name="metric_value[]" placeholder="Value" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><input type="text" name="metric_label[]" placeholder="Label" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></div>');
        }
    </script>
</body>
</html>
