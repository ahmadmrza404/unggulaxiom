<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$financials_file = __DIR__ . '/../data/cipu-financials.json';
$financials_data = json_decode(file_get_contents($financials_file), true);

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update snapshot
    $financials_data['snapshot']['title'] = $_POST['snapshot_title'] ?? '';
    $financials_data['snapshot']['subtitle'] = $_POST['snapshot_subtitle'] ?? '';

    // Update main metrics
    $financials_data['metrics']['production']['value'] = $_POST['production_value'] ?? '';
    $financials_data['metrics']['production']['description'] = $_POST['production_desc'] ?? '';

    $financials_data['metrics']['net_profit']['value'] = $_POST['net_profit_value'] ?? '';
    $financials_data['metrics']['net_profit']['description'] = $_POST['net_profit_desc'] ?? '';
    $financials_data['metrics']['net_profit']['base'] = $_POST['net_profit_base'] ?? '';

    $financials_data['metrics']['capex']['value'] = $_POST['capex_value'] ?? '';

    $financials_data['metrics']['payback']['value'] = $_POST['payback_value'] ?? '';
    $financials_data['metrics']['payback']['description'] = $_POST['payback_desc'] ?? '';

    $financials_data['scalable_note'] = $_POST['scalable_note'] ?? '';

    // Update revenue streams
    $financials_data['revenue_streams'] = [];
    if (!empty($_POST['revenue_name'])) {
        foreach ($_POST['revenue_name'] as $i => $name) {
            if (!empty($name)) {
                $financials_data['revenue_streams'][] = [
                    'name' => $name,
                    'percentage' => $_POST['revenue_percentage'][$i] ?? ''
                ];
            }
        }
    }

    // Update operating metrics
    $financials_data['operating_metrics'] = [];
    if (!empty($_POST['operating_name'])) {
        foreach ($_POST['operating_name'] as $i => $name) {
            if (!empty($name)) {
                $financials_data['operating_metrics'][] = [
                    'name' => $name,
                    'value' => $_POST['operating_value'][$i] ?? ''
                ];
            }
        }
    }

    // Update key assumptions
    $financials_data['key_assumptions'] = [];
    if (!empty($_POST['assumption_label'])) {
        foreach ($_POST['assumption_label'] as $i => $label) {
            if (!empty($label)) {
                $financials_data['key_assumptions'][] = [
                    'label' => $label,
                    'value' => $_POST['assumption_value'][$i] ?? ''
                ];
            }
        }
    }

    file_put_contents($financials_file, json_encode($financials_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Financial data updated successfully';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CIPU Financials - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="includes/admin-design-system.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { serif: ['Cormorant Garamond', 'serif'], sans: ['Inter', 'sans-serif'] },
                    colors: {
                        obsidian: { 900: '#0a0a0a', 950: '#050505' },
                        champagne: { 400: '#d4af37', 500: '#c5a028', 600: '#b69121' },
                        platinum: { 50: '#f5f5f5', 200: '#d1d1d1', 300: '#b0b0b0', 400: '#909090' }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-obsidian-950 text-platinum-50 font-sans">
    <nav class="bg-obsidian-900 border-b border-champagne-500/20 px-6 py-4 sticky top-0 z-50 backdrop-blur-sm bg-obsidian-900/95">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex gap-6 items-center">
                <a href="index.php" class="text-champagne-500 hover:text-champagne-400 transition-colors flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Dashboard
                </a>
                <h1 class="text-xl font-serif text-platinum-50">CIPU Financial Metrics</h1>
            </div>
            <a href="logout.php" class="text-sm text-platinum-300 hover:text-champagne-400 transition-colors">Logout</a>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-6 py-8">
        <?php if ($success): ?>
        <div class="admin-alert admin-alert-success">
            <svg class="admin-icon-md flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            <span><?= htmlspecialchars($success) ?></span>
        </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <!-- Snapshot Header -->
            <div class="admin-card-compact">
                <h2 class="admin-card-title mb-4">Snapshot Header</h2>
                <div class="admin-form-section">
                    <div>
                        <label class="admin-label">Title</label>
                        <input type="text" name="snapshot_title" value="<?= htmlspecialchars($financials_data['snapshot']['title']) ?>" class="admin-input">
                    </div>
                    <div>
                        <label class="admin-label">Subtitle</label>
                        <input type="text" name="snapshot_subtitle" value="<?= htmlspecialchars($financials_data['snapshot']['subtitle']) ?>" class="admin-input">
                    </div>
                </div>
            </div>

            <!-- Main Metrics -->
            <div class="admin-card-compact">
                <h2 class="admin-card-title mb-4">Main Metrics</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-3">
                        <h3 class="text-champagne-400 font-medium">Production</h3>
                        <input type="text" name="production_value" value="<?= htmlspecialchars($financials_data['metrics']['production']['value']) ?>" placeholder="12 million" class="admin-input">
                        <input type="text" name="production_desc" value="<?= htmlspecialchars($financials_data['metrics']['production']['description']) ?>" placeholder="chickens per year" class="admin-input">
                    </div>

                    <div class="space-y-3">
                        <h3 class="text-champagne-400 font-medium">Net Profit</h3>
                        <input type="text" name="net_profit_value" value="<?= htmlspecialchars($financials_data['metrics']['net_profit']['value']) ?>" placeholder="RM7.2M to RM30.6M" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        <input type="text" name="net_profit_desc" value="<?= htmlspecialchars($financials_data['metrics']['net_profit']['description']) ?>" placeholder="range" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        <input type="text" name="net_profit_base" value="<?= htmlspecialchars($financials_data['metrics']['net_profit']['base']) ?>" placeholder="Base: RM19.8M" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>

                    <div class="space-y-3">
                        <h3 class="text-champagne-400 font-medium">CAPEX</h3>
                        <input type="text" name="capex_value" value="<?= htmlspecialchars($financials_data['metrics']['capex']['value']) ?>" placeholder="RM12M to RM18M" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>

                    <div class="space-y-3">
                        <h3 class="text-champagne-400 font-medium">Payback</h3>
                        <input type="text" name="payback_value" value="<?= htmlspecialchars($financials_data['metrics']['payback']['value']) ?>" placeholder="1 to 2 years" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        <input type="text" name="payback_desc" value="<?= htmlspecialchars($financials_data['metrics']['payback']['description']) ?>" placeholder="(target range)" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                </div>

                <div class="mt-4">
                    <label class="block text-sm text-platinum-300 mb-2">Scalable Note</label>
                    <input type="text" name="scalable_note" value="<?= htmlspecialchars($financials_data['scalable_note']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
                </div>
            </div>

            <!-- Revenue Streams -->
            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Revenue Streams</h2>
                <div id="revenue-container" class="space-y-3">
                    <?php foreach ($financials_data['revenue_streams'] as $stream): ?>
                    <div class="grid grid-cols-2 gap-3">
                        <input type="text" name="revenue_name[]" value="<?= htmlspecialchars($stream['name']) ?>" placeholder="Stream name" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        <input type="text" name="revenue_percentage[]" value="<?= htmlspecialchars($stream['percentage']) ?>" placeholder="65%" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" onclick="addRevenue()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add Stream</button>
            </div>

            <!-- Operating Metrics -->
            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Operating Metrics</h2>
                <div id="operating-container" class="space-y-3">
                    <?php foreach ($financials_data['operating_metrics'] as $metric): ?>
                    <div class="grid grid-cols-2 gap-3">
                        <input type="text" name="operating_name[]" value="<?= htmlspecialchars($metric['name']) ?>" placeholder="Metric name" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        <input type="text" name="operating_value[]" value="<?= htmlspecialchars($metric['value']) ?>" placeholder="28-35%" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" onclick="addOperating()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add Metric</button>
            </div>

            <!-- Key Assumptions -->
            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Key Financial Assumptions</h2>
                <div id="assumptions-container" class="space-y-3">
                    <?php foreach ($financials_data['key_assumptions'] as $assumption): ?>
                    <div class="grid grid-cols-2 gap-3">
                        <input type="text" name="assumption_label[]" value="<?= htmlspecialchars($assumption['label']) ?>" placeholder="Label" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                        <input type="text" name="assumption_value[]" value="<?= htmlspecialchars($assumption['value']) ?>" placeholder="Value" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" onclick="addAssumption()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add Assumption</button>
            </div>

            <div class="flex gap-4">
                <button type="submit" class="bg-champagne-500 hover:bg-champagne-600 text-obsidian-950 font-semibold px-8 py-3">Save Changes</button>
                <a href="index.php" class="bg-obsidian-900 text-platinum-300 border border-champagne-500/20 px-8 py-3 inline-block">Cancel</a>
            </div>
        </form>
    </div>

    <script>
        function addRevenue() {
            document.getElementById('revenue-container').insertAdjacentHTML('beforeend', '<div class="grid grid-cols-2 gap-3"><input type="text" name="revenue_name[]" placeholder="Stream name" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><input type="text" name="revenue_percentage[]" placeholder="65%" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></div>');
        }
        function addOperating() {
            document.getElementById('operating-container').insertAdjacentHTML('beforeend', '<div class="grid grid-cols-2 gap-3"><input type="text" name="operating_name[]" placeholder="Metric name" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><input type="text" name="operating_value[]" placeholder="28-35%" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></div>');
        }
        function addAssumption() {
            document.getElementById('assumptions-container').insertAdjacentHTML('beforeend', '<div class="grid grid-cols-2 gap-3"><input type="text" name="assumption_label[]" placeholder="Label" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><input type="text" name="assumption_value[]" placeholder="Value" class="bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></div>');
        }
    </script>
</body>
</html>
