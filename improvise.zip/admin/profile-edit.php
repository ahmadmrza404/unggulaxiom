<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$member_id = $_GET['id'] ?? '';
if (empty($member_id)) {
    header('Location: leadership.php');
    exit;
}

$leadership_file = __DIR__ . '/../data/leadership.json';
$leadership_data = json_decode(file_get_contents($leadership_file), true);

$all_groups = ['board_of_directors', 'executives', 'senior_management', 'department_heads',
               'operations', 'finance', 'legal_compliance', 'human_resources',
               'technology', 'marketing_communications', 'business_development', 'advisors'];

$member = null;
foreach ($all_groups as $group) {
    if (!empty($leadership_data[$group])) {
        foreach ($leadership_data[$group] as $person) {
            if ($person['id'] === $member_id) {
                $member = $person;
                break 2;
            }
        }
    }
}

if (!$member) {
    header('Location: leadership.php');
    exit;
}

$profiles_dir = __DIR__ . '/../data/profiles/';
if (!is_dir($profiles_dir)) {
    mkdir($profiles_dir, 0755, true);
}

$profile_file = $profiles_dir . $member_id . '.json';
$profile = file_exists($profile_file) ? json_decode(file_get_contents($profile_file), true) : [
    'biography' => '',
    'achievements' => [],
    'certifications' => [],
    'education' => [],
    'experience' => [],
    'expertise' => []
];

$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $profile['biography'] = $_POST['biography'] ?? '';
    $profile['achievements'] = array_filter(array_map('trim', explode("\n", $_POST['achievements'] ?? '')));
    $profile['expertise'] = array_filter(array_map('trim', explode(',', $_POST['expertise'] ?? '')));

    $profile['certifications'] = [];
    if (!empty($_POST['cert_name'])) {
        foreach ($_POST['cert_name'] as $i => $name) {
            if (!empty($name)) {
                $profile['certifications'][] = [
                    'name' => $name,
                    'issuer' => $_POST['cert_issuer'][$i] ?? '',
                    'year' => $_POST['cert_year'][$i] ?? ''
                ];
            }
        }
    }

    $profile['education'] = [];
    if (!empty($_POST['edu_degree'])) {
        foreach ($_POST['edu_degree'] as $i => $degree) {
            if (!empty($degree)) {
                $profile['education'][] = [
                    'degree' => $degree,
                    'institution' => $_POST['edu_institution'][$i] ?? '',
                    'year' => $_POST['edu_year'][$i] ?? ''
                ];
            }
        }
    }

    $profile['experience'] = [];
    if (!empty($_POST['exp_position'])) {
        foreach ($_POST['exp_position'] as $i => $position) {
            if (!empty($position)) {
                $profile['experience'][] = [
                    'position' => $position,
                    'company' => $_POST['exp_company'][$i] ?? '',
                    'period' => $_POST['exp_period'][$i] ?? '',
                    'description' => $_POST['exp_description'][$i] ?? ''
                ];
            }
        }
    }

    file_put_contents($profile_file, json_encode($profile, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $success = 'Profile saved successfully';
}

$page_title = 'Edit Profile - ' . $member['name'];
require_once __DIR__ . '/includes/admin-layout-start.php';
?>

<div class="bg-obsidian-900 border-b border-champagne-500/20 px-8 py-6">
    <div class="max-w-5xl mx-auto flex justify-between items-center">
        <div>
            <h2 class="text-2xl font-semibold text-platinum-100 mb-1">Edit Profile</h2>
            <p class="text-platinum-400"><?= htmlspecialchars($member['name']) ?> - <?= htmlspecialchars($member['title']) ?></p>
        </div>
        <a href="../profile.php?id=<?= urlencode($member_id) ?>" target="_blank" class="admin-btn-secondary text-sm">
            <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
            </svg>
            Preview
        </a>
    </div>
</div>

<div class="max-w-5xl mx-auto px-8 py-12">
    <?php if ($success): ?>
    <div class="admin-alert admin-alert-success mb-8">
        <svg class="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span><?= htmlspecialchars($success) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" class="space-y-6">
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Biography</h3>
            </div>
            <textarea name="biography" rows="6" placeholder="Professional background..." class="admin-textarea"><?= htmlspecialchars($profile['biography']) ?></textarea>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Key Achievements</h3>
                <p class="admin-card-subtitle">One achievement per line</p>
            </div>
            <textarea name="achievements" rows="6" placeholder="Led $500M initiative..." class="admin-textarea"><?= htmlspecialchars(implode("\n", $profile['achievements'])) ?></textarea>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Certifications</h3>
            </div>
            <div id="certifications-container" class="space-y-3">
                <?php if (empty($profile['certifications'])): ?>
                <div class="cert-item grid grid-cols-3 gap-3">
                    <input type="text" name="cert_name[]" placeholder="CFA" class="admin-input">
                    <input type="text" name="cert_issuer[]" placeholder="CFA Institute" class="admin-input">
                    <input type="text" name="cert_year[]" placeholder="2015" class="admin-input">
                </div>
                <?php else: ?>
                    <?php foreach ($profile['certifications'] as $cert): ?>
                    <div class="cert-item grid grid-cols-3 gap-3">
                        <input type="text" name="cert_name[]" value="<?= htmlspecialchars($cert['name']) ?>" class="admin-input">
                        <input type="text" name="cert_issuer[]" value="<?= htmlspecialchars($cert['issuer']) ?>" class="admin-input">
                        <input type="text" name="cert_year[]" value="<?= htmlspecialchars($cert['year']) ?>" class="admin-input">
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button type="button" onclick="addCert()" class="mt-3 text-sm text-champagne-400 hover:text-champagne-500">+ Add Certification</button>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Education</h3>
            </div>
            <div id="education-container" class="space-y-3">
                <?php if (empty($profile['education'])): ?>
                <div class="edu-item grid grid-cols-3 gap-3">
                    <input type="text" name="edu_degree[]" placeholder="MBA" class="admin-input">
                    <input type="text" name="edu_institution[]" placeholder="INSEAD" class="admin-input">
                    <input type="text" name="edu_year[]" placeholder="2010" class="admin-input">
                </div>
                <?php else: ?>
                    <?php foreach ($profile['education'] as $edu): ?>
                    <div class="edu-item grid grid-cols-3 gap-3">
                        <input type="text" name="edu_degree[]" value="<?= htmlspecialchars($edu['degree']) ?>" class="admin-input">
                        <input type="text" name="edu_institution[]" value="<?= htmlspecialchars($edu['institution']) ?>" class="admin-input">
                        <input type="text" name="edu_year[]" value="<?= htmlspecialchars($edu['year']) ?>" class="admin-input">
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button type="button" onclick="addEdu()" class="mt-3 text-sm text-champagne-400 hover:text-champagne-500">+ Add Education</button>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Experience</h3>
            </div>
            <div id="experience-container" class="space-y-4">
                <?php if (empty($profile['experience'])): ?>
                <div class="exp-item admin-card-compact">
                    <div class="grid grid-cols-3 gap-3 mb-3">
                        <input type="text" name="exp_position[]" placeholder="CEO" class="admin-input">
                        <input type="text" name="exp_company[]" placeholder="Company" class="admin-input">
                        <input type="text" name="exp_period[]" placeholder="2020-Present" class="admin-input">
                    </div>
                    <textarea name="exp_description[]" rows="2" placeholder="Description..." class="admin-textarea"></textarea>
                </div>
                <?php else: ?>
                    <?php foreach ($profile['experience'] as $exp): ?>
                    <div class="exp-item admin-card-compact">
                        <div class="grid grid-cols-3 gap-3 mb-3">
                            <input type="text" name="exp_position[]" value="<?= htmlspecialchars($exp['position']) ?>" class="admin-input">
                            <input type="text" name="exp_company[]" value="<?= htmlspecialchars($exp['company']) ?>" class="admin-input">
                            <input type="text" name="exp_period[]" value="<?= htmlspecialchars($exp['period']) ?>" class="admin-input">
                        </div>
                        <textarea name="exp_description[]" rows="2" class="admin-textarea"><?= htmlspecialchars($exp['description']) ?></textarea>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button type="button" onclick="addExp()" class="mt-3 text-sm text-champagne-400 hover:text-champagne-500">+ Add Experience</button>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <h3 class="admin-card-title">Expertise</h3>
                <p class="admin-card-subtitle">Comma-separated</p>
            </div>
            <input type="text" name="expertise" value="<?= htmlspecialchars(implode(', ', $profile['expertise'])) ?>" placeholder="Infrastructure, Finance, Strategy" class="admin-input">
        </div>

        <div class="flex gap-4 pt-6">
            <button type="submit" class="admin-btn-primary">Save Profile</button>
            <a href="leadership.php" class="admin-btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<script>
function addCert() {
    document.getElementById('certifications-container').insertAdjacentHTML('beforeend', '<div class="cert-item grid grid-cols-3 gap-3"><input type="text" name="cert_name[]" placeholder="Certification" class="admin-input"><input type="text" name="cert_issuer[]" placeholder="Issuer" class="admin-input"><input type="text" name="cert_year[]" placeholder="Year" class="admin-input"></div>');
}
function addEdu() {
    document.getElementById('education-container').insertAdjacentHTML('beforeend', '<div class="edu-item grid grid-cols-3 gap-3"><input type="text" name="edu_degree[]" placeholder="Degree" class="admin-input"><input type="text" name="edu_institution[]" placeholder="Institution" class="admin-input"><input type="text" name="edu_year[]" placeholder="Year" class="admin-input"></div>');
}
function addExp() {
    document.getElementById('experience-container').insertAdjacentHTML('beforeend', '<div class="exp-item admin-card-compact"><div class="grid grid-cols-3 gap-3 mb-3"><input type="text" name="exp_position[]" placeholder="Position" class="admin-input"><input type="text" name="exp_company[]" placeholder="Company" class="admin-input"><input type="text" name="exp_period[]" placeholder="2020-Present" class="admin-input"></div><textarea name="exp_description[]" rows="2" placeholder="Description..." class="admin-textarea"></textarea></div>');
}
</script>

<?php require_once __DIR__ . '/includes/admin-layout-end.php'; ?>
