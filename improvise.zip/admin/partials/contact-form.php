<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Contact Information</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Location</label>
            <input type="text" name="location" value="<?= htmlspecialchars($current_data['location']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($current_data['email']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Response Time</label>
            <input type="text" name="response_time" value="<?= htmlspecialchars($current_data['response_time']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Description</label>
            <textarea name="description" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['description']) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Inquiry Types</h2>
    <textarea name="inquiry_types" rows="6" placeholder="One inquiry type per line" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['inquiry_types'])) ?></textarea>
</div>
