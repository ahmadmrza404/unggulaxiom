<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Page Header</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Tagline</label>
            <textarea name="tagline" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['tagline']) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Systems</h2>
    <div id="systems-container" class="space-y-6">
        <?php foreach ($current_data['systems'] as $system): ?>
        <div class="system-item border border-champagne-500/20 p-4 space-y-3">
            <input type="text" name="system_name[]" value="<?= htmlspecialchars($system['name']) ?>" placeholder="System Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
            <textarea name="system_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars($system['description']) ?></textarea>
            <textarea name="system_features[]" rows="4" placeholder="Features (one per line)" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars(implode("\n", $system['features'])) ?></textarea>
        </div>
        <?php endforeach; ?>
    </div>
    <button type="button" onclick="addSystem()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add System</button>
</div>

<script>
function addSystem() {
    document.getElementById('systems-container').insertAdjacentHTML('beforeend', '<div class="system-item border border-champagne-500/20 p-4 space-y-3"><input type="text" name="system_name[]" placeholder="System Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><textarea name="system_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></textarea><textarea name="system_features[]" rows="4" placeholder="Features (one per line)" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></textarea></div>');
}
</script>
