<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Project Information</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Project Name</label>
            <input type="text" name="project_name" value="<?= htmlspecialchars($current_data['project_name']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Status</label>
                <input type="text" name="status" value="<?= htmlspecialchars($current_data['status']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Subtitle</label>
                <input type="text" name="subtitle" value="<?= htmlspecialchars($current_data['subtitle']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Location</label>
            <input type="text" name="location" value="<?= htmlspecialchars($current_data['location']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Core Purpose</h2>
    <textarea name="core_purpose" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['core_purpose']) ?></textarea>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Infrastructure Components</h2>
    <textarea name="infrastructure" rows="5" placeholder="One component per line" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['infrastructure'])) ?></textarea>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Operational Standards</h2>
    <textarea name="standards" rows="5" placeholder="One standard per line" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['standards'])) ?></textarea>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Production Focus</h2>
    <textarea name="production_focus" rows="4" placeholder="One focus area per line" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['production_focus'])) ?></textarea>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Technology & Sustainability</h2>
    <textarea name="technology" rows="4" placeholder="One initiative per line" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['technology'])) ?></textarea>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Strategic Role</h2>
    <textarea name="strategic_role" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['strategic_role']) ?></textarea>
</div>
