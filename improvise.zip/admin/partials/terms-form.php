<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Document Information</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Last Updated (YYYY-MM-DD)</label>
            <input type="date" name="last_updated" value="<?= htmlspecialchars($current_data['last_updated']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Company Name</label>
            <input type="text" name="company_name" value="<?= htmlspecialchars($current_data['company']['name']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Registration Number</label>
            <input type="text" name="registration" value="<?= htmlspecialchars($current_data['company']['registration']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Terms Sections</h2>
    <div id="sections-container" class="space-y-4">
        <?php foreach ($current_data['sections'] as $section): ?>
        <div class="section-item border border-champagne-500/20 p-4 space-y-3">
            <input type="text" name="section_title[]" value="<?= htmlspecialchars($section['title']) ?>" placeholder="Section Title" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
            <textarea name="section_content[]" rows="4" placeholder="Content" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars($section['content']) ?></textarea>
        </div>
        <?php endforeach; ?>
    </div>
    <button type="button" onclick="addSection()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add Section</button>
</div>

<script>
function addSection() {
    document.getElementById('sections-container').insertAdjacentHTML('beforeend', '<div class="section-item border border-champagne-500/20 p-4 space-y-3"><input type="text" name="section_title[]" placeholder="Section Title" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><textarea name="section_content[]" rows="4" placeholder="Content" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></textarea></div>');
}
</script>
