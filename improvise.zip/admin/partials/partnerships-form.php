<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Page Information</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Location</label>
            <input type="text" name="location" value="<?= htmlspecialchars($current_data['location']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Purpose</label>
            <textarea name="purpose" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['purpose']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Response Timeline</label>
            <input type="text" name="response_timeline" value="<?= htmlspecialchars($current_data['response_timeline']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Partnership Structures</h2>
    <div id="structures-container" class="space-y-4">
        <?php foreach ($current_data['structures'] as $structure): ?>
        <div class="structure-item border border-champagne-500/20 p-4 space-y-3">
            <input type="text" name="structure_name[]" value="<?= htmlspecialchars($structure['name']) ?>" placeholder="Structure Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
            <textarea name="structure_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars($structure['description']) ?></textarea>
        </div>
        <?php endforeach; ?>
    </div>
    <button type="button" onclick="addStructure()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add Structure</button>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Partnership Criteria</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Institutional Requirements (one per line)</label>
            <textarea name="institutional_requirements" rows="4" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['criteria']['institutional_requirements'])) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Value Requirements (one per line)</label>
            <textarea name="value_requirements" rows="4" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['criteria']['value_requirements'])) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Investment Ranges</h2>
    <textarea name="investment_ranges" rows="4" placeholder="One range per line" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['investment_ranges'])) ?></textarea>
</div>

<script>
function addStructure() {
    document.getElementById('structures-container').insertAdjacentHTML('beforeend', '<div class="structure-item border border-champagne-500/20 p-4 space-y-3"><input type="text" name="structure_name[]" placeholder="Structure Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><textarea name="structure_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></textarea></div>');
}
</script>
