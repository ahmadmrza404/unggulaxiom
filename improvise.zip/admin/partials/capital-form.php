<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Page Header</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Tagline</label>
            <textarea name="tagline" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['tagline']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Introduction</label>
            <textarea name="intro" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['intro']) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Capital Structures</h2>
    <div id="structures-container" class="space-y-6">
        <?php foreach ($current_data['structures'] as $structure): ?>
        <div class="structure-item border border-champagne-500/20 p-4 space-y-3">
            <input type="text" name="structure_name[]" value="<?= htmlspecialchars($structure['name']) ?>" placeholder="Structure Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
            <textarea name="structure_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars($structure['description']) ?></textarea>
            <textarea name="structure_features[]" rows="4" placeholder="Features (one per line)" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars(implode("\n", $structure['features'])) ?></textarea>
        </div>
        <?php endforeach; ?>
    </div>
    <button type="button" onclick="addStructure()" class="mt-3 text-sm text-champagne-500 hover:text-champagne-400">+ Add Structure</button>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Call to Action & Disclaimer</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">CTA Text</label>
            <input type="text" name="cta_text" value="<?= htmlspecialchars($current_data['cta_text']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Disclaimer</label>
            <textarea name="disclaimer" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['disclaimer']) ?></textarea>
        </div>
    </div>
</div>

<script>
function addStructure() {
    document.getElementById('structures-container').insertAdjacentHTML('beforeend', '<div class="structure-item border border-champagne-500/20 p-4 space-y-3"><input type="text" name="structure_name[]" placeholder="Structure Name" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><textarea name="structure_description[]" rows="2" placeholder="Description" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></textarea><textarea name="structure_features[]" rows="4" placeholder="Features (one per line)" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"></textarea></div>');
}
</script>
