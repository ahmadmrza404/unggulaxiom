<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Company Information</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Company Name</label>
            <input type="text" name="company_name" value="<?= htmlspecialchars($current_data['company_info']['name']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Registration Number</label>
            <input type="text" name="registration" value="<?= htmlspecialchars($current_data['company_info']['registration']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Company Description</label>
            <textarea name="company_desc" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['company_info']['description']) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Content Sections</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Business Scope</label>
            <textarea name="business_scope" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['business_scope']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Governance</label>
            <textarea name="governance" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['governance']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Financial Standards</label>
            <textarea name="financial_standards" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['financial_standards']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Compliance Areas (one per line)</label>
            <textarea name="compliance_areas" rows="6" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['compliance_areas'])) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Ethics Framework</label>
            <textarea name="ethics" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['ethics']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Risk Management</label>
            <textarea name="risk_management" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['risk_management']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Contact Email</label>
            <input type="email" name="contact_email" value="<?= htmlspecialchars($current_data['contact_email']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
    </div>
</div>
