<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Market Section Header</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Section Label</label>
            <input type="text" name="section_label" value="<?= htmlspecialchars($current_data['section_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Headline</label>
            <textarea name="headline" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['headline']) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Market Size</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Market Size (e.g., "10 TRILLION")</label>
            <input type="text" name="market_size" value="<?= htmlspecialchars($current_data['market_size']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Market Size Label</label>
            <input type="text" name="market_size_label" value="<?= htmlspecialchars($current_data['market_size_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Data Points</h2>
    <div id="data-points-container" class="space-y-3">
        <?php foreach ($current_data['data_points'] as $i => $point): ?>
            <div class="flex gap-2">
                <input type="text" name="data_point[]" value="<?= htmlspecialchars($point) ?>" class="flex-1 bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
                <button type="button" onclick="this.parentElement.remove()" class="px-4 py-2 bg-red-900/50 text-red-400 hover:bg-red-900 transition-colors">Remove</button>
            </div>
        <?php endforeach; ?>
    </div>
    <button type="button" onclick="addDataPoint()" class="mt-3 px-4 py-2 bg-champagne-500/20 text-champagne-400 hover:bg-champagne-500/30 transition-colors">+ Add Data Point</button>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Market Reality</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Market Reality Label</label>
            <input type="text" name="market_reality_label" value="<?= htmlspecialchars($current_data['market_reality_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Market Reality Text</label>
            <textarea name="market_reality_text" rows="4" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['market_reality_text']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Positioning Statement</label>
            <textarea name="positioning_statement" rows="4" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['positioning_statement']) ?></textarea>
        </div>
    </div>
</div>

<script>
function addDataPoint() {
    const container = document.getElementById('data-points-container');
    const div = document.createElement('div');
    div.className = 'flex gap-2';
    div.innerHTML = '<input type="text" name="data_point[]" class="flex-1 bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><button type="button" onclick="this.parentElement.remove()" class="px-4 py-2 bg-red-900/50 text-red-400 hover:bg-red-900 transition-colors">Remove</button>';
    container.appendChild(div);
}
</script>
