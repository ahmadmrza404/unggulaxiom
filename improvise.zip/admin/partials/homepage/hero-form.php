<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Hero Section</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Main Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Subtitle</label>
            <input type="text" name="subtitle" value="<?= htmlspecialchars($current_data['subtitle']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Tagline</label>
            <input type="text" name="tagline" value="<?= htmlspecialchars($current_data['tagline']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Call to Action Buttons</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="space-y-4">
            <h3 class="text-sm text-champagne-400 font-semibold">Primary CTA</h3>
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Button Text</label>
                <input type="text" name="cta_primary_text" value="<?= htmlspecialchars($current_data['cta_primary']['text']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Button URL</label>
                <input type="text" name="cta_primary_url" value="<?= htmlspecialchars($current_data['cta_primary']['url']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
        </div>
        <div class="space-y-4">
            <h3 class="text-sm text-champagne-400 font-semibold">Secondary CTA</h3>
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Button Text</label>
                <input type="text" name="cta_secondary_text" value="<?= htmlspecialchars($current_data['cta_secondary']['text']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Button URL</label>
                <input type="text" name="cta_secondary_url" value="<?= htmlspecialchars($current_data['cta_secondary']['url']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
        </div>
    </div>
</div>
