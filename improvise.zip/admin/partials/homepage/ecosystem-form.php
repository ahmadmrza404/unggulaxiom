<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Ecosystem Header</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Section Label</label>
            <input type="text" name="section_label" value="<?= htmlspecialchars($current_data['section_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Description</label>
            <textarea name="description" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['description']) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Ecosystem Entities</h2>
    <div id="entities-container" class="space-y-4">
        <?php foreach ($current_data['entities'] as $i => $entity): ?>
            <div class="border border-champagne-500/10 p-4">
                <div class="space-y-3">
                    <div>
                        <label class="block text-xs text-platinum-400 mb-2">Entity Name</label>
                        <input type="text" name="entity_name[]" value="<?= htmlspecialchars($entity['name']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-platinum-400 mb-2">Description</label>
                        <input type="text" name="entity_description[]" value="<?= htmlspecialchars($entity['description']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-platinum-400 mb-2">URL</label>
                        <input type="text" name="entity_url[]" value="<?= htmlspecialchars($entity['url']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
