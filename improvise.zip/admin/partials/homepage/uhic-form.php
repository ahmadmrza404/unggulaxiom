<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">UHIC Header</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Section Label</label>
            <input type="text" name="section_label" value="<?= htmlspecialchars($current_data['section_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <textarea name="title" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['title']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Intro Text</label>
            <input type="text" name="intro_text" value="<?= htmlspecialchars($current_data['intro_text']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Description</label>
            <textarea name="description" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['description']) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Platform Objectives</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Objectives Label</label>
            <input type="text" name="objectives_label" value="<?= htmlspecialchars($current_data['objectives_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Objectives (one per line)</label>
            <textarea name="objectives" rows="4" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars(implode("\n", $current_data['objectives'])) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Platform Modules</h2>
    <div class="mb-4">
        <label class="block text-sm text-platinum-300 mb-2">Modules Title</label>
        <input type="text" name="modules_title" value="<?= htmlspecialchars($current_data['modules_title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
    </div>
    <div id="modules-container" class="space-y-4">
        <?php foreach ($current_data['modules'] as $i => $module): ?>
            <div class="border border-champagne-500/10 p-4">
                <div class="space-y-3">
                    <div>
                        <label class="block text-xs text-platinum-400 mb-2">Module Name</label>
                        <input type="text" name="module_name[]" value="<?= htmlspecialchars($module['name']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-platinum-400 mb-2">Description</label>
                        <textarea name="module_description[]" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars($module['description']) ?></textarea>
                    </div>
                    <div>
                        <label class="block text-xs text-platinum-400 mb-2">Tech Stack</label>
                        <input type="text" name="module_tech[]" value="<?= htmlspecialchars($module['tech_stack']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Deployment Sectors</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Deployment Title</label>
            <input type="text" name="deployment_title" value="<?= htmlspecialchars($current_data['deployment_title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Deployment Description</label>
            <textarea name="deployment_description" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['deployment_description']) ?></textarea>
        </div>
    </div>
    <div id="sectors-container" class="space-y-3 mt-4">
        <?php foreach ($current_data['deployment_sectors'] as $i => $sector): ?>
            <div class="flex gap-3">
                <input type="text" name="sector_name[]" value="<?= htmlspecialchars($sector['name']) ?>" placeholder="Sector name" class="flex-1 bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                <input type="text" name="sector_status[]" value="<?= htmlspecialchars($sector['status']) ?>" placeholder="Status" class="flex-1 bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
            </div>
        <?php endforeach; ?>
    </div>
</div>
