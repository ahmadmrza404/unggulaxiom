<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Framework Header</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Section Label</label>
            <input type="text" name="section_label" value="<?= htmlspecialchars($current_data['section_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Description</label>
            <textarea name="description" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['description']) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">8 Pillars</h2>
    <div id="pillars-container" class="space-y-6">
        <?php foreach ($current_data['pillars'] as $i => $pillar): ?>
            <div class="border border-champagne-500/10 p-4">
                <div class="grid grid-cols-12 gap-4 mb-3">
                    <div class="col-span-2">
                        <label class="block text-xs text-platinum-400 mb-2">Number</label>
                        <input type="text" name="pillar_number[]" value="<?= htmlspecialchars($pillar['number']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                    <div class="col-span-10">
                        <label class="block text-xs text-platinum-400 mb-2">Pillar Name</label>
                        <input type="text" name="pillar_name[]" value="<?= htmlspecialchars($pillar['name']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm">
                    </div>
                </div>
                <div>
                    <label class="block text-xs text-platinum-400 mb-2">Description</label>
                    <textarea name="pillar_description[]" rows="4" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-3 py-2 text-sm"><?= htmlspecialchars($pillar['description']) ?></textarea>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
