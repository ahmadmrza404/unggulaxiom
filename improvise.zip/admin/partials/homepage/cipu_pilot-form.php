<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">CIPU Pilot Information</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Section Label</label>
            <input type="text" name="section_label" value="<?= htmlspecialchars($current_data['section_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Title</label>
            <input type="text" name="title" value="<?= htmlspecialchars($current_data['title']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Subtitle</label>
            <input type="text" name="subtitle" value="<?= htmlspecialchars($current_data['subtitle']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Status</label>
                <input type="text" name="status" value="<?= htmlspecialchars($current_data['status']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Function</label>
                <input type="text" name="function" value="<?= htmlspecialchars($current_data['function']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Location</label>
                <input type="text" name="location" value="<?= htmlspecialchars($current_data['location']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
            <div>
                <label class="block text-sm text-platinum-300 mb-2">Capacity</label>
                <input type="text" name="capacity" value="<?= htmlspecialchars($current_data['capacity']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
            </div>
        </div>
    </div>
</div>
