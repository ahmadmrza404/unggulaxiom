<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Position Block</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Position Label</label>
            <input type="text" name="position_label" value="<?= htmlspecialchars($current_data['position_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Position Text (Paragraph 1)</label>
            <textarea name="position_text_1" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['position_text_1']) ?></textarea>
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Position Text (Paragraph 2)</label>
            <textarea name="position_text_2" rows="3" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['position_text_2']) ?></textarea>
        </div>
    </div>
</div>

<div class="bg-obsidian-900 border border-champagne-500/20 p-6">
    <h2 class="text-xl font-serif text-champagne-500 mb-4">Principle Block</h2>
    <div class="space-y-4">
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Principle Label</label>
            <input type="text" name="principle_label" value="<?= htmlspecialchars($current_data['principle_label']) ?>" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2">
        </div>
        <div>
            <label class="block text-sm text-platinum-300 mb-2">Principle Statement</label>
            <textarea name="principle_statement" rows="2" class="w-full bg-obsidian-950 border border-champagne-500/30 text-platinum-50 px-4 py-2"><?= htmlspecialchars($current_data['principle_statement']) ?></textarea>
        </div>
    </div>
</div>
