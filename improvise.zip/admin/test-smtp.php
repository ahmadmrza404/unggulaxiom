<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['test_email'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$test_email = filter_var($_POST['test_email'], FILTER_VALIDATE_EMAIL);
if (!$test_email) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

// Load SMTP config
$config_file = __DIR__ . '/../config/smtp.php';
if (!file_exists($config_file)) {
    echo json_encode(['success' => false, 'message' => 'SMTP not configured. Save settings first.']);
    exit;
}

$smtp = require $config_file;

if (!$smtp['enabled']) {
    echo json_encode(['success' => false, 'message' => 'SMTP is disabled. Enable it in settings.']);
    exit;
}

// Use PHPMailer if available, otherwise fallback to mail()
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require __DIR__ . '/../vendor/autoload.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = $smtp['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $smtp['username'];
        $mail->Password = $smtp['password'];
        $mail->SMTPSecure = $smtp['encryption'];
        $mail->Port = $smtp['port'];

        $mail->setFrom($smtp['from_email'], $smtp['from_name']);
        $mail->addAddress($test_email);

        $mail->isHTML(true);
        $mail->Subject = 'SMTP Test - Unggul Axiom';
        $mail->Body = '<h2>SMTP Configuration Test</h2><p>This is a test email sent at ' . date('Y-m-d H:i:s') . '</p><p>If you received this, your SMTP settings are working correctly!</p>';

        $mail->send();
        echo json_encode(['success' => true, 'message' => 'Test email sent successfully']);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $mail->ErrorInfo]);
    }
} else {
    // Fallback to basic mail() with custom headers
    $subject = 'SMTP Test - Unggul Axiom';
    $message = 'This is a test email sent at ' . date('Y-m-d H:i:s') . '. If you received this, your email configuration is working!';
    $headers = "From: {$smtp['from_name']} <{$smtp['from_email']}>\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    if (mail($test_email, $subject, $message, $headers)) {
        echo json_encode(['success' => true, 'message' => 'Test email sent (using PHP mail function)']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to send email. Check PHP mail configuration.']);
    }
}
