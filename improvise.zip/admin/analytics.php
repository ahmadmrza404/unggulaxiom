<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$analytics_file = __DIR__ . '/../data/analytics.json';
$analytics_data = file_exists($analytics_file) ? json_decode(file_get_contents($analytics_file), true) : [];

// Calculate stats
$total_views = array_sum($analytics_data['page_views'] ?? []);
$unique_visitors = count($analytics_data['unique_visitors'] ?? []);
$top_pages = $analytics_data['popular_pages'] ?? [];
arsort($top_pages);
$top_pages = array_slice($top_pages, 0, 10, true);

// Server stats
$memory_usage = memory_get_usage(true);
$memory_limit = ini_get('memory_limit');
$disk_free = disk_free_space(__DIR__);
$disk_total = disk_total_space(__DIR__);

function formatBytes($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    return round($bytes / pow(1024, $pow), 2) . ' ' . $units[$pow];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { serif: ['Cormorant Garamond', 'serif'], sans: ['Inter', 'sans-serif'] },
                    colors: {
                        obsidian: { 900: '#0a0a0a', 950: '#050505' },
                        champagne: { 400: '#d4af37', 500: '#c5a028', 600: '#b69121' },
                        platinum: { 50: '#f5f5f5', 200: '#d1d1d1', 300: '#b0b0b0', 400: '#909090' }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-obsidian-950 text-platinum-50 font-sans">
    <nav class="bg-obsidian-900 border-b border-champagne-500/20 px-6 py-4 sticky top-0 z-50 backdrop-blur-sm bg-obsidian-900/95">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex gap-6 items-center">
                <a href="index.php" class="text-champagne-500 hover:text-champagne-400 transition-colors flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Dashboard
                </a>
                <h1 class="text-xl font-serif text-platinum-50">Live Analytics</h1>
            </div>
            <a href="logout.php" class="text-sm text-platinum-300 hover:text-champagne-400 transition-colors">Logout</a>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-6 py-8">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-sm text-platinum-400 font-medium">Total Page Views</span>
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                    </svg>
                </div>
                <p class="text-3xl font-serif text-platinum-50"><?= number_format($total_views) ?></p>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-sm text-platinum-400 font-medium">Unique Visitors</span>
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                    </svg>
                </div>
                <p class="text-3xl font-serif text-platinum-50"><?= number_format($unique_visitors) ?></p>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-sm text-platinum-400 font-medium">Memory Usage</span>
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"/>
                    </svg>
                </div>
                <p class="text-3xl font-serif text-platinum-50"><?= formatBytes($memory_usage) ?></p>
                <p class="text-xs text-platinum-400 mt-1">of <?= $memory_limit ?></p>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-sm text-platinum-400 font-medium">Disk Space</span>
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4"/>
                    </svg>
                </div>
                <p class="text-3xl font-serif text-platinum-50"><?= formatBytes($disk_free) ?></p>
                <p class="text-xs text-platinum-400 mt-1">of <?= formatBytes($disk_total) ?> free</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">Top Pages</h2>
                <div class="space-y-3">
                    <?php if (empty($top_pages)): ?>
                    <p class="text-sm text-platinum-400">No data available yet</p>
                    <?php else: ?>
                        <?php foreach ($top_pages as $page => $views): ?>
                        <div class="flex justify-between items-center py-2 border-b border-champagne-500/10">
                            <span class="text-sm text-platinum-300"><?= htmlspecialchars($page) ?></span>
                            <span class="text-sm text-champagne-400 font-mono"><?= number_format($views) ?> views</span>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="bg-obsidian-900 border border-champagne-500/20 p-6">
                <h2 class="text-xl font-serif text-champagne-500 mb-4">System Information</h2>
                <div class="space-y-3">
                    <div class="flex justify-between py-2 border-b border-champagne-500/10">
                        <span class="text-sm text-platinum-400">PHP Version</span>
                        <span class="text-sm text-platinum-200"><?= phpversion() ?></span>
                    </div>
                    <div class="flex justify-between py-2 border-b border-champagne-500/10">
                        <span class="text-sm text-platinum-400">Server Software</span>
                        <span class="text-sm text-platinum-200"><?= $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown' ?></span>
                    </div>
                    <div class="flex justify-between py-2 border-b border-champagne-500/10">
                        <span class="text-sm text-platinum-400">Max Upload Size</span>
                        <span class="text-sm text-platinum-200"><?= ini_get('upload_max_filesize') ?></span>
                    </div>
                    <div class="flex justify-between py-2 border-b border-champagne-500/10">
                        <span class="text-sm text-platinum-400">Max Execution Time</span>
                        <span class="text-sm text-platinum-200"><?= ini_get('max_execution_time') ?>s</span>
                    </div>
                    <div class="flex justify-between py-2">
                        <span class="text-sm text-platinum-400">Last Updated</span>
                        <span class="text-sm text-platinum-200"><?= date('Y-m-d H:i:s') ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-6 bg-obsidian-900 border border-champagne-500/20 p-6">
            <div class="flex justify-between items-center">
                <div>
                    <h3 class="text-lg font-serif text-platinum-50 mb-1">Real-time Tracking</h3>
                    <p class="text-sm text-platinum-400">Analytics are tracked automatically via tracking script</p>
                </div>
                <button onclick="location.reload()" class="bg-champagne-500 hover:bg-champagne-600 text-obsidian-950 px-6 py-2 text-sm font-semibold transition-colors">
                    Refresh Data
                </button>
            </div>
        </div>
    </div>

    <script>
        setTimeout(() => location.reload(), 30000);
    </script>
</body>
</html>
