<?php
/**
 * ============================================
 * AXIOM CAPITAL PAGE
 * ============================================
 */

require_once __DIR__ . '/config.php';
$__entity_data = json_decode(file_get_contents(DATA_PATH . '/ecosystem-axiom-capital.json'), true);
$page_title = $__entity_data['page_title'];
require_once INCLUDES_PATH . '/header.php';
require_once PARTIALS_PATH . '/ecosystem-entity-content.php';
require_once INCLUDES_PATH . '/footer.php';
