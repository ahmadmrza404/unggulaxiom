# UNGGUL AXIOM GROUP - ARCHITECTURE MAP

## Directory Structure

```
UnggulAxiom/
├── config.php                          # Master configuration & utility functions
├── index.php                           # Homepage router
├── .htaccess                          # Apache routing, security, performance
│
├── includes/                          # Global layout components
│   ├── header.php                     # Navigation & HTML head
│   ├── footer.php                     # Footer & script dependencies
│   ├── seo-config.php                 # SEO metadata engine
│   ├── cookies-consent.php            # Cookie consent UI
│   └── image-utils.php                # Image optimization utilities
│
├── partials/                          # Page section components
│   └── home/                          # Homepage sections (sequential)
│       ├── hero.php                   # Vanguard section with canvas network
│       ├── positioning.php            # Position & Principle blocks
│       ├── systems-sectors.php        # Infrastructure matrix grid
│       ├── cipu-pilot.php            # Flagship system dossier
│       ├── capital-structure.php      # Financial participation models
│       └── governance-value.php       # Regulatory foundation
│
├── assets/
│   ├── css/
│   │   ├── styles.css                # Global design system
│   │   ├── custom.css                # Custom overrides
│   │   └── micro-interactions.css    # Hover states & transitions
│   │
│   └── js/
│       ├── animations.js             # Lenis smooth scroll engine
│       ├── canvas-network.js         # Canvas network (disabled)
│       ├── blueprint.js              # Blueprint effects (minimal)
│       └── main.js                   # Custom functionality
│
└── [page].php                        # Individual page controllers
```

## Dependency Load Order

### Header (includes/header.php)
1. Tailwind CSS CDN with custom config
2. Google Fonts (Playfair Display + Inter)
3. GSAP Core + ScrollTrigger
4. Alpine.js (deferred)
5. Custom CSS files

### Footer (includes/footer.php)
1. GSAP Core Library
2. GSAP ScrollTrigger Plugin
3. Lenis Smooth Scroll
4. SplitType Typography
5. Custom JavaScript (main.js)
6. Canvas Network (canvas-network.js)
7. Blueprint Engine (blueprint.js)
8. Animation Engine (animations.js)
9. Cookie Consent

## PHP Include Chain

```
index.php
  ├── config.php (defines constants & helpers)
  ├── includes/header.php
  │   └── includes/seo-config.php
  ├── partials/home/hero.php
  ├── partials/home/positioning.php
  ├── partials/home/systems-sectors.php
  ├── partials/home/cipu-pilot.php
  ├── partials/home/capital-structure.php
  ├── partials/home/governance-value.php
  └── includes/footer.php
      └── includes/cookies-consent.php
```

## Critical Path Constants

Defined in `config.php`:
- `SITE_NAME` - Brand name
- `BASE_URL` - Auto-detected domain
- `ROOT_PATH` - Absolute server path
- `INCLUDES_PATH` - Includes directory path
- `ASSETS_PATH` - Assets directory path

## Utility Functions

Defined in `config.php`:
- `url($path)` - Generate full URLs
- `esc($string)` - XSS prevention
- `is_current_page($path)` - Navigation state

## Security Layers

1. `.htaccess` - Directory browsing disabled, file access restrictions
2. `config.php` - Direct access prevention, session security
3. `esc()` - Output escaping throughout templates
4. CSP headers - Script/style source restrictions
5. HSTS - HTTPS enforcement
