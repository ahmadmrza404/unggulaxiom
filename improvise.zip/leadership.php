<?php
/**
 * ============================================
 * LEADERSHIP - COMMAND STRUCTURE
 * ============================================
 * Purpose: Institutional command hierarchy
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Leadership';

require_once INCLUDES_PATH . '/header.php';

// Load leadership data
$leadership_data = json_decode(file_get_contents(__DIR__ . '/data/leadership.json'), true);

// Define group display configuration
$group_config = [
    'board_of_directors' => ['title' => 'BOARD OF DIRECTORS', 'show' => true],
    'executives' => ['title' => 'EXECUTIVE COMMAND', 'show' => true],
    'senior_management' => ['title' => 'SENIOR MANAGEMENT', 'show' => true],
    'department_heads' => ['title' => 'DEPARTMENT HEADS', 'show' => true],
    'operations' => ['title' => 'OPERATIONS', 'show' => true],
    'finance' => ['title' => 'FINANCE', 'show' => true],
    'legal_compliance' => ['title' => 'LEGAL & COMPLIANCE', 'show' => true],
    'human_resources' => ['title' => 'HUMAN RESOURCES', 'show' => true],
    'technology' => ['title' => 'TECHNOLOGY', 'show' => true],
    'marketing_communications' => ['title' => 'MARKETING & COMMUNICATIONS', 'show' => true],
    'business_development' => ['title' => 'BUSINESS DEVELOPMENT', 'show' => true],
    'advisors' => ['title' => 'ADVISORY BOARD', 'show' => true]
];
?>

<!-- HEADER SECTION -->
<section class="py-32 bg-obsidian-950 border-b border-champagne-500/20 isolate">
    <div class="container-sovereign">
        <div class="max-w-4xl">
            <h1 class="font-serif text-5xl md:text-6xl text-platinum-50 mb-6 tracking-editorial">
                Command Structure
            </h1>
            <p class="text-xl text-platinum-200 leading-institutional">
                Institutional leadership framework for infrastructure coordination and capital deployment
            </p>
        </div>
    </div>
</section>

<!-- COMMAND ROSTER -->
<section class="py-24 bg-obsidian-900 isolate">
    <div class="container-sovereign">

        <?php
        foreach ($group_config as $group_key => $config):
            if (!$config['show'] || empty($leadership_data[$group_key])) continue;
            $is_last = ($group_key === array_key_last($group_config));
        ?>
        <div class="<?= $is_last ? '' : 'mb-24' ?>">
            <div class="mb-20">
                <h2 class="text-sovereign-xs text-champagne-600 font-semibold tracking-ultra-wide mb-3">
                    <?= $config['title'] ?>
                </h2>
                <div class="w-16 h-px bg-champagne-500"></div>
            </div>

            <div class="mt-1 divide-y divide-champagne-500/10">
                <?php foreach ($leadership_data[$group_key] as $member): ?>
                <a href="profile.php?id=<?= htmlspecialchars($member['id']) ?>" class="group block py-6 transition-all duration-300 hover:bg-obsidian-950/5">
                    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        <div class="lg:col-span-2 flex items-start gap-4">
                            <p class="font-mono text-xs text-champagne-600 tracking-wider"><?= htmlspecialchars($member['id']) ?></p>
                            <?php if (!empty($member['image']) && file_exists(__DIR__ . '/' . $member['image'])): ?>
                            <img src="<?= htmlspecialchars($member['image']) ?>" alt="<?= htmlspecialchars($member['name']) ?>" class="w-12 h-12 rounded-full object-cover border border-champagne-500/20">
                            <?php endif; ?>
                        </div>
                        <div class="lg:col-span-4">
                            <h3 class="font-serif text-2xl text-platinum-50 tracking-tight mb-2">
                                <?= htmlspecialchars($member['title']) ?>
                            </h3>
                            <?php if (!empty($member['name']) && $member['name'] !== 'Your Name Here'): ?>
                            <p class="text-sm text-champagne-400 font-medium"><?= htmlspecialchars($member['name']) ?></p>
                            <?php endif; ?>
                            <div class="flex gap-3 mt-3">
                                <?php if (!empty($member['email'])): ?>
                                <button onclick="event.stopPropagation(); window.location.href='mailto:<?= htmlspecialchars($member['email']) ?>'" class="text-xs text-platinum-400 hover:text-champagne-500 transition-colors">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/></svg>
                                </button>
                                <?php endif; ?>
                                <?php if (!empty($member['linkedin'])): ?>
                                <button onclick="event.stopPropagation(); window.open('<?= htmlspecialchars($member['linkedin']) ?>', '_blank')" class="text-xs text-platinum-400 hover:text-champagne-500 transition-colors">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M16.338 16.338H13.67V12.16c0-.995-.017-2.277-1.387-2.277-1.39 0-1.601 1.086-1.601 2.207v4.248H8.014v-8.59h2.559v1.174h.037c.356-.675 1.227-1.387 2.526-1.387 2.703 0 3.203 1.778 3.203 4.092v4.711zM5.005 6.575a1.548 1.548 0 11-.003-3.096 1.548 1.548 0 01.003 3.096zm-1.337 9.763H6.34v-8.59H3.667v8.59zM17.668 1H2.328C1.595 1 1 1.581 1 2.298v15.403C1 18.418 1.595 19 2.328 19h15.34c.734 0 1.332-.582 1.332-1.299V2.298C19 1.581 18.402 1 17.668 1z"/></svg>
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="lg:col-span-6">
                            <p class="text-base text-platinum-200 leading-institutional">
                                <?= htmlspecialchars($member['description']) ?>
                            </p>
                            <span class="text-sm text-champagne-500 mt-4 flex items-center gap-2">
                                View Full Profile
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                                </svg>
                            </span>
                        </div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>

    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
