<?php
/**
 * ============================================
 * ECOSYSTEM PAGE
 * ============================================
 */

require_once __DIR__ . '/config.php';

$_eco = json_decode(file_get_contents(DATA_PATH . '/ecosystem.json'), true);
$page_title = 'Ecosystem';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO SECTION -->
<section class="py-32 bg-obsidian-950 border-b border-champagne-500/20">
    <div class="container-sovereign">
        <div class="max-w-4xl">
            <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block">
                <?= htmlspecialchars($_eco['hero']['section_label']) ?>
            </span>
            <h1 class="font-serif text-5xl md:text-6xl text-platinum-50 tracking-editorial mb-8 leading-tight">
                <?= htmlspecialchars($_eco['hero']['title']) ?>
            </h1>
            <p class="text-lg text-platinum-200 leading-institutional">
                <?= htmlspecialchars($_eco['hero']['description']) ?>
            </p>
        </div>
    </div>
</section>

<!-- PLATFORM OVERVIEW -->
<section class="py-20 bg-obsidian-900">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto mb-16">
            <p class="text-xl text-platinum-200 leading-institutional">
                <?= htmlspecialchars($_eco['overview']) ?>
            </p>
        </div>

        <!-- VERTICALS GRID -->
        <div class="max-w-6xl mx-auto space-y-0">

            <?php foreach ($_eco['verticals'] as $v): ?>
            <a href="<?php echo url($v['url']); ?>"
               class="block group py-12 border-t border-champagne-500/20 hover:border-champagne-500/60 transition-all duration-300">
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    <div class="lg:col-span-3">
                        <span class="font-mono text-champagne-500 text-sm tracking-wider font-semibold mb-4 block"><?= htmlspecialchars($v['number']) ?></span>
                        <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 tracking-editorial group-hover:text-champagne-400 transition-colors">
                            <?= htmlspecialchars($v['name']) ?>
                        </h2>
                    </div>
                    <div class="lg:col-span-9">
                        <p class="text-base text-platinum-200 leading-institutional mb-4">
                            <?= htmlspecialchars($v['tagline']) ?>
                        </p>
                        <p class="text-sm text-sovereign-400 leading-institutional">
                            <?= htmlspecialchars($v['description']) ?>
                        </p>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>

            <!-- Axiom HalalTech -->
            <a href="<?php echo url('/ecosystem/axiom-halaltech'); ?>"
               class="block group py-12 border-t border-champagne-500/20 hover:border-champagne-500/60 transition-all duration-300">
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    <div class="lg:col-span-3">
                        <span class="font-mono text-champagne-500 text-sm tracking-wider font-semibold mb-4 block">02</span>
                        <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 tracking-editorial group-hover:text-champagne-400 transition-colors">
                            Axiom HalalTech
                        </h2>
                    </div>
                    <div class="lg:col-span-9">
                        <p class="text-base text-platinum-200 leading-institutional mb-4">
                            Certification and compliance systems
                        </p>
                        <p class="text-sm text-sovereign-400 leading-institutional">
                            Comprehensive halal certification management and supply chain verification services. Operations include coordination with JAKIM and international certification bodies, traceability platform implementation, compliance consulting, and training programs addressing MS 1500:2019 standards and destination market requirements.
                        </p>
                    </div>
                </div>
            </a>

            <!-- Axiom Logistics -->
            <a href="<?php echo url('/ecosystem/axiom-logistics'); ?>"
               class="block group py-12 border-t border-champagne-500/20 hover:border-champagne-500/60 transition-all duration-300">
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    <div class="lg:col-span-3">
                        <span class="font-mono text-champagne-500 text-sm tracking-wider font-semibold mb-4 block">03</span>
                        <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 tracking-editorial group-hover:text-champagne-400 transition-colors">
                            Axiom Logistics
                        </h2>
                    </div>
                    <div class="lg:col-span-9">
                        <p class="text-base text-platinum-200 leading-institutional mb-4">
                            Distribution and cold-chain networks
                        </p>
                        <p class="text-sm text-sovereign-400 leading-institutional">
                            Temperature-controlled warehousing and refrigerated transportation infrastructure maintaining halal integrity. Services include segregated storage facilities, GPS-tracked fleet management, order fulfillment, and distribution addressing domestic retail, food service, institutional customers, and export consolidation requirements.
                        </p>
                    </div>
                </div>
            </a>

            <!-- Axiom Capital -->
            <a href="<?php echo url('/ecosystem/axiom-capital'); ?>"
               class="block group py-12 border-t border-b border-champagne-500/20 hover:border-champagne-500/60 transition-all duration-300">
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    <div class="lg:col-span-3">
                        <span class="font-mono text-champagne-500 text-sm tracking-wider font-semibold mb-4 block">04</span>
                        <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 tracking-editorial group-hover:text-champagne-400 transition-colors">
                            Axiom Capital
                        </h2>
                    </div>
                    <div class="lg:col-span-9">
                        <p class="text-base text-platinum-200 leading-institutional mb-4">
                            Investment structuring and financial alignment
                        </p>
                        <p class="text-sm text-sovereign-400 leading-institutional">
                            Shariah-compliant investment structuring and financial management supporting halal infrastructure development. Services encompass investment holding, venture building, project development financing, and strategic partnership structuring utilizing Islamic finance instruments including mudarabah, musharakah, and murabaha arrangements.
                        </p>
                    </div>
                </div>
            </a>

        </div>
    </div>
</section>

<!-- PLATFORM INTEGRATION -->
<section class="py-20 bg-obsidian-950">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto space-y-12">

            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-editorial mb-6">
                    Platform Integration
                </h2>
                <p class="text-base text-platinum-200 leading-institutional mb-6">
                    Operational integration across divisions enables efficient coordination throughout the value chain. Production output from Axiom Agro flows through Axiom HalalTech certification systems and Axiom Logistics distribution networks, with Axiom Capital providing financial structuring supporting infrastructure development and market expansion.
                </p>
                <p class="text-base text-platinum-200 leading-institutional">
                    This integrated model reduces transaction costs, improves traceability, and enables rapid response to market opportunities while maintaining halal integrity and regulatory compliance throughout the supply chain.
                </p>
            </div>

            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-editorial mb-6">
                    Strategic Positioning
                </h2>
                <p class="text-base text-platinum-200 leading-institutional">
                    The platform addresses structural fragmentation within the halal economy by providing integrated infrastructure spanning production through market access. This positioning enables the Group to capture value across multiple stages of the supply chain while providing customers and partners with comprehensive solutions addressing their halal infrastructure requirements.
                </p>
            </div>

        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
