<?php
echo password_hash('unggulbronto', PASSWORD_BCRYPT, ['cost' => 12]);
