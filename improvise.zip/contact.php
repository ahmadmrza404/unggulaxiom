<?php
/**
 * ============================================
 * CONTACT PAGE - UNGGUL AXIOM GROUP
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Contact';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO SECTION -->
<section class="py-32 bg-obsidian-900 border-t border-champagne-500/20">
    <div class="container-sovereign">
        <div class="max-w-4xl mx-auto text-center gsap-fade-up">
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-6 tracking-editorial">
                Contact Us
            </h1>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 leading-relaxed max-w-2xl mx-auto">
                Get in touch with our team for inquiries, partnerships, and institutional engagement
            </p>
        </div>
    </div>
</section>

<!-- CONTACT INFORMATION -->
<section class="py-32 bg-obsidian-800 border-t border-champagne-500/20">
    <div class="container-sovereign">

        <div class="mb-20 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                GET IN TOUCH
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto"></div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">

            <div class="border border-champagne-500/20 p-8 text-center hover:bg-champagne-500/5 transition-colors gsap-fade-up">
                <div class="w-12 h-12 border border-champagne-500/40 flex items-center justify-center mx-auto mb-6">
                    <svg class="w-6 h-6 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                    </svg>
                </div>
                <h3 class="text-lg text-platinum-50 mb-3">Location</h3>
                <p class="text-sm text-sovereign-300">Kuala Lumpur, Malaysia</p>
            </div>

            <div class="border border-champagne-500/20 p-8 text-center hover:bg-champagne-500/5 transition-colors gsap-fade-up">
                <div class="w-12 h-12 border border-champagne-500/40 flex items-center justify-center mx-auto mb-6">
                    <svg class="w-6 h-6 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                    </svg>
                </div>
                <h3 class="text-lg text-platinum-50 mb-3">Email</h3>
                <p class="text-sm text-sovereign-300">contact@unggulaxiom.com</p>
            </div>

            <div class="border border-champagne-500/20 p-8 text-center hover:bg-champagne-500/5 transition-colors gsap-fade-up">
                <div class="w-12 h-12 border border-champagne-500/40 flex items-center justify-center mx-auto mb-6">
                    <svg class="w-6 h-6 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <h3 class="text-lg text-platinum-50 mb-3">Response Time</h3>
                <p class="text-sm text-sovereign-300">48-72 hours</p>
            </div>

        </div>

    </div>
</section>

<!-- CONTACT FORM -->
<section class="py-32 bg-obsidian-900 border-t border-champagne-500/20">
    <div class="container-sovereign">

        <div class="mb-20 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                SEND US A MESSAGE
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-sovereign-300 max-w-2xl mx-auto">
                Fill out the form below and our team will get back to you within 48-72 hours.
            </p>
        </div>

        <div class="max-w-3xl mx-auto">

            <div x-data="{ submitted: false, loading: false, error: '' }">

                <!-- FORM STATE -->
                <div x-show="!submitted">
                    <form @submit.prevent="
                        loading = true;
                        error = '';
                        fetch('process-contact-form.php', {
                            method: 'POST',
                            body: new FormData($event.target)
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                submitted = true;
                            } else {
                                error = data.message || 'Submission failed';
                            }
                        })
                        .catch(() => {
                            error = 'Network error. Please try again.';
                        })
                        .finally(() => {
                            loading = false;
                        })
                    " class="space-y-6 border border-champagne-500/20 p-8 gsap-fade-up">

                        <!-- NAME -->
                        <div>
                            <label class="block text-sm text-champagne-500 font-mono uppercase tracking-wider mb-2">
                                Full Name *
                            </label>
                            <input
                                type="text"
                                name="full_name"
                                required
                                class="w-full bg-obsidian-800 border border-champagne-500/20 text-platinum-50 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors"
                                placeholder="Your Full Name"
                            >
                        </div>

                        <!-- ORGANIZATION -->
                        <div>
                            <label class="block text-sm text-champagne-500 font-mono uppercase tracking-wider mb-2">
                                Organization
                            </label>
                            <input
                                type="text"
                                name="organization"
                                class="w-full bg-obsidian-800 border border-champagne-500/20 text-platinum-50 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors"
                                placeholder="Company or Institution (Optional)"
                            >
                        </div>

                        <!-- EMAIL -->
                        <div>
                            <label class="block text-sm text-champagne-500 font-mono uppercase tracking-wider mb-2">
                                Email Address *
                            </label>
                            <input
                                type="email"
                                name="email"
                                required
                                class="w-full bg-obsidian-800 border border-champagne-500/20 text-platinum-50 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors"
                                placeholder="email@domain.com"
                            >
                        </div>

                        <!-- PHONE -->
                        <div>
                            <label class="block text-sm text-champagne-500 font-mono uppercase tracking-wider mb-2">
                                Phone Number
                            </label>
                            <input
                                type="tel"
                                name="phone"
                                class="w-full bg-obsidian-800 border border-champagne-500/20 text-platinum-50 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors"
                                placeholder="+60 12-345 6789 (Optional)"
                            >
                        </div>

                        <!-- INQUIRY TYPE -->
                        <div>
                            <label class="block text-sm text-champagne-500 font-mono uppercase tracking-wider mb-2">
                                Inquiry Type *
                            </label>
                            <select
                                name="inquiry_type"
                                required
                                class="w-full bg-obsidian-800 border border-champagne-500/20 text-platinum-50 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors"
                            >
                                <option value="">Select Inquiry Type</option>
                                <option value="general">General Inquiry</option>
                                <option value="partnership">Partnership Opportunity</option>
                                <option value="investment">Investment Inquiry</option>
                                <option value="media">Media & Press</option>
                                <option value="careers">Career Opportunities</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <!-- MESSAGE -->
                        <div>
                            <label class="block text-sm text-champagne-500 font-mono uppercase tracking-wider mb-2">
                                Message *
                            </label>
                            <textarea
                                name="message"
                                required
                                rows="6"
                                class="w-full bg-obsidian-800 border border-champagne-500/20 text-platinum-50 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors resize-none"
                                placeholder="Tell us about your inquiry..."
                            ></textarea>
                        </div>

                        <!-- SUBMIT BUTTON -->
                        <button
                            type="submit"
                            :disabled="loading"
                            class="w-full py-4 font-mono text-sm uppercase tracking-wider transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            style="background-color: #D4AF37 !important; color: #0A0E14 !important; font-weight: 600 !important; -webkit-text-fill-color: #0A0E14 !important; text-shadow: none !important;"
                            x-text="loading ? 'SENDING...' : 'Send Message'"
                        >
                        </button>

                        <!-- ERROR MESSAGE -->
                        <div x-show="error" x-text="error" class="text-red-400 text-sm text-center"></div>

                        <p class="text-xs text-sovereign-400 text-center">* Required fields</p>

                    </form>
                </div>

                <!-- SUCCESS MESSAGE -->
                <div x-show="submitted" x-cloak style="display: none;" class="border border-champagne-500/20 p-12 text-center bg-champagne-500/5">
                    <svg class="w-16 h-16 text-champagne-500 mx-auto mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <h3 class="text-xl font-serif text-platinum-50 mb-4">Thank You</h3>
                    <p class="text-sovereign-300 leading-relaxed mb-2">
                        Your message has been received.
                    </p>
                    <p class="text-sm text-sovereign-400">
                        We will respond to your inquiry within 48-72 hours.
                    </p>
                </div>

            </div>

        </div>

    </div>
</section>

<style>
[x-cloak] { display: none !important; }
</style>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
