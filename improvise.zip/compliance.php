<?php
/**
 * ============================================
 * COMPLIANCE PAGE
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Compliance';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO SECTION -->
<section class="py-24 bg-obsidian-950 border-b border-champagne-500/20">
    <div class="container-sovereign">
        <div class="max-w-3xl">
            <span class="text-xs text-champagne-500 tracking-widest mb-4 block uppercase">
                REGULATORY FRAMEWORK
            </span>
            <h1 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-tight mb-6 leading-tight">
                Compliance
            </h1>
            <p class="text-base text-platinum-200 leading-relaxed">
                Unggul Axiom Group operates under rigorous regulatory oversight, maintaining institutional-grade compliance standards across all jurisdictions of operation.
            </p>
        </div>
    </div>
</section>

<!-- CONTENT SECTIONS -->
<section class="py-16 bg-obsidian-900">
    <div class="container-sovereign">
        <div class="max-w-3xl mx-auto space-y-12">

            <!-- Section 1 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    1. Regulatory Oversight
                </h2>
                <div class="space-y-3 text-sm text-platinum-200 leading-relaxed">
                    <p>
                        Unggul Bronto Sdn. Bhd. (Registration No: 202301027920) operates as a Malaysian-registered investment holding company subject to the regulatory jurisdiction of the Companies Commission of Malaysia (SSM) and applicable provisions of the Companies Act 2016.
                    </p>
                    <p>
                        The Group's business activities encompass investment holding and strategic development within the halal economy, including halal food production, halal agri-tech, pharmaceuticals, logistics infrastructure, halal supply chain certification, smart agriculture systems, food security infrastructure, livestock integration, and agri-technology innovation. Additional activities include venture building, project development, and strategic partnerships.
                    </p>
                    <p>
                        Operations span multiple regulatory domains including agricultural production, food processing, pharmaceutical manufacturing, logistics infrastructure, and financial services. Each operational vertical maintains compliance with sector-specific regulatory requirements administered by relevant Malaysian authorities including the Ministry of Agriculture and Food Security, Department of Veterinary Services, Malaysian Quarantine and Inspection Services, National Pharmaceutical Regulatory Agency, and Securities Commission Malaysia where applicable.
                    </p>
                    <p>
                        As an infrastructure platform operating within the global halal economy, the Group adheres to international standards governing halal certification, food safety, supply chain integrity, and cross-border trade facilitation.
                    </p>
                </div>
            </div>

            <!-- Section 2 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    2. Corporate Governance Framework
                </h2>
                <div class="space-y-5 text-sm text-platinum-200 leading-relaxed">
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">2.1 Board Oversight</h3>
                        <p>
                            The Group maintains a structured board governance framework with clearly defined roles, responsibilities, and accountability mechanisms. Board composition reflects appropriate expertise across infrastructure development, agricultural operations, financial management, and regulatory compliance.
                        </p>
                        <p>
                            Board committees address specialized oversight functions including audit and risk management, investment evaluation, regulatory compliance, and strategic planning. Committee charters define scope, authority, and reporting obligations to ensure effective governance execution.
                        </p>
                    </div>
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">2.2 Management Structure</h3>
                        <p>
                            Executive management operates under delegated authority from the Board, with clear reporting lines and accountability frameworks. Management committees coordinate cross-functional operations, risk assessment, compliance monitoring, and strategic initiative execution.
                        </p>
                    </div>
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">2.3 Internal Controls</h3>
                        <p>
                            The Group implements comprehensive internal control systems addressing financial reporting accuracy, operational efficiency, asset protection, and regulatory compliance. Control frameworks undergo regular assessment and enhancement to address evolving risks and regulatory requirements.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 3 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    3. Financial Compliance
                </h2>
                <div class="space-y-5 text-sm text-platinum-200 leading-relaxed">
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">3.1 Financial Reporting Standards</h3>
                        <p>
                            Financial statements are prepared in accordance with Malaysian Financial Reporting Standards (MFRS), which are substantially aligned with International Financial Reporting Standards (IFRS). The Group maintains rigorous accounting policies, internal controls, and disclosure practices to ensure financial reporting integrity.
                        </p>
                        <p>
                            Annual financial statements undergo independent audit by qualified external auditors registered with the Malaysian Institute of Accountants. Audit scope encompasses financial position, operational results, cash flows, and compliance with applicable accounting standards and regulatory requirements.
                        </p>
                    </div>
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">3.2 Tax Compliance</h3>
                        <p>
                            The Group maintains full compliance with Malaysian tax legislation including the Income Tax Act 1967, Goods and Services Tax Act 2014 (where applicable), and related tax regulations. Tax positions are supported by appropriate documentation, professional advice, and transparent disclosure to tax authorities.
                        </p>
                        <p>
                            Transfer pricing policies for inter-company transactions adhere to arm's length principles consistent with OECD guidelines and Malaysian transfer pricing regulations. Documentation standards meet statutory requirements for contemporaneous preparation and maintenance.
                        </p>
                    </div>
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">3.3 Anti-Money Laundering</h3>
                        <p>
                            The Group implements comprehensive anti-money laundering (AML) and counter-terrorism financing (CTF) controls consistent with the Anti-Money Laundering, Anti-Terrorism Financing and Proceeds of Unlawful Activities Act 2001 (AMLA) and related regulations.
                        </p>
                        <p>
                            AML/CTF framework encompasses customer due diligence, enhanced due diligence for high-risk counterparties, ongoing transaction monitoring, suspicious activity reporting, record retention, and employee training. Compliance procedures are regularly reviewed and updated to reflect regulatory developments and emerging risks.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 4 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    4. Operational Compliance
                </h2>
                <div class="space-y-5 text-sm text-platinum-200 leading-relaxed">
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">4.1 Food Safety and Quality</h3>
                        <p>
                            Production facilities operate under stringent food safety management systems aligned with international standards including Hazard Analysis and Critical Control Points (HACCP), Good Manufacturing Practices (GMP), and ISO 22000 Food Safety Management.
                        </p>
                        <p>
                            Quality assurance protocols encompass raw material sourcing, production process controls, finished product testing, traceability systems, and continuous improvement mechanisms. Regular audits by internal quality teams and external certification bodies verify ongoing compliance and system effectiveness.
                        </p>
                    </div>
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">4.2 Environmental Compliance</h3>
                        <p>
                            Operations comply with the Environmental Quality Act 1974 and related environmental regulations governing air emissions, water discharge, waste management, and environmental impact assessment. Environmental management systems address pollution prevention, resource efficiency, and environmental performance monitoring.
                        </p>
                        <p>
                            The Group maintains necessary environmental permits and licenses, conducts regular environmental monitoring, and implements corrective actions to address any identified non-conformances. Environmental compliance reporting meets statutory requirements and stakeholder expectations.
                        </p>
                    </div>
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">4.3 Occupational Health and Safety</h3>
                        <p>
                            Workplace safety programs comply with the Occupational Safety and Health Act 1994 and industry-specific safety regulations. Safety management systems address hazard identification, risk assessment, control implementation, incident investigation, and continuous improvement.
                        </p>
                        <p>
                            Employee training, safety equipment provision, emergency preparedness, and regular safety audits ensure ongoing compliance and workplace safety performance. Safety metrics are monitored and reported to management and regulatory authorities as required.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 5 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    5. Data Protection and Privacy
                </h2>
                <div class="space-y-3 text-sm text-platinum-200 leading-relaxed">
                    <p>
                        The Group maintains comprehensive data protection compliance aligned with the Personal Data Protection Act 2010 (PDPA) and international data protection standards. Data protection framework encompasses lawful processing principles, consent management, data subject rights, security safeguards, and breach notification procedures.
                    </p>
                    <p>
                        A designated Data Protection Officer oversees compliance implementation, conducts privacy impact assessments, manages data subject requests, and coordinates with regulatory authorities. Regular audits and employee training ensure ongoing compliance and privacy awareness throughout the organization.
                    </p>
                    <p>
                        Cross-border data transfers comply with applicable legal requirements including adequacy assessments, standard contractual clauses, or other approved transfer mechanisms. Third-party processors are subject to contractual data protection obligations and regular compliance verification.
                    </p>
                </div>
            </div>

            <!-- Section 6 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    6. Trade and Export Compliance
                </h2>
                <div class="space-y-3 text-sm text-platinum-200 leading-relaxed">
                    <p>
                        International trade operations comply with Malaysian customs regulations, export control laws, and destination country import requirements. Trade compliance framework addresses product classification, valuation, origin determination, licensing requirements, and documentation standards.
                    </p>
                    <p>
                        The Group maintains awareness of international sanctions regimes and export control restrictions, implementing screening procedures to prevent prohibited transactions. Trade compliance personnel receive regular training on regulatory developments and compliance obligations.
                    </p>
                    <p>
                        Halal certification for export products meets requirements of destination country halal authorities, ensuring market access and regulatory acceptance. Certification documentation, traceability records, and quality attestations support smooth customs clearance and regulatory compliance.
                    </p>
                </div>
            </div>

            <!-- Section 7 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    7. Ethics and Conduct Standards
                </h2>
                <div class="space-y-5 text-sm text-platinum-200 leading-relaxed">
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">7.1 Code of Conduct</h3>
                        <p>
                            The Group maintains a comprehensive Code of Business Conduct and Ethics applicable to all directors, officers, employees, and representatives. The Code addresses conflicts of interest, confidentiality obligations, fair dealing, protection of company assets, compliance with laws, and reporting of violations.
                        </p>
                        <p>
                            All personnel receive Code training upon joining and periodic refresher training thereafter. Acknowledgment of Code obligations is documented and maintained. Violations are subject to disciplinary action up to and including termination of employment or engagement.
                        </p>
                    </div>
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">7.2 Anti-Corruption</h3>
                        <p>
                            The Group maintains zero tolerance for bribery and corruption in all forms. Anti-corruption policies comply with the Malaysian Anti-Corruption Commission Act 2009 and international anti-corruption standards including the UK Bribery Act and US Foreign Corrupt Practices Act where applicable.
                        </p>
                        <p>
                            Anti-corruption framework encompasses prohibition of improper payments, gifts and hospitality policies, third-party due diligence, and reporting mechanisms. Regular risk assessments identify corruption risks and inform control enhancements.
                        </p>
                    </div>
                    <div>
                        <h3 class="text-base text-champagne-400 mb-2 font-medium ml-0">7.3 Whistleblower Protection</h3>
                        <p>
                            The Group maintains confidential reporting channels for employees and stakeholders to report suspected violations of law, regulation, or company policy. Whistleblower protection policies prohibit retaliation against individuals making good faith reports.
                        </p>
                        <p>
                            Reports are investigated promptly and thoroughly by appropriate personnel. Investigation findings inform corrective actions, disciplinary measures, and compliance program enhancements. Reporting and investigation records are maintained in accordance with legal requirements.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 8 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    8. Risk Management
                </h2>
                <div class="space-y-3 text-sm text-platinum-200 leading-relaxed">
                    <p>
                        The Group implements enterprise risk management (ERM) framework addressing strategic, operational, financial, and compliance risks. Risk management processes encompass risk identification, assessment, mitigation, monitoring, and reporting.
                    </p>
                    <p>
                        Risk appetite and tolerance levels are established by the Board and inform strategic decision-making and operational planning. Risk registers document identified risks, control measures, residual risk levels, and action plans for risk mitigation.
                    </p>
                    <p>
                        Regular risk assessments evaluate emerging risks including regulatory changes, market developments, operational disruptions, and cybersecurity threats. Risk management reporting provides Board and management visibility into risk exposure and mitigation effectiveness.
                    </p>
                </div>
            </div>

            <!-- Section 9 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    9. Third-Party Management
                </h2>
                <div class="space-y-3 text-sm text-platinum-200 leading-relaxed">
                    <p>
                        Third-party relationships are subject to due diligence, contractual controls, and ongoing monitoring to ensure compliance with Group standards and regulatory requirements. Due diligence scope addresses financial stability, operational capability, regulatory compliance, and reputational considerations.
                    </p>
                    <p>
                        Contracts with suppliers, service providers, and business partners include appropriate compliance obligations, audit rights, and termination provisions. High-risk third parties undergo enhanced due diligence and more frequent monitoring.
                    </p>
                    <p>
                        Third-party performance and compliance are monitored through regular reviews, audits, and performance metrics. Non-compliance issues trigger corrective action requirements and, if unresolved, relationship termination.
                    </p>
                </div>
            </div>

            <!-- Section 10 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    10. Compliance Monitoring and Reporting
                </h2>
                <div class="space-y-3 text-sm text-platinum-200 leading-relaxed">
                    <p>
                        Compliance function maintains ongoing monitoring of regulatory developments, conducts compliance assessments, and coordinates regulatory reporting obligations. Compliance monitoring activities include transaction reviews, policy compliance testing, and regulatory change impact analysis.
                    </p>
                    <p>
                        Compliance reporting provides Board and management visibility into compliance status, identified issues, remediation progress, and emerging regulatory risks. Regulatory filings and notifications are submitted accurately and timely in accordance with applicable requirements.
                    </p>
                    <p>
                        Internal audit function provides independent assurance regarding compliance program effectiveness, internal control adequacy, and risk management processes. Audit findings inform compliance program enhancements and management action plans.
                    </p>
                </div>
            </div>

            <!-- Section 11 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    11. Continuous Improvement
                </h2>
                <div class="space-y-3 text-sm text-platinum-200 leading-relaxed">
                    <p>
                        The Group is committed to continuous enhancement of compliance programs, internal controls, and risk management processes. Improvement initiatives are informed by regulatory developments, industry best practices, internal assessments, and stakeholder feedback.
                    </p>
                    <p>
                        Compliance training programs ensure personnel understand their obligations and can identify and escalate compliance concerns. Training content is tailored to role-specific risks and updated to reflect regulatory changes and lessons learned from compliance events.
                    </p>
                    <p>
                        Compliance culture is reinforced through tone from the top, accountability mechanisms, recognition of compliance excellence, and transparent communication regarding compliance expectations and performance.
                    </p>
                </div>
            </div>

            <!-- Section 12 -->
            <div>
                <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6">
                    12. Contact Information
                </h2>
                <div class="space-y-3 text-sm text-platinum-200 leading-relaxed">
                    <p>
                        For compliance-related inquiries, regulatory matters, or to report compliance concerns:
                    </p>
                    <div class="mt-6 p-6 bg-obsidian-800 border border-champagne-500/20">
                        <p class="font-semibold text-platinum-50 mb-4">Compliance Department</p>
                        <p>Unggul Bronto Sdn. Bhd.</p>
                        <p>Registration No: 202301027920 (1521843-P)</p>
                        <p>Kuala Lumpur, Malaysia</p>
                        <p class="mt-4">Email: <a href="mailto:compliance@unggulaxiom.com" class="text-champagne-400 hover:text-champagne-300">compliance@unggulaxiom.com</a></p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
