<?php
/**
 * ============================================
 * ABOUT PAGE - UNGGUL AXIOM GROUP
 * ============================================
 * Purpose: Institutional overview and strategic positioning
 * Architecture: Chairman's letter aesthetic
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'About';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- ============================================ -->
<!-- PAGE VANGUARD: INSTITUTIONAL HEADER -->
<!-- ============================================ -->
<section class="min-h-[60vh] flex items-center justify-center bg-obsidian-950 py-40 isolate">
    <div class="container-sovereign">
        <div class="max-w-5xl">
            <h1 class="split-hero-title font-serif text-6xl md:text-7xl lg:text-8xl text-platinum-50 tracking-tight leading-none mb-8">
                Integrated Infrastructure for the Global Halal Economy
            </h1>
            <p class="text-xl text-sovereign-400 leading-relaxed">
                Building infrastructure systems across food production, pharmaceuticals, manufacturing, logistics, finance, and trade.
            </p>
        </div>
    </div>
</section>

<!-- ============================================ -->
<!-- EDITORIAL BODY: PHILOSOPHY & STRATEGY -->
<!-- ============================================ -->
<section class="py-32 bg-obsidian-900 text-platinum-50 isolate">
    <div class="container-sovereign">

        <!-- 12-COLUMN GRID WITH OFFSET EDITORIAL LAYOUT -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-12">

            <!-- BLOCK 1: INSTITUTIONAL MANDATE -->
            <div class="md:col-start-4 md:col-span-9">
                <div class="mb-12">
                    <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                        INSTITUTIONAL MANDATE
                    </h2>
                    <div class="w-16 h-px bg-champagne-500"></div>
                </div>

                <div class="space-y-8">
                    <div class="border-l border-champagne-500/30 pl-8">
                        <p class="text-lg text-platinum-200 leading-institutional">
                            Unggul Axiom Group operates as a sovereign-level infrastructure coordination platform, designed to integrate production systems, compliance frameworks, and capital deployment mechanisms across the global halal economy.
                        </p>
                    </div>

                    <div class="border-l border-champagne-500/30 pl-8">
                        <p class="text-lg text-platinum-200 leading-institutional">
                            The platform architecture enables systematic deployment across six operational sectors: food and agriculture, pharmaceuticals and wellness, manufacturing, logistics and distribution, Islamic finance, and global trade infrastructure.
                        </p>
                    </div>

                    <div class="border-l border-champagne-500/30 pl-8">
                        <p class="text-lg text-platinum-200 leading-institutional">
                            Structured for institutional participation, the organization maintains operational command in Kuala Lumpur, Malaysia, under the governance of UNGGUL BRONTO SDN. BHD. (Registration No: 202301027920).
                        </p>
                    </div>
                </div>
            </div>

            <!-- BLOCK 2: OUR PHILOSOPHY -->
            <div class="md:col-start-4 md:col-span-9 mt-24">
                <div class="border-l-2 border-champagne-500 pl-12" data-gsap-fade-up data-gsap-delay="0.2">
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block">
                        OUR APPROACH
                    </span>
                    <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-editorial mb-8 leading-tight">
                        Strategic Infrastructure Development
                    </h2>
                    <p class="text-lg text-platinum-200 leading-institutional mb-8">
                        Our business activities encompass investment holding, venture building, project development, and strategic partnerships across key sectors:
                    </p>
                    <ul class="space-y-4 text-lg text-platinum-200 leading-institutional">
                        <li class="flex items-start">
                            <span class="text-champagne-500 mr-4">-</span>
                            <span>Halal food production and processing infrastructure</span>
                        </li>
                        <li class="flex items-start">
                            <span class="text-champagne-500 mr-4">-</span>
                            <span>Halal agri-tech and smart agriculture systems</span>
                        </li>
                        <li class="flex items-start">
                            <span class="text-champagne-500 mr-4">-</span>
                            <span>Pharmaceutical manufacturing and distribution</span>
                        </li>
                        <li class="flex items-start">
                            <span class="text-champagne-500 mr-4">-</span>
                            <span>Logistics and halal supply chain certification</span>
                        </li>
                        <li class="flex items-start">
                            <span class="text-champagne-500 mr-4">-</span>
                            <span>Food security systems and livestock integration</span>
                        </li>
                        <li class="flex items-start">
                            <span class="text-champagne-500 mr-4">-</span>
                            <span>Agri-technology innovation and development</span>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- BLOCK 3: STRATEGIC OBJECTIVE -->
            <div class="md:col-start-4 md:col-span-9 mt-24">
                <div class="border-l-2 border-champagne-500 pl-12" data-gsap-fade-up data-gsap-delay="0.3">
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block">
                        STRATEGIC OBJECTIVE
                    </span>
                    <p class="text-2xl md:text-3xl font-serif text-platinum-50 leading-relaxed tracking-editorial">
                        To develop scalable halal infrastructure platforms that enable traceability, compliance, and market access across the global halal economy.
                    </p>
                </div>
            </div>

            <!-- BLOCK 4: CORPORATE STRUCTURE -->
            <div class="md:col-start-4 md:col-span-9 mt-24">
                <div class="border-l-2 border-champagne-500 pl-12" data-gsap-fade-up data-gsap-delay="0.4">
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block">
                        CORPORATE STRUCTURE
                    </span>
                    <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-editorial mb-8 leading-tight">
                        Unggul Bronto Sdn. Bhd.
                    </h2>
                    <p class="text-lg text-platinum-200 leading-institutional mb-4">
                        Registration No: 202301027920 (1521843-P)
                    </p>
                    <p class="text-lg text-platinum-200 leading-institutional">
                        Malaysian-registered investment holding company operating under the Unggul Axiom Group platform, focused on halal infrastructure development, wholesale trade, domestic trade affairs, and strategic partnerships within the global halal economy.
                    </p>
                </div>
            </div>

        </div>

    </div>
</section>

<?php
require_once INCLUDES_PATH . '/footer.php';
?>
