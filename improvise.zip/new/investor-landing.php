<?php
/**
 * ============================================
 * INVESTOR LANDING PAGE - HIGH CONVERSION VERSION
 * ============================================
 * Purpose: Strategic institutional investment page
 * Architecture: Data room aesthetic with conversion focus
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Investor Landing';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- ============================================ -->
<!-- HERO SECTION -->
<!-- ============================================ -->
<section class="min-h-[70vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-24 relative z-10">
        <div class="max-w-5xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                INSTITUTIONAL INVESTMENT OPPORTUNITY
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-8xl text-platinum-50 mb-8 tracking-editorial leading-tight font-extrabold">
                Unggul Axiom Group
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl md:text-2xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto mb-4">
                Emerging Halal Infrastructure Platform
            </p>
            <p class="text-lg md:text-xl text-champagne-500/80 tracking-institutional max-w-2xl mx-auto">
                Backed by South Korean Government Technology Transfer
            </p>
        </div>
    </div>
</section>

<!-- ============================================ -->
<!-- SOUTH KOREA BACKING SECTION -->
<!-- ============================================ -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4 block uppercase font-semibold" data-gsap-fade-up>
            GOVERNMENT BACKING
        </span>

        <div class="max-w-4xl mb-12" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight font-bold">
                South Korean Government Support
            </h2>
            <p class="text-lg text-platinum-200 leading-institutional mb-6">
                The Unggul Bronto project is heavily backed by the South Korean government through comprehensive technology transfer agreements, institutional support frameworks, and direct financial commitment.
            </p>
            
            <div class="glass-panel p-8 rounded-2xl border-l-4 border-l-champagne-500 border-t border-r border-b border-champagne-500/15 relative overflow-hidden my-8">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <p class="text-2xl font-serif text-champagne-500 mb-2 font-bold">
                        USD 10 Million Government Grant
                    </p>
                    <p class="text-lg text-platinum-200 leading-institutional">
                        South Korean government committed to providing USD 10 million grant upon successful completion and validation of the first farm deployment in Malaysia.
                    </p>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
            <div class="glass-card p-8 rounded-2xl border border-champagne-500/10 flex flex-col justify-between" data-gsap-fade-up>
                <div>
                    <h3 class="text-2xl font-serif text-platinum-50 mb-4 font-bold">AI and IoT Technology Transfer</h3>
                    <p class="text-base text-platinum-200 leading-institutional mb-4">
                        Complete transfer of South Korean advanced poultry production technology powered by artificial intelligence and Internet of Things systems. This technology represents the most sophisticated chicken farming infrastructure currently deployed globally.
                    </p>
                </div>
                <p class="text-sm text-sovereign-400 leading-institutional mt-4 pt-4 border-t border-champagne-500/10">
                    South Korean AI and IoT integrated systems significantly outperform all existing chicken farming technology in Malaysia across every operational metric including feed conversion efficiency, disease prevention, growth optimization, and production yield.
                </p>
            </div>

            <div class="glass-card p-8 rounded-2xl border border-champagne-500/10 flex flex-col justify-between" data-gsap-fade-up>
                <div>
                    <h3 class="text-2xl font-serif text-platinum-50 mb-4 font-bold">Institutional Framework</h3>
                    <p class="text-base text-platinum-200 leading-institutional">
                        Government supported infrastructure development with bilateral cooperation agreements ensuring long term operational stability.
                    </p>
                </div>
                <p class="text-sm text-sovereign-400 leading-institutional mt-4 pt-4 border-t border-champagne-500/10">
                    Secured via inter-governmental frameworks to mitigate sovereign and political risk while establishing long-term regional development viability.
                </p>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- TECHNOLOGY TRANSFER DETAILS -->
<!-- ============================================ -->
<section class="py-24 bg-gradient-to-b from-obsidian-900 to-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4 block uppercase font-semibold" data-gsap-fade-up>
            TECHNOLOGY TRANSFER
        </span>

        <div class="max-w-4xl mb-12" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight font-bold">
                Complete Operational Independence
            </h2>
            <p class="text-lg text-platinum-200 leading-institutional">
                Full technology transfer from South Korea enables complete operational autonomy. From parent stock to feed formulation, every component is transferred with 100% rights and zero ongoing dependencies.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div class="glass-card p-8 rounded-2xl border border-champagne-500/10" data-gsap-fade-up>
                <div class="text-champagne-500 font-mono text-sm mb-4">01 // GENETIC PROTOCOL</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-4 font-bold">Parent Stock Technology</h3>
                <p class="text-sm text-platinum-200 leading-relaxed">
                    Complete breeding technology transfer including genetic lines, breeding protocols, and hatchery systems. Full operational control without external dependencies.
                </p>
            </div>

            <div class="glass-card p-8 rounded-2xl border border-champagne-500/10" data-gsap-fade-up>
                <div class="text-champagne-500 font-mono text-sm mb-4">02 // PATENTED SCIENCE</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-4 font-bold">Exclusive Feed Formula</h3>
                <p class="text-sm text-platinum-200 leading-relaxed">
                    Patented feed formulation developed by South Korean research institutions, granted with 100% usage rights. Proprietary nutritional specifications optimized for halal production standards.
                </p>
            </div>

            <div class="glass-card p-8 rounded-2xl border border-champagne-500/10" data-gsap-fade-up>
                <div class="text-champagne-500 font-mono text-sm mb-4">03 // AUTONOMOUS SYSTEM</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-4 font-bold">End to End Systems</h3>
                <p class="text-sm text-platinum-200 leading-relaxed">
                    Complete operational systems covering production, processing, quality control, and distribution. No reliance on external companies for any operational component.
                </p>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- CORE SECTION -->
<!-- ============================================ -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4 block uppercase font-semibold" data-gsap-fade-up>
            CORE INFRASTRUCTURE
        </span>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div class="glass-card p-8 rounded-2xl border border-champagne-500/10 relative overflow-hidden" data-gsap-fade-up>
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <span class="text-sovereign-xs text-champagne-500 tracking-wider mb-2 block uppercase">Platform</span>
                    <h3 class="text-2xl font-serif text-platinum-50 mb-4 font-bold">UHIC</h3>
                    <p class="text-base text-platinum-200 leading-relaxed">
                        Unggul Halal Integrated Centre serves as the coordinating platform for multi sector halal infrastructure deployment.
                    </p>
                </div>
            </div>
            
            <div class="glass-card p-8 rounded-2xl border border-champagne-500/10 relative overflow-hidden" data-gsap-fade-up>
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <span class="text-sovereign-xs text-champagne-500 tracking-wider mb-2 block uppercase">Pilot Project</span>
                    <h3 class="text-2xl font-serif text-platinum-50 mb-4 font-bold">CIPU</h3>
                    <p class="text-base text-platinum-200 leading-relaxed">
                        Central Integrated Poultry Unggul demonstrates the operational model with South Korean technology integration.
                    </p>
                </div>
            </div>
        </div>

        <div class="max-w-4xl" data-gsap-fade-up>
            <p class="text-2xl text-champagne-500 font-serif leading-institutional">
                Expansion Strategy: Established in Malaysia, Scaling Regionally.
            </p>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- FINANCIAL SNAPSHOT -->
<!-- ============================================ -->
<section class="py-24 bg-gradient-to-b from-obsidian-900 to-obsidian-950 text-platinum-50 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4 block uppercase font-semibold" data-gsap-fade-up>
            FINANCIAL SNAPSHOT
        </span>

        <div class="max-w-6xl">
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-12 leading-tight font-bold" data-gsap-fade-up>
                Per-Node Economics
            </h2>
 
            <!-- Key Metrics Grid -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
                <div class="glass-card p-6 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">ANNUAL CAPACITY</p>
                        <p class="text-4xl font-serif text-platinum-50 mb-2 font-bold">3.6M</p>
                        <p class="text-xs text-sovereign-400">Chickens per node</p>
                    </div>
                </div>
 
                <div class="glass-card p-6 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">BASE NET PROFIT</p>
                        <p class="text-4xl font-serif text-platinum-50 mb-2 font-bold">RM19.8M</p>
                        <p class="text-xs text-sovereign-400">Annual per node</p>
                    </div>
                </div>
 
                <div class="glass-card p-6 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">TARGET IRR</p>
                        <p class="text-4xl font-serif text-platinum-50 mb-2 font-bold">25-35%</p>
                        <p class="text-xs text-sovereign-400">Institutional returns</p>
                    </div>
                </div>
 
                <div class="glass-card p-6 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">PAYBACK PERIOD</p>
                        <p class="text-4xl font-serif text-platinum-50 mb-2 font-bold">3-4 Yrs</p>
                        <p class="text-xs text-sovereign-400">Capital recovery</p>
                    </div>
                </div>
            </div>
 
            <!-- Revenue Projection Chart -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
                <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">5-Year Revenue Projection</h3>
                        <canvas id="revenueChart" class="w-full" style="max-height: 300px;"></canvas>
                        <p class="text-xs text-sovereign-400 mt-4">Based on 5-node deployment by Year 3</p>
                    </div>
                </div>
 
                <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Profit Margin Analysis</h3>
                        <canvas id="marginChart" class="w-full" style="max-height: 300px;"></canvas>
                        <p class="text-xs text-sovereign-400 mt-4">Operational efficiency vs. industry benchmark</p>
                    </div>
                </div>
            </div>
 
            <!-- Cost Structure Breakdown -->
            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 relative overflow-hidden mb-16" data-gsap-fade-up>
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h3 class="text-xl font-serif text-platinum-50 mb-8 font-bold tracking-wide">Cost Structure per Node</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                        <div class="flex justify-center">
                            <canvas id="costChart" style="max-height: 280px; max-width: 280px;"></canvas>
                        </div>
                        <div class="space-y-6">
                            <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                                <div class="flex items-center gap-3">
                                    <span class="w-4 h-4 bg-champagne-500 rounded-sm"></span>
                                    <span class="text-platinum-200">Feed & Inputs</span>
                                </div>
                                <span class="text-platinum-100 font-medium">42%</span>
                            </div>
                            <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                                <div class="flex items-center gap-3">
                                    <span class="w-4 h-4 bg-champagne-400 rounded-sm"></span>
                                    <span class="text-platinum-200">Labor & Operations</span>
                                </div>
                                <span class="text-platinum-100 font-medium">18%</span>
                            </div>
                            <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                                <div class="flex items-center gap-3">
                                    <span class="w-4 h-4 bg-champagne-300 rounded-sm"></span>
                                    <span class="text-platinum-200">Utilities & Maintenance</span>
                                </div>
                                <span class="text-platinum-100 font-medium">12%</span>
                            </div>
                            <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                                <div class="flex items-center gap-3">
                                    <span class="w-4 h-4 bg-champagne-200 rounded-sm"></span>
                                    <span class="text-platinum-200">Logistics & Distribution</span>
                                </div>
                                <span class="text-platinum-100 font-medium">8%</span>
                            </div>
                            <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                                <div class="flex items-center gap-3">
                                    <span class="w-4 h-4 bg-sovereign-500 rounded-sm"></span>
                                    <span class="text-platinum-200">Net Profit Margin</span>
                                </div>
                                <span class="text-champagne-500 font-semibold text-lg">20%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 
            <!-- Scalability Model -->
            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h3 class="text-2xl font-serif text-platinum-50 mb-8 font-bold tracking-wide">Scalability Framework</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <div>
                            <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3 font-semibold">MODULAR DEPLOYMENT</p>
                            <p class="text-sm text-platinum-200 leading-relaxed">
                                Each node operates independently with standardized infrastructure enabling rapid replication across markets.
                            </p>
                        </div>
                        <div>
                            <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3 font-semibold">ZERO DEPENDENCIES</p>
                            <p class="text-sm text-platinum-200 leading-relaxed">
                                Complete operational autonomy from breeding to distribution eliminates supply chain vulnerabilities.
                            </p>
                        </div>
                        <div>
                            <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3 font-semibold">TECHNOLOGY ADVANTAGE</p>
                            <p class="text-sm text-platinum-200 leading-relaxed">
                                AI-powered systems deliver 30% cost advantage versus conventional operations.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
 
    </div>
</section>
 
<!-- Chart.js Integration -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const chartColors = {
        champagne: '#C9A961',
        champagneLight: '#D4B876',
        champagneLighter: '#E0C89B',
        champagneLightest: '#EBD8B0',
        sovereign: '#607A92',
        obsidian: '#0F1E33',
        platinum: '#F5F7F9'
    };
 
    // Revenue Projection Chart
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5'],
                datasets: [{
                    label: 'Projected Revenue (RM Million)',
                    data: [19.8, 39.6, 99.0, 158.4, 198.0],
                    borderColor: chartColors.champagne,
                    backgroundColor: chartColors.champagne + '20',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 6,
                    pointBackgroundColor: chartColors.champagne,
                    pointBorderColor: chartColors.obsidian,
                    pointBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: chartColors.obsidian,
                        titleColor: chartColors.platinum,
                        bodyColor: chartColors.platinum,
                        borderColor: chartColors.champagne,
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return 'RM ' + context.parsed.y.toFixed(1) + 'M';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: chartColors.champagne + '10' },
                        ticks: {
                            color: chartColors.sovereign,
                            callback: function(value) {
                                return 'RM ' + value + 'M';
                            }
                        }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: chartColors.sovereign }
                    }
                }
            }
        });
    }
 
    // Profit Margin Chart
    const marginCtx = document.getElementById('marginChart');
    if (marginCtx) {
        new Chart(marginCtx, {
            type: 'bar',
            data: {
                labels: ['Unggul Axiom\n(AI-Powered)', 'Industry\nAverage', 'Traditional\nFarms'],
                datasets: [{
                    label: 'Net Profit Margin (%)',
                    data: [20, 12, 8],
                    backgroundColor: [
                        chartColors.champagne,
                        chartColors.champagneLight,
                        chartColors.sovereign
                    ],
                    borderWidth: 0,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: chartColors.obsidian,
                        titleColor: chartColors.platinum,
                        bodyColor: chartColors.platinum,
                        borderColor: chartColors.champagne,
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return context.parsed.y + '% Net Margin';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 25,
                        grid: { color: chartColors.champagne + '10' },
                        ticks: {
                            color: chartColors.sovereign,
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    },
                    x: {
                        grid: { display: false },
                        ticks: {
                            color: chartColors.sovereign,
                            font: { size: 11 }
                        }
                    }
                }
            }
        });
    }
 
    // Cost Structure Doughnut Chart
    const costCtx = document.getElementById('costChart');
    if (costCtx) {
        new Chart(costCtx, {
            type: 'doughnut',
            data: {
                labels: ['Feed & Inputs', 'Labor & Operations', 'Utilities & Maintenance', 'Logistics & Distribution', 'Net Profit'],
                datasets: [{
                    data: [42, 18, 12, 8, 20],
                    backgroundColor: [
                        chartColors.champagne,
                        chartColors.champagneLight,
                        chartColors.champagneLighter,
                        chartColors.champagneLightest,
                        chartColors.sovereign
                    ],
                    borderWidth: 0,
                    hoverOffset: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: chartColors.obsidian,
                        titleColor: chartColors.platinum,
                        bodyColor: chartColors.platinum,
                        borderColor: chartColors.champagne,
                        borderWidth: 1,
                        padding: 12,
                        displayColors: true,
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed + '%';
                            }
                        }
                    }
                },
                cutout: '65%'
            }
        });
    }
});
</script>
 
<!-- ============================================ -->
<!-- CAPITAL ENTRY -->
<!-- ============================================ -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 text-platinum-50 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4 block uppercase font-semibold" data-gsap-fade-up>
            CAPITAL ENTRY
        </span>

        <div class="max-w-4xl mb-12" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight font-bold">
                Investment Structure
            </h2>
            <p class="text-lg text-platinum-200 leading-institutional">
                Flexible participation frameworks designed for institutional investors seeking exposure to halal infrastructure development.
            </p>
        </div>

        <div class="grid grid-cols-1 gap-6 max-w-4xl">
            <div class="glass-card p-8 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h3 class="text-2xl font-serif text-platinum-50 mb-3 font-bold">Equity Participation</h3>
                    <p class="text-base text-platinum-200 leading-institutional mb-4">
                        Direct equity investment in Unggul Bronto Sdn. Bhd. with participation in pilot phase development and regional expansion.
                    </p>
                    <div class="flex flex-wrap gap-4 text-xs font-mono uppercase tracking-wider text-champagne-500 pt-4 border-t border-champagne-500/10">
                        <span>MIN INVESTMENT: RM5M</span>
                        <span class="text-sovereign-500">|</span>
                        <span>TARGET IRR: 25% - 35%</span>
                        <span class="text-sovereign-500">|</span>
                        <span>EXIT TIMELINE: 1 year</span>
                    </div>
                </div>
            </div>

            <div class="glass-card p-8 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h3 class="text-2xl font-serif text-platinum-50 mb-3 font-bold">Joint Venture Systems</h3>
                    <p class="text-base text-platinum-200 leading-institutional mb-4">
                        Co development partnerships for regional node deployment. Shared investment in infrastructure development with technology transfer rights.
                    </p>
                    <div class="flex flex-wrap gap-4 text-xs font-mono uppercase tracking-wider text-champagne-500 pt-4 border-t border-champagne-500/10">
                        <span>STRUCTURE: 51% Unggul / 49% Partner</span>
                        <span class="text-sovereign-500">|</span>
                        <span>NODE INVESTMENT: RM12M - RM18M</span>
                    </div>
                </div>
            </div>

            <div class="glass-card p-8 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h3 class="text-2xl font-serif text-platinum-50 mb-3 font-bold">Infrastructure Financing</h3>
                    <p class="text-base text-platinum-200 leading-institutional mb-4">
                        Project based financing for specific infrastructure components. Shariah compliant financing structures available.
                    </p>
                    <div class="flex flex-wrap gap-4 text-xs font-mono uppercase tracking-wider text-champagne-500 pt-4 border-t border-champagne-500/10">
                        <span>FACILITY SIZE: RM10M - RM50M</span>
                        <span class="text-sovereign-500">|</span>
                        <span>TENOR: 5 - 10 years</span>
                        <span class="text-sovereign-500">|</span>
                        <span>SECURITY: First charge on assets</span>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
 
 
<!-- ============================================ -->
<!-- INVESTMENT THESIS -->
<!-- ============================================ -->
<section class="py-24 bg-gradient-to-b from-obsidian-900 to-obsidian-950 text-platinum-50 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4 block uppercase font-semibold" data-gsap-fade-up>
            INVESTMENT THESIS
        </span>

        <div class="max-w-4xl" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight font-bold">
                Why Invest Now
            </h2>
 
            <div class="space-y-8">
                <div class="glass-panel p-8 rounded-2xl border-l-4 border-l-champagne-500 border-t border-r border-b border-champagne-500/15 relative overflow-hidden">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <p class="text-xl font-serif text-champagne-500 leading-tight mb-4 font-semibold">
                            Rare combination of government backing, proven technology, and first mover advantage in high growth market.
                        </p>
                        <p class="text-base text-platinum-200 leading-institutional">
                            South Korean government support provides technology access typically unavailable to private enterprises. Complete operational independence eliminates ongoing dependencies. Pilot phase demonstrates model viability before regional scaling.
                        </p>
                    </div>
                </div>
 
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="glass-card p-6 rounded-2xl border border-champagne-500/10">
                        <h3 class="text-xl font-serif text-platinum-50 mb-4 font-bold">Market Opportunity</h3>
                        <ul class="space-y-3 text-sm text-platinum-200">
                            <li class="flex items-center gap-2"><span class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></span> USD 3 trillion global halal food market</li>
                            <li class="flex items-center gap-2"><span class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></span> 8% annual growth in Malaysia market</li>
                            <li class="flex items-center gap-2"><span class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></span> Increasing export demand to Middle East</li>
                            <li class="flex items-center gap-2"><span class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></span> Government food security priorities</li>
                        </ul>
                    </div>
 
                    <div class="glass-card p-6 rounded-2xl border border-champagne-500/10">
                        <h3 class="text-xl font-serif text-platinum-50 mb-4 font-bold">Execution Readiness</h3>
                        <ul class="space-y-3 text-sm text-platinum-200">
                            <li class="flex items-center gap-2"><span class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></span> Technology transfer agreements finalized</li>
                            <li class="flex items-center gap-2"><span class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></span> Pilot site identified and secured</li>
                            <li class="flex items-center gap-2"><span class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></span> Management team assembled</li>
                            <li class="flex items-center gap-2"><span class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></span> Regulatory approvals in progress</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
 
    </div>
</section>
 
<!-- ============================================ -->
<!-- ASIA EXPANSION STRATEGY -->
<!-- ============================================ -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 text-platinum-50 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4 block uppercase font-semibold" data-gsap-fade-up>
            ASIA EXPANSION STRATEGY
        </span>

        <div class="max-w-4xl mb-12" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight font-bold">
                Regional Dominance Framework
            </h2>
            <p class="text-lg text-platinum-200 leading-institutional mb-6">
                Unggul Bronto is positioned to establish market leadership across the Asian continent through systematic deployment of South Korean AI and IoT powered infrastructure.
            </p>
            
            <div class="glass-panel p-8 rounded-2xl border-l-4 border-l-champagne-500 border-t border-r border-b border-champagne-500/15 relative overflow-hidden">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <p class="text-2xl font-serif text-champagne-500 mb-4 font-bold">
                        Asia Continental Expansion: 2026 to 2030
                    </p>
                    <p class="text-base text-platinum-200 leading-institutional">
                        Strategic rollout across 12 Asian markets with technology superiority providing insurmountable competitive advantage. First mover advantage combined with government backed AI systems creates defensible market position.
                    </p>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div class="glass-card p-8 rounded-2xl border border-champagne-500/20" data-gsap-fade-up>
                <div class="text-champagne-500 font-mono text-xs mb-3 font-semibold">PHASE 1</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-4 font-bold">Malaysia Dominance</h3>
                <p class="text-sm text-platinum-200 leading-relaxed mb-4">
                    2026 to 2027: Establish market leadership in Malaysia through rapid node deployment across Peninsular Malaysia, Sabah, and Sarawak.
                </p>
                <ul class="space-y-2 text-xs text-sovereign-400">
                    <li>• 5 operational nodes by end 2026</li>
                    <li>• 15% market share by 2027</li>
                    <li>• Export certification secured</li>
                </ul>
            </div>

            <div class="glass-card p-8 rounded-2xl border border-champagne-500/20" data-gsap-fade-up>
                <div class="text-champagne-500 font-mono text-xs mb-3 font-semibold">PHASE 2</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-4 font-bold">Southeast Asia</h3>
                <p class="text-sm text-platinum-200 leading-relaxed mb-4">
                    2027 to 2028: Regional expansion into Indonesia, Thailand, Singapore, and Brunei with technology licensing partnerships.
                </p>
                <ul class="space-y-2 text-xs text-sovereign-400">
                    <li>• 20 nodes across 4 countries</li>
                    <li>• Joint venture partnerships</li>
                    <li>• Regional supply chain control</li>
                </ul>
            </div>

            <div class="glass-card p-8 rounded-2xl border border-champagne-500/20" data-gsap-fade-up>
                <div class="text-champagne-500 font-mono text-xs mb-3 font-semibold">PHASE 3</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-4 font-bold">Pan Asia</h3>
                <p class="text-sm text-platinum-200 leading-relaxed mb-4">
                    2028 to 2030: Continental expansion into Middle East, South Asia, and East Asia markets with established infrastructure model.
                </p>
                <ul class="space-y-2 text-xs text-sovereign-400">
                    <li>• 50+ nodes across 12 countries</li>
                    <li>• Market leadership position</li>
                    <li>• Technology licensing revenue</li>
                </ul>
            </div>
        </div>

        <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 relative overflow-hidden" data-gsap-fade-up>
            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
            <div class="relative z-10">
                <h3 class="text-2xl font-serif text-platinum-50 mb-6 font-bold">Competitive Moat</h3>
                <p class="text-base text-platinum-200 leading-institutional mb-6">
                    South Korean AI and IoT technology creates insurmountable barrier to entry. Competitors using conventional farming methods cannot match production efficiency, cost structure, or quality consistency.
                </p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="flex items-start gap-4">
                        <span class="text-champagne-500 text-xl font-bold">→</span>
                        <p class="text-sm text-platinum-200 leading-relaxed">
                            <strong>Feed Conversion Ratio:</strong> 30% better than Malaysia industry average through AI optimized nutrition management.
                        </p>
                    </div>
                    <div class="flex items-start gap-4">
                        <span class="text-champagne-500 text-xl font-bold">→</span>
                        <p class="text-sm text-platinum-200 leading-relaxed">
                            <strong>Disease Prevention:</strong> IoT monitoring reduces mortality rates by 40% versus conventional systems.
                        </p>
                    </div>
                    <div class="flex items-start gap-4">
                        <span class="text-champagne-500 text-xl font-bold">→</span>
                        <p class="text-sm text-platinum-200 leading-relaxed">
                            <strong>Growth Optimization:</strong> AI controlled environment reduces time to market by 15% with superior meat quality.
                        </p>
                    </div>
                    <div class="flex items-start gap-4">
                        <span class="text-champagne-500 text-xl font-bold">→</span>
                        <p class="text-sm text-platinum-200 leading-relaxed">
                            <strong>Labor Efficiency:</strong> Automated systems reduce labor costs by 50% while improving operational consistency.
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- NEXT STEPS -->
<!-- ============================================ -->
<section class="py-24 bg-gradient-to-b from-obsidian-900 to-obsidian-950 text-platinum-50 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4 block uppercase font-semibold" data-gsap-fade-up>
            NEXT STEPS
        </span>

        <div class="max-w-4xl mx-auto" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-12 leading-tight text-center font-bold">
                Investment Process
            </h2>

            <div class="space-y-6">
                <div class="glass-card flex items-start gap-6 border-l-4 border-l-champagne-500 p-8 rounded-r-2xl border-t border-r border-b border-champagne-500/10">
                    <span class="text-champagne-500 font-mono text-sm font-bold">01</span>
                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-2 font-bold">Initial Discussion</h3>
                        <p class="text-sm text-platinum-200 leading-relaxed">
                            Confidential discussion of investment parameters, timeline expectations, and preliminary due diligence requirements.
                        </p>
                    </div>
                </div>

                <div class="glass-card flex items-start gap-6 border-l-4 border-l-champagne-500 p-8 rounded-r-2xl border-t border-r border-b border-champagne-500/10">
                    <span class="text-champagne-500 font-mono text-sm font-bold">02</span>
                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-2 font-bold">Data Room Access</h3>
                        <p class="text-sm text-platinum-200 leading-relaxed">
                            Comprehensive documentation including financial models, technology transfer agreements, operational plans, and regulatory compliance materials.
                        </p>
                    </div>
                </div>

                <div class="glass-card flex items-start gap-6 border-l-4 border-l-champagne-500 p-8 rounded-r-2xl border-t border-r border-b border-champagne-500/10">
                    <span class="text-champagne-500 font-mono text-sm font-bold">03</span>
                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-2 font-bold">Due Diligence</h3>
                        <p class="text-sm text-platinum-200 leading-relaxed">
                            Technical, financial, and legal due diligence with site visits and management presentations. Typical timeline: 4 to 6 weeks.
                        </p>
                    </div>
                </div>

                <div class="glass-card flex items-start gap-6 border-l-4 border-l-champagne-500 p-8 rounded-r-2xl border-t border-r border-b border-champagne-500/10">
                    <span class="text-champagne-500 font-mono text-sm font-bold">04</span>
                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-2 font-bold">Term Sheet & Closing</h3>
                        <p class="text-sm text-platinum-200 leading-relaxed">
                            Negotiation of investment terms, shareholder agreements, and closing documentation. Target closing: 8 to 12 weeks from initial discussion.
                        </p>
                    </div>
                </div>
            </div>

            <div class="mt-16 pt-12 border-t border-champagne-500/10 text-center">
                <p class="text-xl text-platinum-200 leading-institutional mb-8 font-serif">
                    For institutional investment inquiries:
                </p>
                <a href="<?php echo url('/partnerships'); ?>" 
                   class="inline-flex items-center gap-3 px-10 py-4 rounded-lg bg-gradient-to-r from-champagne-600 to-champagne-500 text-obsidian-950 text-sm font-semibold tracking-wider uppercase hover:from-champagne-500 hover:to-champagne-400 transition-all duration-300 hover:shadow-[0_0_25px_rgba(201,169,97,0.35)] shadow-lg transform hover:-translate-y-0.5">
                    <span>Submit Investment Inquiry</span>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                    </svg>
                </a>
            </div>
        </div>

    </div>
</section>

<?php
require_once INCLUDES_PATH . '/footer.php';
?>
