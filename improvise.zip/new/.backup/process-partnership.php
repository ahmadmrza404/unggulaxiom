<?php
/**
 * Partnership Form Handler
 * Sends form data to partnership@unggulaxiom.com
 */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method not allowed');
}

// Sanitize input
function clean_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Determine form type
$partner_type = isset($_POST['company_name']) ? 'corporate' : 'individual';

// Build email content
$to = 'partnership@unggulaxiom.com';
$subject = 'Strategic Partnership Inquiry - ' . ucfirst($partner_type);

$message = "New Strategic Partnership Inquiry\n";
$message .= "Type: " . ucfirst($partner_type) . "\n";
$message .= "Submitted: " . date('Y-m-d H:i:s') . "\n\n";

if ($partner_type === 'corporate') {
    $message .= "CORPORATE INFORMATION\n";
    $message .= "Company Name: " . clean_input($_POST['company_name'] ?? '') . "\n";
    $message .= "Registration Number: " . clean_input($_POST['registration_number'] ?? '') . "\n";
    $message .= "Website: " . clean_input($_POST['website'] ?? '') . "\n";
    $message .= "Industry Sector: " . clean_input($_POST['industry_sector'] ?? '') . "\n";
    $message .= "Company Size: " . clean_input($_POST['company_size'] ?? '') . "\n\n";

    $message .= "REPRESENTATIVE\n";
    $message .= "Name: " . clean_input($_POST['rep_name'] ?? '') . "\n";
    $message .= "Title: " . clean_input($_POST['rep_title'] ?? '') . "\n";
    $message .= "Email: " . clean_input($_POST['rep_email'] ?? '') . "\n";
    $message .= "Phone: " . clean_input($_POST['rep_phone'] ?? '') . "\n\n";

    $message .= "PARTNERSHIP DETAILS\n";
    $message .= "Partnership Model: " . clean_input($_POST['partnership_model'] ?? '') . "\n";
    $message .= "Geographic Focus: " . clean_input($_POST['geographic_focus'] ?? '') . "\n";
    $message .= "Investment Capacity: " . clean_input($_POST['investment_capacity'] ?? '') . "\n\n";
    $message .= "Executive Summary:\n" . clean_input($_POST['executive_summary'] ?? '') . "\n";
} else {
    $message .= "PROFESSIONAL INFORMATION\n";
    $message .= "Name: " . clean_input($_POST['individual_name'] ?? '') . "\n";
    $message .= "Title: " . clean_input($_POST['professional_title'] ?? '') . "\n";
    $message .= "Email: " . clean_input($_POST['individual_email'] ?? '') . "\n";
    $message .= "Phone: " . clean_input($_POST['individual_phone'] ?? '') . "\n";
    $message .= "LinkedIn: " . clean_input($_POST['linkedin_url'] ?? '') . "\n";
    $message .= "Specialization: " . clean_input($_POST['specialization'] ?? '') . "\n";
    $message .= "Experience: " . clean_input($_POST['experience_years'] ?? '') . "\n\n";

    $message .= "COLLABORATION DETAILS\n";
    $message .= "Engagement Type: " . clean_input($_POST['engagement_type'] ?? '') . "\n";
    $message .= "Availability: " . clean_input($_POST['availability'] ?? '') . "\n\n";
    $message .= "Value Proposition:\n" . clean_input($_POST['value_proposition'] ?? '') . "\n";
}

// Email headers
$headers = "From: noreply@unggulaxiom.com\r\n";
$headers .= "Reply-To: " . ($partner_type === 'corporate' ? clean_input($_POST['rep_email'] ?? '') : clean_input($_POST['individual_email'] ?? '')) . "\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

// Send email
if (mail($to, $subject, $message, $headers)) {
    header('Location: /strategic-partnership?success=1');
} else {
    header('Location: /strategic-partnership?error=1');
}
exit;
