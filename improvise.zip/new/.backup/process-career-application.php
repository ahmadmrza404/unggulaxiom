<?php
/**
 * ============================================
 * CAREER APPLICATION FORM PROCESSOR
 * ============================================
 */

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Set response header
header('Content-Type: application/json');

// Load form settings
$settings_file = __DIR__ . '/data/form-settings.json';
$settings = json_decode(file_get_contents($settings_file), true);
$form_config = $settings['careers'] ?? [];

// Load mailer
require_once __DIR__ . '/includes/mailer.php';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Function to validate email
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Validate required fields
$required_fields = [
    'full_name', 'email', 'phone', 'location', 'position',
    'availability', 'salary_expectation', 'experience_years',
    'education', 'skills', 'cover_letter', 'consent'
];

$errors = [];

foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
    }
}

// Validate email format
if (!empty($_POST['email']) && !validate_email($_POST['email'])) {
    $errors[] = 'Invalid email address';
}

// Validate consent checkbox
if (empty($_POST['consent']) || $_POST['consent'] !== 'on') {
    $errors[] = 'You must consent to data processing';
}

// Validate resume file upload
if (empty($_FILES['resume']) || $_FILES['resume']['error'] !== UPLOAD_ERR_OK) {
    $errors[] = 'Resume file is required';
}

// Return errors if any
if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// Sanitize form data
$full_name = sanitize_input($_POST['full_name']);
$email = sanitize_input($_POST['email']);
$phone = sanitize_input($_POST['phone']);
$location = sanitize_input($_POST['location']);
$linkedin = !empty($_POST['linkedin']) ? sanitize_input($_POST['linkedin']) : 'Not provided';
$position = sanitize_input($_POST['position']);
$availability = sanitize_input($_POST['availability']);
$salary_expectation = sanitize_input($_POST['salary_expectation']);
$experience_years = sanitize_input($_POST['experience_years']);
$education = sanitize_input($_POST['education']);
$field_of_study = !empty($_POST['field_of_study']) ? sanitize_input($_POST['field_of_study']) : 'Not provided';
$skills = sanitize_input($_POST['skills']);
$cover_letter = sanitize_input($_POST['cover_letter']);

// Handle file uploads
$upload_dir = __DIR__ . '/uploads/career-applications/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

$resume_file = null;
$additional_doc_file = null;

// Process resume upload
if (isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
    $resume_tmp = $_FILES['resume']['tmp_name'];
    $resume_name = basename($_FILES['resume']['name']);
    $resume_ext = strtolower(pathinfo($resume_name, PATHINFO_EXTENSION));

    // Validate file type
    $allowed_types = ['pdf', 'doc', 'docx'];
    if (!in_array($resume_ext, $allowed_types)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid resume file type. Only PDF, DOC, DOCX allowed.']);
        exit;
    }

    // Validate file size (5MB max)
    if ($_FILES['resume']['size'] > 5 * 1024 * 1024) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Resume file too large. Maximum 5MB allowed.']);
        exit;
    }

    $resume_filename = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $resume_name);
    $resume_path = $upload_dir . $resume_filename;

    if (move_uploaded_file($resume_tmp, $resume_path)) {
        $resume_file = $resume_path;
    }
}

// Process additional document upload (optional)
if (isset($_FILES['additional_doc']) && $_FILES['additional_doc']['error'] === UPLOAD_ERR_OK) {
    $doc_tmp = $_FILES['additional_doc']['tmp_name'];
    $doc_name = basename($_FILES['additional_doc']['name']);
    $doc_ext = strtolower(pathinfo($doc_name, PATHINFO_EXTENSION));

    $allowed_types = ['pdf', 'doc', 'docx'];
    if (in_array($doc_ext, $allowed_types) && $_FILES['additional_doc']['size'] <= 5 * 1024 * 1024) {
        $doc_filename = time() . '_additional_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $doc_name);
        $doc_path = $upload_dir . $doc_filename;

        if (move_uploaded_file($doc_tmp, $doc_path)) {
            $additional_doc_file = $doc_path;
        }
    }
}

// Prepare email
$to = $form_config['recipient_email'] ?? 'careers@unggulaxiom.com';
$subject = 'New Career Application: ' . $position . ' - ' . $full_name;

// Email body (HTML)
$email_body = '
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { background: #1a2332; color: #d4af37; padding: 20px; text-align: center; }
        .section { margin: 20px 0; padding: 15px; border-left: 3px solid #d4af37; background: #f9f9f9; }
        .section-title { font-weight: bold; color: #1a2332; margin-bottom: 10px; }
        .field { margin: 10px 0; }
        .field-label { font-weight: bold; color: #666; }
        .field-value { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>New Career Application</h1>
            <p>Unggul Bronto Sdn. Bhd.</p>
        </div>

        <div class="section">
            <div class="section-title">Personal Information</div>
            <div class="field"><span class="field-label">Name:</span><span class="field-value">' . $full_name . '</span></div>
            <div class="field"><span class="field-label">Email:</span><span class="field-value">' . $email . '</span></div>
            <div class="field"><span class="field-label">Phone:</span><span class="field-value">' . $phone . '</span></div>
            <div class="field"><span class="field-label">Location:</span><span class="field-value">' . $location . '</span></div>
            <div class="field"><span class="field-label">LinkedIn:</span><span class="field-value">' . $linkedin . '</span></div>
        </div>

        <div class="section">
            <div class="section-title">Position Details</div>
            <div class="field"><span class="field-label">Position:</span><span class="field-value">' . $position . '</span></div>
            <div class="field"><span class="field-label">Availability:</span><span class="field-value">' . $availability . '</span></div>
            <div class="field"><span class="field-label">Salary Expectation:</span><span class="field-value">RM ' . $salary_expectation . '</span></div>
        </div>

        <div class="section">
            <div class="section-title">Professional Background</div>
            <div class="field"><span class="field-label">Experience:</span><span class="field-value">' . $experience_years . ' years</span></div>
            <div class="field"><span class="field-label">Education:</span><span class="field-value">' . $education . '</span></div>
            <div class="field"><span class="field-label">Field of Study:</span><span class="field-value">' . $field_of_study . '</span></div>
            <div class="field"><span class="field-label">Skills:</span><div style="margin-left: 10px; margin-top: 5px;">' . nl2br($skills) . '</div></div>
        </div>

        <div class="section">
            <div class="section-title">Application Statement</div>
            <div style="margin-top: 10px;">' . nl2br($cover_letter) . '</div>
        </div>

        <div class="section">
            <div class="section-title">Attachments</div>
            <div class="field">Resume: ' . ($resume_file ? basename($resume_file) : 'Not attached') . '</div>
            <div class="field">Additional Document: ' . ($additional_doc_file ? basename($additional_doc_file) : 'None') . '</div>
        </div>

        <div style="margin-top: 30px; padding: 15px; background: #f0f0f0; text-align: center; font-size: 12px; color: #666;">
            <p>Application submitted on ' . date('F j, Y \a\t g:i A') . '</p>
            <p>Unggul Axiom Group - Career Applications</p>
        </div>
    </div>
</body>
</html>
';

// Email headers
$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
$headers .= "From: Unggul Axiom Careers <noreply@unggulaxiom.com>\r\n";
$headers .= "Reply-To: " . $email . "\r\n";

// Log submission first
$log_file = __DIR__ . '/logs/career-applications.log';
$log_dir = dirname($log_file);
if (!file_exists($log_dir)) {
    mkdir($log_dir, 0755, true);
}

$log_entry = date('Y-m-d H:i:s') . " - Application received from: $full_name ($email) for position: $position\n";
file_put_contents($log_file, $log_entry, FILE_APPEND);

// Save to JSON file as backup
$data_file = __DIR__ . '/data/career-applications.json';
$applications = file_exists($data_file) ? json_decode(file_get_contents($data_file), true) : [];
$applications[] = [
    'timestamp' => date('Y-m-d H:i:s'),
    'full_name' => $full_name,
    'email' => $email,
    'phone' => $phone,
    'location' => $location,
    'linkedin' => $linkedin,
    'position' => $position,
    'availability' => $availability,
    'salary_expectation' => $salary_expectation,
    'experience_years' => $experience_years,
    'education' => $education,
    'field_of_study' => $field_of_study,
    'skills' => $skills,
    'cover_letter' => $cover_letter,
    'resume_file' => $resume_file ? basename($resume_file) : null,
    'additional_doc_file' => $additional_doc_file ? basename($additional_doc_file) : null
];
file_put_contents($data_file, json_encode($applications, JSON_PRETTY_PRINT));

// Try to send email using mailer
$mail_sent = send_email($to, $subject, $email_body, $email);

// Always return success since we saved the data
http_response_code(200);
echo json_encode([
    'success' => true,
    'message' => $form_config['success_message'] ?? 'Application submitted successfully!',
    'email_sent' => $mail_sent
]);
?>
