<?php
/**
 * ============================================
 * SECTORS - MARKET DEPLOYMENT LEDGER
 * ============================================
 * Purpose: Sector deployment and execution strategy
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Sector Deployment';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- VANGUARD SECTION -->
<section class="min-h-[60vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/20 isolate">
    <div class="container-sovereign py-32">
        <div class="max-w-5xl mx-auto text-center">
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-editorial leading-tight">
                SECTOR DEPLOYMENT
            </h1>
            <p class="text-xl text-sovereign-400 tracking-institutional max-w-3xl mx-auto">
                Operational domains for systematic infrastructure integration
            </p>
        </div>
    </div>
</section>

<!-- SECTOR LEDGER -->
<section class="py-32 bg-obsidian-950 isolate">
    <div class="container-sovereign">

        <div class="mb-16">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4">
                DEPLOYMENT MATRIX
            </h2>
            <div class="w-16 h-px bg-champagne-500"></div>
        </div>

        <div class="space-y-0">

            <!-- SECTOR 01: FOOD & AGRICULTURE -->
            <div class="sector-row grid grid-cols-1 lg:grid-cols-2 gap-8 py-16 border-b border-champagne-500/20">
                <div>
                    <h3 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-tight leading-tight">
                        Food & Agriculture
                    </h3>
                </div>
                <div class="flex items-center">
                    <p class="text-base text-platinum-200 leading-institutional">
                        Integrated halal food production infrastructure, agricultural operations, and supply chain coordination. Encompasses farm-to-table systems, processing facilities, and quality control frameworks for halal-certified food products.
                    </p>
                </div>
            </div>

            <!-- SVG SEPARATOR -->
            <svg class="sector-divider w-full h-px" viewBox="0 0 1000 1" preserveAspectRatio="none">
                <line x1="0" y1="0.5" x2="1000" y2="0.5" stroke="rgba(205, 127, 50, 0.3)" stroke-width="1" />
            </svg>

            <!-- SECTOR 02: PHARMACEUTICALS & WELLNESS -->
            <div class="sector-row grid grid-cols-1 lg:grid-cols-2 gap-8 py-16 border-b border-champagne-500/20">
                <div>
                    <h3 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-tight leading-tight">
                        Pharmaceuticals & Wellness
                    </h3>
                </div>
                <div class="flex items-center">
                    <p class="text-base text-platinum-200 leading-institutional">
                        Halal pharmaceutical manufacturing, wellness product development, and healthcare supply chain infrastructure. Includes production facilities, regulatory compliance systems, and distribution networks for halal-certified medical products.
                    </p>
                </div>
            </div>

            <!-- SVG SEPARATOR -->
            <svg class="sector-divider w-full h-px" viewBox="0 0 1000 1" preserveAspectRatio="none">
                <line x1="0" y1="0.5" x2="1000" y2="0.5" stroke="rgba(205, 127, 50, 0.3)" stroke-width="1" />
            </svg>

            <!-- SECTOR 03: MANUFACTURING -->
            <div class="sector-row grid grid-cols-1 lg:grid-cols-2 gap-8 py-16 border-b border-champagne-500/20">
                <div>
                    <h3 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-tight leading-tight">
                        Manufacturing
                    </h3>
                </div>
                <div class="flex items-center">
                    <p class="text-base text-platinum-200 leading-institutional">
                        Industrial manufacturing infrastructure for halal-compliant production processes. Covers facility management, equipment coordination, process automation, and quality assurance systems across multiple manufacturing domains.
                    </p>
                </div>
            </div>

            <!-- SVG SEPARATOR -->
            <svg class="sector-divider w-full h-px" viewBox="0 0 1000 1" preserveAspectRatio="none">
                <line x1="0" y1="0.5" x2="1000" y2="0.5" stroke="rgba(205, 127, 50, 0.3)" stroke-width="1" />
            </svg>

            <!-- SECTOR 04: LOGISTICS & DISTRIBUTION -->
            <div class="sector-row grid grid-cols-1 lg:grid-cols-2 gap-8 py-16 border-b border-champagne-500/20">
                <div>
                    <h3 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-tight leading-tight">
                        Logistics & Distribution
                    </h3>
                </div>
                <div class="flex items-center">
                    <p class="text-base text-platinum-200 leading-institutional">
                        Supply chain coordination and distribution infrastructure for halal product movement. Includes warehouse management, transportation systems, cold chain monitoring, and inventory tracking across domestic and international markets.
                    </p>
                </div>
            </div>

            <!-- SVG SEPARATOR -->
            <svg class="sector-divider w-full h-px" viewBox="0 0 1000 1" preserveAspectRatio="none">
                <line x1="0" y1="0.5" x2="1000" y2="0.5" stroke="rgba(205, 127, 50, 0.3)" stroke-width="1" />
            </svg>

            <!-- SECTOR 05: ISLAMIC FINANCE -->
            <div class="sector-row grid grid-cols-1 lg:grid-cols-2 gap-8 py-16 border-b border-champagne-500/20">
                <div>
                    <h3 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-tight leading-tight">
                        Islamic Finance
                    </h3>
                </div>
                <div class="flex items-center">
                    <p class="text-base text-platinum-200 leading-institutional">
                        Shariah-compliant capital deployment and financial infrastructure. Encompasses equity participation frameworks, joint venture structures, project-based financing, and institutional investment mechanisms aligned with Islamic finance principles.
                    </p>
                </div>
            </div>

            <!-- SVG SEPARATOR -->
            <svg class="sector-divider w-full h-px" viewBox="0 0 1000 1" preserveAspectRatio="none">
                <line x1="0" y1="0.5" x2="1000" y2="0.5" stroke="rgba(205, 127, 50, 0.3)" stroke-width="1" />
            </svg>

            <!-- SECTOR 06: GLOBAL TRADE -->
            <div class="sector-row grid grid-cols-1 lg:grid-cols-2 gap-8 py-16">
                <div>
                    <h3 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-tight leading-tight">
                        Global Trade
                    </h3>
                </div>
                <div class="flex items-center">
                    <p class="text-base text-platinum-200 leading-institutional">
                        International trade infrastructure for halal product export and import coordination. Includes customs facilitation, trade documentation, market access systems, and global distribution networks for halal-certified products.
                    </p>
                </div>
            </div>

        </div>

    </div>
</section>


<?php require_once INCLUDES_PATH . '/footer.php'; ?>
