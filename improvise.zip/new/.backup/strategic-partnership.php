<?php
/**
 * ============================================
 * STRATEGIC PARTNERSHIP PAGE
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Strategic Partnership';

require_once INCLUDES_PATH . '/header.php';

// Check for success/error messages
$success = isset($_GET['success']) && $_GET['success'] == '1';
$error = isset($_GET['error']) && $_GET['error'] == '1';
?>

<?php if ($success): ?>
<div class="fixed top-4 right-4 z-50 max-w-md bg-green-900/90 border border-green-500 text-green-100 px-6 py-4 rounded shadow-lg" x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 5000)">
    <div class="flex items-start gap-3">
        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <div>
            <p class="font-semibold">Partnership inquiry submitted successfully</p>
            <p class="text-sm text-green-200 mt-1">Our team will review your submission and respond within 5-7 business days.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="fixed top-4 right-4 z-50 max-w-md bg-red-900/90 border border-red-500 text-red-100 px-6 py-4 rounded shadow-lg" x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 8000)">
    <div class="flex items-start gap-3">
        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
        </svg>
        <div>
            <p class="font-semibold">Submission failed</p>
            <p class="text-sm text-red-200 mt-1">There was an error processing your request. Please try again or contact partnership@unggulaxiom.com directly.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- HERO SECTION -->
<section class="py-32 bg-obsidian-950 border-b border-champagne-500/20">
    <div class="container-sovereign">
        <div class="max-w-4xl">
            <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block">
                INSTITUTIONAL COLLABORATION
            </span>
            <h1 class="font-serif text-5xl md:text-6xl text-platinum-50 tracking-editorial mb-8 leading-tight">
                Strategic Partnership
            </h1>
            <p class="text-lg text-platinum-200 leading-institutional">
                Unggul Axiom Group engages with institutional partners and qualified professionals to advance halal infrastructure development across production, certification, logistics, and market access.
            </p>
        </div>
    </div>
</section>

<!-- PARTNERSHIP FORM SECTION -->
<section class="py-20 bg-obsidian-900">
    <div class="container-sovereign">
        <div class="max-w-4xl mx-auto">

            <!-- Partnership Type Selector -->
            <div class="mb-12" x-data="{ partnerType: 'corporate' }" x-init="$watch('partnerType', value => {
                // Disable validation for hidden form
                const corporateInputs = document.querySelectorAll('[x-show=\'partnerType === \\\'corporate\\\'\'] input, [x-show=\'partnerType === \\\'corporate\\\'\'] select, [x-show=\'partnerType === \\\'corporate\\\'\'] textarea');
                const individualInputs = document.querySelectorAll('[x-show=\'partnerType === \\\'individual\\\'\'] input, [x-show=\'partnerType === \\\'individual\\\'\'] select, [x-show=\'partnerType === \\\'individual\\\'\'] textarea');

                if (value === 'corporate') {
                    corporateInputs.forEach(el => el.disabled = false);
                    individualInputs.forEach(el => el.disabled = true);
                } else {
                    corporateInputs.forEach(el => el.disabled = true);
                    individualInputs.forEach(el => el.disabled = false);
                }
            })"

                <!-- Toggle Tabs -->
                <div class="flex gap-4 mb-12 border-b border-champagne-500/20">
                    <button
                        type="button"
                        @click="partnerType = 'corporate'"
                        :class="partnerType === 'corporate' ? 'border-b-2 border-champagne-500 text-champagne-500' : 'text-platinum-300'"
                        class="px-6 py-4 text-sm tracking-institutional font-semibold transition-colors duration-300">
                        CORPORATE ENTITY
                    </button>
                    <button
                        type="button"
                        @click="partnerType = 'individual'"
                        :class="partnerType === 'individual' ? 'border-b-2 border-champagne-500 text-champagne-500' : 'text-platinum-300'"
                        class="px-6 py-4 text-sm tracking-institutional font-semibold transition-colors duration-300">
                        INDIVIDUAL PROFESSIONAL
                    </button>
                </div>

                <!-- Form Container -->
                <form action="/process-partnership.php" method="POST" enctype="multipart/form-data" class="space-y-8">

                    <!-- CORPORATE ENTITY FORM -->
                    <div x-show="partnerType === 'corporate'" x-transition:enter="transition ease-out duration-300">

                        <!-- Company Information -->
                        <div class="space-y-6">
                            <h3 class="text-xl text-platinum-50 font-serif tracking-editorial mb-6">Corporate Information</h3>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Company Name</label>
                                <input type="text" name="company_name" required
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Corporate Registration Number</label>
                                <input type="text" name="registration_number"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Corporate Website</label>
                                <input type="url" name="website" required
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors"
                                    placeholder="https://www.company.com">
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Industry Sector</label>
                                    <select name="industry_sector" required
                                        class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                        <option value="">Select Sector</option>
                                        <option value="agriculture">Agriculture & Food Production</option>
                                        <option value="technology">Technology & Software</option>
                                        <option value="logistics">Logistics & Supply Chain</option>
                                        <option value="pharmaceutical">Pharmaceutical & Healthcare</option>
                                        <option value="certification">Certification & Compliance</option>
                                        <option value="finance">Financial Services</option>
                                        <option value="manufacturing">Manufacturing & Processing</option>
                                        <option value="trading">International Trade</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>

                                <div>
                                    <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Company Size</label>
                                    <select name="company_size" required
                                        class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                        <option value="">Select Size</option>
                                        <option value="startup">Startup (1-50 employees)</option>
                                        <option value="sme">SME (51-250 employees)</option>
                                        <option value="midmarket">Mid-Market (251-1000 employees)</option>
                                        <option value="enterprise">Enterprise (1000+ employees)</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Representative Information -->
                        <div class="space-y-6 mt-12">
                            <h3 class="text-xl text-platinum-50 font-serif tracking-editorial mb-6">Authorized Representative</h3>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Full Name</label>
                                    <input type="text" name="rep_name" required
                                        class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                </div>

                                <div>
                                    <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Executive Title</label>
                                    <input type="text" name="rep_title" required
                                        class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors"
                                        placeholder="e.g., Chief Executive Officer">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Corporate Email Address</label>
                                    <input type="email" name="rep_email" required
                                        class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                    <p class="text-xs text-sovereign-400 mt-1">Corporate domain email preferred</p>
                                </div>

                                <div>
                                    <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Direct Contact Number</label>
                                    <input type="tel" name="rep_phone" required
                                        class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors"
                                        placeholder="+60 3 1234 5678">
                                </div>
                            </div>
                        </div>

                        <!-- Partnership Details -->
                        <div class="space-y-6 mt-12">
                            <h3 class="text-xl text-platinum-50 font-serif tracking-editorial mb-6">Partnership Proposal</h3>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Proposed Partnership Model</label>
                                <select name="partnership_model" required
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                    <option value="">Select Partnership Type</option>
                                    <option value="joint_venture">Joint Venture Development</option>
                                    <option value="strategic_investment">Strategic Investment</option>
                                    <option value="technology_integration">Technology Integration & Licensing</option>
                                    <option value="market_expansion">Market Expansion & Distribution</option>
                                    <option value="supply_chain">Supply Chain & Procurement</option>
                                    <option value="rd_collaboration">R&D Collaboration</option>
                                    <option value="certification">Certification & Compliance Services</option>
                                    <option value="infrastructure">Infrastructure Development</option>
                                    <option value="other">Other Strategic Collaboration</option>
                                </select>
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Geographic Focus</label>
                                <select name="geographic_focus" required
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                    <option value="">Select Region</option>
                                    <option value="malaysia">Malaysia</option>
                                    <option value="southeast_asia">Southeast Asia</option>
                                    <option value="middle_east">Middle East</option>
                                    <option value="east_asia">East Asia</option>
                                    <option value="south_asia">South Asia</option>
                                    <option value="global">Global</option>
                                </select>
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Executive Summary</label>
                                <textarea name="executive_summary" rows="6" required
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors resize-none"
                                    placeholder="Outline the strategic rationale, mutual value proposition, and alignment with halal infrastructure development objectives. Include relevant experience, capabilities, and proposed collaboration structure."></textarea>
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Investment Capacity (if applicable)</label>
                                <select name="investment_capacity"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                    <option value="">Select Range</option>
                                    <option value="under_1m">Under USD 1 Million</option>
                                    <option value="1m_5m">USD 1-5 Million</option>
                                    <option value="5m_10m">USD 5-10 Million</option>
                                    <option value="10m_25m">USD 10-25 Million</option>
                                    <option value="25m_50m">USD 25-50 Million</option>
                                    <option value="over_50m">Over USD 50 Million</option>
                                    <option value="not_applicable">Not Applicable</option>
                                </select>
                            </div>
                        </div>

                        <!-- Document Upload -->
                        <div class="space-y-6 mt-12">
                            <h3 class="text-xl text-platinum-50 font-serif tracking-editorial mb-6">Supporting Documentation</h3>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Corporate Profile / Pitch Deck</label>
                                <div class="border-2 border-dashed border-champagne-500/30 bg-obsidian-800 p-8 text-center hover:border-champagne-500/60 transition-colors">
                                    <input type="file" name="corporate_document" accept=".pdf" class="hidden" id="corporate-upload">
                                    <label for="corporate-upload" class="cursor-pointer">
                                        <div class="text-platinum-300 mb-2">
                                            <svg class="w-12 h-12 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                            </svg>
                                        </div>
                                        <p class="text-sm text-platinum-200">Drop PDF file here or click to upload</p>
                                        <p class="text-xs text-sovereign-400 mt-2">Maximum file size: 10MB</p>
                                    </label>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- INDIVIDUAL PROFESSIONAL FORM -->
                    <div x-show="partnerType === 'individual'" x-transition:enter="transition ease-out duration-300" style="display: none;">

                        <!-- Professional Information -->
                        <div class="space-y-6">
                            <h3 class="text-xl text-platinum-50 font-serif tracking-editorial mb-6">Professional Profile</h3>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Full Name</label>
                                <input type="text" name="individual_name"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Core Expertise / Professional Title</label>
                                <input type="text" name="professional_title"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors"
                                    placeholder="e.g., Halal Certification Specialist, Agricultural Technology Consultant">
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Professional Email Address</label>
                                    <input type="email" name="individual_email"
                                        class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                </div>

                                <div>
                                    <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Direct Contact Number</label>
                                    <input type="tel" name="individual_phone"
                                        class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors"
                                        placeholder="+60 12 345 6789">
                                </div>
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">LinkedIn Profile URL</label>
                                <input type="url" name="linkedin_url"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors"
                                    placeholder="https://www.linkedin.com/in/yourprofile">
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Area of Specialization</label>
                                <select name="specialization"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                    <option value="">Select Specialization</option>
                                    <option value="halal_certification">Halal Certification & Compliance</option>
                                    <option value="agritech">Agricultural Technology</option>
                                    <option value="food_science">Food Science & Processing</option>
                                    <option value="supply_chain">Supply Chain Management</option>
                                    <option value="quality_assurance">Quality Assurance & Food Safety</option>
                                    <option value="logistics">Logistics & Distribution</option>
                                    <option value="islamic_finance">Islamic Finance & Investment</option>
                                    <option value="market_development">Market Development & Trade</option>
                                    <option value="regulatory">Regulatory Affairs</option>
                                    <option value="technology">Technology & Digital Systems</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Years of Experience</label>
                                <select name="experience_years"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                    <option value="">Select Range</option>
                                    <option value="3-5">3-5 years</option>
                                    <option value="5-10">5-10 years</option>
                                    <option value="10-15">10-15 years</option>
                                    <option value="15-20">15-20 years</option>
                                    <option value="20+">20+ years</option>
                                </select>
                            </div>
                        </div>

                        <!-- Collaboration Proposal -->
                        <div class="space-y-6 mt-12">
                            <h3 class="text-xl text-platinum-50 font-serif tracking-editorial mb-6">Collaboration Proposal</h3>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Engagement Type</label>
                                <select name="engagement_type"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                    <option value="">Select Type</option>
                                    <option value="consulting">Consulting Services</option>
                                    <option value="advisory">Advisory Board / Strategic Advisor</option>
                                    <option value="technical">Technical Specialist</option>
                                    <option value="project_based">Project-Based Engagement</option>
                                    <option value="training">Training & Capacity Building</option>
                                    <option value="research">Research & Development</option>
                                    <option value="other">Other Collaboration</option>
                                </select>
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Value Proposition</label>
                                <textarea name="value_proposition" rows="6"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors resize-none"
                                    placeholder="Describe your specialized capabilities, relevant experience, and how your expertise aligns with halal infrastructure development. Include specific areas where you can contribute value to Unggul Axiom Group operations."></textarea>
                            </div>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Availability</label>
                                <select name="availability"
                                    class="w-full px-4 py-3 bg-obsidian-800 border border-champagne-500/20 text-platinum-50 focus:border-champagne-500 focus:outline-none transition-colors">
                                    <option value="">Select Availability</option>
                                    <option value="immediate">Immediate</option>
                                    <option value="1_month">Within 1 month</option>
                                    <option value="2_3_months">2-3 months</option>
                                    <option value="flexible">Flexible</option>
                                </select>
                            </div>
                        </div>

                        <!-- Document Upload -->
                        <div class="space-y-6 mt-12">
                            <h3 class="text-xl text-platinum-50 font-serif tracking-editorial mb-6">Professional Documentation</h3>

                            <div>
                                <label class="block text-sm text-platinum-200 mb-2 tracking-institutional">Portfolio / Curriculum Vitae</label>
                                <div class="border-2 border-dashed border-champagne-500/30 bg-obsidian-800 p-8 text-center hover:border-champagne-500/60 transition-colors">
                                    <input type="file" name="professional_document" accept=".pdf" class="hidden" id="professional-upload">
                                    <label for="professional-upload" class="cursor-pointer">
                                        <div class="text-platinum-300 mb-2">
                                            <svg class="w-12 h-12 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                            </svg>
                                        </div>
                                        <p class="text-sm text-platinum-200">Drop PDF file here or click to upload</p>
                                        <p class="text-xs text-sovereign-400 mt-2">Maximum file size: 10MB</p>
                                    </label>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- Submit Button -->
                    <div class="mt-12 pt-8 border-t border-champagne-500/20">
                        <button type="submit"
                            class="w-full md:w-auto px-12 py-4 text-sm tracking-institutional font-semibold hover:bg-champagne-400 transition-all duration-300"
                            style="background-color: #D4AF37 !important; color: #0A0E14 !important; font-weight: 600 !important; -webkit-text-fill-color: #0A0E14 !important; text-shadow: none !important;">
                            SUBMIT PARTNERSHIP INQUIRY
                        </button>
                        <p class="text-xs text-sovereign-400 mt-4">
                            All submissions are reviewed by our business development team. Qualified inquiries will receive a response within 5-7 business days.
                        </p>
                    </div>

                </form>

            </div>

        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
