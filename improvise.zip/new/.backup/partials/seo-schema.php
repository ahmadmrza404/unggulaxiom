<?php
/**
 * ============================================
 * JSON-LD STRUCTURED DATA
 * ============================================
 * Phase 17: Schema.org markup for search engines
 *
 * Usage: Include after header.php, pass $schema_type
 * Example: include 'partials/seo-schema.php';
 * ============================================
 */

$schema_data = [];

// Organization Schema (Global)
$organization_schema = [
    '@context' => 'https://schema.org',
    '@type' => 'Organization',
    'name' => 'Unggul Axiom Group',
    'url' => BASE_URL,
    'logo' => url('/assets/images/logo.png'),
    'description' => 'Sovereign-level halal infrastructure platform integrating production, certification, logistics, and global market access.',
    'address' => [
        '@type' => 'PostalAddress',
        'addressCountry' => 'MY',
        'addressLocality' => 'Kuala Lumpur',
        'addressRegion' => 'Federal Territory of Kuala Lumpur'
    ],
    'contactPoint' => [
        '@type' => 'ContactPoint',
        'telephone' => '+60-3-1234-5678',
        'contactType' => 'Strategic Partnerships',
        'email' => 'info@unggulaxiom.com',
        'areaServed' => ['MY', 'SG', 'ID', 'Global'],
        'availableLanguage' => ['en', 'ms']
    ],
    'sameAs' => [
        'https://linkedin.com/company/unggulaxiom'
    ]
];

// Page-specific schemas
switch($seo_page) {
    case 'home':
        $schema_data[] = $organization_schema;
        $schema_data[] = [
            '@context' => 'https://schema.org',
            '@type' => 'Service',
            'serviceType' => 'Halal Infrastructure Development',
            'provider' => [
                '@type' => 'Organization',
                'name' => 'Unggul Axiom Group'
            ],
            'areaServed' => [
                '@type' => 'Country',
                'name' => 'Malaysia'
            ],
            'description' => 'Integrated halal infrastructure platform connecting production, certification, logistics, and global market access.'
        ];
        break;

    case 'cipu':
        $schema_data[] = $organization_schema;
        $schema_data[] = [
            '@context' => 'https://schema.org',
            '@type' => 'Project',
            'name' => 'Central Integrated Poultry Unggul (CIPU)',
            'description' => 'High-efficiency vertically integrated poultry infrastructure designed to strengthen food security and enable scalable halal protein production.',
            'founder' => [
                '@type' => 'Organization',
                'name' => 'Unggul Axiom Group'
            ],
            'location' => [
                '@type' => 'Country',
                'name' => 'Malaysia'
            ],
            'keywords' => 'integrated poultry infrastructure, halal poultry production, food security, halal protein supply chain'
        ];
        break;

    case 'investor':
        $schema_data[] = $organization_schema;
        $schema_data[] = [
            '@context' => 'https://schema.org',
            '@type' => 'FinancialService',
            'name' => 'Strategic Partnerships & Investment',
            'provider' => [
                '@type' => 'Organization',
                'name' => 'Unggul Axiom Group'
            ],
            'description' => 'Institutional investment opportunities in sovereign halal infrastructure. Structured entry into the global halal economy for accredited investors.',
            'areaServed' => 'Global',
            'audience' => [
                '@type' => 'Audience',
                'audienceType' => 'Institutional Investors'
            ]
        ];
        break;

    case 'ecosystem':
        $schema_data[] = $organization_schema;
        $schema_data[] = [
            '@context' => 'https://schema.org',
            '@type' => 'ItemList',
            'name' => 'Unggul Axiom Ecosystem',
            'description' => 'Five vertically integrated entities forming a complete halal infrastructure platform',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Unggul Agro',
                    'description' => 'Integrated halal production and farming infrastructure'
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'Unggul HalalTech',
                    'description' => 'Certification, traceability, and compliance systems'
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => 'Unggul Logistics',
                    'description' => 'Cold-chain transport and distribution networks'
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 4,
                    'name' => 'Unggul Global Trade',
                    'description' => 'Export facilitation and international market access'
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 5,
                    'name' => 'Unggul Capital',
                    'description' => 'Structured investment and financial ecosystem development'
                ]
            ]
        ];
        break;

    default:
        $schema_data[] = $organization_schema;
}

// Output JSON-LD
foreach ($schema_data as $schema) {
    echo '<script type="application/ld+json">' . "\n";
    echo json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    echo "\n" . '</script>' . "\n";
}
?>
