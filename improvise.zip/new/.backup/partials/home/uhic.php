<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$uhic = $homepage_data['uhic'] ?? [];
?>
<section class="py-32 bg-obsidian-800 border-t border-champagne-500/20 isolate">

    <div class="container-sovereign">

        <!-- UHIC HEADER -->
        <div class="mb-20 gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-600 font-semibold tracking-ultra-wide mb-6">
                <?= htmlspecialchars($uhic['section_label'] ?? 'UHIC (UNGGUL HALAL INTEGRATED CENTRE)') ?>
            </h2>
            <div class="w-24 h-px bg-champagne-500 mb-8"></div>
            <p class="text-2xl md:text-3xl font-serif text-platinum-50 leading-tight max-w-4xl">
                <?= htmlspecialchars($uhic['title'] ?? '') ?>
            </p>
        </div>

        <!-- DESCRIPTION BLOCK -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div class="gsap-fade-up">
                <p class="text-lg text-platinum-200 leading-institutional mb-6">
                    <?= htmlspecialchars($uhic['intro_text'] ?? '') ?>
                </p>
                <p class="text-sovereign-300 leading-relaxed">
                    <?= htmlspecialchars($uhic['description'] ?? '') ?>
                </p>
            </div>
            <div class="gsap-fade-up">
                <div class="border-l-2 border-champagne-500 pl-6">
                    <h3 class="text-champagne-500 text-sm font-mono uppercase tracking-wider mb-4"><?= htmlspecialchars($uhic['objectives_label'] ?? 'Platform Objectives') ?></h3>
                    <ul class="space-y-3 text-sovereign-300">
                        <?php foreach (($uhic['objectives'] ?? []) as $objective): ?>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1">→</span>
                            <span><?= htmlspecialchars($objective) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- PLATFORM MODULES -->
        <div class="mb-16 gsap-fade-up">
            <h3 class="text-2xl font-serif text-platinum-50 mb-8 text-center"><?= htmlspecialchars($uhic['modules_title'] ?? 'Core Platform Modules') ?></h3>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

                <?php foreach (($uhic['modules'] ?? []) as $module): ?>
                <div class="border border-champagne-500/20 p-6 hover:bg-champagne-500/5 transition-colors">
                    <div class="w-12 h-12 border border-champagne-500/40 flex items-center justify-center mb-4">
                        <svg class="w-6 h-6 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                        </svg>
                    </div>
                    <h4 class="text-lg text-platinum-50 mb-3"><?= htmlspecialchars($module['name']) ?></h4>
                    <p class="text-sm text-sovereign-300 mb-4"><?= htmlspecialchars($module['description']) ?></p>
                    <div class="text-xs text-champagne-500 font-mono"><?= htmlspecialchars($module['tech_stack']) ?></div>
                </div>
                <?php endforeach; ?>

            </div>
        </div>

        <!-- DEPLOYMENT SECTORS -->
        <div class="border border-champagne-500/20 p-8 gsap-fade-up">
            <h3 class="text-lg font-mono text-champagne-500 uppercase tracking-wider mb-6 text-center"><?= htmlspecialchars($uhic['deployment_title'] ?? 'Multi-Sector Deployment Framework') ?></h3>
            <p class="text-center text-sovereign-300 mb-8 max-w-3xl mx-auto">
                <?= htmlspecialchars($uhic['deployment_description'] ?? '') ?>
            </p>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php foreach (($uhic['deployment_sectors'] ?? []) as $sector): ?>
                <div class="text-center p-4 border border-champagne-500/10">
                    <div class="text-2xl font-serif text-platinum-50 mb-2"><?= htmlspecialchars($sector['name']) ?></div>
                    <div class="text-xs text-sovereign-400"><?= htmlspecialchars($sector['status']) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>

</section>
