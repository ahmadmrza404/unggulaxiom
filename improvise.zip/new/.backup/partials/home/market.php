<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$market = $homepage_data['market'] ?? [];
?>
<section id="global-market" class="py-32 bg-obsidian-800 text-platinum-50">
    <div class="container-sovereign">

        <!-- 12-COLUMN ASYMMETRIC GRID -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-16">

            <!-- LEFT COLUMN: SECTION HEADER & THESIS (4 COLS) -->
            <div class="md:col-span-4">
                <div class="md:sticky md:top-32">
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block" data-gsap-fade-up>
                        <?= htmlspecialchars($market['section_label'] ?? 'GLOBAL MARKET OPPORTUNITY') ?>
                    </span>
                    <h2 class="font-serif text-4xl lg:text-5xl text-platinum-50 tracking-editorial mb-8 leading-tight" data-gsap-fade-up data-gsap-delay="0.2">
                        <?= htmlspecialchars($market['headline'] ?? '') ?>
                    </h2>
                </div>
            </div>

            <!-- RIGHT COLUMN: DATA & MARKET REALITY (8 COLS) -->
            <div class="md:col-span-8">

                <!-- MASSIVE STAT: TYPOGRAPHIC ART -->
                <div class="mb-16 pb-16 border-b border-champagne-500/30" data-gsap-fade-up data-gsap-delay="0.3">
                    <div class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 leading-none tracking-tight mb-4 reveal-mask parallax-header">
                        <span class="block text-champagne-500 text-2xl md:text-3xl tracking-institutional mb-3">USD</span>
                        <span class="block"><?= htmlspecialchars($market['market_size'] ?? '10 TRILLION') ?></span>
                    </div>
                    <p class="text-sovereign-sm text-platinum-200 tracking-institutional mt-6">
                        <?= htmlspecialchars($market['market_size_label'] ?? 'GLOBAL HALAL ECONOMY (2030)') ?>
                    </p>
                </div>

                <!-- DATA POINTS: BORDERED LIST -->
                <div class="mb-16" data-gsap-fade-up data-gsap-delay="0.4">
                    <ul class="space-y-0">
                        <?php foreach (($market['data_points'] ?? []) as $point): ?>
                        <li class="py-6 border-b border-champagne-500/20 flex items-start">
                            <span class="text-champagne-500 text-2xl font-serif mr-6 mt-1">-</span>
                            <div>
                                <p class="text-xl md:text-2xl font-serif text-platinum-50 tracking-editorial">
                                    <?= htmlspecialchars($point) ?>
                                </p>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- MARKET REALITY SUB-SECTION -->
                <div class="mb-12" data-gsap-fade-up data-gsap-delay="0.5">
                    <h3 class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6">
                        <?= htmlspecialchars($market['market_reality_label'] ?? 'MARKET REALITY') ?>
                    </h3>
                    <p class="text-lg text-platinum-200 leading-institutional">
                        <?= htmlspecialchars($market['market_reality_text'] ?? '') ?>
                    </p>
                </div>

                <!-- POSITIONING BLOCK: INSET BOX -->
                <div class="border-l-2 border-champagne-500 pl-8 py-6 bg-obsidian-800" data-gsap-fade-up data-gsap-delay="0.6">
                    <p class="text-xl md:text-2xl font-serif text-platinum-50 leading-institutional italic">
                        <?= htmlspecialchars($market['positioning_statement'] ?? '') ?>
                    </p>
                </div>

            </div>

        </div>

    </div>
</section>
