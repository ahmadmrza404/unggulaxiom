<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$ecosystem = $homepage_data['ecosystem'] ?? [];
?>
<section id="ecosystem" class="py-32 bg-obsidian-800 text-platinum-50">
    <div class="container-sovereign">

        <!-- SECTION HEADER -->
        <div class="mb-20" data-gsap-fade-up>
            <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block">
                <?= htmlspecialchars($ecosystem['section_label'] ?? 'OUR ECOSYSTEM') ?>
            </span>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-editorial max-w-3xl">
                <?= htmlspecialchars($ecosystem['title'] ?? 'Integrated Infrastructure Platform') ?>
            </h2>
            <p class="text-lg text-platinum-200 mt-6 max-w-2xl">
                <?= htmlspecialchars($ecosystem['description'] ?? '') ?>
            </p>
        </div>

        <!-- ENTITY LIST: BRUTALIST TYPOGRAPHY -->
        <div class="space-y-0">

            <?php foreach (($ecosystem['entities'] ?? []) as $index => $entity): ?>
            <!-- ENTITY -->
            <a href="<?= url($entity['url'] ?? '#') ?>"
               class="entity-item axiom-card group block py-12 border-t border-champagne-500/20 transition-all duration-500 hover:border-champagne-500/60 relative overflow-hidden <?= $index === count($ecosystem['entities']) - 1 ? 'border-b' : '' ?>"
               x-data="{ hover: false }"
               @mouseenter="hover = true"
               @mouseleave="hover = false">
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    <div class="lg:col-span-5">
                        <h3 class="entity-name font-serif text-5xl md:text-6xl text-sovereign-500 tracking-tight transition-all duration-500 group-hover:text-platinum-50"
                            style="will-change: color, letter-spacing;">
                            <?= htmlspecialchars($entity['name']) ?>
                        </h3>
                    </div>
                    <div class="lg:col-span-7 relative">
                        <div class="border-l-2 border-champagne-500/0 pl-6 transition-all duration-500 group-hover:border-champagne-500/60"
                             :class="{ 'translate-x-0 opacity-100': hover, '-translate-x-4 opacity-70': !hover }">
                            <p class="text-lg text-sovereign-400 leading-institutional transition-all duration-500 group-hover:text-platinum-200">
                                <?= htmlspecialchars($entity['description']) ?>
                            </p>
                        </div>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>

        </div>

    </div>
</section>
