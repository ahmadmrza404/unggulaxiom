<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$framework = $homepage_data['framework'] ?? [];
?>
<section id="framework" class="py-32 bg-obsidian-900 text-platinum-50 relative">
    <div class="container-sovereign">

        <!-- STICKY SCROLL LAYOUT: 12-COLUMN GRID -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-16 relative z-10">

            <!-- LEFT COLUMN: STICKY HEADER (4 COLS) -->
            <div class="md:col-span-4">
                <div class="md:sticky md:top-32">
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block" data-gsap-fade-up>
                        <?= htmlspecialchars($framework['section_label'] ?? 'INFRASTRUCTURE ARCHITECTURE') ?>
                    </span>
                    <h2 class="font-serif text-4xl lg:text-5xl text-platinum-50 tracking-editorial mb-8 leading-tight" data-gsap-fade-up data-gsap-delay="0.2">
                        <?= htmlspecialchars($framework['title'] ?? 'THE AXIOM-8 FRAMEWORK') ?>
                    </h2>
                    <p class="text-lg text-platinum-200 leading-institutional" data-gsap-fade-up data-gsap-delay="0.3">
                        <?= htmlspecialchars($framework['description'] ?? '') ?>
                    </p>
                </div>
            </div>

            <!-- RIGHT COLUMN: 8 PILLARS (8 COLS) -->
            <div class="md:col-span-8">
                <div class="space-y-0">

                    <?php foreach (($framework['pillars'] ?? []) as $pillar): ?>
                    <!-- PILLAR -->
                    <div class="pillar-item py-8 border-t-2 border-champagne-500/30 <?= end($framework['pillars']) === $pillar ? 'border-b-2' : '' ?>">
                        <div class="flex items-start gap-6">
                            <span class="font-mono text-champagne-500 text-sm tracking-wider font-semibold"><?= htmlspecialchars($pillar['number']) ?></span>
                            <div class="flex-1">
                                <h3 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-editorial mb-3">
                                    <?= htmlspecialchars($pillar['name']) ?>
                                </h3>
                                <p class="text-base text-platinum-200 leading-institutional">
                                    <?= htmlspecialchars($pillar['description']) ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>

                </div>
            </div>

        </div>

    </div>
</section>
