<section class="py-32 bg-obsidian-900 border-t border-champagne-500/20 isolate">

    <div class="container-sovereign">

        <!-- GOVERNANCE HEADER -->
        <div class="mb-20 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-600 font-semibold tracking-ultra-wide mb-6">
                GOVERNANCE
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-8"></div>
        </div>

        <!-- GOVERNANCE CONTENT -->
        <div class="max-w-3xl mx-auto text-center">
            <h3 class="font-serif text-4xl md:text-5xl text-platinum-50 mb-6 gsap-fade-up">
                UNGGUL BRONTO SDN. BHD.
            </h3>
            <p class="text-xl text-platinum-200 mb-8 gsap-fade-up">Malaysia</p>
            <p class="text-sovereign-300 leading-relaxed gsap-fade-up">
                A registered Malaysian entity built on institutional-grade governance principles. We maintain rigorous financial controls and transparent reporting structures that meet the standards institutional investors expect.
            </p>
        </div>

        <!-- PRINCIPLE BLOCK -->
        <div class="mt-20 max-w-4xl mx-auto border-l-4 border-champagne-600 pl-12 py-8 gsap-fade-up">
            <p class="text-2xl md:text-3xl font-serif text-platinum-50 leading-relaxed tracking-editorial italic">
                System integration creates long term economic resilience.
            </p>
        </div>

        <!-- INVESTMENT HIGHLIGHTS -->
        <div class="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 gsap-fade-up">

            <div class="border border-champagne-500/20 p-8 hover:bg-champagne-500/5 transition-colors">
                <div class="text-champagne-500 text-sm font-mono uppercase tracking-wider mb-4">Proven Model</div>
                <p class="text-platinum-50 text-lg mb-3">Scalable infrastructure with demonstrated unit economics</p>
                <p class="text-sm text-sovereign-300">
                    Our CIPU pilot has validated the operational model. The numbers work, the systems are in place, and we have a clear roadmap for replication across regions.
                </p>
            </div>

            <div class="border border-champagne-500/20 p-8 hover:bg-champagne-500/5 transition-colors">
                <div class="text-champagne-500 text-sm font-mono uppercase tracking-wider mb-4">Market Position</div>
                <p class="text-platinum-50 text-lg mb-3">First-mover advantage in integrated halal ecosystem</p>
                <p class="text-sm text-sovereign-300">
                    We're building at the intersection of production, technology, and compliance in Malaysia's strategic halal sector—a position that's difficult to replicate.
                </p>
            </div>

            <div class="border border-champagne-500/20 p-8 hover:bg-champagne-500/5 transition-colors">
                <div class="text-champagne-500 text-sm font-mono uppercase tracking-wider mb-4">Risk Mitigation</div>
                <p class="text-platinum-50 text-lg mb-3">Diversified revenue streams and asset-backed security</p>
                <p class="text-sm text-sovereign-300">
                    Revenue flows from production, processing, and platform services. Every facility represents tangible infrastructure assets that secure the investment.
                </p>
            </div>

        </div>

        <!-- VALUE PROPOSITION -->
        <div class="mt-16 border border-champagne-500/20 p-10 gsap-fade-up">
            <h3 class="text-2xl font-serif text-platinum-50 mb-8 text-center">Investment Value Proposition</h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">

                <div>
                    <h4 class="text-champagne-500 text-sm font-mono uppercase tracking-wider mb-4">Growth Trajectory</h4>
                    <ul class="space-y-3">
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1">→</span>
                            <span class="text-sovereign-300 text-sm">Deploying 7-11 facilities across Malaysia over the next five years</span>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1">→</span>
                            <span class="text-sovereign-300 text-sm">Scaling to 84-132M units of annual production capacity</span>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1">→</span>
                            <span class="text-sovereign-300 text-sm">Expanding the platform beyond poultry into livestock, seafood, and F&B</span>
                        </li>
                    </ul>
                </div>

                <div>
                    <h4 class="text-champagne-500 text-sm font-mono uppercase tracking-wider mb-4">Competitive Advantages</h4>
                    <ul class="space-y-3">
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1">→</span>
                            <span class="text-sovereign-300 text-sm">Vertical integration captures margins typically lost to intermediaries</span>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1">→</span>
                            <span class="text-sovereign-300 text-sm">Our UHIC platform creates network effects that strengthen with each new participant</span>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1">→</span>
                            <span class="text-sovereign-300 text-sm">Deep expertise in halal certification and compliance infrastructure</span>
                        </li>
                    </ul>
                </div>

            </div>
        </div>

    </div>

</section>
