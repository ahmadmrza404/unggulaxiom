<section class="py-32 bg-obsidian-800 border-t border-champagne-500/20 isolate">

    <div class="container-sovereign">

        <!-- HEADER BLOCK -->
        <div class="mb-20 text-center gsap-fade-up">
            <h2 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-6 tracking-editorial">
                CAPITAL
            </h2>
            <p class="text-lg text-sovereign-400 tracking-institutional max-w-3xl mx-auto">
                Institutional participation structure for infrastructure development.
            </p>
        </div>

        <!-- PARTICIPATION GRID: 3-COLUMN DATA ROOM -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-0 border border-champagne-500/20 mb-16">

            <!-- Column 1: Equity Participation -->
            <div class="group border-r border-champagne-500/20 p-10 transition-all duration-300 hover:bg-champagne-500/5"
                 onmouseenter="this.parentElement.querySelectorAll('.group').forEach(el => el !== this && el.classList.add('dimmed'))"
                 onmouseleave="this.parentElement.querySelectorAll('.group').forEach(el => el.classList.remove('dimmed'))">

                <div class="border-t-2 border-champagne-500 w-16 mb-8"></div>

                <h3 class="text-xl text-platinum-50 mb-6 tracking-institutional">
                    Equity Participation
                </h3>

                <div class="space-y-4 mb-8">
                    <p class="text-sm text-sovereign-300 leading-relaxed">
                        Direct ownership structures enabling institutional investors to participate in infrastructure development with aligned governance frameworks.
                    </p>
                </div>

                <div class="space-y-3 pt-4 border-t border-champagne-500/20">
                    <div class="flex items-center gap-2">
                        <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></div>
                        <span class="text-xs text-sovereign-400">Minority stake options</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></div>
                        <span class="text-xs text-sovereign-400">Board representation rights</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></div>
                        <span class="text-xs text-sovereign-400">Dividend distribution models</span>
                    </div>
                </div>
            </div>

            <!-- Column 2: Joint Venture Systems -->
            <div class="group border-r border-champagne-500/20 p-10 transition-all duration-300 hover:bg-champagne-500/5"
                 onmouseenter="this.parentElement.querySelectorAll('.group').forEach(el => el !== this && el.classList.add('dimmed'))"
                 onmouseleave="this.parentElement.querySelectorAll('.group').forEach(el => el.classList.remove('dimmed'))">

                <div class="border-t-2 border-champagne-500 w-16 mb-8"></div>

                <h3 class="text-xl text-platinum-50 mb-6 tracking-institutional">
                    Joint Venture Systems
                </h3>

                <div class="space-y-4 mb-8">
                    <p class="text-sm text-sovereign-300 leading-relaxed">
                        Strategic partnerships combining operational expertise with capital deployment for shared risk and value creation across the ecosystem.
                    </p>
                </div>

                <div class="space-y-3 pt-4 border-t border-champagne-500/20">
                    <div class="flex items-center gap-2">
                        <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></div>
                        <span class="text-xs text-sovereign-400">50/50 partnership structures</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></div>
                        <span class="text-xs text-sovereign-400">Shared operational control</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></div>
                        <span class="text-xs text-sovereign-400">Technology transfer agreements</span>
                    </div>
                </div>
            </div>

            <!-- Column 3: Project-Based Financing -->
            <div class="group p-10 transition-all duration-300 hover:bg-champagne-500/5"
                 onmouseenter="this.parentElement.querySelectorAll('.group').forEach(el => el !== this && el.classList.add('dimmed'))"
                 onmouseleave="this.parentElement.querySelectorAll('.group').forEach(el => el.classList.remove('dimmed'))">

                <div class="border-t-2 border-champagne-500 w-16 mb-8"></div>

                <h3 class="text-xl text-platinum-50 mb-6 tracking-institutional">
                    Project-Based Financing
                </h3>

                <div class="space-y-4 mb-8">
                    <p class="text-sm text-sovereign-300 leading-relaxed">
                        Non-recourse debt structures secured against specific project assets and cash flows, optimizing capital efficiency and risk allocation.
                    </p>
                </div>

                <div class="space-y-3 pt-4 border-t border-champagne-500/20">
                    <div class="flex items-center gap-2">
                        <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></div>
                        <span class="text-xs text-sovereign-400">Asset-backed securities</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></div>
                        <span class="text-xs text-sovereign-400">Revenue-based repayment</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full"></div>
                        <span class="text-xs text-sovereign-400">Institutional debt facilities</span>
                    </div>
                </div>
            </div>

        </div>

        <!-- INSTITUTIONAL FOOTER BLOCK -->
        <div class="border-t border-champagne-500/20 pt-12 gsap-fade-up">
            <p class="text-center font-mono text-sm text-champagne-500 tracking-institutional">
                Strategic institutional alignment. Capital engagement is structured through institutional channels.
            </p>
        </div>

    </div>

    <style>
        .dimmed {
            opacity: 0.4 !important;
        }
    </style>

</section>
