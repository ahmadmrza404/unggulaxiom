<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$hero = $homepage_data['hero'] ?? [];
?>
<section class="min-h-[100dvh] flex items-center justify-center relative overflow-hidden bg-obsidian-950 isolate">

    <!-- CANVAS: GLOBAL INFRASTRUCTURE NETWORK -->
    <canvas id="hero-network" class="absolute inset-0 z-0"></canvas>

    <div class="container-sovereign relative z-10">
        <div class="max-w-6xl mx-auto text-center">

            <h1 class="split-hero-title font-serif text-6xl md:text-7xl lg:text-8xl text-platinum-50 mb-16 tracking-tight leading-none reveal-mask">
                <?= htmlspecialchars($hero['title'] ?? 'Unggul Axiom Group') ?>
            </h1>

            <div class="mb-8 gsap-fade-up">
                <h2 class="text-2xl md:text-3xl lg:text-4xl font-sans text-platinum-100 tracking-wide leading-tight mb-4">
                    <?= htmlspecialchars($hero['subtitle'] ?? 'Emerging Infrastructure Systems Platform') ?>
                </h2>
                <p class="text-lg md:text-xl text-sovereign-400 leading-relaxed max-w-4xl mx-auto">
                    <?= htmlspecialchars($hero['tagline'] ?? 'Global Halal Economy Architecture') ?>
                </p>
            </div>

            <div class="w-24 h-px bg-champagne-500 mx-auto mb-10 gsap-fade-up"></div>

            <div class="flex flex-col sm:flex-row gap-6 justify-center mt-16 gsap-fade-up">
                <a href="<?= url($hero['cta_primary']['url'] ?? '/systems') ?>"
                   class="px-10 py-4 bg-champagne-500 text-obsidian-950 text-sm font-semibold hover:bg-champagne-400 transition-all duration-300 rounded">
                    <?= htmlspecialchars($hero['cta_primary']['text'] ?? 'View Systems') ?>
                </a>
                <a href="<?= url($hero['cta_secondary']['url'] ?? '/capital') ?>"
                   class="px-10 py-4 border-2 border-champagne-500 text-champagne-500 text-sm font-semibold hover:bg-champagne-500/10 transition-all duration-300 rounded">
                    <?= htmlspecialchars($hero['cta_secondary']['text'] ?? 'Capital Structure') ?>
                </a>
            </div>

        </div>
    </div>

</section>
