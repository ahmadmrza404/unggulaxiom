<section class="py-32 bg-obsidian-900 border-t border-champagne-500/20 isolate">

    <div class="container-sovereign">

        <!-- CIPU FINANCIAL SNAPSHOT HEADER -->
        <div class="mb-20 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                CIPU FINANCIAL SNAPSHOT
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-lg text-sovereign-300 max-w-3xl mx-auto">
                Projected financial performance metrics for single facility deployment
            </p>
        </div>

        <!-- FINANCIAL GRID -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0 border border-champagne-500/20">

            <!-- PRODUCTION -->
            <div class="border-b md:border-r border-champagne-500/20 p-10 gsap-fade-up">
                <h3 class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4">PRODUCTION</h3>
                <p class="text-3xl md:text-4xl font-serif text-platinum-50 mb-2">12 million</p>
                <p class="text-sm text-sovereign-400">chickens per year</p>
            </div>

            <!-- NET PROFIT -->
            <div class="border-b lg:border-r border-champagne-500/20 p-10 gsap-fade-up">
                <h3 class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4">NET PROFIT</h3>
                <p class="text-3xl md:text-4xl font-serif text-platinum-50 mb-2">RM7.2M to RM30.6M</p>
                <p class="text-sm text-sovereign-400">range</p>
                <p class="text-lg text-champagne-400 mt-2">Base: RM19.8M</p>
            </div>

            <!-- CAPEX -->
            <div class="border-b md:border-r border-champagne-500/20 p-10 gsap-fade-up">
                <h3 class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4">CAPEX</h3>
                <p class="text-3xl md:text-4xl font-serif text-platinum-50 mb-2">RM12M to RM18M</p>
            </div>

            <!-- PAYBACK -->
            <div class="border-b border-champagne-500/20 p-10 gsap-fade-up">
                <h3 class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4">PAYBACK</h3>
                <p class="text-3xl md:text-4xl font-serif text-platinum-50 mb-2">1 to 2 years</p>
                <p class="text-sm text-sovereign-400">(target range)</p>
            </div>

        </div>

        <!-- FOOTER NOTE -->
        <div class="mt-12 text-center gsap-fade-up">
            <p class="text-xs text-champagne-500 tracking-institutional">
                Scalable infrastructure model
            </p>
        </div>

        <!-- ADDITIONAL FINANCIAL DETAILS -->
        <div class="mt-20 grid grid-cols-1 md:grid-cols-2 gap-8 gsap-fade-up">

            <!-- Revenue Breakdown -->
            <div class="border border-champagne-500/20 p-8">
                <h3 class="text-lg font-mono text-champagne-500 uppercase tracking-wider mb-6">Revenue Streams</h3>
                <div class="space-y-4">
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                        <span class="text-sm text-sovereign-300">Live bird sales</span>
                        <span class="text-platinum-50 font-mono">65%</span>
                    </div>
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                        <span class="text-sm text-sovereign-300">Processed products</span>
                        <span class="text-platinum-50 font-mono">25%</span>
                    </div>
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                        <span class="text-sm text-sovereign-300">By-products & feed</span>
                        <span class="text-platinum-50 font-mono">10%</span>
                    </div>
                </div>
            </div>

            <!-- Operating Metrics -->
            <div class="border border-champagne-500/20 p-8">
                <h3 class="text-lg font-mono text-champagne-500 uppercase tracking-wider mb-6">Operating Metrics</h3>
                <div class="space-y-4">
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                        <span class="text-sm text-sovereign-300">Gross margin</span>
                        <span class="text-platinum-50 font-mono">28-35%</span>
                    </div>
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                        <span class="text-sm text-sovereign-300">EBITDA margin</span>
                        <span class="text-platinum-50 font-mono">22-28%</span>
                    </div>
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                        <span class="text-sm text-sovereign-300">Operating cycle</span>
                        <span class="text-platinum-50 font-mono">42 days</span>
                    </div>
                </div>
            </div>

        </div>

        <!-- KEY ASSUMPTIONS -->
        <div class="mt-8 border border-champagne-500/20 p-8 gsap-fade-up">
            <h3 class="text-lg font-mono text-champagne-500 uppercase tracking-wider mb-6 text-center">Key Financial Assumptions</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="text-center">
                    <div class="text-2xl font-serif text-platinum-50 mb-2">RM6.50</div>
                    <div class="text-xs text-sovereign-400">Average selling price per kg</div>
                </div>
                <div class="text-center">
                    <div class="text-2xl font-serif text-platinum-50 mb-2">1.65kg</div>
                    <div class="text-xs text-sovereign-400">Average bird weight</div>
                </div>
                <div class="text-center">
                    <div class="text-2xl font-serif text-platinum-50 mb-2">95%</div>
                    <div class="text-xs text-sovereign-400">Survival rate target</div>
                </div>
            </div>
        </div>

    </div>

</section>
