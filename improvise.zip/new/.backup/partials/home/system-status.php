<section class="py-32 bg-obsidian-900 border-t border-champagne-500/20 isolate">

    <div class="container-sovereign">

        <!-- SYSTEM STATUS HEADER -->
        <div class="mb-20 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-600 font-semibold tracking-ultra-wide mb-6">
                SYSTEM STATUS
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-6"></div>
            <p class="text-sovereign-400 max-w-2xl mx-auto">
                Real-time progress across our integrated poultry ecosystem
            </p>
        </div>

        <!-- STATUS GRID -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-0 border border-champagne-500/20">

            <!-- CIPU -->
            <div class="border-b md:border-b-0 md:border-r border-champagne-500/20 p-10 gsap-fade-up hover:bg-champagne-500/5 transition-colors">
                <div class="flex items-start justify-between mb-6">
                    <h3 class="font-serif text-2xl text-platinum-50">CIPU</h3>
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-mono bg-champagne-500/20 text-champagne-500">
                        Active
                    </span>
                </div>

                <p class="text-lg text-champagne-600 font-mono mb-6">Pilot Deployment</p>

                <!-- Progress Bar -->
                <div class="mb-6">
                    <div class="flex justify-between text-xs text-sovereign-400 mb-2">
                        <span>Progress</span>
                        <span>75%</span>
                    </div>
                    <div class="h-1 bg-obsidian-800 rounded-full overflow-hidden">
                        <div class="h-full bg-champagne-500 rounded-full" style="width: 75%"></div>
                    </div>
                </div>

                <!-- Key Metrics -->
                <div class="space-y-3 text-sm">
                    <div class="flex justify-between">
                        <span class="text-sovereign-400">Location</span>
                        <span class="text-platinum-50">Kelantan, Malaysia</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sovereign-400">Capacity</span>
                        <span class="text-platinum-50">12M chickens/year</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sovereign-400">Timeline</span>
                        <span class="text-platinum-50">Q2 2026</span>
                    </div>
                </div>
            </div>

            <!-- UHIC -->
            <div class="border-b md:border-b-0 md:border-r border-champagne-500/20 p-10 gsap-fade-up hover:bg-champagne-500/5 transition-colors">
                <div class="flex items-start justify-between mb-6">
                    <h3 class="font-serif text-2xl text-platinum-50">UHIC</h3>
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-mono bg-blue-500/20 text-blue-400">
                        Development
                    </span>
                </div>

                <p class="text-lg text-champagne-600 font-mono mb-6">Platform Development</p>

                <!-- Progress Bar -->
                <div class="mb-6">
                    <div class="flex justify-between text-xs text-sovereign-400 mb-2">
                        <span>Progress</span>
                        <span>60%</span>
                    </div>
                    <div class="h-1 bg-obsidian-800 rounded-full overflow-hidden">
                        <div class="h-full bg-blue-400 rounded-full" style="width: 60%"></div>
                    </div>
                </div>

                <!-- Key Metrics -->
                <div class="space-y-3 text-sm">
                    <div class="flex justify-between">
                        <span class="text-sovereign-400">Focus</span>
                        <span class="text-platinum-50">Healthcare Integration</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sovereign-400">Phase</span>
                        <span class="text-platinum-50">Beta Testing</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sovereign-400">Launch</span>
                        <span class="text-platinum-50">Q3 2026</span>
                    </div>
                </div>
            </div>

            <!-- CAPITAL -->
            <div class="p-10 gsap-fade-up hover:bg-champagne-500/5 transition-colors">
                <div class="flex items-start justify-between mb-6">
                    <h3 class="font-serif text-2xl text-platinum-50">Capital</h3>
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-mono bg-amber-500/20 text-amber-400">
                        Structuring
                    </span>
                </div>

                <p class="text-lg text-champagne-600 font-mono mb-6">Structuring Phase</p>

                <!-- Progress Bar -->
                <div class="mb-6">
                    <div class="flex justify-between text-xs text-sovereign-400 mb-2">
                        <span>Progress</span>
                        <span>45%</span>
                    </div>
                    <div class="h-1 bg-obsidian-800 rounded-full overflow-hidden">
                        <div class="h-full bg-amber-400 rounded-full" style="width: 45%"></div>
                    </div>
                </div>

                <!-- Key Metrics -->
                <div class="space-y-3 text-sm">
                    <div class="flex justify-between">
                        <span class="text-sovereign-400">Type</span>
                        <span class="text-platinum-50">Equity + Debt</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sovereign-400">Target</span>
                        <span class="text-platinum-50">RM12-18M</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sovereign-400">Close</span>
                        <span class="text-platinum-50">Q2 2026</span>
                    </div>
                </div>
            </div>

        </div>

        <!-- FOOTER NOTE -->
        <div class="mt-12 text-center gsap-fade-up">
            <p class="text-xs text-champagne-500 tracking-institutional">
                Last updated: April 2026 • All systems operational
            </p>
        </div>

    </div>

</section>
