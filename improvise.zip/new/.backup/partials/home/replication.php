<section class="py-32 bg-obsidian-900 border-t border-champagne-500/20 isolate">

    <div class="container-sovereign">

        <!-- REPLICATION HEADER -->
        <div class="mb-20 gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                REPLICATION
            </h2>
            <div class="w-24 h-px bg-champagne-500 mb-8"></div>
            <p class="text-xl text-sovereign-300 max-w-3xl">
                Strategic expansion framework designed for nationwide deployment across key Malaysian regions
            </p>
        </div>

        <!-- REPLICATION GRID -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">

            <!-- Peninsular Malaysia -->
            <div class="border border-champagne-500/20 p-8 gsap-fade-up hover:border-champagne-500/40 transition-colors group">
                <div class="mb-6">
                    <h3 class="text-2xl font-serif text-platinum-50 mb-3">Peninsular Malaysia</h3>
                    <div class="w-12 h-px bg-champagne-500 group-hover:w-20 transition-all"></div>
                </div>

                <div class="space-y-4 mb-6">
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-2 bg-champagne-500 rounded-full"></div>
                        <span class="text-sovereign-300 text-sm">Primary market concentration</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-2 bg-champagne-500 rounded-full"></div>
                        <span class="text-sovereign-300 text-sm">Established supply chain networks</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-2 bg-champagne-500 rounded-full"></div>
                        <span class="text-sovereign-300 text-sm">High-density urban distribution</span>
                    </div>
                </div>

                <div class="pt-4 border-t border-champagne-500/20">
                    <div class="flex justify-between items-center mb-2">
                        <span class="text-xs text-champagne-500 font-mono uppercase tracking-wider">Target Sites</span>
                        <span class="text-platinum-50 font-mono">3-5</span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-xs text-champagne-500 font-mono uppercase tracking-wider">Timeline</span>
                        <span class="text-platinum-50 font-mono">2026-2028</span>
                    </div>
                </div>
            </div>

            <!-- Sabah -->
            <div class="border border-champagne-500/20 p-8 gsap-fade-up hover:border-champagne-500/40 transition-colors group">
                <div class="mb-6">
                    <h3 class="text-2xl font-serif text-platinum-50 mb-3">Sabah</h3>
                    <div class="w-12 h-px bg-champagne-500 group-hover:w-20 transition-all"></div>
                </div>

                <div class="space-y-4 mb-6">
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-2 bg-champagne-500 rounded-full"></div>
                        <span class="text-sovereign-300 text-sm">East Malaysia gateway</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-2 bg-champagne-500 rounded-full"></div>
                        <span class="text-sovereign-300 text-sm">Regional self-sufficiency focus</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-2 bg-champagne-500 rounded-full"></div>
                        <span class="text-sovereign-300 text-sm">Cross-border trade potential</span>
                    </div>
                </div>

                <div class="pt-4 border-t border-champagne-500/20">
                    <div class="flex justify-between items-center mb-2">
                        <span class="text-xs text-champagne-500 font-mono uppercase tracking-wider">Target Sites</span>
                        <span class="text-platinum-50 font-mono">2-3</span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-xs text-champagne-500 font-mono uppercase tracking-wider">Timeline</span>
                        <span class="text-platinum-50 font-mono">2027-2029</span>
                    </div>
                </div>
            </div>

            <!-- Sarawak -->
            <div class="border border-champagne-500/20 p-8 gsap-fade-up hover:border-champagne-500/40 transition-colors group">
                <div class="mb-6">
                    <h3 class="text-2xl font-serif text-platinum-50 mb-3">Sarawak</h3>
                    <div class="w-12 h-px bg-champagne-500 group-hover:w-20 transition-all"></div>
                </div>

                <div class="space-y-4 mb-6">
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-2 bg-champagne-500 rounded-full"></div>
                        <span class="text-sovereign-300 text-sm">Strategic resource hub</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-2 bg-champagne-500 rounded-full"></div>
                        <span class="text-sovereign-300 text-sm">Infrastructure development zone</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-2 bg-champagne-500 rounded-full"></div>
                        <span class="text-sovereign-300 text-sm">Export corridor access</span>
                    </div>
                </div>

                <div class="pt-4 border-t border-champagne-500/20">
                    <div class="flex justify-between items-center mb-2">
                        <span class="text-xs text-champagne-500 font-mono uppercase tracking-wider">Target Sites</span>
                        <span class="text-platinum-50 font-mono">2-3</span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-xs text-champagne-500 font-mono uppercase tracking-wider">Timeline</span>
                        <span class="text-platinum-50 font-mono">2027-2029</span>
                    </div>
                </div>
            </div>

        </div>

        <!-- EXPANSION METRICS -->
        <div class="mt-16 grid grid-cols-1 md:grid-cols-4 gap-6 gsap-fade-up">
            <div class="border-l-2 border-champagne-500 pl-6">
                <div class="text-3xl font-serif text-platinum-50 mb-2">7-11</div>
                <div class="text-sm text-sovereign-400">Total Planned Sites</div>
            </div>
            <div class="border-l-2 border-champagne-500 pl-6">
                <div class="text-3xl font-serif text-platinum-50 mb-2">84-132M</div>
                <div class="text-sm text-sovereign-400">Annual Production Capacity</div>
            </div>
            <div class="border-l-2 border-champagne-500 pl-6">
                <div class="text-3xl font-serif text-platinum-50 mb-2">3-5 Years</div>
                <div class="text-sm text-sovereign-400">Full Deployment Timeline</div>
            </div>
            <div class="border-l-2 border-champagne-500 pl-6">
                <div class="text-3xl font-serif text-platinum-50 mb-2">100%</div>
                <div class="text-sm text-sovereign-400">Halal Certified Operations</div>
            </div>
        </div>

    </div>

</section>
