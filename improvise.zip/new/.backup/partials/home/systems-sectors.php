<section class="py-32 bg-obsidian-950 border-t border-champagne-500/20 isolate">

    <div class="container-sovereign">

        <!-- SECTION HEADER -->
        <div class="mb-20 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4">
                INTEGRATED INFRASTRUCTURE
            </h2>
            <p class="text-base text-sovereign-400 tracking-institutional">
                Systematic deployment across operational domains
            </p>
        </div>

        <!-- INFRASTRUCTURE MATRIX GRID -->
        <div class="grid grid-cols-1 lg:grid-cols-2 border border-champagne-500/20">

            <!-- LEFT BLOCK: SYSTEMS -->
            <div class="border-b lg:border-b-0 lg:border-r border-champagne-500/20">

                <!-- Systems Header -->
                <div class="border-b border-champagne-500/20 p-8 bg-obsidian-900/30">
                    <h3 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-editorial">
                        SYSTEMS
                    </h3>
                </div>

                <!-- Systems Grid -->
                <div class="divide-y divide-champagne-500/20">

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Production Systems
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Industrial Systems
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Compliance Systems
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Logistics Systems
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Finance Systems
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Trade Systems
                        </span>
                    </div>

                </div>
            </div>

            <!-- RIGHT BLOCK: SECTORS -->
            <div>

                <!-- Sectors Header -->
                <div class="border-b border-champagne-500/20 p-8 bg-obsidian-900/30">
                    <h3 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-editorial">
                        SECTORS
                    </h3>
                </div>

                <!-- Sectors Grid -->
                <div class="divide-y divide-champagne-500/20">

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Food & Agriculture
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Pharmaceuticals & Wellness
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Manufacturing
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Logistics & Distribution
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Islamic Finance
                        </span>
                    </div>

                    <div class="matrix-item group p-6 transition-all duration-300 hover:border-champagne-500 border-l-2 border-transparent">
                        <span class="text-lg text-sovereign-400 group-hover:text-platinum-50 transition-colors duration-300">
                            Global Trade
                        </span>
                    </div>

                </div>
            </div>

        </div>

        <!-- INTEGRATION STATEMENT -->
        <div class="mt-16 text-center gsap-fade-up">
            <p class="text-xs text-champagne-500 tracking-[0.15em] font-sans uppercase">
                Systems Architecture × Sector Deployment = Operational Integration
            </p>
        </div>

    </div>

</section>
