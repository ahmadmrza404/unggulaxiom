<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$cipu = $homepage_data['cipu_pilot'] ?? [];
?>
<section class="py-32 bg-obsidian-800 border-t border-champagne-500/20 isolate">

    <div class="container-sovereign">

        <!-- SPLIT-PANE TECHNICAL DOSSIER -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">

            <!-- LEFT PANE: ENGINEERING SPECS -->
            <div class="lg:col-span-5 gsap-fade-up">

                <div class="space-y-8">

                    <!-- Primary Header -->
                    <div>
                        <h2 class="text-sovereign-xs text-champagne-600 font-semibold tracking-ultra-wide mb-3">
                            <?= htmlspecialchars($cipu['section_label'] ?? 'PILOT SYSTEM') ?>
                        </h2>
                        <h3 class="font-serif text-5xl md:text-6xl text-platinum-50 tracking-tight leading-none">
                            <?= htmlspecialchars($cipu['title'] ?? 'CIPU') ?>
                        </h3>
                    </div>

                    <!-- Sub-header -->
                    <div class="border-l-2 border-champagne-500 pl-6">
                        <p class="text-xl text-platinum-200 tracking-institutional">
                            <?= htmlspecialchars($cipu['subtitle'] ?? 'Central Integrated Poultry Unggul') ?>
                        </p>
                    </div>

                    <!-- Technical Data Tags -->
                    <div class="space-y-4 pt-8">

                        <div class="border border-champagne-500 p-4 bg-champagne-500/10">
                            <div class="flex items-baseline justify-between">
                                <span class="font-mono text-xs text-champagne-500 tracking-wider uppercase">
                                    STATUS
                                </span>
                                <span class="font-mono text-sm text-platinum-50 tracking-wide">
                                    <?= htmlspecialchars($cipu['status'] ?? 'Development Phase') ?>
                                </span>
                            </div>
                        </div>

                        <div class="border border-champagne-500 p-4 bg-champagne-500/10">
                            <div class="flex items-baseline justify-between">
                                <span class="font-mono text-xs text-champagne-500 tracking-wider uppercase">
                                    FUNCTION
                                </span>
                                <span class="font-mono text-sm text-platinum-50 tracking-wide">
                                    <?= htmlspecialchars($cipu['function'] ?? 'Replicable Infrastructure Model') ?>
                                </span>
                            </div>
                        </div>

                        <div class="border border-champagne-500 p-4 bg-champagne-500/10">
                            <div class="flex items-baseline justify-between">
                                <span class="font-mono text-xs text-champagne-500 tracking-wider uppercase">
                                    LOCATION
                                </span>
                                <span class="font-mono text-sm text-platinum-50 tracking-wide">
                                    <?= htmlspecialchars($cipu['location'] ?? 'Johor, Malaysia') ?>
                                </span>
                            </div>
                        </div>

                        <div class="border border-champagne-500 p-4 bg-champagne-500/10">
                            <div class="flex items-baseline justify-between">
                                <span class="font-mono text-xs text-champagne-500 tracking-wider uppercase">
                                    CAPACITY
                                </span>
                                <span class="font-mono text-sm text-platinum-50 tracking-wide">
                                    <?= htmlspecialchars($cipu['capacity'] ?? '12M Units Annually') ?>
                                </span>
                            </div>
                        </div>

                    </div>

                </div>

            </div>

            <!-- RIGHT PANE: NARRATIVE BLOCK -->
            <div class="lg:col-span-7 flex items-center gsap-fade-up">

                <div class="space-y-8">
                    <p class="font-serif text-4xl md:text-5xl lg:text-6xl text-platinum-50 leading-tight tracking-tight">
                        Pilot infrastructure system for integrated halal production and supply chain coordination.
                    </p>

                    <div class="space-y-6 pt-6">
                        <div class="flex items-start gap-4">
                            <div class="w-1 h-16 bg-champagne-500 flex-shrink-0"></div>
                            <div>
                                <h4 class="text-champagne-500 text-sm font-mono tracking-wider uppercase mb-2">Vertical Integration</h4>
                                <p class="text-sovereign-300 leading-relaxed">
                                    End-to-end control from breeding to distribution, ensuring quality standards and operational efficiency across the entire value chain.
                                </p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4">
                            <div class="w-1 h-16 bg-champagne-500 flex-shrink-0"></div>
                            <div>
                                <h4 class="text-champagne-500 text-sm font-mono tracking-wider uppercase mb-2">Scalable Architecture</h4>
                                <p class="text-sovereign-300 leading-relaxed">
                                    Modular design enabling rapid deployment across multiple regions with standardized operational protocols and infrastructure.
                                </p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4">
                            <div class="w-1 h-16 bg-champagne-500 flex-shrink-0"></div>
                            <div>
                                <h4 class="text-champagne-500 text-sm font-mono tracking-wider uppercase mb-2">Halal Compliance</h4>
                                <p class="text-sovereign-300 leading-relaxed">
                                    Comprehensive certification framework maintaining the highest standards of halal integrity throughout production and logistics.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

</section>
