<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$positioning = $homepage_data['positioning'] ?? [];
?>
<section class="py-32 bg-obsidian-900 border-t border-champagne-500/20 isolate">

    <div class="container-sovereign">

        <!-- 12-COLUMN ASYMMETRICAL GRID -->
        <div class="grid grid-cols-12 gap-8 lg:gap-12">

            <!-- POSITION BLOCK: LEFT-WEIGHTED (COLUMNS 2-6) -->
            <div class="col-span-12 lg:col-start-2 lg:col-span-5 gsap-fade-up">

                <div class="mb-8">
                    <h2 class="text-sovereign-xs text-champagne-600 font-semibold tracking-ultra-wide mb-6">
                        <?= htmlspecialchars($positioning['position_label'] ?? 'POSITION') ?>
                    </h2>
                    <div class="w-16 h-px bg-champagne-500"></div>
                </div>

                <div class="prose-institutional">
                    <p class="text-lg md:text-xl text-platinum-100 leading-institutional font-sans">
                        <?= htmlspecialchars($positioning['position_text_1'] ?? '') ?>
                    </p>
                    <p class="text-lg md:text-xl text-platinum-100 leading-institutional font-sans mt-4">
                        <?= htmlspecialchars($positioning['position_text_2'] ?? '') ?>
                    </p>
                </div>

            </div>

            <!-- PRINCIPLE BLOCK: RIGHT-WEIGHTED (COLUMNS 8-13) -->
            <div class="col-span-12 lg:col-start-8 lg:col-span-5 gsap-fade-up">

                <div class="mb-8">
                    <h2 class="text-sovereign-xs text-champagne-600 font-semibold tracking-ultra-wide mb-6">
                        <?= htmlspecialchars($positioning['principle_label'] ?? 'PRINCIPLE') ?>
                    </h2>
                    <div class="w-16 h-px bg-champagne-500"></div>
                </div>

                <div class="border-l border-champagne-500 pl-8">
                    <h3 class="font-serif text-4xl md:text-5xl lg:text-6xl text-platinum-50 leading-tight tracking-tight">
                        <?= htmlspecialchars($positioning['principle_statement'] ?? '') ?>
                    </h3>
                </div>

            </div>

        </div>

    </div>

</section>
