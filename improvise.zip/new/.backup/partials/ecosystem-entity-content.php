<?php
/**
 * Shared render template for all 5 ecosystem entity pages.
 * Caller must set $__entity_data before including this file.
 * $__entity_data = json_decode(file_get_contents(...), true);
 */
$_d = $__entity_data;
?>

<!-- HERO SECTION -->
<section class="py-24 bg-obsidian-950 border-b border-champagne-500/20">
    <div class="container-sovereign">
        <div class="max-w-3xl">
            <span class="text-xs text-champagne-500 tracking-widest mb-4 block uppercase">
                <?= htmlspecialchars($_d['hero']['label']) ?>
            </span>
            <h1 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-tight mb-6 leading-tight">
                <?= htmlspecialchars($_d['hero']['title']) ?>
            </h1>
            <p class="text-base text-platinum-200 leading-relaxed">
                <?= htmlspecialchars($_d['hero']['tagline']) ?>
            </p>
        </div>
    </div>
</section>

<!-- CONTENT SECTIONS -->
<section class="py-16 bg-obsidian-900">
    <div class="container-sovereign">
        <div class="max-w-3xl space-y-12">

            <?php foreach ($_d['sections'] as $section): ?>
            <div>
                <h2 class="font-serif text-2xl text-platinum-50 tracking-tight mb-4">
                    <?= htmlspecialchars($section['title']) ?>
                </h2>

                <?php if (!empty($section['subsections'])): ?>
                    <?php if (!empty($section['paragraphs'])): ?>
                        <div class="space-y-3 text-base text-platinum-200 leading-relaxed mb-5">
                            <?php foreach ($section['paragraphs'] as $para): ?>
                                <p><?= htmlspecialchars($para) ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <div class="space-y-5 text-base text-platinum-200 leading-relaxed">
                        <?php foreach ($section['subsections'] as $sub): ?>
                        <div>
                            <h3 class="text-base text-champagne-400 mb-2 font-medium"><?= htmlspecialchars($sub['subtitle']) ?></h3>
                            <p><?= htmlspecialchars($sub['text']) ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="space-y-3 text-base text-platinum-200 leading-relaxed">
                        <?php foreach ($section['paragraphs'] as $para): ?>
                            <p><?= htmlspecialchars($para) ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>

        </div>
    </div>
</section>
