<?php
/**
 * ============================================
 * PARTNERSHIPS - STRATEGIC ROUTING PORTAL
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Partnerships';

$_partnerships = json_decode(file_get_contents(__DIR__ . '/data/partnerships.json'), true);
$p = $_partnerships['partnerships'];

require_once INCLUDES_PATH . '/header.php';
?>

<!-- ═══════════════════════════════════════ HERO ═══ -->
<section class="relative py-36 bg-obsidian-900 border-t border-champagne-500/20 overflow-hidden">

    <!-- Background grid -->
    <div class="absolute inset-0 opacity-5 pointer-events-none"
         style="background-image: linear-gradient(rgba(197,160,40,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(197,160,40,0.4) 1px, transparent 1px); background-size: 64px 64px;"></div>


<div class="container-sovereign relative z-10">
        <div class="max-w-4xl mx-auto text-center gsap-fade-up">
            <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                <?= htmlspecialchars($p['hero']['label']) ?>
            </p>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-6 tracking-editorial leading-tight">
                <?= htmlspecialchars($p['hero']['title']) ?>
            </h1>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 leading-relaxed max-w-2xl mx-auto">
                <?= htmlspecialchars($p['hero']['subtitle']) ?>
            </p>
            <div class="mt-10 flex flex-wrap justify-center gap-4">
                <a href="#inquiry-form"
                   class="inline-flex items-center gap-3 px-10 py-4 bg-champagne-500 text-obsidian-900 text-xs font-bold uppercase tracking-wider hover:bg-champagne-400 transition-all duration-300 hover:shadow-lg hover:shadow-champagne-500/20">
                    <span>Submit Inquiry</span>
                    <span>→</span>
                </a>
                <a href="#structures"
                   class="inline-flex items-center gap-3 px-10 py-4 border border-champagne-500/40 text-champagne-500 text-xs font-bold uppercase tracking-wider hover:bg-champagne-500/10 transition-all duration-300">
                    <span>Partnership Structures</span>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════ STATS BAR ═══ -->
<section class="py-0 bg-obsidian-950 border-y border-champagne-500/20">
    <div class="container-sovereign">
        <div class="grid grid-cols-2 md:grid-cols-4 divide-x divide-champagne-500/10">
            <?php foreach ($p['stats'] as $i => $stat): ?>
            <div class="py-8 px-6 text-center gsap-fade-up">
                <div class="text-2xl md:text-3xl font-serif text-champagne-500 mb-1"><?= htmlspecialchars($stat['value']) ?></div>
                <div class="text-xs text-sovereign-400 uppercase tracking-wider"><?= htmlspecialchars($stat['label']) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════ PARTNERSHIP STRUCTURES ═══ -->
<section id="structures" class="py-28 bg-obsidian-800 border-t border-champagne-500/20">
    <div class="container-sovereign">

        <div class="mb-16 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                PARTNERSHIP STRUCTURES
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-sovereign-300 max-w-2xl mx-auto">
                We offer three institutional-grade engagement frameworks, each designed to align capital objectives with long-term operational outcomes.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">

            <!-- Structure 1 -->
            <div class="group relative border border-champagne-500/20 bg-obsidian-900/50 p-8 hover:border-champagne-500/50 hover:bg-champagne-500/5 transition-all duration-300 gsap-fade-up">
                <div class="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-champagne-500/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div class="w-12 h-12 border border-champagne-500/30 flex items-center justify-center mb-6 group-hover:border-champagne-500/60 transition-colors">
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <div class="text-xs text-champagne-500/60 font-mono uppercase tracking-wider mb-2">01</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-3"><?= htmlspecialchars($p['structures'][0]['title']) ?></h3>
                <p class="text-sm text-sovereign-300 mb-6 leading-relaxed"><?= htmlspecialchars($p['structures'][0]['description']) ?></p>
                <div class="text-xs text-champagne-500/80 font-mono border-t border-champagne-500/10 pt-4"><?= htmlspecialchars($p['structures'][0]['tags']) ?></div>
            </div>

            <!-- Structure 2 -->
            <div class="group relative border border-champagne-500/20 bg-obsidian-900/50 p-8 hover:border-champagne-500/50 hover:bg-champagne-500/5 transition-all duration-300 gsap-fade-up">
                <div class="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-champagne-500/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div class="w-12 h-12 border border-champagne-500/30 flex items-center justify-center mb-6 group-hover:border-champagne-500/60 transition-colors">
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </div>
                <div class="text-xs text-champagne-500/60 font-mono uppercase tracking-wider mb-2">02</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-3"><?= htmlspecialchars($p['structures'][1]['title']) ?></h3>
                <p class="text-sm text-sovereign-300 mb-6 leading-relaxed"><?= htmlspecialchars($p['structures'][1]['description']) ?></p>
                <div class="text-xs text-champagne-500/80 font-mono border-t border-champagne-500/10 pt-4"><?= htmlspecialchars($p['structures'][1]['tags']) ?></div>
            </div>

            <!-- Structure 3 -->
            <div class="group relative border border-champagne-500/20 bg-obsidian-900/50 p-8 hover:border-champagne-500/50 hover:bg-champagne-500/5 transition-all duration-300 gsap-fade-up">
                <div class="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-champagne-500/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div class="w-12 h-12 border border-champagne-500/30 flex items-center justify-center mb-6 group-hover:border-champagne-500/60 transition-colors">
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                    </svg>
                </div>
                <div class="text-xs text-champagne-500/60 font-mono uppercase tracking-wider mb-2">03</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-3"><?= htmlspecialchars($p['structures'][2]['title']) ?></h3>
                <p class="text-sm text-sovereign-300 mb-6 leading-relaxed"><?= htmlspecialchars($p['structures'][2]['description']) ?></p>
                <div class="text-xs text-champagne-500/80 font-mono border-t border-champagne-500/10 pt-4"><?= htmlspecialchars($p['structures'][2]['tags']) ?></div>
            </div>

        </div>

        <!-- PARTNERSHIP CRITERIA -->
        <div class="border border-champagne-500/20 bg-obsidian-900/30 gsap-fade-up">
            <div class="px-8 py-6 border-b border-champagne-500/10">
                <h3 class="text-xs text-champagne-500 font-semibold tracking-ultra-wide"><?= htmlspecialchars($p['criteria']['section_label']) ?></h3>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-champagne-500/10">
                <div class="p-8">
                    <h4 class="text-sm text-champagne-500 font-mono uppercase tracking-wider mb-6"><?= htmlspecialchars($p['criteria']['institutional_profile']['heading']) ?></h4>
                    <ul class="space-y-4">
                        <?php foreach ($p['criteria']['institutional_profile']['items'] as $item): ?>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-0.5 flex-shrink-0">→</span>
                            <span class="text-sovereign-300 text-sm leading-relaxed"><?= htmlspecialchars($item) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="p-8">
                    <h4 class="text-sm text-champagne-500 font-mono uppercase tracking-wider mb-6"><?= htmlspecialchars($p['criteria']['value_alignment']['heading']) ?></h4>
                    <ul class="space-y-4">
                        <?php foreach ($p['criteria']['value_alignment']['items'] as $item): ?>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-0.5 flex-shrink-0">→</span>
                            <span class="text-sovereign-300 text-sm leading-relaxed"><?= htmlspecialchars($item) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- ═══════════════════════════════════════ INQUIRY FORM ═══ -->
<section id="inquiry-form" class="py-28 bg-obsidian-900 border-t border-champagne-500/20">
    <div class="container-sovereign">

        <div class="mb-16 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                <?= htmlspecialchars($p['inquiry_form']['section_label']) ?>
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-8"></div>
            <h3 class="text-3xl font-serif text-platinum-50 mb-4"><?= htmlspecialchars($p['inquiry_form']['title']) ?></h3>
            <p class="text-sovereign-300 max-w-2xl mx-auto leading-relaxed">
                <?= htmlspecialchars($p['inquiry_form']['description']) ?>
            </p>
        </div>

        <div class="max-w-4xl mx-auto">

            <div x-data="{ submitted: false, loading: false, error: '' }">

            <!-- FORM -->
            <div x-show="!submitted" x-cloak>
                <form @submit.prevent="
                    loading = true;
                    error = '';
                    fetch('process-partnership-inquiry.php', {
                        method: 'POST',
                        body: new FormData($event.target)
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) { submitted = true; }
                        else { error = data.message || 'Submission failed. Please try again.'; }
                    })
                    .catch(() => { error = 'Network error. Please try again.'; })
                    .finally(() => { loading = false; })
                " class="space-y-6 gsap-fade-up">

                    <!-- Organisation & Contact -->
                    <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                        <h4 class="text-xl font-serif text-platinum-50 mb-6">Organisation & Contact</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Organisation Name *</label>
                                <input type="text" name="organization" required placeholder="Company or Institution"
                                       class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500">
                            </div>
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Organisation Type *</label>
                                <select name="organization_type" required
                                        class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                                    <option value="">Select Type</option>
                                    <?php foreach ($p['inquiry_form']['organization_type_options'] as $opt): ?>
                                    <option value="<?= htmlspecialchars(strtolower(str_replace([' ', '/'], '-', $opt))) ?>"><?= htmlspecialchars($opt) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Representative Name *</label>
                                <input type="text" name="representative" required placeholder="Full Name & Title"
                                       class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500">
                            </div>
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Designation / Title *</label>
                                <input type="text" name="designation" required placeholder="e.g. Managing Director"
                                       class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500">
                            </div>
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Email Address *</label>
                                <input type="email" name="email" required placeholder="email@domain.com"
                                       class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500">
                            </div>
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Phone Number *</label>
                                <input type="tel" name="phone" required placeholder="+60 12-345 6789"
                                       class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500">
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Country / Region *</label>
                                <input type="text" name="country" required placeholder="e.g. Malaysia, UAE, Singapore"
                                       class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500">
                            </div>
                        </div>
                    </div>

                    <!-- Partnership Details -->
                    <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                        <h4 class="text-xl font-serif text-platinum-50 mb-6">Partnership Details</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Partnership Structure *</label>
                                <select name="partnership_type" required
                                        class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                                    <option value="">Select Structure</option>
                                    <?php foreach ($p['inquiry_form']['partnership_type_options'] as $opt): ?>
                                    <option value="<?= htmlspecialchars(strtolower(str_replace(' ', '-', $opt))) ?>"><?= htmlspecialchars($opt) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Investment Range</label>
                                <select name="investment_range"
                                        class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                                    <option value="">Select Range</option>
                                    <?php foreach ($p['inquiry_form']['investment_range_options'] as $opt): ?>
                                    <option value="<?= htmlspecialchars($opt) ?>"><?= htmlspecialchars($opt) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Areas of Interest</label>
                                <input type="text" name="areas_of_interest" placeholder="e.g. Poultry infrastructure, cold-chain logistics, halal compliance systems"
                                       class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500">
                            </div>
                        </div>
                    </div>

                    <!-- Proposal Statement -->
                    <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                        <h4 class="text-xl font-serif text-platinum-50 mb-6">Proposal Statement</h4>
                        <div>
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">Partnership Proposal *</label>
                            <textarea name="proposal" required rows="6"
                                      placeholder="Describe your partnership proposal, strategic objectives, and the value you bring to this engagement..."
                                      class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors resize-none placeholder:text-sovereign-500"></textarea>
                        </div>
                    </div>

                    <!-- Confidentiality & Submit -->
                    <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                        <label class="flex items-start gap-3 cursor-pointer mb-8">
                            <input type="checkbox" name="consent" required
                                   class="mt-1 w-4 h-4 border-champagne-500/20 bg-obsidian-900 text-champagne-500 focus:ring-champagne-500 flex-shrink-0">
                            <span class="text-sm text-sovereign-300 leading-relaxed">
                                I confirm that the information provided is accurate and I consent to Unggul Axiom Group contacting me regarding this inquiry. All submissions are handled with strict confidentiality. *
                            </span>
                        </label>

                        <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                            <p class="text-xs text-sovereign-400">* Required fields &nbsp;·&nbsp; Response within 5–7 business days</p>
                            <button type="submit" :disabled="loading"
                                    class="inline-flex items-center gap-3 px-12 py-4 bg-champagne-500 text-obsidian-900 text-xs font-bold uppercase tracking-wider hover:bg-champagne-400 transition-all duration-300 hover:shadow-lg hover:shadow-champagne-500/20 disabled:opacity-50 disabled:cursor-not-allowed w-full sm:w-auto justify-center">
                                <span x-text="loading ? 'Submitting...' : 'Submit Inquiry'"></span>
                                <span x-show="!loading">→</span>
                            </button>
                        </div>

                        <div x-show="error" x-text="error" class="mt-4 text-red-400 text-sm text-center"></div>
                    </div>

                </form>
            </div>

            <!-- SUCCESS STATE -->
            <div x-show="submitted" x-cloak style="display: none;" class="border border-champagne-500/30 bg-champagne-500/5 p-16 text-center gsap-fade-up">
                <div class="w-16 h-16 border border-champagne-500/40 flex items-center justify-center mx-auto mb-6">
                    <svg class="w-8 h-8 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <h3 class="text-2xl font-serif text-platinum-50 mb-3">Inquiry Received</h3>
                <p class="text-sovereign-300 leading-relaxed mb-2">Thank you. Your partnership proposal has been submitted to our executive team.</p>
                <p class="text-sm text-sovereign-400">You will receive a response within 5–7 business days.</p>
            </div>

            </div>

        </div>

    </div>
</section>

<style>[x-cloak] { display: none !important; }</style>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
