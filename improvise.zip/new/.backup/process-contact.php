<?php
/**
 * Contact Form Handler
 * Sends form data based on inquiry type
 */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method not allowed');
}

// Load form settings
$settings_file = __DIR__ . '/data/form-settings.json';
$settings = json_decode(file_get_contents($settings_file), true);

// Sanitize input
function clean_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Determine inquiry type
$inquiry_type = 'general';
if (isset($_POST['partnership_name'])) $inquiry_type = 'partnership';
elseif (isset($_POST['investor_name'])) $inquiry_type = 'investment';
elseif (isset($_POST['media_name'])) $inquiry_type = 'media';

// Get form config
$form_config = $settings[$inquiry_type] ?? $settings['contact'];

// Build email content
$to = $form_config['recipient_email'] ?? 'contact@unggulaxiom.com';
$subject = 'Contact Inquiry - ' . ucfirst($inquiry_type);

$message = "New Contact Inquiry\n";
$message .= "Type: " . ucfirst($inquiry_type) . "\n";
$message .= "Submitted: " . date('Y-m-d H:i:s') . "\n\n";

$reply_to = '';

switch ($inquiry_type) {
    case 'general':
        $message .= "Name: " . clean_input($_POST['name'] ?? '') . "\n";
        $message .= "Email: " . clean_input($_POST['email'] ?? '') . "\n";
        $message .= "Organization: " . clean_input($_POST['organization'] ?? '') . "\n";
        $message .= "Phone: " . clean_input($_POST['phone'] ?? '') . "\n";
        $message .= "Subject: " . clean_input($_POST['subject'] ?? '') . "\n\n";
        $message .= "Message:\n" . clean_input($_POST['message'] ?? '') . "\n";
        $reply_to = clean_input($_POST['email'] ?? '');
        break;

    case 'partnership':
        $message .= "Name: " . clean_input($_POST['partnership_name'] ?? '') . "\n";
        $message .= "Title: " . clean_input($_POST['partnership_title'] ?? '') . "\n";
        $message .= "Company: " . clean_input($_POST['partnership_company'] ?? '') . "\n";
        $message .= "Email: " . clean_input($_POST['partnership_email'] ?? '') . "\n";
        $message .= "Partnership Type: " . clean_input($_POST['partnership_type'] ?? '') . "\n\n";
        $message .= "Proposal:\n" . clean_input($_POST['partnership_proposal'] ?? '') . "\n";
        $reply_to = clean_input($_POST['partnership_email'] ?? '');
        break;

    case 'investment':
        $message .= "Name: " . clean_input($_POST['investor_name'] ?? '') . "\n";
        $message .= "Title: " . clean_input($_POST['investor_title'] ?? '') . "\n";
        $message .= "Organization: " . clean_input($_POST['investor_organization'] ?? '') . "\n";
        $message .= "Email: " . clean_input($_POST['investor_email'] ?? '') . "\n";
        $message .= "Investor Type: " . clean_input($_POST['investor_type'] ?? '') . "\n";
        $message .= "Investment Interest: " . clean_input($_POST['investment_interest'] ?? '') . "\n\n";
        $message .= "Inquiry:\n" . clean_input($_POST['investment_inquiry'] ?? '') . "\n";
        $reply_to = clean_input($_POST['investor_email'] ?? '');
        break;

    case 'media':
        $message .= "Name: " . clean_input($_POST['media_name'] ?? '') . "\n";
        $message .= "Email: " . clean_input($_POST['media_email'] ?? '') . "\n";
        $message .= "Organization: " . clean_input($_POST['media_organization'] ?? '') . "\n";
        $message .= "Phone: " . clean_input($_POST['media_phone'] ?? '') . "\n";
        $message .= "Media Type: " . clean_input($_POST['media_type'] ?? '') . "\n";
        $message .= "Deadline: " . clean_input($_POST['media_deadline'] ?? '') . "\n\n";
        $message .= "Inquiry:\n" . clean_input($_POST['media_inquiry'] ?? '') . "\n";
        $reply_to = clean_input($_POST['media_email'] ?? '');
        break;
}

// Email headers
$headers = "From: noreply@unggulaxiom.com\r\n";
$headers .= "Reply-To: " . $reply_to . "\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

// Send email
if (mail($to, $subject, $message, $headers)) {
    header('Location: /contact?success=1');
} else {
    header('Location: /contact?error=1');
}
exit;
