<?php
/**
 * Email Configuration Test
 * Visit this page to test if emails can be sent
 */

$test_email = 'your-email@example.com'; // Change this to your email

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to = $_POST['test_email'] ?? $test_email;
    $subject = 'Test Email from Unggul Axiom';
    $message = 'This is a test email sent at ' . date('Y-m-d H:i:s');
    $headers = "From: noreply@unggulaxiom.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    $result = mail($to, $subject, $message, $headers);

    $status = $result ? 'SUCCESS' : 'FAILED';
    $color = $result ? '#4CAF50' : '#f44336';
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Email Test - Unggul Axiom</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .result { padding: 20px; margin: 20px 0; border-radius: 4px; color: white; }
        input, button { padding: 10px; margin: 10px 0; width: 100%; box-sizing: border-box; }
        button { background: #d4af37; border: none; cursor: pointer; font-weight: bold; }
        .info { background: #f0f0f0; padding: 15px; border-left: 4px solid #d4af37; margin: 20px 0; }
    </style>
</head>
<body>
    <h1>Email Configuration Test</h1>

    <?php if (isset($status)): ?>
    <div class="result" style="background: <?= $color ?>">
        <strong><?= $status ?></strong><br>
        <?php if ($result): ?>
            Test email sent to: <?= htmlspecialchars($to) ?>
        <?php else: ?>
            Email failed to send. Check configuration below.
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <form method="POST">
        <label>Test Email Address:</label>
        <input type="email" name="test_email" value="<?= htmlspecialchars($test_email) ?>" required>
        <button type="submit">Send Test Email</button>
    </form>

    <div class="info">
        <h3>Current Configuration</h3>
        <p><strong>PHP Version:</strong> <?= phpversion() ?></p>
        <p><strong>mail() function:</strong> <?= function_exists('mail') ? 'Available' : 'NOT Available' ?></p>
        <p><strong>SMTP (php.ini):</strong> <?= ini_get('SMTP') ?: 'Not configured' ?></p>
        <p><strong>smtp_port:</strong> <?= ini_get('smtp_port') ?: 'Not configured' ?></p>
        <p><strong>sendmail_from:</strong> <?= ini_get('sendmail_from') ?: 'Not configured' ?></p>
    </div>

    <div class="info">
        <h3>Setup Instructions</h3>
        <p><strong>For XAMPP/WAMP on Windows:</strong></p>
        <ol>
            <li>Edit php.ini file</li>
            <li>Find [mail function] section</li>
            <li>Configure SMTP settings:
                <pre>SMTP = smtp.gmail.com
smtp_port = 587
sendmail_from = your-email@gmail.com</pre>
            </li>
            <li>For Gmail: Use App Password (not regular password)</li>
            <li>Restart Apache/PHP service</li>
        </ol>
        <p><strong>Alternative:</strong> Use PHPMailer library for better SMTP support</p>
    </div>
</body>
</html>
