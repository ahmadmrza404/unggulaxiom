<?php
/**
 * ============================================
 * LEADERSHIP PROFILE - EXECUTIVE DOSSIER
 * ============================================
 * Purpose: Comprehensive executive profile
 * ============================================
 */

require_once __DIR__ . '/config.php';

$member_id = $_GET['id'] ?? '';
$leadership_data = json_decode(file_get_contents(__DIR__ . '/data/leadership.json'), true);

$member = null;
$member_group = '';

$all_groups = ['board_of_directors', 'executives', 'senior_management', 'department_heads',
               'operations', 'finance', 'legal_compliance', 'human_resources',
               'technology', 'marketing_communications', 'business_development', 'advisors'];

foreach ($all_groups as $group) {
    if (!empty($leadership_data[$group])) {
        foreach ($leadership_data[$group] as $person) {
            if ($person['id'] === $member_id) {
                $member = $person;
                $member_group = $group;
                break 2;
            }
        }
    }
}

if (!$member) {
    header('Location: leadership.php');
    exit;
}

$profile_file = __DIR__ . '/data/profiles/' . $member_id . '.json';
$profile = file_exists($profile_file) ? json_decode(file_get_contents($profile_file), true) : [];

$page_title = $member['name'] . ' - Leadership';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- EXECUTIVE HEADER -->
<section class="py-20 bg-obsidian-950 border-b border-champagne-500/10 isolate">
    <div class="container-sovereign">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-16">

            <!-- Executive Portrait -->
            <div class="lg:col-span-4">
                <?php if (!empty($member['image']) && file_exists(__DIR__ . '/' . $member['image'])): ?>
                <div class="aspect-[3/4] overflow-hidden border border-champagne-500/20 bg-obsidian-900">
                    <img src="<?= htmlspecialchars($member['image']) ?>" alt="<?= htmlspecialchars($member['name']) ?>" class="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500">
                </div>
                <?php else: ?>
                <div class="aspect-[3/4] bg-obsidian-900 border border-champagne-500/20 flex items-center justify-center">
                    <span class="font-mono text-7xl text-champagne-600/30"><?= htmlspecialchars($member['id']) ?></span>
                </div>
                <?php endif; ?>
            </div>

            <!-- Executive Information -->
            <div class="lg:col-span-8">
                <p class="font-mono text-xs text-champagne-600 tracking-[0.2em] uppercase mb-6"><?= htmlspecialchars($member['id']) ?></p>

                <h1 class="font-serif text-5xl md:text-6xl text-platinum-50 mb-3 tracking-tight leading-[1.1]">
                    <?= htmlspecialchars($member['name']) ?>
                </h1>

                <h2 class="text-2xl text-champagne-400 font-medium mb-6 tracking-wide">
                    <?= htmlspecialchars($member['title']) ?>
                </h2>

                <div class="w-20 h-px bg-champagne-500/50 mb-6"></div>

                <p class="text-lg text-platinum-200 leading-relaxed mb-8 max-w-3xl">
                    <?= htmlspecialchars($member['description']) ?>
                </p>

                <!-- Executive Contact -->
                <div class="flex flex-wrap gap-6">
                    <?php if (!empty($member['email'])): ?>
                    <a href="mailto:<?= htmlspecialchars($member['email']) ?>" class="inline-flex items-center gap-3 px-6 py-3 bg-obsidian-900 border border-champagne-500/20 hover:border-champagne-500/50 text-sm text-platinum-200 hover:text-champagne-400 transition-all">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/></svg>
                        <span class="tracking-wide">Email</span>
                    </a>
                    <?php endif; ?>

                    <?php if (!empty($member['linkedin'])): ?>
                    <a href="<?= htmlspecialchars($member['linkedin']) ?>" target="_blank" class="inline-flex items-center gap-3 px-6 py-3 bg-obsidian-900 border border-champagne-500/20 hover:border-champagne-500/50 text-sm text-platinum-200 hover:text-champagne-400 transition-all">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.338 16.338H13.67V12.16c0-.995-.017-2.277-1.387-2.277-1.39 0-1.601 1.086-1.601 2.207v4.248H8.014v-8.59h2.559v1.174h.037c.356-.675 1.227-1.387 2.526-1.387 2.703 0 3.203 1.778 3.203 4.092v4.711zM5.005 6.575a1.548 1.548 0 11-.003-3.096 1.548 1.548 0 01.003 3.096zm-1.337 9.763H6.34v-8.59H3.667v8.59zM17.668 1H2.328C1.595 1 1 1.581 1 2.298v15.403C1 18.418 1.595 19 2.328 19h15.34c.734 0 1.332-.582 1.332-1.299V2.298C19 1.581 18.402 1 17.668 1z"/></svg>
                        <span class="tracking-wide">LinkedIn</span>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- EXECUTIVE PROFILE -->
<section class="py-24 bg-obsidian-900 isolate">
    <div class="container-sovereign">
        <div class="max-w-6xl mx-auto">

            <?php if (!empty($profile['biography'])): ?>
            <!-- Executive Summary -->
            <div class="mb-24">
                <h3 class="text-xs text-champagne-600 font-semibold tracking-[0.2em] uppercase mb-8">
                    Executive Summary
                </h3>
                <div class="prose prose-invert prose-lg max-w-none">
                    <p class="text-xl text-platinum-200 leading-relaxed whitespace-pre-line">
                        <?= htmlspecialchars($profile['biography']) ?>
                    </p>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-16">

                <!-- Left Column -->
                <div class="space-y-16">

                    <?php if (!empty($profile['experience'])): ?>
                    <!-- Career Trajectory -->
                    <div>
                        <h3 class="text-xs text-champagne-600 font-semibold tracking-[0.2em] uppercase mb-8">
                            Career Trajectory
                        </h3>
                        <div class="space-y-8">
                            <?php foreach ($profile['experience'] as $exp): ?>
                            <div class="border-l-2 border-champagne-500/30 pl-6">
                                <div class="flex justify-between items-start mb-2">
                                    <h4 class="font-serif text-xl text-platinum-50">
                                        <?= htmlspecialchars($exp['position']) ?>
                                    </h4>
                                    <?php if (!empty($exp['period'])): ?>
                                    <p class="font-mono text-xs text-platinum-400 tracking-wider">
                                        <?= htmlspecialchars($exp['period']) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <p class="text-base text-champagne-400 mb-3">
                                    <?= htmlspecialchars($exp['company']) ?>
                                </p>
                                <?php if (!empty($exp['description'])): ?>
                                <p class="text-sm text-platinum-300 leading-relaxed">
                                    <?= htmlspecialchars($exp['description']) ?>
                                </p>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($profile['education'])): ?>
                    <!-- Academic Credentials -->
                    <div>
                        <h3 class="text-xs text-champagne-600 font-semibold tracking-[0.2em] uppercase mb-8">
                            Academic Credentials
                        </h3>
                        <div class="space-y-6">
                            <?php foreach ($profile['education'] as $edu): ?>
                            <div class="bg-obsidian-950/50 border border-champagne-500/10 p-6">
                                <h4 class="font-serif text-lg text-platinum-50 mb-2">
                                    <?= htmlspecialchars($edu['degree']) ?>
                                </h4>
                                <p class="text-base text-champagne-400 mb-1">
                                    <?= htmlspecialchars($edu['institution']) ?>
                                </p>
                                <?php if (!empty($edu['year'])): ?>
                                <p class="font-mono text-xs text-platinum-400 tracking-wider">
                                    <?= htmlspecialchars($edu['year']) ?>
                                </p>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>

                <!-- Right Column -->
                <div class="space-y-16">

                    <?php if (!empty($profile['achievements'])): ?>
                    <!-- Strategic Achievements -->
                    <div>
                        <h3 class="text-xs text-champagne-600 font-semibold tracking-[0.2em] uppercase mb-8">
                            Strategic Achievements
                        </h3>
                        <div class="space-y-4">
                            <?php foreach ($profile['achievements'] as $achievement): ?>
                            <div class="flex gap-4">
                                <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full mt-2 flex-shrink-0"></div>
                                <p class="text-base text-platinum-200 leading-relaxed">
                                    <?= htmlspecialchars($achievement) ?>
                                </p>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($profile['certifications'])): ?>
                    <!-- Professional Certifications -->
                    <div>
                        <h3 class="text-xs text-champagne-600 font-semibold tracking-[0.2em] uppercase mb-8">
                            Professional Certifications
                        </h3>
                        <div class="space-y-4">
                            <?php foreach ($profile['certifications'] as $cert): ?>
                            <div class="bg-obsidian-950/50 border border-champagne-500/10 p-5">
                                <h4 class="text-base text-platinum-50 font-medium mb-2">
                                    <?= htmlspecialchars($cert['name']) ?>
                                </h4>
                                <p class="text-sm text-champagne-400 mb-1">
                                    <?= htmlspecialchars($cert['issuer']) ?>
                                </p>
                                <?php if (!empty($cert['year'])): ?>
                                <p class="font-mono text-xs text-platinum-400 tracking-wider">
                                    <?= htmlspecialchars($cert['year']) ?>
                                </p>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($profile['expertise'])): ?>
                    <!-- Core Competencies -->
                    <div>
                        <h3 class="text-xs text-champagne-600 font-semibold tracking-[0.2em] uppercase mb-8">
                            Core Competencies
                        </h3>
                        <div class="flex flex-wrap gap-3">
                            <?php foreach ($profile['expertise'] as $skill): ?>
                            <span class="px-4 py-2.5 bg-obsidian-950/50 border border-champagne-500/20 text-sm text-platinum-200 tracking-wide">
                                <?= htmlspecialchars($skill) ?>
                            </span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>

            </div>

        </div>
    </div>
</section>

<!-- NAVIGATION -->
<section class="py-12 bg-obsidian-950 border-t border-champagne-500/10">
    <div class="container-sovereign">
        <a href="leadership.php" class="inline-flex items-center gap-3 text-sm text-champagne-500 hover:text-champagne-400 transition-colors tracking-wide">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
            <span>Return to Leadership</span>
        </a>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
