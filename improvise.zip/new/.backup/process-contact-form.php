<?php
/**
 * Contact Form Processor
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Load form settings
$settings_file = __DIR__ . '/data/form-settings.json';
$settings = json_decode(file_get_contents($settings_file), true);
$form_config = $settings['contact'] ?? [];

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Validate required fields
$required = ['full_name', 'email', 'inquiry_type', 'message'];
$errors = [];

foreach ($required as $field) {
    if (empty($_POST[$field])) {
        $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
    }
}

if (!empty($_POST['email']) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Invalid email address';
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// Sanitize data
$full_name = sanitize($_POST['full_name']);
$organization = !empty($_POST['organization']) ? sanitize($_POST['organization']) : 'Not provided';
$email = sanitize($_POST['email']);
$phone = !empty($_POST['phone']) ? sanitize($_POST['phone']) : 'Not provided';
$inquiry_type = sanitize($_POST['inquiry_type']);
$message = sanitize($_POST['message']);

// Email configuration from settings
$to = $form_config['recipient_email'] ?? 'contact@unggulaxiom.com';
$subject = 'New Contact Inquiry: ' . ucfirst($inquiry_type) . ' - ' . $full_name;

// Email body
$email_body = '
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { background: #1a2332; color: #d4af37; padding: 20px; text-align: center; }
        .section { margin: 20px 0; padding: 15px; border-left: 3px solid #d4af37; background: #f9f9f9; }
        .section-title { font-weight: bold; color: #1a2332; margin-bottom: 10px; }
        .field { margin: 10px 0; }
        .field-label { font-weight: bold; color: #666; }
        .field-value { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>New Contact Inquiry</h1>
            <p>Unggul Axiom Group</p>
        </div>

        <div class="section">
            <div class="section-title">Contact Information</div>
            <div class="field"><span class="field-label">Name:</span><span class="field-value">' . $full_name . '</span></div>
            <div class="field"><span class="field-label">Organization:</span><span class="field-value">' . $organization . '</span></div>
            <div class="field"><span class="field-label">Email:</span><span class="field-value">' . $email . '</span></div>
            <div class="field"><span class="field-label">Phone:</span><span class="field-value">' . $phone . '</span></div>
        </div>

        <div class="section">
            <div class="section-title">Inquiry Details</div>
            <div class="field"><span class="field-label">Type:</span><span class="field-value">' . ucfirst(str_replace('-', ' ', $inquiry_type)) . '</span></div>
        </div>

        <div class="section">
            <div class="section-title">Message</div>
            <div style="margin-top: 10px;">' . nl2br($message) . '</div>
        </div>

        <div style="margin-top: 30px; padding: 15px; background: #f0f0f0; text-align: center; font-size: 12px; color: #666;">
            <p>Inquiry submitted on ' . date('F j, Y \a\t g:i A') . '</p>
            <p>Unggul Axiom Group - Contact Inquiries</p>
        </div>
    </div>
</body>
</html>
';

// Email headers
$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
$headers .= "From: Unggul Axiom Contact <noreply@unggulaxiom.com>\r\n";
$headers .= "Reply-To: " . $email . "\r\n";

// Send email
$mail_sent = mail($to, $subject, $email_body, $headers);

if ($mail_sent) {
    $log_file = __DIR__ . '/logs/contact-inquiries.log';
    $log_dir = dirname($log_file);
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $log_entry = date('Y-m-d H:i:s') . " - Contact inquiry from: $full_name ($email) - Type: $inquiry_type\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => $form_config['success_message'] ?? 'Message sent successfully'
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $form_config['error_message'] ?? 'Failed to send message. Please try again.'
    ]);
}
?>
