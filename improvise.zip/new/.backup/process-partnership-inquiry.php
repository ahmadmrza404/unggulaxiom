<?php
/**
 * Partnership Inquiry Form Processor
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Load form settings
$settings_file = __DIR__ . '/data/form-settings.json';
$settings = json_decode(file_get_contents($settings_file), true);
$form_config = $settings['partnership'] ?? [];

// Load mailer
require_once __DIR__ . '/includes/mailer.php';

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Validate required fields
$required = ['organization', 'organization_type', 'representative', 'designation', 'email', 'phone', 'country', 'partnership_type', 'proposal'];
$errors = [];

foreach ($required as $field) {
    if (empty($_POST[$field])) {
        $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
    }
}

if (!empty($_POST['email']) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Invalid email address';
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// Sanitize data
$organization      = sanitize($_POST['organization']);
$org_type          = sanitize($_POST['organization_type'] ?? '');
$representative    = sanitize($_POST['representative']);
$designation       = sanitize($_POST['designation'] ?? '');
$email             = sanitize($_POST['email']);
$phone             = sanitize($_POST['phone']);
$country           = sanitize($_POST['country'] ?? '');
$partnership_type  = sanitize($_POST['partnership_type']);
$investment_range  = !empty($_POST['investment_range']) ? sanitize($_POST['investment_range']) : 'Not specified';
$areas_of_interest = !empty($_POST['areas_of_interest']) ? sanitize($_POST['areas_of_interest']) : 'Not specified';
$proposal          = sanitize($_POST['proposal']);

// Email configuration
$to = $form_config['recipient_email'] ?? 'partnerships@unggulaxiom.com';
$subject = "New Partnership Inquiry: {$partnership_type} - {$organization}";

$partnership_type_label = ucfirst(str_replace('-', ' ', $partnership_type));
$submitted_on           = date('F j, Y \a\t g:i A');
$proposal_html          = nl2br($proposal);

// Email body
$email_body = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { background: #1a2332; color: #d4af37; padding: 20px; text-align: center; }
        .section { margin: 20px 0; padding: 15px; border-left: 3px solid #d4af37; background: #f9f9f9; }
        .section-title { font-weight: bold; color: #1a2332; margin-bottom: 10px; }
        .field { margin: 10px 0; }
        .field-label { font-weight: bold; color: #666; }
        .field-value { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>New Partnership Inquiry</h1>
            <p>Unggul Axiom Group</p>
        </div>

        <div class="section">
            <div class="section-title">Organisation Information</div>
            <div class="field"><span class="field-label">Organisation:</span><span class="field-value">{$organization}</span></div>
            <div class="field"><span class="field-label">Organisation Type:</span><span class="field-value">{$org_type}</span></div>
            <div class="field"><span class="field-label">Representative:</span><span class="field-value">{$representative}</span></div>
            <div class="field"><span class="field-label">Designation:</span><span class="field-value">{$designation}</span></div>
            <div class="field"><span class="field-label">Email:</span><span class="field-value">{$email}</span></div>
            <div class="field"><span class="field-label">Phone:</span><span class="field-value">{$phone}</span></div>
            <div class="field"><span class="field-label">Country / Region:</span><span class="field-value">{$country}</span></div>
        </div>

        <div class="section">
            <div class="section-title">Partnership Details</div>
            <div class="field"><span class="field-label">Partnership Structure:</span><span class="field-value">{$partnership_type_label}</span></div>
            <div class="field"><span class="field-label">Investment Range:</span><span class="field-value">{$investment_range}</span></div>
            <div class="field"><span class="field-label">Areas of Interest:</span><span class="field-value">{$areas_of_interest}</span></div>
        </div>

        <div class="section">
            <div class="section-title">Proposal</div>
            <div style="margin-top: 10px;">{$proposal_html}</div>
        </div>

        <div style="margin-top: 30px; padding: 15px; background: #f0f0f0; text-align: center; font-size: 12px; color: #666;">
            <p>Inquiry submitted on {$submitted_on}</p>
            <p>Unggul Axiom Group - Partnership Inquiries</p>
        </div>
    </div>
</body>
</html>
HTML;

// Log submission first (so we don't lose data if email fails)
$log_file = __DIR__ . '/logs/partnership-inquiries.log';
$log_dir = dirname($log_file);
if (!file_exists($log_dir)) {
    mkdir($log_dir, 0755, true);
}

$log_entry = date('Y-m-d H:i:s') . " - Partnership inquiry from: $organization ($email) - Type: $partnership_type\n";
file_put_contents($log_file, $log_entry, FILE_APPEND);

// Save to JSON file as backup
$data_file = __DIR__ . '/data/partnership-inquiries.json';
$inquiries = file_exists($data_file) ? json_decode(file_get_contents($data_file), true) : [];
$inquiries[] = [
    'timestamp' => date('Y-m-d H:i:s'),
    'organization' => $organization,
    'org_type' => $org_type,
    'representative' => $representative,
    'designation' => $designation,
    'email' => $email,
    'phone' => $phone,
    'country' => $country,
    'partnership_type' => $partnership_type,
    'investment_range' => $investment_range,
    'areas_of_interest' => $areas_of_interest,
    'proposal' => $proposal
];
file_put_contents($data_file, json_encode($inquiries, JSON_PRETTY_PRINT));

// Try to send email using mailer
$mail_sent = send_email($to, $subject, $email_body, $email);

// Always return success since we saved the data
http_response_code(200);
echo json_encode([
    'success' => true,
    'message' => $form_config['success_message'] ?? 'Partnership inquiry submitted successfully',
    'email_sent' => $mail_sent
]);
