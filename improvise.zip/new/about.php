<?php
/**
 * ============================================
 * ABOUT PAGE - UNGGUL AXIOM GROUP
 * ============================================
 * Purpose: Institutional overview and strategic positioning
 * Architecture: Chairman's letter aesthetic
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'About';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- ============================================ -->
<!-- PAGE VANGUARD: INSTITUTIONAL HEADER -->
<!-- ============================================ -->
<section class="min-h-[60vh] flex items-center justify-center bg-obsidian-950 py-40 isolate">
    <div class="container-sovereign">
        <div class="max-w-5xl">
            <h1 class="split-hero-title font-serif text-6xl md:text-7xl lg:text-8xl text-platinum-50 tracking-tight leading-none mb-8">
                Integrated Infrastructure for the Global Halal Economy
            </h1>
            <p class="text-xl text-sovereign-400 leading-relaxed">
                Building infrastructure systems across food production, pharmaceuticals, manufacturing, logistics, finance, and trade.
            </p>
        </div>
    </div>
</section>

<!-- ============================================ -->
<!-- EDITORIAL BODY: PHILOSOPHY & STRATEGY -->
<!-- ============================================ -->
<section class="py-32 bg-gradient-to-b from-obsidian-900 to-obsidian-950 text-platinum-50 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-10 pointer-events-none"></div>
    <div class="ambient-spotlight -top-40 right-20 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- 12-COLUMN GRID WITH OFFSET EDITORIAL LAYOUT -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-12">

            <!-- BLOCK 1: INSTITUTIONAL MANDATE -->
            <div class="md:col-start-3 md:col-span-8">
                <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden mb-12">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="mb-8">
                        <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                            INSTITUTIONAL MANDATE
                        </span>
                        <div class="w-16 h-0.5 bg-gradient-to-r from-champagne-500 to-transparent"></div>
                    </div>

                    <div class="space-y-6">
                        <div class="border-l-2 border-champagne-500 pl-6">
                            <p class="text-lg text-platinum-100 leading-editorial font-serif">
                                Unggul Axiom Group operates as a sovereign-level infrastructure coordination platform, designed to integrate production systems, compliance frameworks, and capital deployment mechanisms across the global halal economy.
                            </p>
                        </div>

                        <div class="border-l-2 border-champagne-500/30 pl-6">
                            <p class="text-base text-sovereign-300 leading-institutional">
                                The platform architecture enables systematic deployment across six operational sectors: food and agriculture, pharmaceuticals and wellness, manufacturing, logistics and distribution, Islamic finance, and global trade infrastructure.
                            </p>
                        </div>

                        <div class="border-l-2 border-champagne-500/30 pl-6">
                            <p class="text-base text-sovereign-300 leading-institutional">
                                Structured for institutional participation, the organization maintains operational command in Kuala Lumpur, Malaysia, under the governance of UNGGUL BRONTO SDN. BHD. (Registration No: 202301027920).
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- BLOCK 2: OUR PHILOSOPHY -->
            <div class="md:col-start-3 md:col-span-8 mt-12">
                <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden" data-gsap-fade-up data-gsap-delay="0.2">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block uppercase">
                        OUR APPROACH
                    </span>
                    <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 tracking-editorial mb-8 leading-tight font-bold">
                        Strategic Infrastructure Development
                    </h2>
                    <p class="text-base text-sovereign-300 leading-institutional mb-8">
                        Our business activities encompass investment holding, venture building, project development, and strategic partnerships across key sectors:
                    </p>
                    <ul class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-platinum-200">
                        <li class="flex items-center gap-3 p-4 bg-obsidian-950/40 rounded-lg border border-champagne-500/5 hover:border-champagne-500/30 transition-colors">
                            <span class="text-champagne-500 font-bold">✓</span>
                            <span>Halal food production & processing</span>
                        </li>
                        <li class="flex items-center gap-3 p-4 bg-obsidian-950/40 rounded-lg border border-champagne-500/5 hover:border-champagne-500/30 transition-colors">
                            <span class="text-champagne-500 font-bold">✓</span>
                            <span>Halal agri-tech & smart farming</span>
                        </li>
                        <li class="flex items-center gap-3 p-4 bg-obsidian-950/40 rounded-lg border border-champagne-500/5 hover:border-champagne-500/30 transition-colors">
                            <span class="text-champagne-500 font-bold">✓</span>
                            <span>Pharmaceutical manufacturing</span>
                        </li>
                        <li class="flex items-center gap-3 p-4 bg-obsidian-950/40 rounded-lg border border-champagne-500/5 hover:border-champagne-500/30 transition-colors">
                            <span class="text-champagne-500 font-bold">✓</span>
                            <span>Logistics & supply chain audit</span>
                        </li>
                        <li class="flex items-center gap-3 p-4 bg-obsidian-950/40 rounded-lg border border-champagne-500/5 hover:border-champagne-500/30 transition-colors">
                            <span class="text-champagne-500 font-bold">✓</span>
                            <span>Food security systems</span>
                        </li>
                        <li class="flex items-center gap-3 p-4 bg-obsidian-950/40 rounded-lg border border-champagne-500/5 hover:border-champagne-500/30 transition-colors">
                            <span class="text-champagne-500 font-bold">✓</span>
                            <span>Agri-technology innovation</span>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- BLOCK 3: STRATEGIC OBJECTIVE -->
            <div class="md:col-start-3 md:col-span-8 mt-12">
                <div class="glass-panel border-l-4 border-l-champagne-500 border-t-0 border-r-0 border-b-0 pl-10 pr-6 py-8 rounded-r-2xl shadow-2xl" data-gsap-fade-up data-gsap-delay="0.3">
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-4 block uppercase font-mono">
                        STRATEGIC OBJECTIVE
                    </span>
                    <p class="text-xl md:text-2xl font-serif text-platinum-100 leading-editorial italic">
                        "To develop scalable halal infrastructure platforms that enable traceability, compliance, and market access across the global halal economy."
                    </p>
                </div>
            </div>

            <!-- BLOCK 4: CORPORATE STRUCTURE -->
            <div class="md:col-start-3 md:col-span-8 mt-12">
                <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden" data-gsap-fade-up data-gsap-delay="0.4">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block uppercase font-mono">
                        CORPORATE STRUCTURE
                    </span>
                    <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 tracking-editorial mb-4 leading-tight font-bold">
                        Unggul Bronto Sdn. Bhd.
                    </h2>
                    <p class="text-xs text-champagne-500 font-mono tracking-widest uppercase mb-6">
                        Registration No: 202301027920 (1521843-P)
                    </p>
                    <p class="text-base text-sovereign-300 leading-institutional">
                        Malaysian-registered investment holding company operating under the Unggul Axiom Group platform, focused on halal infrastructure development, wholesale trade, domestic trade affairs, and strategic partnerships within the global halal economy.
                    </p>
                </div>
            </div>

        </div>

    </div>
</section>

<?php
require_once INCLUDES_PATH . '/footer.php';
?>
