<?php
/**
 * ============================================
 * LEADERSHIP - COMMAND STRUCTURE
 * ============================================
 * Purpose: Institutional command hierarchy
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Leadership';

require_once INCLUDES_PATH . '/header.php';

// Load leadership data
$leadership_data = json_decode(file_get_contents(__DIR__ . '/data/leadership.json'), true);

// Define group display configuration
$group_config = [
    'board_of_directors' => ['title' => 'BOARD OF DIRECTORS', 'show' => true],
    'executives' => ['title' => 'EXECUTIVE COMMAND', 'show' => true],
    'senior_management' => ['title' => 'SENIOR MANAGEMENT', 'show' => true],
    'department_heads' => ['title' => 'DEPARTMENT HEADS', 'show' => true],
    'operations' => ['title' => 'OPERATIONS', 'show' => true],
    'finance' => ['title' => 'FINANCE', 'show' => true],
    'legal_compliance' => ['title' => 'LEGAL & COMPLIANCE', 'show' => true],
    'human_resources' => ['title' => 'HUMAN RESOURCES', 'show' => true],
    'technology' => ['title' => 'TECHNOLOGY', 'show' => true],
    'marketing_communications' => ['title' => 'MARKETING & COMMUNICATIONS', 'show' => true],
    'business_development' => ['title' => 'BUSINESS DEVELOPMENT', 'show' => true],
    'advisors' => ['title' => 'ADVISORY BOARD', 'show' => true]
];
?>

<!-- HEADER SECTION -->
<section class="min-h-[50vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-5xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                COMMAND STRUCTURE
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-editorial leading-tight font-extrabold">
                Leadership Team
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto">
                Institutional leadership framework for infrastructure coordination and capital deployment.
            </p>
        </div>
    </div>
</section>

<!-- COMMAND ROSTER -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">

        <?php
        foreach ($group_config as $group_key => $config):
            if (!$config['show'] || empty($leadership_data[$group_key])) continue;
            $is_last = ($group_key === array_key_last($group_config));
        ?>
        <div class="<?= $is_last ? '' : 'mb-24' ?>">
            <div class="mb-12">
                <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                    <?= $config['title'] ?>
                </span>
                <div class="w-16 h-px bg-gradient-to-r from-champagne-500 to-transparent"></div>
            </div>

            <div class="mt-8 space-y-6">
                <?php foreach ($leadership_data[$group_key] as $member): ?>
                <a href="profile.php?id=<?= htmlspecialchars($member['id']) ?>" 
                   class="group block p-6 md:p-8 rounded-2xl border border-champagne-500/10 bg-obsidian-950/30 hover:bg-obsidian-900/50 hover:border-champagne-500/30 transition-all duration-500 hover:-translate-y-1 shadow-lg relative overflow-hidden gsap-fade-up">
                    <div class="tech-grid absolute inset-0 opacity-[0.03] pointer-events-none"></div>
                    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center relative z-10">
                        
                        <!-- Column 1: ID / Image -->
                        <div class="lg:col-span-2 flex items-center gap-4">
                            <p class="font-mono text-xs text-champagne-500/60 tracking-wider"><?= htmlspecialchars($member['id']) ?></p>
                            <?php if (!empty($member['image']) && file_exists(__DIR__ . '/' . $member['image'])): ?>
                            <img src="<?= htmlspecialchars($member['image']) ?>" alt="<?= htmlspecialchars($member['name']) ?>" class="w-14 h-14 rounded-full object-cover border-2 border-champagne-500/20 group-hover:border-champagne-500/50 transition-colors duration-300">
                            <?php else: ?>
                            <div class="w-14 h-14 rounded-full bg-obsidian-900/80 border border-champagne-500/20 flex items-center justify-center text-champagne-500 font-serif text-xl font-bold">
                                <?= !empty($member['name']) ? strtoupper(substr($member['name'], 0, 1)) : 'U' ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Column 2: Role / Title -->
                        <div class="lg:col-span-4">
                            <h3 class="font-serif text-2xl text-platinum-50 tracking-tight group-hover:text-champagne-400 transition-colors duration-300 font-bold">
                                <?= htmlspecialchars($member['title']) ?>
                            </h3>
                            <?php if (!empty($member['name']) && $member['name'] !== 'Your Name Here'): ?>
                            <p class="text-sm text-platinum-300 mt-1 font-medium tracking-wide"><?= htmlspecialchars($member['name']) ?></p>
                            <?php endif; ?>
                            
                            <div class="flex gap-3 mt-4">
                                <?php if (!empty($member['email'])): ?>
                                <button onclick="event.stopPropagation(); window.location.href='mailto:<?= htmlspecialchars($member['email']) ?>'" 
                                        class="w-8 h-8 rounded-full bg-obsidian-950/60 border border-champagne-500/10 flex items-center justify-center text-platinum-400 hover:text-champagne-500 hover:border-champagne-500/40 transition-colors duration-300"
                                        aria-label="Email">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/></svg>
                                </button>
                                <?php endif; ?>
                                <?php if (!empty($member['linkedin'])): ?>
                                <button onclick="event.stopPropagation(); window.open('<?= htmlspecialchars($member['linkedin']) ?>', '_blank')" 
                                        class="w-8 h-8 rounded-full bg-obsidian-950/60 border border-champagne-500/10 flex items-center justify-center text-platinum-400 hover:text-champagne-500 hover:border-champagne-500/40 transition-colors duration-300"
                                        aria-label="LinkedIn">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M16.338 16.338H13.67V12.16c0-.995-.017-2.277-1.387-2.277-1.39 0-1.601 1.086-1.601 2.207v4.248H8.014v-8.59h2.559v1.174h.037c.356-.675 1.227-1.387 2.526-1.387 2.703 0 3.203 1.778 3.203 4.092v4.711zM5.005 6.575a1.548 1.548 0 11-.003-3.096 1.548 1.548 0 01.003 3.096zm-1.337 9.763H6.34v-8.59H3.667v8.59zM17.668 1H2.328C1.595 1 1 1.581 1 2.298v15.403C1 18.418 1.595 19 2.328 19h15.34c.734 0 1.332-.582 1.332-1.299V2.298C19 1.581 18.402 1 17.668 1z"/></svg>
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Column 3: Description -->
                        <div class="lg:col-span-6 flex flex-col justify-between">
                            <p class="text-sm md:text-base text-sovereign-300 leading-institutional mb-4">
                                <?= htmlspecialchars($member['description']) ?>
                            </p>
                            <div class="flex items-center gap-2 text-xs md:text-sm text-champagne-500 font-semibold tracking-wider uppercase">
                                <span>View Full Profile</span>
                                <svg class="w-4 h-4 transform group-hover:translate-x-1.5 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                                </svg>
                            </div>
                        </div>
                        
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>

    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
