<?php
/**
 * ============================================
 * SHARIAH GOVERNANCE PAGE
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Shariah Governance';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO SECTION -->
<section class="py-32 bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign relative z-10">
        <div class="max-w-3xl gsap-fade-up">
            <span class="text-xs text-champagne-500 tracking-widest mb-4 block uppercase font-semibold">
                ISLAMIC PRINCIPLES
            </span>
            <h1 class="font-serif text-4xl md:text-5xl lg:text-6xl text-platinum-50 tracking-tight mb-6 leading-tight font-extrabold">
                Shariah Governance
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mb-6"></div>
            <p class="text-base text-sovereign-300 leading-relaxed">
                Unggul Axiom Group operates in accordance with Islamic principles, maintaining rigorous Shariah compliance across all business activities within the global halal economy.
            </p>
        </div>
    </div>
</section>

<!-- CONTENT SECTIONS -->
<section class="py-24 bg-obsidian-900 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-4xl mx-auto space-y-12">

            <!-- Section 1 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        1. Shariah Governance Framework
                    </h2>
                    <div class="space-y-4 text-sm text-sovereign-300 leading-relaxed">
                        <p>
                            Unggul Axiom Group is committed to conducting all business operations in full compliance with Shariah principles as interpreted by qualified Islamic scholars and recognized Shariah advisory bodies. This commitment extends across the entire value chain, from production and processing to certification, logistics, and financial structuring.
                        </p>
                        <p>
                            The Group operates as an investment holding company engaged in halal infrastructure development, including halal food production, halal agri-tech, pharmaceuticals, logistics, halal supply chain certification, smart agriculture, food security systems, livestock integration, and agri-technology innovation. Business activities encompass investment holding, venture building, project development, and strategic partnerships within the global halal economy.
                        </p>
                        <p>
                            The Group's Shariah governance framework is designed to ensure that all activities, transactions, contracts, and business relationships conform to Islamic jurisprudence (fiqh) and the objectives of Shariah (maqasid al-Shariah), promoting ethical conduct, social responsibility, and economic justice.
                        </p>
                        <p>
                            Shariah compliance is not merely a regulatory requirement but a fundamental principle embedded in the Group's corporate culture, strategic decision-making, and operational execution.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 2 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        2. Shariah Advisory Structure
                    </h2>
                    <div class="space-y-6 text-sm text-sovereign-300 leading-relaxed">
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">2.1 Shariah Advisory Board</h3>
                            <p class="text-platinum-200">
                                The Group maintains a Shariah Advisory Board comprising qualified Islamic scholars with expertise in Islamic commercial jurisprudence (fiqh al-muamalat), halal standards, and contemporary financial transactions. Board members possess recognized credentials from reputable Islamic institutions and demonstrate deep understanding of both classical Islamic scholarship and modern business practices.
                            </p>
                            <p class="text-platinum-200 mt-3">
                                The Shariah Advisory Board provides authoritative guidance on matters of Shariah compliance, reviews business activities and transactions, issues rulings (fatwas) on novel or complex matters, and ensures alignment between business operations and Islamic principles.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">2.2 Independence and Authority</h3>
                            <p class="text-platinum-200">
                                The Shariah Advisory Board operates with independence from management, possessing authority to review any aspect of Group operations and to require modifications or cessation of activities that contravene Shariah principles. Board decisions on matters of Shariah compliance are binding and take precedence over commercial considerations.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">2.3 Shariah Compliance Function</h3>
                            <p class="text-platinum-200">
                                A dedicated Shariah compliance function supports the Advisory Board, conducting ongoing monitoring of business activities, reviewing contracts and transactions, coordinating Shariah audits, and ensuring implementation of Advisory Board directives. Shariah compliance personnel receive specialized training in Islamic commercial law and halal industry standards.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 3 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        3. Halal Integrity System
                    </h2>
                    <div class="space-y-6 text-sm text-sovereign-300 leading-relaxed">
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">3.1 Halal Certification Standards</h3>
                            <p class="text-platinum-200">
                                All production facilities and processes maintain certification from recognized halal certification bodies, including the Department of Islamic Development Malaysia (JAKIM) and internationally recognized halal authorities. Certification scope encompasses raw material sourcing, production processes, handling procedures, storage facilities, and distribution networks.
                            </p>
                            <p class="text-platinum-200 mt-3">
                                Halal certification standards applied by the Group meet or exceed requirements established by the Malaysian Standard MS 1500:2019 (Halal Food - General Requirements), Codex Alimentarius guidelines for halal food, and destination market halal requirements for export products.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">3.2 Halal Assurance System</h3>
                            <p class="text-platinum-200">
                                The Group implements comprehensive Halal Assurance Systems addressing critical control points throughout the value chain. Control measures ensure prevention of contamination with non-halal substances, segregation of halal and non-halal materials where applicable, proper slaughtering procedures in accordance with Islamic rites (dhabiha), and maintenance of halal integrity during processing, storage, and transportation.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">3.3 Traceability and Documentation</h3>
                            <p class="text-platinum-200">
                                Complete traceability systems track products from source to consumer, documenting halal status at each stage of the supply chain. Traceability records include supplier halal certification, raw material specifications, production batch records, halal certification documentation, and distribution chain custody records.
                            </p>
                            <p class="text-platinum-200 mt-3">
                                Documentation systems enable rapid response to any halal integrity concerns and provide transparency to regulatory authorities, certification bodies, and institutional customers.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 4 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        4. Shariah-Compliant Business Practices
                    </h2>
                    <div class="space-y-6 text-sm text-sovereign-300 leading-relaxed">
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">4.1 Prohibited Activities</h3>
                            <p class="text-platinum-200">
                                The Group strictly avoids all activities prohibited under Islamic law (haram), including but not limited to: involvement with alcohol, pork, gambling, interest-based lending (riba), excessive uncertainty (gharar), speculation (maysir), and any business activities deemed harmful to society or contrary to Islamic ethics.
                            </p>
                            <p class="text-platinum-200 mt-3">
                                Due diligence procedures screen potential business partners, suppliers, and investment opportunities to ensure alignment with Shariah principles and absence of prohibited activities.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">4.2 Ethical Business Conduct</h3>
                            <p class="text-platinum-200">
                                Business operations reflect Islamic ethical principles including honesty in dealings, fulfillment of contracts, fair treatment of employees and business partners, environmental stewardship, and contribution to social welfare. These principles inform corporate policies, operational procedures, and stakeholder relationships.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">4.3 Transparency and Disclosure</h3>
                            <p class="text-platinum-200">
                                The Group maintains transparency in business dealings, providing clear and accurate information to stakeholders regarding products, services, financial performance, and Shariah compliance status. Disclosure practices meet both regulatory requirements and Islamic principles of honesty and transparency in commercial transactions.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 5 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        5. Islamic Financial Principles
                    </h2>
                    <div class="space-y-6 text-sm text-sovereign-300 leading-relaxed">
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">5.1 Prohibition of Interest (Riba)</h3>
                            <p class="text-platinum-200">
                                All financial arrangements and transactions are structured to avoid interest-based lending and borrowing (riba), which is strictly prohibited in Islam. The Group utilizes Shariah-compliant financing structures including profit-sharing arrangements (mudarabah), partnership structures (musharakah), cost-plus financing (murabaha), and leasing arrangements (ijarah).
                            </p>
                            <p class="text-platinum-200 mt-3">
                                Financial structuring receives prior approval from the Shariah Advisory Board to ensure compliance with Islamic financial principles and contemporary Shariah standards for Islamic finance.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">5.2 Risk Sharing and Asset-Backing</h3>
                            <p class="text-platinum-200">
                                Financial transactions are structured on principles of risk-sharing between parties and backed by real economic assets or activities. Speculative transactions lacking underlying assets or productive economic activity are avoided in accordance with Islamic prohibitions against gharar (excessive uncertainty) and maysir (speculation).
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-6">
                            <h3 class="text-lg text-champagne-400 mb-3 font-semibold">5.3 Zakat and Social Responsibility</h3>
                            <p class="text-platinum-200">
                                The Group calculates and facilitates payment of zakat (obligatory charity) on behalf of Muslim shareholders in accordance with Islamic jurisprudence. Zakat calculation methodologies receive approval from the Shariah Advisory Board and align with recognized Islamic scholarly opinions.
                            </p>
                            <p class="text-platinum-200 mt-3">
                                Beyond zakat obligations, the Group engages in voluntary charitable activities (sadaqah) and social responsibility initiatives that contribute to community welfare and align with Islamic values of social justice and mutual support.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 6 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        6. Shariah Audit and Review
                    </h2>
                    <div class="space-y-4 text-sm text-sovereign-300 leading-relaxed">
                        <p>
                            The Group conducts regular Shariah audits to verify ongoing compliance with Islamic principles and identify any areas requiring corrective action. Shariah audit scope encompasses business activities, financial transactions, contracts, operational procedures, and halal certification maintenance.
                        </p>
                        <p>
                            Internal Shariah audit function operates independently, reporting directly to the Shariah Advisory Board. Audit findings are documented, reviewed by the Advisory Board, and addressed through management action plans with defined timelines and accountability.
                        </p>
                        <p>
                            External Shariah audits may be conducted by independent Islamic scholars or specialized Shariah audit firms to provide additional assurance regarding compliance status and governance effectiveness.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 7 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        7. Employee Training and Awareness
                    </h2>
                    <div class="space-y-4 text-sm text-sovereign-300 leading-relaxed">
                        <p>
                            All employees receive training on Shariah principles relevant to their roles and responsibilities. Training programs address Islamic business ethics, halal requirements for production and handling, prohibited activities and substances, and procedures for escalating Shariah compliance concerns.
                        </p>
                        <p>
                            Specialized training is provided to personnel in critical roles including production management, quality assurance, procurement, and financial operations. Training content is developed in consultation with the Shariah Advisory Board and updated to reflect evolving standards and best practices.
                        </p>
                        <p>
                            The Group fosters a culture of Shariah awareness and compliance, encouraging employees to raise questions or concerns regarding potential Shariah issues and providing clear channels for consultation with Shariah compliance personnel.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 8 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        8. Stakeholder Communication
                    </h2>
                    <div class="space-y-4 text-sm text-sovereign-300 leading-relaxed">
                        <p>
                            The Group maintains transparent communication with stakeholders regarding Shariah governance framework, compliance status, and Advisory Board activities. Annual Shariah compliance reports provide stakeholders with information on governance structure, Advisory Board composition and activities, Shariah audit findings, and compliance performance.
                        </p>
                        <p>
                            Halal certification status and documentation are made available to customers, regulatory authorities, and certification bodies as required. The Group responds promptly to stakeholder inquiries regarding Shariah compliance and halal integrity.
                        </p>
                        <p>
                            Marketing and promotional materials accurately represent the Group's Shariah compliance status and halal certification, avoiding misleading claims or exaggeration. All representations regarding Islamic compliance receive prior review by Shariah compliance function.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 9 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        9. Continuous Improvement
                    </h2>
                    <div class="space-y-4 text-sm text-sovereign-300 leading-relaxed">
                        <p>
                            The Group is committed to continuous enhancement of Shariah governance practices, halal assurance systems, and compliance performance. Improvement initiatives are informed by Advisory Board guidance, audit findings, regulatory developments, industry best practices, and stakeholder feedback.
                        </p>
                        <p>
                            The Shariah Advisory Board regularly reviews governance framework effectiveness and recommends enhancements to strengthen compliance assurance. Management implements Advisory Board recommendations and reports on implementation progress.
                        </p>
                        <p>
                            The Group participates in industry forums, halal standards development, and Islamic finance initiatives to contribute to advancement of Shariah governance practices and halal industry standards.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 10 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        10. Non-Compliance Management
                    </h2>
                    <div class="space-y-4 text-sm text-sovereign-300 leading-relaxed">
                        <p>
                            In the event of identified Shariah non-compliance, the Group implements immediate corrective actions to address the issue and prevent recurrence. Non-compliance incidents are reported to the Shariah Advisory Board for review and guidance on appropriate remedial measures.
                        </p>
                        <p>
                            Depending on the nature and severity of non-compliance, remedial actions may include cessation of affected activities, disposal of non-compliant products or materials, purification of income derived from non-compliant transactions, and implementation of enhanced controls to prevent similar occurrences.
                        </p>
                        <p>
                            The Group maintains transparency regarding material non-compliance incidents, providing appropriate disclosure to affected stakeholders and regulatory authorities as required by applicable regulations and Islamic principles of honesty and accountability.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 11 -->
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
