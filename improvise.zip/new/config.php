<?php
/**
 * ============================================
 * UNGGUL AXIOM GROUP - GLOBAL CONFIGURATION
 * ============================================
 * Purpose: Centralized configuration for site-wide constants
 * Usage: Include this file at the top of every page
 * Example: require_once __DIR__ . '/config.php';
 * ============================================
 */

// Prevent direct access to this file
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    die('Direct access not permitted');
}

// ============================================
// ENVIRONMENT DETECTION
// ============================================
// Automatically detect if running on localhost or production
$is_local = in_array($_SERVER['HTTP_HOST'], ['localhost', '127.0.0.1', 'localhost:8000']);

// Set environment constant
define('ENVIRONMENT', $is_local ? 'development' : 'production');

// ============================================
// ERROR REPORTING
// ============================================
// Show errors in development, hide in production
if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// ============================================
// SITE CONFIGURATION
// ============================================
// Site identity and branding
define('SITE_NAME', 'Unggul Axiom Group');
define('SITE_TAGLINE', 'Excellence in Corporate Leadership');

// ============================================
// URL CONFIGURATION
// ============================================
// Auto-detect protocol (http or https)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443 ? 'https://' : 'http://';

// Auto-detect domain
$domain = $_SERVER['HTTP_HOST'];

// Construct base URL
define('BASE_URL', $protocol . $domain);

// Alternative: Hardcoded for production (uncomment if auto-detection fails)
// define('BASE_URL', 'https://unggulaxiom.com');

// ============================================
// PATH CONFIGURATION
// ============================================
// Absolute server paths for file includes
define('ROOT_PATH', __DIR__);
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('PARTIALS_PATH', ROOT_PATH . '/partials');
define('DATA_PATH', ROOT_PATH . '/data');
define('ASSETS_PATH', ROOT_PATH . '/assets');

// ============================================
// TIMEZONE CONFIGURATION
// ============================================
// Set default timezone (adjust based on company location)
date_default_timezone_set('Asia/Kuala_Lumpur');

// ============================================
// SECURITY CONFIGURATION
// ============================================
// Start session securely
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', ENVIRONMENT === 'production' ? 1 : 0);
    ini_set('session.use_strict_mode', 1);
    // Uncomment when sessions are needed:
    // session_start();
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Safely escape output to prevent XSS attacks
 * @param string $string The string to escape
 * @return string Escaped string safe for HTML output
 */
function esc($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Generate full URL from relative path
 * @param string $path Relative path (e.g., '/about')
 * @return string Full URL
 */
function url($path = '') {
    return BASE_URL . $path;
}

// ============================================
// SOVEREIGN ROUTING MATRIX
// ============================================
// Centralized route definitions for absolute path control
define('ROUTES', [
    // Primary Navigation
    'home' => '/',
    'about' => '/about',
    'systems' => '/systems',
    'sectors' => '/sectors',
    'cipu' => '/cipu',
    'capital' => '/capital',
    'governance' => '/governance',
    'contact' => '/contact',

    // Governance & Compliance
    'shariah_governance' => '/shariah-governance',
    'compliance' => '/compliance',
    'privacy_policy' => '/privacy-policy',
    'terms_of_service' => '/terms-of-service',

    // Corporate
    'leadership' => '/leadership',
    'careers' => '/careers',

    // Institutional Engagement
    'partnerships' => '/partnerships',
    'institutional_engagement' => '/institutional-engagement',
    'contact_general' => '/contact/general',
    'contact_partnerships' => '/contact/partnerships',
    'contact_capital' => '/contact/capital',

    // Ecosystem
    'ecosystem' => '/ecosystem',
    'ecosystem_agro' => '/ecosystem/axiom-agro',
    'ecosystem_halaltech' => '/ecosystem/axiom-halaltech',
    'ecosystem_logistics' => '/ecosystem/axiom-logistics',
    'ecosystem_global_trade' => '/ecosystem/axiom-global-trade',
    'ecosystem_capital' => '/ecosystem/axiom-capital',

    // Investor Relations
    'investor_relations' => '/investor-relations',
]);

/**
 * Get route URL from routing matrix
 * @param string $route_key Key from ROUTES array
 * @return string Full URL for the route
 */
function route($route_key) {
    if (!isset(ROUTES[$route_key])) {
        error_log("Warning: Route key '{$route_key}' not found in ROUTES array");
        return url('/');
    }
    return url(ROUTES[$route_key]);
}

/**
 * Check if current page matches given path
 * @param string $path Path to check (e.g., '/about')
 * @return bool True if current page matches
 */
function is_current_page($path) {
    $current = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    return $current === $path || $current === $path . '.php';
}

/**
 * Check if route is currently active
 * @param string $route_key Key from ROUTES array
 * @return bool True if route is active
 */
function is_active_route($route_key) {
    if (!isset(ROUTES[$route_key])) {
        return false;
    }
    return is_current_page(ROUTES[$route_key]);
}

/**
 * Get CSS classes for active navigation link
 * @param string $route_key Key from ROUTES array
 * @return string Tailwind CSS classes
 */
function nav_link_classes($route_key) {
    $base = 'text-sovereign-sm transition-colors duration-300 nav-link-underline pb-1';
    if (is_active_route($route_key)) {
        return $base . ' text-platinum-50 active';
    }
    return $base . ' text-platinum-200 hover:text-champagne-400';
}
