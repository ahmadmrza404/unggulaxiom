<?php
/**
 * Partnership Form Handler
 * Sends form data to partnership@unggulaxiom.com using SMTP config
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Load form settings
$settings_file = __DIR__ . '/data/form-settings.json';
$settings = file_exists($settings_file) ? json_decode(file_get_contents($settings_file), true) : [];
$form_config = $settings['partnership'] ?? [];

// Load mailer
require_once __DIR__ . '/includes/mailer.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method not allowed');
}

// Sanitize input
function clean_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Determine form type
$partner_type = isset($_POST['company_name']) ? 'corporate' : 'individual';

// Validation & Sanitization
$errors = [];
$uploaded_file_path = null;

if ($partner_type === 'corporate') {
    $company_name = clean_input($_POST['company_name'] ?? '');
    $registration_number = clean_input($_POST['registration_number'] ?? '');
    $website = clean_input($_POST['website'] ?? '');
    $industry_sector = clean_input($_POST['industry_sector'] ?? '');
    $company_size = clean_input($_POST['company_size'] ?? '');

    $rep_name = clean_input($_POST['rep_name'] ?? '');
    $rep_title = clean_input($_POST['rep_title'] ?? '');
    $email = clean_input($_POST['rep_email'] ?? '');
    $phone = clean_input($_POST['rep_phone'] ?? '');

    $partnership_model = clean_input($_POST['partnership_model'] ?? '');
    $geographic_focus = clean_input($_POST['geographic_focus'] ?? '');
    $investment_capacity = clean_input($_POST['investment_capacity'] ?? '');
    $executive_summary = clean_input($_POST['executive_summary'] ?? '');

    if (empty($company_name) || empty($website) || empty($rep_name) || empty($rep_title) || empty($email) || empty($phone) || empty($partnership_model) || empty($geographic_focus) || empty($executive_summary)) {
        $errors[] = 'Please fill in all required fields.';
    }

    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid representative email address.';
    }

    // Process file upload
    if (isset($_FILES['corporate_document']) && $_FILES['corporate_document']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['corporate_document']['tmp_name'];
        $file_name = basename($_FILES['corporate_document']['name']);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if ($file_ext !== 'pdf') {
            $errors[] = 'Only PDF files are allowed for supporting documentation.';
        } elseif ($_FILES['corporate_document']['size'] > 10 * 1024 * 1024) {
            $errors[] = 'File size exceeds the 10MB limit.';
        } else {
            $upload_dir = __DIR__ . '/uploads/partnership-documents/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            $new_file_name = time() . '_corporate_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file_name);
            if (move_uploaded_file($file_tmp, $upload_dir . $new_file_name)) {
                $uploaded_file_path = $upload_dir . $new_file_name;
            }
        }
    }
} else {
    $individual_name = clean_input($_POST['individual_name'] ?? '');
    $professional_title = clean_input($_POST['professional_title'] ?? '');
    $email = clean_input($_POST['individual_email'] ?? '');
    $phone = clean_input($_POST['individual_phone'] ?? '');
    $linkedin_url = clean_input($_POST['linkedin_url'] ?? '');
    $specialization = clean_input($_POST['specialization'] ?? '');
    $experience_years = clean_input($_POST['experience_years'] ?? '');

    $engagement_type = clean_input($_POST['engagement_type'] ?? '');
    $value_proposition = clean_input($_POST['value_proposition'] ?? '');
    $availability = clean_input($_POST['availability'] ?? '');

    if (empty($individual_name) || empty($professional_title) || empty($email) || empty($phone) || empty($specialization) || empty($experience_years) || empty($engagement_type) || empty($value_proposition) || empty($availability)) {
        $errors[] = 'Please fill in all required fields.';
    }

    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address.';
    }

    // Process file upload
    if (isset($_FILES['professional_document']) && $_FILES['professional_document']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['professional_document']['tmp_name'];
        $file_name = basename($_FILES['professional_document']['name']);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if ($file_ext !== 'pdf') {
            $errors[] = 'Only PDF files are allowed for supporting documentation.';
        } elseif ($_FILES['professional_document']['size'] > 10 * 1024 * 1024) {
            $errors[] = 'File size exceeds the 10MB limit.';
        } else {
            $upload_dir = __DIR__ . '/uploads/partnership-documents/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            $new_file_name = time() . '_professional_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file_name);
            if (move_uploaded_file($file_tmp, $upload_dir . $new_file_name)) {
                $uploaded_file_path = $upload_dir . $new_file_name;
            }
        }
    }
}

if (!empty($errors)) {
    header('Location: /strategic-partnership?error=1');
    exit;
}

// Build email content (HTML)
$to = $form_config['recipient_email'] ?? 'partnership@unggulaxiom.com';
$subject = 'Strategic Partnership Inquiry - ' . ucfirst($partner_type);

$email_body = '<!DOCTYPE html><html><head><style>';
$email_body .= 'body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }';
$email_body .= '.container { max-width: 800px; margin: 0 auto; padding: 20px; }';
$email_body .= '.header { background: #1a2332; color: #d4af37; padding: 20px; text-align: center; }';
$email_body .= '.section { margin: 20px 0; padding: 15px; border-left: 3px solid #d4af37; background: #f9f9f9; }';
$email_body .= '.section-title { font-weight: bold; color: #1a2332; margin-bottom: 10px; }';
$email_body .= '.field { margin: 10px 0; }';
$email_body .= '.field-label { font-weight: bold; color: #666; }';
$email_body .= '.field-value { margin-left: 10px; }';
$email_body .= '</style></head><body><div class="container">';
$email_body .= '<div class="header"><h1>Strategic Partnership Inquiry</h1><p>Unggul Axiom Group</p></div>';

if ($partner_type === 'corporate') {
    $email_body .= '<div class="section"><div class="section-title">Corporate Information</div>';
    $email_body .= '<div class="field"><span class="field-label">Company Name:</span><span class="field-value">' . $company_name . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Registration Number:</span><span class="field-value">' . $registration_number . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Website:</span><span class="field-value">' . $website . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Sector:</span><span class="field-value">' . $industry_sector . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Company Size:</span><span class="field-value">' . $company_size . '</span></div></div>';

    $email_body .= '<div class="section"><div class="section-title">Representative Contact</div>';
    $email_body .= '<div class="field"><span class="field-label">Name:</span><span class="field-value">' . $rep_name . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Title:</span><span class="field-value">' . $rep_title . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Email:</span><span class="field-value">' . $email . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Phone:</span><span class="field-value">' . $phone . '</span></div></div>';

    $email_body .= '<div class="section"><div class="section-title">Partnership Proposal</div>';
    $email_body .= '<div class="field"><span class="field-label">Proposed Model:</span><span class="field-value">' . $partnership_model . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Geographic Focus:</span><span class="field-value">' . $geographic_focus . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Investment Capacity:</span><span class="field-value">' . $investment_capacity . '</span></div>';
    $email_body .= '<div style="margin-top: 15px;"><strong>Executive Summary:</strong><br>' . nl2br($executive_summary) . '</div></div>';
} else {
    $email_body .= '<div class="section"><div class="section-title">Professional Profile</div>';
    $email_body .= '<div class="field"><span class="field-label">Name:</span><span class="field-value">' . $individual_name . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Expertise/Title:</span><span class="field-value">' . $professional_title . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Email:</span><span class="field-value">' . $email . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Phone:</span><span class="field-value">' . $phone . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">LinkedIn:</span><span class="field-value">' . $linkedin_url . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Specialization:</span><span class="field-value">' . $specialization . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Experience:</span><span class="field-value">' . $experience_years . '</span></div></div>';

    $email_body .= '<div class="section"><div class="section-title">Collaboration Proposal</div>';
    $email_body .= '<div class="field"><span class="field-label">Engagement Type:</span><span class="field-value">' . $engagement_type . '</span></div>';
    $email_body .= '<div class="field"><span class="field-label">Availability:</span><span class="field-value">' . $availability . '</span></div>';
    $email_body .= '<div style="margin-top: 15px;"><strong>Value Proposition:</strong><br>' . nl2br($value_proposition) . '</div></div>';
}

if ($uploaded_file_path) {
    $email_body .= '<div class="section"><div class="section-title">Attachments</div>';
    $email_body .= '<div class="field"><span class="field-label">Document:</span><span class="field-value">' . basename($uploaded_file_path) . ' (Saved on Server)</span></div></div>';
}

$email_body .= '<div style="margin-top: 30px; padding: 15px; background: #f0f0f0; text-align: center; font-size: 12px; color: #666;">';
$email_body .= '<p>Inquiry submitted on ' . date('F j, Y \a\t g:i A') . '</p>';
$email_body .= '<p>Unggul Axiom Group - Strategic Partnerships</p>';
$email_body .= '</div></div></body></html>';

// Log to file first
$log_file = __DIR__ . '/logs/partnership-inquiries.log';
$log_dir = dirname($log_file);
if (!file_exists($log_dir)) {
    mkdir($log_dir, 0755, true);
}

$org_or_name = ($partner_type === 'corporate') ? $company_name : $individual_name;
$log_entry = date('Y-m-d H:i:s') . " - Strategic Partnership inquiry from: $org_or_name ($email) - Type: $partner_type\n";
file_put_contents($log_file, $log_entry, FILE_APPEND);

// Save to JSON database backup
$data_file = __DIR__ . '/data/partnership-inquiries.json';
$inquiries = file_exists($data_file) ? json_decode(file_get_contents($data_file), true) : [];
$inquiries[] = [
    'source' => 'strategic-partnership.php',
    'timestamp' => date('Y-m-d H:i:s'),
    'type' => $partner_type,
    'name' => $org_or_name,
    'email' => $email,
    'phone' => $phone,
    'document' => $uploaded_file_path ? basename($uploaded_file_path) : null,
    'details' => ($partner_type === 'corporate') ? [
        'company_name' => $company_name,
        'registration_number' => $registration_number,
        'website' => $website,
        'industry_sector' => $industry_sector,
        'company_size' => $company_size,
        'rep_name' => $rep_name,
        'rep_title' => $rep_title,
        'partnership_model' => $partnership_model,
        'geographic_focus' => $geographic_focus,
        'investment_capacity' => $investment_capacity,
        'executive_summary' => $executive_summary
    ] : [
        'individual_name' => $individual_name,
        'professional_title' => $professional_title,
        'linkedin_url' => $linkedin_url,
        'specialization' => $specialization,
        'experience_years' => $experience_years,
        'engagement_type' => $engagement_type,
        'availability' => $availability,
        'value_proposition' => $value_proposition
    ]
];
file_put_contents($data_file, json_encode($inquiries, JSON_PRETTY_PRINT));

// Try to send email using mailer
send_email($to, $subject, $email_body, $email);

// Always redirect to success page because data is safely logged
header('Location: /strategic-partnership?success=1');
exit;
