<?php
/**
 * ============================================
 * CIPU - FLAGSHIP ASSET DOSSIER
 * ============================================
 */

require_once __DIR__ . '/config.php';
$_cipu = json_decode(file_get_contents(DATA_PATH . '/cipu.json'), true);
$page_title = 'CIPU - Central Integrated Poultry Unggul';
require_once INCLUDES_PATH . '/header.php';
?>

<style>
@keyframes pulse-status {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
}
.status-indicator {
    animation: pulse-status 2s ease-in-out infinite;
}
</style>

<!-- VANGUARD SECTION -->
<section class="py-32 bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign relative z-10">
        <div class="max-w-6xl mx-auto gsap-fade-up">
            <div class="mb-8">
                <p class="font-mono text-xs text-champagne-500 tracking-[0.15em] uppercase">
                    <?= htmlspecialchars($_cipu['hero']['classification']) ?>
                </p>
            </div>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-tight leading-none font-extrabold">
                <?= htmlspecialchars($_cipu['hero']['title']) ?>
            </h1>
            <div class="flex items-center gap-3">
                <div class="w-3 h-3 bg-champagne-500 rounded-full status-indicator"></div>
                <p class="font-mono text-sm text-champagne-400 tracking-wider uppercase font-semibold">
                    <?= htmlspecialchars($_cipu['hero']['status']) ?>
                </p>
            </div>
        </div>
    </div>
</section>

<!-- CONTENT SECTIONS -->
<section class="py-24 bg-obsidian-900 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-4xl mx-auto space-y-12">
            <?php foreach ($_cipu['sections'] as $section): ?>
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>

                <div class="border-l-2 border-champagne-500 pl-8 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 tracking-editorial mb-6 font-bold">
                        <?= htmlspecialchars($section['title']) ?>
                    </h2>

                    <?php if (!empty($section['subsections'])): ?>
                        <?php if (!empty($section['content'])): ?>
                            <div class="space-y-4 text-sovereign-300 leading-institutional mb-6">
                                <?php foreach ($section['content'] as $para): ?>
                                    <p><?= htmlspecialchars($para) ?></p>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <div class="space-y-6 text-sovereign-300 leading-institutional">
                            <?php foreach ($section['subsections'] as $sub): ?>
                            <div class="border-t border-champagne-500/10 pt-6">
                                <h3 class="text-xl text-champagne-400 mb-3 tracking-institutional font-semibold"><?= htmlspecialchars($sub['subtitle']) ?></h3>
                                <p class="text-sm text-platinum-200"><?= htmlspecialchars($sub['text']) ?></p>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="space-y-4 text-sovereign-300 leading-institutional">
                            <?php foreach ($section['content'] as $para): ?>
                                <p><?= htmlspecialchars($para) ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
