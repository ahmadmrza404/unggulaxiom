<?php
/**
 * ============================================
 * PARTNERSHIPS - STRATEGIC ROUTING PORTAL
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Partnerships';

$_partnerships = json_decode(file_get_contents(__DIR__ . '/data/partnerships.json'), true);
$p = $_partnerships['partnerships'];

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO SECTION -->
<section class="min-h-[60vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-4xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                <?= htmlspecialchars($p['hero']['label']) ?>
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-editorial leading-tight font-extrabold">
                <?= htmlspecialchars($p['hero']['title']) ?>
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-2xl mx-auto mb-10">
                <?= htmlspecialchars($p['hero']['subtitle']) ?>
            </p>
            <div class="flex flex-wrap justify-center gap-4">
                <a href="#inquiry-form"
                   class="inline-flex items-center gap-3 px-8 py-4 rounded-lg bg-gradient-to-r from-champagne-600 to-champagne-500 text-obsidian-950 text-sm font-semibold tracking-wider uppercase hover:from-champagne-500 hover:to-champagne-400 transition-all duration-300 hover:shadow-[0_0_25px_rgba(201,169,97,0.35)] shadow-lg transform hover:-translate-y-0.5">
                    <span>Submit Inquiry</span>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                    </svg>
                </a>
                <a href="#structures"
                   class="inline-flex items-center gap-3 px-8 py-4 rounded-lg border border-champagne-500/30 text-champagne-500 text-sm font-semibold tracking-wider uppercase hover:bg-champagne-500/10 hover:border-champagne-500/60 transition-all duration-300">
                    <span>Partnership Structures</span>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- STATS BAR -->
<section class="py-0 bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="container-sovereign relative z-10">
        <div class="grid grid-cols-2 md:grid-cols-4 divide-x divide-champagne-500/10 border-x border-champagne-500/10">
            <?php foreach ($p['stats'] as $i => $stat): ?>
            <div class="py-10 px-6 text-center gsap-fade-up">
                <div class="text-3xl md:text-4xl font-serif text-champagne-500 mb-2 font-bold"><?= htmlspecialchars($stat['value']) ?></div>
                <div class="text-xs text-sovereign-400 uppercase tracking-wider font-semibold"><?= htmlspecialchars($stat['label']) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- PARTNERSHIP STRUCTURES -->
<section id="structures" class="py-32 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">

        <div class="mb-20 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                PARTNERSHIP STRUCTURES
            </span>
            <div class="w-16 h-px bg-gradient-to-r from-champagne-500 to-transparent mx-auto mb-6"></div>
            <p class="text-sovereign-300 max-w-2xl mx-auto text-base">
                We offer three institutional-grade engagement frameworks, each designed to align capital objectives with long-term operational outcomes.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-20">

            <!-- Structure 1 -->
            <div class="group relative glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/40 transition-all duration-300 shadow-2xl overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="w-12 h-12 rounded-xl bg-obsidian-950/60 border border-champagne-500/20 flex items-center justify-center mb-6 group-hover:border-champagne-500/50 transition-colors relative z-10">
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <div class="text-xs text-champagne-500/60 font-mono uppercase tracking-wider mb-2 relative z-10">01</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-3 font-bold relative z-10"><?= htmlspecialchars($p['structures'][0]['title']) ?></h3>
                <p class="text-sm text-sovereign-300 mb-6 leading-relaxed relative z-10"><?= htmlspecialchars($p['structures'][0]['description']) ?></p>
                <div class="text-xs text-champagne-500 font-mono border-t border-champagne-500/10 pt-4 relative z-10"><?= htmlspecialchars($p['structures'][0]['tags']) ?></div>
            </div>

            <!-- Structure 2 -->
            <div class="group relative glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/40 transition-all duration-300 shadow-2xl overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="w-12 h-12 rounded-xl bg-obsidian-950/60 border border-champagne-500/20 flex items-center justify-center mb-6 group-hover:border-champagne-500/50 transition-colors relative z-10">
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </div>
                <div class="text-xs text-champagne-500/60 font-mono uppercase tracking-wider mb-2 relative z-10">02</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-3 font-bold relative z-10"><?= htmlspecialchars($p['structures'][1]['title']) ?></h3>
                <p class="text-sm text-sovereign-300 mb-6 leading-relaxed relative z-10"><?= htmlspecialchars($p['structures'][1]['description']) ?></p>
                <div class="text-xs text-champagne-500 font-mono border-t border-champagne-500/10 pt-4 relative z-10"><?= htmlspecialchars($p['structures'][1]['tags']) ?></div>
            </div>

            <!-- Structure 3 -->
            <div class="group relative glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/40 transition-all duration-300 shadow-2xl overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="w-12 h-12 rounded-xl bg-obsidian-950/60 border border-champagne-500/20 flex items-center justify-center mb-6 group-hover:border-champagne-500/50 transition-colors relative z-10">
                    <svg class="w-5 h-5 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                    </svg>
                </div>
                <div class="text-xs text-champagne-500/60 font-mono uppercase tracking-wider mb-2 relative z-10">03</div>
                <h3 class="text-xl font-serif text-platinum-50 mb-3 font-bold relative z-10"><?= htmlspecialchars($p['structures'][2]['title']) ?></h3>
                <p class="text-sm text-sovereign-300 mb-6 leading-relaxed relative z-10"><?= htmlspecialchars($p['structures'][2]['description']) ?></p>
                <div class="text-xs text-champagne-500 font-mono border-t border-champagne-500/10 pt-4 relative z-10"><?= htmlspecialchars($p['structures'][2]['tags']) ?></div>
            </div>

        </div>

        <!-- PARTNERSHIP CRITERIA -->
        <div class="glass-panel rounded-2xl border border-champagne-500/15 shadow-2xl overflow-hidden max-w-5xl mx-auto gsap-fade-up">
            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
            <div class="px-8 py-6 border-b border-champagne-500/10 relative z-10">
                <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide uppercase">
                    <?= htmlspecialchars($p['criteria']['section_label']) ?>
                </span>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-champagne-500/10 relative z-10">
                <div class="p-8">
                    <h4 class="text-sm text-champagne-500 font-mono uppercase tracking-wider mb-6 font-semibold"><?= htmlspecialchars($p['criteria']['institutional_profile']['heading']) ?></h4>
                    <ul class="space-y-4">
                        <?php foreach ($p['criteria']['institutional_profile']['items'] as $item): ?>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1 flex-shrink-0">→</span>
                            <span class="text-sovereign-300 text-sm md:text-base leading-relaxed"><?= htmlspecialchars($item) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="p-8">
                    <h4 class="text-sm text-champagne-500 font-mono uppercase tracking-wider mb-6 font-semibold"><?= htmlspecialchars($p['criteria']['value_alignment']['heading']) ?></h4>
                    <ul class="space-y-4">
                        <?php foreach ($p['criteria']['value_alignment']['items'] as $item): ?>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 mt-1 flex-shrink-0">→</span>
                            <span class="text-sovereign-300 text-sm md:text-base leading-relaxed"><?= htmlspecialchars($item) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- INQUIRY FORM -->
<section id="inquiry-form" class="py-32 bg-obsidian-950 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 left-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">

        <div class="mb-20 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                <?= htmlspecialchars($p['inquiry_form']['section_label']) ?>
            </span>
            <div class="w-16 h-px bg-gradient-to-r from-champagne-500 to-transparent mx-auto mb-6"></div>
            <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 mb-4 font-bold"><?= htmlspecialchars($p['inquiry_form']['title']) ?></h2>
            <p class="text-sovereign-300 max-w-2xl mx-auto leading-relaxed text-base">
                <?= htmlspecialchars($p['inquiry_form']['description']) ?>
            </p>
        </div>

        <div class="max-w-4xl mx-auto">

            <div x-data="{ submitted: false, loading: false, error: '' }">

            <!-- FORM -->
            <div x-show="!submitted" x-cloak>
                <form @submit.prevent="
                    loading = true;
                    error = '';
                    fetch('process-partnership-inquiry.php', {
                        method: 'POST',
                        body: new FormData($event.target)
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) { submitted = true; }
                        else { error = data.message || 'Submission failed. Please try again.'; }
                    })
                    .catch(() => { error = 'Network error. Please try again.'; })
                    .finally(() => { loading = false; })
                " class="space-y-8 gsap-fade-up">

                    <!-- Organisation & Contact -->
                    <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                        <div class="relative z-10">
                            <h4 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Organisation & Contact</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Organisation Name *</label>
                                    <input type="text" name="organization" required placeholder="Company or Institution"
                                           class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500">
                                </div>
                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Organisation Type *</label>
                                    <select name="organization_type" required
                                            class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Type</option>
                                        <?php foreach ($p['inquiry_form']['organization_type_options'] as $opt): ?>
                                        <option value="<?= htmlspecialchars(strtolower(str_replace([' ', '/'], '-', $opt))) ?>" class="bg-obsidian-950 text-platinum-100"><?= htmlspecialchars($opt) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Representative Name *</label>
                                    <input type="text" name="representative" required placeholder="Full Name & Title"
                                           class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500">
                                </div>
                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Designation / Title *</label>
                                    <input type="text" name="designation" required placeholder="e.g. Managing Director"
                                           class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500">
                                </div>
                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Email Address *</label>
                                    <input type="email" name="email" required placeholder="email@domain.com"
                                           class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500">
                                </div>
                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Phone Number *</label>
                                    <input type="tel" name="phone" required placeholder="+60 12-345 6789"
                                           class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500">
                                </div>
                                <div class="md:col-span-2">
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Country / Region *</label>
                                    <input type="text" name="country" required placeholder="e.g. Malaysia, UAE, Singapore"
                                           class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Partnership Details -->
                    <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                        <div class="relative z-10">
                            <h4 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Partnership Details</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Partnership Structure *</label>
                                    <select name="partnership_type" required
                                            class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Structure</option>
                                        <?php foreach ($p['inquiry_form']['partnership_type_options'] as $opt): ?>
                                        <option value="<?= htmlspecialchars(strtolower(str_replace(' ', '-', $opt))) ?>" class="bg-obsidian-950 text-platinum-100"><?= htmlspecialchars($opt) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Investment Range</label>
                                    <select name="investment_range"
                                            class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Range</option>
                                        <?php foreach ($p['inquiry_form']['investment_range_options'] as $opt): ?>
                                        <option value="<?= htmlspecialchars($opt) ?>" class="bg-obsidian-950 text-platinum-100"><?= htmlspecialchars($opt) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="md:col-span-2">
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Areas of Interest</label>
                                    <input type="text" name="areas_of_interest" placeholder="e.g. Poultry infrastructure, cold-chain logistics, halal compliance systems"
                                           class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Proposal Statement -->
                    <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                        <div class="relative z-10">
                            <h4 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Proposal Statement</h4>
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Partnership Proposal *</label>
                                <textarea name="proposal" required rows="6"
                                          placeholder="Describe your partnership proposal, strategic objectives, and the value you bring to this engagement..."
                                          class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base resize-none placeholder:text-sovereign-500"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- Confidentiality & Submit -->
                    <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                        <div class="relative z-10">
                            <label class="flex items-start gap-4 cursor-pointer mb-8 select-none">
                                <div class="relative flex items-center justify-center w-5 h-5 rounded border border-champagne-500/30 bg-obsidian-950/60 group-hover:border-champagne-500/60 transition-all duration-300 mt-0.5">
                                    <input type="checkbox" name="consent" required class="peer absolute inset-0 opacity-0 cursor-pointer w-full h-full">
                                    <svg class="w-3 h-3 text-champagne-500 opacity-0 peer-checked:opacity-100 transition-opacity duration-300 pointer-events-none" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                    </svg>
                                </div>
                                <span class="text-sm text-sovereign-300 leading-relaxed hover:text-platinum-100 transition-colors duration-300">
                                    I confirm that the information provided is accurate and I consent to Unggul Axiom Group contacting me regarding this inquiry. All submissions are handled with strict confidentiality. *
                                </span>
                            </label>

                            <div class="flex flex-col sm:flex-row items-center justify-between gap-6 border-t border-champagne-500/10 pt-6">
                                <p class="text-xs text-sovereign-400 font-medium">* Required fields &nbsp;·&nbsp; Response within 5–7 business days</p>
                                <button type="submit" :disabled="loading"
                                        class="inline-flex items-center gap-3 px-10 py-4 rounded-lg bg-gradient-to-r from-champagne-600 to-champagne-500 text-obsidian-950 text-sm font-semibold tracking-wider uppercase hover:from-champagne-500 hover:to-champagne-400 transition-all duration-300 hover:shadow-[0_0_25px_rgba(201,169,97,0.35)] shadow-lg transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed w-full sm:w-auto justify-center">
                                    <span x-text="loading ? 'Submitting...' : 'Submit Inquiry'"></span>
                                    <svg x-show="!loading" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                                    </svg>
                                </button>
                            </div>

                            <div x-show="error" x-text="error" class="mt-4 text-red-400 text-sm text-center"></div>
                        </div>
                    </div>

                </form>
            </div>

            <!-- SUCCESS STATE -->
            <div x-show="submitted" x-cloak style="display: none;" class="glass-panel p-16 rounded-2xl border border-champagne-500/20 bg-champagne-500/5 text-center gsap-fade-up">
                <div class="w-16 h-16 border border-champagne-500/40 rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg class="w-8 h-8 text-champagne-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <h3 class="text-2xl font-serif text-platinum-50 mb-3 font-bold">Inquiry Received</h3>
                <p class="text-sovereign-300 leading-relaxed mb-2 text-base">Thank you. Your partnership proposal has been submitted to our executive team.</p>
                <p class="text-sm text-sovereign-400 font-medium">You will receive a response within 5–7 business days.</p>
            </div>

            </div>

        </div>

    </div>
</section>

<style>[x-cloak] { display: none !important; }</style>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
