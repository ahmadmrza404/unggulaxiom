<?php
/**
 * ============================================
 * GOVERNANCE - FRAMEWORK DOCUMENTATION
 * ============================================
 * Purpose: Institutional governance framework
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Governance Framework';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- VANGUARD SECTION -->
<section class="py-32 bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign relative z-10">
        <div class="max-w-6xl mx-auto gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                INSTITUTIONAL CONTROLS
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-tight leading-none font-extrabold">
                GOVERNANCE FRAMEWORK
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mb-8"></div>
            <p class="text-lg text-platinum-200 leading-institutional mb-4">
                UNGGUL BRONTO SDN. BHD. <span class="text-sm font-mono text-champagne-500 font-semibold tracking-wider">(Registration No: 202301027920)</span>
            </p>
            <p class="text-base text-sovereign-400 leading-institutional">
                Institutional governance structure for infrastructure operations and capital deployment
            </p>
        </div>
    </div>
</section>

<!-- GOVERNANCE DOCUMENT -->
<section class="py-32 bg-obsidian-900 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">
        <div class="reveal-mask max-w-6xl mx-auto space-y-12">

            <!-- Section 1 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden grid grid-cols-1 md:grid-cols-12 gap-8 items-start gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="md:col-span-3 relative z-10">
                    <p class="font-mono text-xs text-champagne-500 font-bold tracking-wider">SECTION 1.0</p>
                </div>
                <div class="md:col-span-9 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 mb-6 tracking-tight font-bold">Corporate Governance Structure</h2>
                    <p class="text-base text-sovereign-300 leading-relaxed mb-4">
                        Unggul Axiom Group maintains a structured governance framework with clearly defined roles, responsibilities, and accountability mechanisms. Board composition reflects appropriate expertise across infrastructure development, operational management, financial oversight, and regulatory compliance.
                    </p>
                    <p class="text-base text-sovereign-300 leading-relaxed">
                        Governance structure encompasses board oversight, executive management authority, internal control systems, and stakeholder engagement protocols designed to ensure institutional accountability and operational transparency.
                    </p>
                </div>
            </div>

            <!-- Section 2 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden grid grid-cols-1 md:grid-cols-12 gap-8 items-start gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="md:col-span-3 relative z-10">
                    <p class="font-mono text-xs text-champagne-500 font-bold tracking-wider">SECTION 2.0</p>
                </div>
                <div class="md:col-span-9 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 mb-6 tracking-tight font-bold">Board Oversight</h2>
                    <p class="text-base text-sovereign-300 leading-relaxed mb-4">
                        Board of Directors provides strategic oversight and governance direction for all organizational activities. Board responsibilities include strategic planning approval, capital deployment authorization, risk management oversight, and regulatory compliance monitoring.
                    </p>
                    <p class="text-base text-sovereign-300 leading-relaxed">
                        Board committees address specialized oversight functions including audit and risk management, investment evaluation, governance and nomination, and compensation review. Committee charters define scope, authority, and reporting obligations.
                    </p>
                </div>
            </div>

            <!-- Section 3 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden grid grid-cols-1 md:grid-cols-12 gap-8 items-start gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="md:col-span-3 relative z-10">
                    <p class="font-mono text-xs text-champagne-500 font-bold tracking-wider">SECTION 3.0</p>
                </div>
                <div class="md:col-span-9 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 mb-6 tracking-tight font-bold">Management Structure</h2>
                    <p class="text-base text-sovereign-300 leading-relaxed mb-4">
                        Executive management operates under delegated authority from the Board with clear reporting lines and accountability frameworks. Management committees coordinate cross-functional operations, strategic initiative execution, and operational performance monitoring.
                    </p>
                    <p class="text-base text-sovereign-300 leading-relaxed">
                        Command structure encompasses infrastructure systems coordination, sector integration management, capital deployment oversight, and institutional engagement protocols.
                    </p>
                </div>
            </div>

            <!-- Section 4 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden grid grid-cols-1 md:grid-cols-12 gap-8 items-start gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="md:col-span-3 relative z-10">
                    <p class="font-mono text-xs text-champagne-500 font-bold tracking-wider">SECTION 4.0</p>
                </div>
                <div class="md:col-span-9 relative z-10">
                    <h2 class="font-serif text-3xl text-platinum-50 mb-6 tracking-tight font-bold">Stakeholder Engagement</h2>
                    <p class="text-base text-sovereign-300 leading-relaxed mb-4">
                        Governance framework includes structured stakeholder engagement protocols for institutional investors, strategic partners, regulatory authorities, and operational stakeholders. Engagement mechanisms ensure transparency, accountability, and alignment with institutional standards.
                    </p>
                    <p class="text-base text-sovereign-300 leading-relaxed">
                        Communication protocols address financial reporting, operational updates, regulatory disclosures, and strategic initiative announcements through appropriate institutional channels.
                    </p>
                </div>
            </div>

        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
