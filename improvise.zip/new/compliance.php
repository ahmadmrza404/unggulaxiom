<?php
/**
 * ============================================
 * COMPLIANCE PAGE
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Compliance';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO SECTION -->
<section class="min-h-[50vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-5xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                REGULATORY FRAMEWORK
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-editorial leading-tight font-extrabold">
                Compliance & Oversight
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto">
                Unggul Axiom Group operates under rigorous regulatory oversight, maintaining institutional-grade compliance standards across all jurisdictions of operation.
            </p>
        </div>
    </div>
</section>

<!-- CONTENT SECTIONS -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-4xl mx-auto space-y-12">

            <!-- Section 1 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        1. Regulatory Oversight
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <p>
                            Unggul Bronto Sdn. Bhd. (Registration No: 202301027920) operates as a Malaysian-registered investment holding company subject to the regulatory jurisdiction of the Companies Commission of Malaysia (SSM) and applicable provisions of the Companies Act 2016.
                        </p>
                        <p>
                            The Group's business activities encompass investment holding and strategic development within the halal economy, including halal food production, halal agri-tech, pharmaceuticals, logistics infrastructure, halal supply chain certification, smart agriculture systems, food security infrastructure, livestock integration, and agri-technology innovation. Additional activities include venture building, project development, and strategic partnerships.
                        </p>
                        <p>
                            Operations span multiple regulatory domains including agricultural production, food processing, pharmaceutical manufacturing, logistics infrastructure, and financial services. Each operational vertical maintains compliance with sector-specific regulatory requirements administered by relevant Malaysian authorities including the Ministry of Agriculture and Food Security, Department of Veterinary Services, Malaysian Quarantine and Inspection Services, National Pharmaceutical Regulatory Agency, and Securities Commission Malaysia where applicable.
                        </p>
                        <p>
                            As an infrastructure platform operating within the global halal economy, the Group adheres to international standards governing halal certification, food safety, supply chain integrity, and cross-border trade facilitation.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 2 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        2. Corporate Governance Framework
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">2.1 Board Oversight</h3>
                            <p>
                                The Group maintains a structured board governance framework with clearly defined roles, responsibilities, and accountability mechanisms. Board composition reflects appropriate expertise across infrastructure development, agricultural operations, financial management, and regulatory compliance.
                            </p>
                            <p class="mt-2">
                                Board committees address specialized oversight functions including audit and risk management, investment evaluation, regulatory compliance, and strategic planning. Committee charters define scope, authority, and reporting obligations to ensure effective governance execution.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">2.2 Management Structure</h3>
                            <p>
                                Executive management operates under delegated authority from the Board, with clear reporting lines and accountability frameworks. Management committees coordinate cross-functional operations, risk assessment, compliance monitoring, and strategic initiative execution.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">2.3 Internal Controls</h3>
                            <p>
                                The Group implements comprehensive internal control systems addressing financial reporting accuracy, operational efficiency, asset protection, and regulatory compliance. Control frameworks undergo regular assessment and enhancement to address evolving risks and regulatory requirements.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 3 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        3. Financial Compliance
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">3.1 Financial Reporting Standards</h3>
                            <p>
                                Financial statements are prepared in accordance with Malaysian Financial Reporting Standards (MFRS), which are substantially aligned with International Financial Reporting Standards (IFRS). The Group maintains rigorous accounting policies, internal controls, and disclosure practices to ensure financial reporting integrity.
                            </p>
                            <p class="mt-2">
                                Annual financial statements undergo independent audit by qualified external auditors registered with the Malaysian Institute of Accountants. Audit scope encompasses financial position, operational results, cash flows, and compliance with applicable accounting standards and regulatory requirements.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">3.2 Tax Compliance</h3>
                            <p>
                                The Group maintains full compliance with Malaysian tax legislation including the Income Tax Act 1967, Goods and Services Tax Act 2014 (where applicable), and related tax regulations. Tax positions are supported by appropriate documentation, professional advice, and transparent disclosure to tax authorities.
                            </p>
                            <p class="mt-2">
                                Transfer pricing policies for inter-company transactions adhere to arm's length principles consistent with OECD guidelines and Malaysian transfer pricing regulations. Documentation standards meet statutory requirements for contemporaneous preparation and maintenance.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">3.3 Anti-Money Laundering</h3>
                            <p>
                                The Group implements comprehensive anti-money laundering (AML) and counter-terrorism financing (CTF) controls consistent with the Anti-Money Laundering, Anti-Terrorism Financing and Proceeds of Unlawful Activities Act 2001 (AMLA) and related regulations.
                            </p>
                            <p class="mt-2">
                                AML/CTF framework encompasses customer due diligence, enhanced due diligence for high-risk counterparties, ongoing transaction monitoring, suspicious activity reporting, record retention, and employee training. Compliance procedures are regularly reviewed and updated to reflect regulatory developments and emerging risks.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 4 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        4. Operational Compliance
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">4.1 Food Safety and Quality</h3>
                            <p>
                                Production facilities operate under stringent food safety management systems aligned with international standards including Hazard Analysis and Critical Control Points (HACCP), Good Manufacturing Practices (GMP), and ISO 22000 Food Safety Management.
                            </p>
                            <p class="mt-2">
                                Quality assurance protocols encompass raw material sourcing, production process controls, finished product testing, traceability systems, and continuous improvement mechanisms. Regular audits by internal quality teams and external certification bodies verify ongoing compliance and system effectiveness.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">4.2 Environmental Compliance</h3>
                            <p>
                                Operations comply with the Environmental Quality Act 1974 and related environmental regulations governing air emissions, water discharge, waste management, and environmental impact assessment. Environmental management systems address pollution prevention, resource efficiency, and environmental performance monitoring.
                            </p>
                            <p class="mt-2">
                                The Group maintains necessary environmental permits and licenses, conducts regular environmental monitoring, and implements corrective actions to address any identified non-conformances. Environmental compliance reporting meets statutory requirements and stakeholder expectations.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">4.3 Occupational Health and Safety</h3>
                            <p>
                                Workplace safety programs comply with the Occupational Safety and Health Act 1994 and industry-specific safety regulations. Safety management systems address hazard identification, risk assessment, control implementation, incident investigation, and continuous improvement.
                            </p>
                            <p class="mt-2">
                                Employee training, safety equipment provision, emergency preparedness, and regular safety audits ensure ongoing compliance and workplace safety performance. Safety metrics are monitored and reported to management and regulatory authorities as required.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 5 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        5. Data Protection and Privacy
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <p>
                            The Group maintains comprehensive data protection compliance aligned with the Personal Data Protection Act 2010 (PDPA) and international data protection standards. Data protection framework encompasses lawful processing principles, consent management, data subject rights, security safeguards, and breach notification procedures.
                        </p>
                        <p>
                            A designated Data Protection Officer oversees compliance implementation, conducts privacy impact assessments, manages data subject requests, and coordinates with regulatory authorities. Regular audits and employee training ensure ongoing compliance and privacy awareness throughout the organization.
                        </p>
                        <p>
                            Cross-border data transfers comply with applicable legal requirements including adequacy assessments, standard contractual clauses, or other approved transfer mechanisms. Third-party processors are subject to contractual data protection obligations and regular compliance verification.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 6 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        6. Trade and Export Compliance
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <p>
                            International trade operations comply with Malaysian customs regulations, export control laws, and destination country import requirements. Trade compliance framework addresses product classification, valuation, origin determination, licensing requirements, and documentation standards.
                        </p>
                        <p>
                            The Group maintains awareness of international sanctions regimes and export control restrictions, implementing screening procedures to prevent prohibited transactions. Trade compliance personnel receive regular training on regulatory developments and compliance obligations.
                        </p>
                        <p>
                            Halal certification for export products meets requirements of destination country halal authorities, ensuring market access and regulatory acceptance. Certification documentation, traceability records, and quality attestations support smooth customs clearance and regulatory compliance.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 7 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        7. Ethics and Conduct Standards
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">7.1 Code of Conduct</h3>
                            <p>
                                The Group maintains a comprehensive Code of Business Conduct and Ethics applicable to all directors, officers, employees, and representatives. The Code addresses conflicts of interest, confidentiality obligations, fair dealing, protection of company assets, compliance with laws, and reporting of violations.
                            </p>
                            <p class="mt-2">
                                All personnel receive Code training upon joining and periodic refresher training thereafter. Acknowledgment of Code obligations is documented and maintained. Violations are subject to disciplinary action up to and including termination of employment or engagement.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">7.2 Anti-Corruption</h3>
                            <p>
                                The Group maintains zero tolerance for bribery and corruption in all forms. Anti-corruption policies comply with the Malaysian Anti-Corruption Commission Act 2009 and international anti-corruption standards including the UK Bribery Act and US Foreign Corrupt Practices Act where applicable.
                            </p>
                            <p class="mt-2">
                                Anti-corruption framework encompasses prohibition of improper payments, gifts and hospitality policies, third-party due diligence, and reporting mechanisms. Regular risk assessments identify corruption risks and inform control enhancements.
                            </p>
                        </div>
                        <div class="border-t border-champagne-500/10 pt-4">
                            <h3 class="text-lg text-champagne-400 mb-2 font-semibold">7.3 Whistleblower Protection</h3>
                            <p>
                                The Group maintains confidential reporting channels for employees and stakeholders to report suspected violations of law, regulation, or company policy. Whistleblower protection policies prohibit retaliation against individuals making good faith reports.
                            </p>
                            <p class="mt-2">
                                Reports are investigated promptly and thoroughly by appropriate personnel. Investigation findings inform corrective actions, disciplinary measures, and compliance program enhancements. Reporting and investigation records are maintained in accordance with legal requirements.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 8 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        8. Risk Management
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <p>
                            The Group implements enterprise risk management (ERM) framework addressing strategic, operational, financial, and compliance risks. Risk management processes encompass risk identification, assessment, mitigation, monitoring, and reporting.
                        </p>
                        <p>
                            Risk appetite and tolerance levels are established by the Board and inform strategic decision-making and operational planning. Risk registers document identified risks, control measures, residual risk levels, and action plans for risk mitigation.
                        </p>
                        <p>
                            Regular risk assessments evaluate emerging risks including regulatory changes, market developments, operational disruptions, and cybersecurity threats. Risk management reporting provides Board and management visibility into risk exposure and mitigation effectiveness.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 9 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        9. Third-Party Management
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <p>
                            Third-party relationships are subject to due diligence, contractual controls, and ongoing monitoring to ensure compliance with Group standards and regulatory requirements. Due diligence scope addresses financial stability, operational capability, regulatory compliance, and reputational considerations.
                        </p>
                        <p>
                            Contracts with suppliers, service providers, and business partners include appropriate compliance obligations, audit rights, and termination provisions. High-risk third parties undergo enhanced due diligence and more frequent monitoring.
                        </p>
                        <p>
                            Third-party performance and compliance are monitored through regular reviews, audits, and performance metrics. Non-compliance issues trigger corrective action requirements and, if unresolved, relationship termination.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 10 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        10. Compliance Monitoring and Reporting
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <p>
                            Compliance function maintains ongoing monitoring of regulatory developments, conducts compliance assessments, and coordinates regulatory reporting obligations. Compliance monitoring activities include transaction reviews, policy compliance testing, and regulatory change impact analysis.
                        </p>
                        <p>
                            Compliance reporting provides Board and management visibility into compliance status, identified issues, remediation progress, and emerging regulatory risks. Regulatory filings and notifications are submitted accurately and timely in accordance with applicable requirements.
                        </p>
                        <p>
                            Internal audit function provides independent assurance regarding compliance program effectiveness, internal control adequacy, and risk management processes. Audit findings inform compliance program enhancements and management action plans.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 11 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        11. Continuous Improvement
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <p>
                            The Group is committed to continuous enhancement of compliance programs, internal controls, and risk management processes. Improvement initiatives are informed by regulatory developments, industry best practices, internal assessments, and stakeholder feedback.
                        </p>
                        <p>
                            Compliance training programs ensure personnel understand their obligations and can identify and escalate compliance concerns. Training content is tailored to role-specific risks and updated to reflect regulatory changes and lessons learned from compliance events.
                        </p>
                        <p>
                            Compliance culture is reinforced through tone from the top, accountability mechanisms, recognition of compliance excellence, and transparent communication regarding compliance expectations and performance.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 12 -->
            <div class="glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        12. Contact Information
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-sovereign-300 leading-institutional">
                        <p>
                            For compliance-related inquiries, regulatory matters, or to report compliance concerns:
                        </p>
                        <div class="mt-6 p-8 rounded-xl bg-obsidian-950/40 border border-champagne-500/15 text-platinum-200 hover:border-champagne-500/35 transition-all duration-300">
                            <p class="font-semibold text-lg text-platinum-50 mb-4 tracking-wide">Compliance Department</p>
                            <p class="mb-1">Unggul Bronto Sdn. Bhd.</p>
                            <p class="mb-1 text-sovereign-400">Registration No: 202301027920 (1521843-P)</p>
                            <p class="mb-4 text-sovereign-400">Kuala Lumpur, Malaysia</p>
                            <div class="w-12 h-px bg-champagne-500/20 mb-4"></div>
                            <p class="text-sm">
                                Email: 
                                <a href="mailto:compliance@unggulaxiom.com" class="text-champagne-500 hover:text-champagne-400 font-medium transition-colors">
                                    compliance@unggulaxiom.com
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
