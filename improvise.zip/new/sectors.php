<?php
/**
 * ============================================
 * SECTORS - MARKET DEPLOYMENT LEDGER
 * ============================================
 * Purpose: Sector deployment and execution strategy
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Sector Deployment';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- VANGUARD SECTION -->
<section class="min-h-[60vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-5xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                OPERATIONAL DOMAINS
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-editorial leading-tight font-extrabold">
                SECTOR DEPLOYMENT
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto">
                Operational domains for systematic infrastructure integration and value creation
            </p>
        </div>
    </div>
</section>

<!-- SECTOR LEDGER -->
<section class="py-32 bg-obsidian-950 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-20 opacity-20"></div>
    <div class="container-sovereign relative z-10">

        <div class="mb-16 gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4">
                DEPLOYMENT MATRIX
            </h2>
            <div class="w-16 h-0.5 bg-gradient-to-r from-champagne-500 to-transparent"></div>
        </div>

        <div class="space-y-6">

            <!-- SECTOR 01: FOOD & AGRICULTURE -->
            <div class="sector-row glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/60 transition-all duration-300 shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center group gsap-fade-up">
                <div class="lg:col-span-1">
                    <span class="font-mono text-xs text-champagne-500 group-hover:text-champagne-400 transition-colors">01</span>
                </div>
                <div class="lg:col-span-4">
                    <h3 class="font-serif text-3xl text-platinum-50 tracking-tight leading-tight group-hover:text-champagne-400 transition-colors duration-300 font-bold">
                        Food & Agriculture
                    </h3>
                </div>
                <div class="lg:col-span-7">
                    <p class="text-base text-sovereign-300 leading-institutional group-hover:text-platinum-100 transition-colors duration-300">
                        Integrated halal food production infrastructure, agricultural operations, and supply chain coordination. Encompasses farm-to-table systems, processing facilities, and quality control frameworks for halal-certified food products.
                    </p>
                </div>
            </div>

            <!-- SECTOR 02: PHARMACEUTICALS & WELLNESS -->
            <div class="sector-row glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/60 transition-all duration-300 shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center group gsap-fade-up">
                <div class="lg:col-span-1">
                    <span class="font-mono text-xs text-champagne-500 group-hover:text-champagne-400 transition-colors">02</span>
                </div>
                <div class="lg:col-span-4">
                    <h3 class="font-serif text-3xl text-platinum-50 tracking-tight leading-tight group-hover:text-champagne-400 transition-colors duration-300 font-bold">
                        Pharmaceuticals & Wellness
                    </h3>
                </div>
                <div class="lg:col-span-7">
                    <p class="text-base text-sovereign-300 leading-institutional group-hover:text-platinum-100 transition-colors duration-300">
                        Halal pharmaceutical manufacturing, wellness product development, and healthcare supply chain infrastructure. Includes production facilities, regulatory compliance systems, and distribution networks for halal-certified medical products.
                    </p>
                </div>
            </div>

            <!-- SECTOR 03: MANUFACTURING -->
            <div class="sector-row glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/60 transition-all duration-300 shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center group gsap-fade-up">
                <div class="lg:col-span-1">
                    <span class="font-mono text-xs text-champagne-500 group-hover:text-champagne-400 transition-colors">03</span>
                </div>
                <div class="lg:col-span-4">
                    <h3 class="font-serif text-3xl text-platinum-50 tracking-tight leading-tight group-hover:text-champagne-400 transition-colors duration-300 font-bold">
                        Manufacturing
                    </h3>
                </div>
                <div class="lg:col-span-7">
                    <p class="text-base text-sovereign-300 leading-institutional group-hover:text-platinum-100 transition-colors duration-300">
                        Industrial manufacturing infrastructure for halal-compliant production processes. Covers facility management, equipment coordination, process automation, and quality assurance systems across multiple manufacturing domains.
                    </p>
                </div>
            </div>

            <!-- SECTOR 04: LOGISTICS & DISTRIBUTION -->
            <div class="sector-row glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/60 transition-all duration-300 shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center group gsap-fade-up">
                <div class="lg:col-span-1">
                    <span class="font-mono text-xs text-champagne-500 group-hover:text-champagne-400 transition-colors">04</span>
                </div>
                <div class="lg:col-span-4">
                    <h3 class="font-serif text-3xl text-platinum-50 tracking-tight leading-tight group-hover:text-champagne-400 transition-colors duration-300 font-bold">
                        Logistics & Distribution
                    </h3>
                </div>
                <div class="lg:col-span-7">
                    <p class="text-base text-sovereign-300 leading-institutional group-hover:text-platinum-100 transition-colors duration-300">
                        Supply chain coordination and distribution infrastructure for halal product movement. Includes warehouse management, transportation systems, cold chain monitoring, and inventory tracking across domestic and international markets.
                    </p>
                </div>
            </div>

            <!-- SECTOR 05: ISLAMIC FINANCE -->
            <div class="sector-row glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/60 transition-all duration-300 shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center group gsap-fade-up">
                <div class="lg:col-span-1">
                    <span class="font-mono text-xs text-champagne-500 group-hover:text-champagne-400 transition-colors">05</span>
                </div>
                <div class="lg:col-span-4">
                    <h3 class="font-serif text-3xl text-platinum-50 tracking-tight leading-tight group-hover:text-champagne-400 transition-colors duration-300 font-bold">
                        Islamic Finance
                    </h3>
                </div>
                <div class="lg:col-span-7">
                    <p class="text-base text-sovereign-300 leading-institutional group-hover:text-platinum-100 transition-colors duration-300">
                        Shariah-compliant capital deployment and financial infrastructure. Encompasses equity participation frameworks, joint venture structures, project-based financing, and institutional investment mechanisms aligned with Islamic finance principles.
                    </p>
                </div>
            </div>

            <!-- SECTOR 06: GLOBAL TRADE -->
            <div class="sector-row glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/60 transition-all duration-300 shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center group gsap-fade-up">
                <div class="lg:col-span-1">
                    <span class="font-mono text-xs text-champagne-500 group-hover:text-champagne-400 transition-colors">06</span>
                </div>
                <div class="lg:col-span-4">
                    <h3 class="font-serif text-3xl text-platinum-50 tracking-tight leading-tight group-hover:text-champagne-400 transition-colors duration-300 font-bold">
                        Global Trade
                    </h3>
                </div>
                <div class="lg:col-span-7">
                    <p class="text-base text-sovereign-300 leading-institutional group-hover:text-platinum-100 transition-colors duration-300">
                        International trade infrastructure for halal product export and import coordination. Includes customs facilitation, trade documentation, market access systems, and global distribution networks for halal-certified products.
                    </p>
                </div>
            </div>

        </div>

    </div>
</section>


<?php require_once INCLUDES_PATH . '/footer.php'; ?>
