<?php
/**
 * ============================================
 * SYSTEMS - ENGINEERING BLUEPRINT
 * ============================================
 * Purpose: Infrastructure systems architecture
 * ============================================
 */

require_once __DIR__ . '/config.php';

$_systems = json_decode(file_get_contents(DATA_PATH . '/systems.json'), true);
$page_title = 'Systems Architecture';

require_once INCLUDES_PATH . '/header.php';
?>

<<!-- VANGUARD SECTION -->
<section class="min-h-[60vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-5xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                ENGINEERING BLUEPRINT
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-editorial leading-tight font-extrabold">
                <?= htmlspecialchars($_systems['hero']['title']) ?>
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto mb-4">
                <?= htmlspecialchars($_systems['hero']['tagline']) ?>
            </p>
            <?php if (isset($_systems['hero']['subtitle'])): ?>
            <p class="text-sm text-sovereign-400 tracking-institutional max-w-4xl mx-auto">
                <?= htmlspecialchars($_systems['hero']['subtitle']) ?>
            </p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- OVERVIEW SECTION -->
<?php if (isset($_systems['overview'])): ?>
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-6xl mx-auto">
            <div class="gsap-fade-up">
                <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                    <?= htmlspecialchars($_systems['overview']['section_label']) ?>
                </p>
                <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 mb-8 tracking-tight font-bold">
                    <?= htmlspecialchars($_systems['overview']['headline']) ?>
                </h2>
                <p class="text-lg text-platinum-200 leading-institutional mb-12">
                    <?= htmlspecialchars($_systems['overview']['description']) ?>
                </p>
            </div>

            <!-- Key Metrics -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php foreach ($_systems['overview']['key_metrics'] as $metric): ?>
                <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/60 shadow-lg group gsap-fade-up">
                    <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3">
                        <?= htmlspecialchars($metric['label']) ?>
                    </p>
                    <p class="text-xl text-platinum-100 font-medium">
                        <?= htmlspecialchars($metric['value']) ?>
                    </p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- SYSTEMS MATRIX -->
<section class="py-32 bg-obsidian-950 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12">

            <!-- STICKY NAVIGATION INDEX -->
            <div class="lg:col-span-4">
                <div class="lg:sticky lg:top-32 glass-panel p-8 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-8">
                        SYSTEM INDEX
                    </h2>
                    <nav class="space-y-4 relative z-10">
                        <?php foreach ($_systems['systems'] as $sys): ?>
                        <a href="#sys-<?= htmlspecialchars($sys['id']) ?>"
                           class="system-nav-link block py-3 border-l-2 border-transparent pl-6 text-platinum-200 opacity-40 hover:opacity-85 hover:border-champagne-500/30 transition-all duration-300"
                           data-system="<?= htmlspecialchars($sys['id']) ?>">
                            <span class="text-sm tracking-institutional font-medium"><?= htmlspecialchars($sys['name']) ?></span>
                        </a>
                        <?php endforeach; ?>
                    </nav>
                </div>
            </div>

            <!-- CONTENT BLOCKS -->
            <div class="lg:col-span-8 space-y-20">
                <?php foreach ($_systems['systems'] as $sys): ?>
                <div id="sys-<?= htmlspecialchars($sys['id']) ?>" class="system-block glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>

                    <!-- System Header -->
                    <div class="border-l-2 border-champagne-500 pl-8 mb-12 relative z-10">
                        <?php if (isset($sys['classification'])): ?>
                        <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4">
                            <?= htmlspecialchars($sys['classification']) ?>
                        </p>
                        <?php endif; ?>

                        <h3 class="font-serif text-3xl md:text-4xl text-platinum-50 mb-6 tracking-tight font-bold">
                            <?= htmlspecialchars($sys['name']) ?>
                        </h3>

                        <p class="text-lg text-platinum-100 leading-institutional mb-6">
                            <?= htmlspecialchars($sys['description']) ?>
                        </p>

                        <p class="text-base text-sovereign-300 leading-institutional">
                            <?= htmlspecialchars($sys['details']) ?>
                        </p>
                    </div>

                    <!-- Capabilities -->
                    <?php if (isset($sys['capabilities']) && !empty($sys['capabilities'])): ?>
                    <div class="mb-12 relative z-10">
                        <h4 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-8">
                            CORE CAPABILITIES
                        </h4>
                        <div class="space-y-6">
                            <?php foreach ($sys['capabilities'] as $capability): ?>
                            <div class="border-l border-champagne-500/20 pl-6 hover:border-champagne-500/50 transition-colors">
                                <h5 class="text-lg text-platinum-100 font-semibold mb-2">
                                    <?= htmlspecialchars($capability['title']) ?>
                                </h5>
                                <p class="text-sm text-sovereign-300 leading-institutional">
                                    <?= htmlspecialchars($capability['description']) ?>
                                </p>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Technical Specifications -->
                    <?php if (isset($sys['technical_specifications'])): ?>
                    <div class="border border-champagne-500/10 bg-obsidian-950/40 p-6 md:p-8 rounded-xl relative z-10">
                        <h4 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                            TECHNICAL SPECIFICATIONS
                        </h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <?php if (isset($sys['technical_specifications']['deployment_model'])): ?>
                            <div class="border-l border-champagne-500/15 pl-4">
                                <p class="text-xs text-champagne-400 font-medium mb-1">Deployment Model</p>
                                <p class="text-sm text-sovereign-200">
                                    <?= htmlspecialchars($sys['technical_specifications']['deployment_model']) ?>
                                </p>
                            </div>
                            <?php endif; ?>

                            <?php if (isset($sys['technical_specifications']['integration_points'])): ?>
                            <div class="border-l border-champagne-500/15 pl-4">
                                <p class="text-xs text-champagne-400 font-medium mb-1">Integration Points</p>
                                <p class="text-sm text-sovereign-200">
                                    <?= htmlspecialchars($sys['technical_specifications']['integration_points']) ?>
                                </p>
                            </div>
                            <?php endif; ?>

                            <?php if (isset($sys['technical_specifications']['scalability'])): ?>
                            <div class="border-l border-champagne-500/15 pl-4">
                                <p class="text-xs text-champagne-400 font-medium mb-1">Scalability</p>
                                <p class="text-sm text-sovereign-200">
                                    <?= htmlspecialchars($sys['technical_specifications']['scalability']) ?>
                                </p>
                            </div>
                            <?php endif; ?>

                            <?php if (isset($sys['technical_specifications']['compliance'])): ?>
                            <div class="border-l border-champagne-500/15 pl-4">
                                <p class="text-xs text-champagne-400 font-medium mb-1">Compliance Framework</p>
                                <p class="text-sm text-sovereign-200">
                                    <?= htmlspecialchars($sys['technical_specifications']['compliance']) ?>
                                </p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
                <?php endforeach; ?>
            </div>

        </div>
    </div>
</section>

<!-- SYSTEMS INTEGRATION SECTION -->
<?php if (isset($_systems['integration'])): ?>
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-t border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-6xl mx-auto">
            <div class="gsap-fade-up">
                <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                    <?= htmlspecialchars($_systems['integration']['section_label']) ?>
                </p>
                <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 mb-8 tracking-tight font-bold">
                    <?= htmlspecialchars($_systems['integration']['title']) ?>
                </h2>
                <p class="text-lg text-platinum-200 leading-institutional mb-12">
                    <?= htmlspecialchars($_systems['integration']['description']) ?>
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php foreach ($_systems['integration']['integration_points'] as $point): ?>
                <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/60 shadow-lg gsap-fade-up">
                    <h3 class="text-xl text-platinum-100 font-bold mb-3">
                        <?= htmlspecialchars($point['title']) ?>
                    </h3>
                    <p class="text-sm text-sovereign-300 leading-institutional">
                        <?= htmlspecialchars($point['description']) ?>
                    </p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- INSTITUTIONAL ACCESS SECTION -->
<?php if (isset($_systems['institutional_access'])): ?>
<section class="py-24 bg-obsidian-950 border-t border-champagne-500/10 relative overflow-hidden isolate">
    <div class="ambient-spotlight -bottom-40 left-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-6xl mx-auto">
            <div class="gsap-fade-up text-center md:text-left">
                <p class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                    <?= htmlspecialchars($_systems['institutional_access']['section_label']) ?>
                </p>
                <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 mb-8 tracking-tight font-bold">
                    <?= htmlspecialchars($_systems['institutional_access']['title']) ?>
                </h2>
                <p class="text-lg text-platinum-200 leading-institutional mb-12">
                    <?= htmlspecialchars($_systems['institutional_access']['description']) ?>
                </p>
            </div>

            <!-- Access Tiers -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                <?php foreach ($_systems['institutional_access']['access_tiers'] as $tier): ?>
                <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/60 shadow-lg gsap-fade-up">
                    <h3 class="text-xl text-platinum-100 font-bold mb-3">
                        <?= htmlspecialchars($tier['tier']) ?>
                    </h3>
                    <p class="text-sm text-sovereign-300 leading-institutional">
                        <?= htmlspecialchars($tier['description']) ?>
                    </p>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- CTA -->
            <div class="text-center gsap-fade-up">
                <a href="<?= htmlspecialchars($_systems['institutional_access']['cta']['url']) ?>"
                   class="inline-block px-12 py-4 rounded font-semibold tracking-wide transition-all duration-300 btn-shine-hover shadow-lg shadow-champagne-500/10 hover:shadow-champagne-500/25"
                   style="background-color: #D4AF37 !important; color: #0A0E14 !important; -webkit-text-fill-color: #0A0E14 !important; text-shadow: none !important;">
                    <?= htmlspecialchars($_systems['institutional_access']['cta']['text']) ?>
                </a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<script>
// Vanilla JS scroll tracking for sticky navigation
document.addEventListener('DOMContentLoaded', function() {
    const sections = document.querySelectorAll('.system-block');
    const navLinks = document.querySelectorAll('.system-nav-link');

    function updateActiveLink() {
        let current = '';

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            if (window.pageYOffset >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('opacity-100', 'border-champagne-500');
            link.classList.add('opacity-30', 'border-transparent');

            if (link.getAttribute('href') === '#' + current) {
                link.classList.remove('opacity-30', 'border-transparent');
                link.classList.add('opacity-100', 'border-champagne-500');
            }
        });
    }

    // Smooth scroll with offset for fixed header
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                const headerOffset = 120;
                const elementPosition = targetSection.offsetTop;
                const offsetPosition = elementPosition - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    window.addEventListener('scroll', updateActiveLink);
    updateActiveLink(); // Initial call
});
</script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
