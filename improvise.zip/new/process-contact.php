<?php
/**
 * Contact Form Handler
 * Sends form data based on inquiry type
 */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method not allowed');
}

// Load form settings
$settings_file = __DIR__ . '/data/form-settings.json';
$settings = json_decode(file_get_contents($settings_file), true);

// Sanitize input
function clean_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Determine inquiry type
$inquiry_type = 'general';
if (isset($_POST['partnership_name'])) $inquiry_type = 'partnership';
elseif (isset($_POST['investor_name'])) $inquiry_type = 'investment';
elseif (isset($_POST['media_name'])) $inquiry_type = 'media';

// Get form config
$form_config = $settings[$inquiry_type] ?? $settings['contact'];

// Build email content
$to = $form_config['recipient_email'] ?? 'contact@unggulaxiom.com';
$subject = 'Contact Inquiry - ' . ucfirst($inquiry_type);

$message = "New Contact Inquiry\n";
$message .= "Type: " . ucfirst($inquiry_type) . "\n";
$message .= "Submitted: " . date('Y-m-d H:i:s') . "\n\n";

$reply_to = '';

switch ($inquiry_type) {
    case 'general':
        $message .= "Name: " . clean_input($_POST['name'] ?? '') . "\n";
        $message .= "Email: " . clean_input($_POST['email'] ?? '') . "\n";
        $message .= "Organization: " . clean_input($_POST['organization'] ?? '') . "\n";
        $message .= "Phone: " . clean_input($_POST['phone'] ?? '') . "\n";
        $message .= "Subject: " . clean_input($_POST['subject'] ?? '') . "\n\n";
        $message .= "Message:\n" . clean_input($_POST['message'] ?? '') . "\n";
        $reply_to = clean_input($_POST['email'] ?? '');
        break;

    case 'partnership':
        $message .= "Name: " . clean_input($_POST['partnership_name'] ?? '') . "\n";
        $message .= "Title: " . clean_input($_POST['partnership_title'] ?? '') . "\n";
        $message .= "Company: " . clean_input($_POST['partnership_company'] ?? '') . "\n";
        $message .= "Email: " . clean_input($_POST['partnership_email'] ?? '') . "\n";
        $message .= "Partnership Type: " . clean_input($_POST['partnership_type'] ?? '') . "\n\n";
        $message .= "Proposal:\n" . clean_input($_POST['partnership_proposal'] ?? '') . "\n";
        $reply_to = clean_input($_POST['partnership_email'] ?? '');
        break;

    case 'investment':
        $message .= "Name: " . clean_input($_POST['investor_name'] ?? '') . "\n";
        $message .= "Title: " . clean_input($_POST['investor_title'] ?? '') . "\n";
        $message .= "Organization: " . clean_input($_POST['investor_organization'] ?? '') . "\n";
        $message .= "Email: " . clean_input($_POST['investor_email'] ?? '') . "\n";
        $message .= "Investor Type: " . clean_input($_POST['investor_type'] ?? '') . "\n";
        $message .= "Investment Interest: " . clean_input($_POST['investment_interest'] ?? '') . "\n\n";
        $message .= "Inquiry:\n" . clean_input($_POST['investment_inquiry'] ?? '') . "\n";
        $reply_to = clean_input($_POST['investor_email'] ?? '');
        break;

    case 'media':
        $message .= "Name: " . clean_input($_POST['media_name'] ?? '') . "\n";
        $message .= "Email: " . clean_input($_POST['media_email'] ?? '') . "\n";
        $message .= "Organization: " . clean_input($_POST['media_organization'] ?? '') . "\n";
        $message .= "Phone: " . clean_input($_POST['media_phone'] ?? '') . "\n";
        $message .= "Media Type: " . clean_input($_POST['media_type'] ?? '') . "\n";
        $message .= "Deadline: " . clean_input($_POST['media_deadline'] ?? '') . "\n\n";
        $message .= "Inquiry:\n" . clean_input($_POST['media_inquiry'] ?? '') . "\n";
        $reply_to = clean_input($_POST['media_email'] ?? '');
        break;
}

// Log submission first
$log_file = __DIR__ . '/logs/contact-inquiries.log';
$log_dir = dirname($log_file);
if (!file_exists($log_dir)) {
    mkdir($log_dir, 0755, true);
}
$log_name = $inquiry_type === 'general' ? clean_input($_POST['name'] ?? '') : $reply_to;
$log_entry = date('Y-m-d H:i:s') . " - Contact inquiry (fallback redirect) from: $log_name ($reply_to) - Type: $inquiry_type\n";
file_put_contents($log_file, $log_entry, FILE_APPEND);

// Save to JSON database backup
$data_file = __DIR__ . '/data/contact-inquiries.json';
$inquiries = file_exists($data_file) ? json_decode(file_get_contents($data_file), true) : [];
$inquiries[] = [
    'source' => 'process-contact.php',
    'timestamp' => date('Y-m-d H:i:s'),
    'inquiry_type' => $inquiry_type,
    'email' => $reply_to,
    'details' => array_map('clean_input', $_POST)
];
file_put_contents($data_file, json_encode($inquiries, JSON_PRETTY_PRINT));

// Format HTML message body
$email_body = '<div style="font-family: sans-serif; white-space: pre-wrap;">' . $message . '</div>';

// Send email using SMTP
require_once __DIR__ . '/includes/mailer.php';
send_email($to, $subject, $email_body, $reply_to);

header('Location: /contact?success=1');
exit;
