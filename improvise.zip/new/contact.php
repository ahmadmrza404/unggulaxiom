<?php
/**
 * ============================================
 * CONTACT PAGE - UNGGUL AXIOM GROUP
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Contact';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO SECTION -->
<section class="py-40 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-t border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-50"></div>

    <div class="container-sovereign relative z-10">
        <div class="max-w-4xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                GET IN TOUCH
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-6 tracking-editorial font-extrabold">
                Contact Us
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-lg text-sovereign-300 leading-relaxed max-w-2xl mx-auto">
                Get in touch with our team for inquiries, partnerships, and institutional engagement
            </p>
        </div>
    </div>
</section>

<!-- CONTACT INFORMATION -->
<section class="py-24 bg-gradient-to-b from-obsidian-900 to-obsidian-950 relative overflow-hidden isolate">
    <div class="container-sovereign">

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20 relative z-10">

            <div class="glass-panel p-8 rounded-2xl text-center border border-champagne-500/15 hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/60 shadow-lg group gsap-fade-up">
                <div class="w-12 h-12 rounded-xl bg-champagne-500/5 border border-champagne-500/20 flex items-center justify-center mx-auto mb-6 text-champagne-500 group-hover:bg-champagne-500 group-hover:text-obsidian-950 transition-colors duration-300">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                    </svg>
                </div>
                <h3 class="font-serif text-xl text-platinum-50 mb-2 font-bold">Location</h3>
                <p class="text-sm text-sovereign-300">Kuala Lumpur, Malaysia</p>
            </div>

            <div class="glass-panel p-8 rounded-2xl text-center border border-champagne-500/15 hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/60 shadow-lg group gsap-fade-up">
                <div class="w-12 h-12 rounded-xl bg-champagne-500/5 border border-champagne-500/20 flex items-center justify-center mx-auto mb-6 text-champagne-500 group-hover:bg-champagne-500 group-hover:text-obsidian-950 transition-colors duration-300">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                    </svg>
                </div>
                <h3 class="font-serif text-xl text-platinum-50 mb-2 font-bold">Email</h3>
                <p class="text-sm text-sovereign-300 hover:text-champagne-400 transition-colors duration-300">
                    <a href="mailto:contact@unggulaxiom.com">contact@unggulaxiom.com</a>
                </p>
            </div>

            <div class="glass-panel p-8 rounded-2xl text-center border border-champagne-500/15 hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/60 shadow-lg group gsap-fade-up">
                <div class="w-12 h-12 rounded-xl bg-champagne-500/5 border border-champagne-500/20 flex items-center justify-center mx-auto mb-6 text-champagne-500 group-hover:bg-champagne-500 group-hover:text-obsidian-950 transition-colors duration-300">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <h3 class="font-serif text-xl text-platinum-50 mb-2 font-bold">Response Time</h3>
                <p class="text-sm text-sovereign-300">48 - 72 Hours</p>
            </div>

        </div>

    </div>
</section>

<!-- CONTACT FORM -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">

        <div class="mb-16 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                COMMUNICATIONS
            </span>
            <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 tracking-editorial font-extrabold max-w-xl mx-auto">
                Send Us a Message
            </h2>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto my-4"></div>
            <p class="text-sm text-sovereign-400 max-w-lg mx-auto">
                Fill out the form below and our team will get back to you within 48-72 hours.
            </p>
        </div>

        <div class="max-w-3xl mx-auto">

            <div x-data="{ submitted: false, loading: false, error: '' }">

                <!-- FORM STATE -->
                <div x-show="!submitted">
                    <form @submit.prevent="
                        loading = true;
                        error = '';
                        fetch('process-contact-form.php', {
                            method: 'POST',
                            body: new FormData($event.target)
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                submitted = true;
                            } else {
                                error = data.message || 'Submission failed';
                            }
                        })
                        .catch(() => {
                            error = 'Network error. Please try again.';
                        })
                        .finally(() => {
                            loading = false;
                        })
                    " class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 space-y-6 shadow-2xl relative overflow-hidden gsap-fade-up">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>

                        <!-- NAME -->
                        <div class="relative z-10">
                            <label class="block text-[0.7rem] text-champagne-400 font-mono uppercase tracking-widest mb-2">
                                Full Name *
                            </label>
                            <input
                                type="text"
                                name="full_name"
                                required
                                class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base"
                                placeholder="Your Full Name"
                            >
                        </div>

                        <!-- ORGANIZATION -->
                        <div class="relative z-10">
                            <label class="block text-[0.7rem] text-champagne-400 font-mono uppercase tracking-widest mb-2">
                                Organization
                            </label>
                            <input
                                type="text"
                                name="organization"
                                class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base"
                                placeholder="Company or Institution (Optional)"
                            >
                        </div>

                        <!-- EMAIL & PHONE (flex layout on desktop) -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
                            <div>
                                <label class="block text-[0.7rem] text-champagne-400 font-mono uppercase tracking-widest mb-2">
                                    Email Address *
                                </label>
                                <input
                                    type="email"
                                    name="email"
                                    required
                                    class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base"
                                    placeholder="email@domain.com"
                                >
                            </div>
                            <div>
                                <label class="block text-[0.7rem] text-champagne-400 font-mono uppercase tracking-widest mb-2">
                                    Phone Number
                                </label>
                                <input
                                    type="tel"
                                    name="phone"
                                    class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base"
                                    placeholder="+60 12-345 6789 (Optional)"
                                >
                            </div>
                        </div>

                        <!-- INQUIRY TYPE -->
                        <div class="relative z-10">
                            <label class="block text-[0.7rem] text-champagne-400 font-mono uppercase tracking-widest mb-2">
                                Inquiry Type *
                            </label>
                            <select
                                name="inquiry_type"
                                required
                                class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base"
                            >
                                <option value="">Select Inquiry Type</option>
                                <option value="general">General Inquiry</option>
                                <option value="partnership">Partnership Opportunity</option>
                                <option value="investment">Investment Inquiry</option>
                                <option value="media">Media & Press</option>
                                <option value="careers">Career Opportunities</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <!-- MESSAGE -->
                        <div class="relative z-10">
                            <label class="block text-[0.7rem] text-champagne-400 font-mono uppercase tracking-widest mb-2">
                                Message *
                            </label>
                            <textarea
                                name="message"
                                required
                                rows="6"
                                class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 resize-none text-sm md:text-base"
                                placeholder="Tell us about your inquiry..."
                            ></textarea>
                        </div>

                        <!-- SUBMIT BUTTON -->
                        <div class="relative z-10">
                            <button
                                type="submit"
                                :disabled="loading"
                                class="w-full py-4 rounded-lg font-mono text-sm uppercase tracking-wider transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed btn-shine-hover shadow-lg shadow-champagne-500/10 hover:shadow-champagne-500/25"
                                style="background-color: #D4AF37 !important; color: #0A0E14 !important; font-weight: 600 !important; -webkit-text-fill-color: #0A0E14 !important; text-shadow: none !important;"
                                x-text="loading ? 'SENDING...' : 'Send Message'"
                            >
                            </button>
                        </div>

                        <!-- ERROR MESSAGE -->
                        <div x-show="error" x-text="error" class="text-red-400 text-sm text-center relative z-10"></div>

                        <p class="text-xs text-sovereign-400 text-center relative z-10">* Required fields</p>

                    </form>
                </div>

                <!-- SUCCESS MESSAGE -->
                <div x-show="submitted" x-cloak style="display: none;" class="glass-panel rounded-2xl border border-champagne-500/15 p-12 text-center bg-champagne-500/5 shadow-2xl relative overflow-hidden">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <svg class="w-16 h-16 text-champagne-500 mx-auto mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <h3 class="font-serif text-2xl text-platinum-50 mb-4 font-bold">Thank You</h3>
                    <p class="text-sovereign-300 leading-relaxed mb-2">
                        Your message has been received.
                    </p>
                    <p class="text-sm text-sovereign-400">
                        We will respond to your inquiry within 48-72 hours.
                    </p>
                </div>

            </div>

        </div>

    </div>
</section>

<style>
[x-cloak] { display: none !important; }
</style>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
