<?php
/**
 * ============================================
 * PRIVACY POLICY PAGE
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Privacy Policy';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO SECTION -->
<section class="min-h-[50vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-4xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                LEGAL FRAMEWORK
            </span>
            <h1 class="font-serif text-5xl md:text-6xl text-platinum-50 mb-6 tracking-editorial leading-tight font-extrabold">
                Privacy Policy
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto mb-6">
                Unggul Axiom Group is committed to protecting the privacy and confidentiality of personal information entrusted to us by stakeholders, partners, and institutional counterparties.
            </p>
            <div class="text-xs text-champagne-500/80 font-mono tracking-wider uppercase">
                Last Updated: <?php echo date('F j, Y'); ?>
            </div>
        </div>
    </div>
</section>

<!-- CONTENT SECTIONS -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-4xl mx-auto space-y-8">

            <!-- Section 1 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        1. Scope and Application
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            This Privacy Policy governs the collection, processing, storage, and disclosure of personal information by Unggul Bronto Sdn. Bhd. (Registration No: 202301027920) and its affiliated entities operating under the Unggul Axiom Group platform.
                        </p>
                        <p>
                            The Group operates as an investment holding company engaged in halal infrastructure development, including halal food production, halal agri-tech, pharmaceuticals, logistics, halal supply chain certification, smart agriculture systems, food security infrastructure, livestock integration, and agri-technology innovation. Additional activities encompass investment holding, venture building, project development, and strategic partnerships within the global halal economy.
                        </p>
                        <p>
                            This Policy applies to all individuals who interact with the Group, including but not limited to: institutional investors, strategic partners, suppliers, service providers, employees, contractors, and visitors to our digital platforms.
                        </p>
                        <p>
                            The Group operates in accordance with the Personal Data Protection Act 2010 (Malaysia), applicable international data protection regulations, and industry best practices governing institutional financial services and infrastructure operations.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 2 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        2. Information We Collect
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <div>
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">2.1 Corporate and Institutional Information</h3>
                            <p>
                                We collect corporate identification data, including company registration details, beneficial ownership structures, authorized representative information, corporate governance documentation, financial statements, and regulatory compliance records necessary for institutional due diligence and partnership evaluation.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">2.2 Professional Contact Information</h3>
                            <p>
                                Business contact details including names, titles, corporate email addresses, office telephone numbers, and professional correspondence addresses are collected to facilitate institutional communication and partnership management.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">2.3 Transaction and Investment Data</h3>
                            <p>
                                For accredited investors and institutional partners, we process investment documentation, transaction records, capital commitment details, distribution information, and related financial data required for investment management and regulatory reporting.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">2.4 Technical and Platform Data</h3>
                            <p>
                                Our digital platforms collect standard technical information including IP addresses, browser types, device identifiers, access timestamps, and usage analytics to maintain platform security, optimize performance, and prevent unauthorized access.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 3 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        3. Legal Basis for Processing
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            The Group processes personal information on the following legal grounds:
                        </p>
                        <ul class="space-y-3 pl-4">
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span><strong>Contractual Necessity:</strong> Processing required to execute partnership agreements, investment transactions, and commercial contracts.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span><strong>Legal Obligation:</strong> Compliance with regulatory requirements, anti-money laundering regulations, tax reporting obligations, and corporate governance mandates.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span><strong>Legitimate Business Interest:</strong> Due diligence procedures, risk management, fraud prevention, and operational efficiency improvements.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span><strong>Explicit Consent:</strong> Where specifically obtained for particular processing activities beyond core business operations.</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Section 4 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        4. Data Usage and Purpose
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            Personal information is processed exclusively for legitimate business purposes, including:
                        </p>
                        <p>
                            Partnership evaluation and due diligence procedures; investment transaction processing and management; regulatory compliance and reporting obligations; corporate governance and risk management; communication regarding business operations and strategic initiatives; platform security and fraud prevention; legal proceedings and dispute resolution; and operational analytics for business improvement.
                        </p>
                        <p class="pt-4 border-t border-champagne-500/10 text-sovereign-400">
                            The Group does not engage in consumer marketing activities. All communications are strictly business-to-business and institutional in nature.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 5 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        5. Information Sharing and Disclosure
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <div>
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">5.1 Internal Disclosure</h3>
                            <p>
                                Personal information may be shared among Unggul Axiom Group entities on a need-to-know basis for legitimate business operations, subject to equivalent data protection standards and confidentiality obligations.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">5.2 Service Providers</h3>
                            <p>
                                We engage professional service providers including legal counsel, auditors, financial advisors, technology vendors, and administrative service providers. All third-party processors are bound by strict confidentiality agreements and data protection obligations.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">5.3 Regulatory and Legal Disclosure</h3>
                            <p>
                                Information may be disclosed to regulatory authorities, government agencies, law enforcement bodies, and judicial institutions where required by law, court order, or regulatory mandate.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">5.4 Corporate Transactions</h3>
                            <p>
                                In the event of merger, acquisition, restructuring, or asset transfer, personal information may be disclosed to prospective counterparties under appropriate confidentiality protections.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 6 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        6. Data Security and Protection
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            The Group implements institutional-grade security measures to protect personal information against unauthorized access, disclosure, alteration, or destruction.
                        </p>
                        <p>
                            Security protocols include: encrypted data transmission and storage; multi-factor authentication systems; role-based access controls; regular security audits and penetration testing; incident response procedures; employee confidentiality training; and physical security measures for document storage.
                        </p>
                        <p class="pt-4 border-t border-champagne-500/10 text-sovereign-400">
                            While we maintain rigorous security standards, no system is entirely immune to risk. The Group cannot guarantee absolute security but commits to promptly addressing any identified vulnerabilities or security incidents.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 7 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        7. Data Retention
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            Personal information is retained only for as long as necessary to fulfill the purposes for which it was collected, comply with legal and regulatory obligations, resolve disputes, and enforce contractual agreements.
                        </p>
                        <p>
                            Retention periods vary based on information type and applicable legal requirements. Investment and transaction records are typically retained for a minimum of seven years following transaction completion, in accordance with financial services regulations. Corporate governance documentation is retained for the duration of the business relationship plus applicable statutory periods.
                        </p>
                        <p>
                            Upon expiration of retention periods, personal information is securely destroyed or anonymized in accordance with data protection standards.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 8 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        8. Individual Rights
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            Subject to applicable legal limitations, individuals have the right to:
                        </p>
                        <ul class="space-y-3 pl-4">
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Access personal information held by the Group</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Request correction of inaccurate or incomplete information</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Object to processing based on legitimate interests</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Request deletion of information where legally permissible</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Withdraw consent where processing is consent-based</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Lodge complaints with relevant data protection authorities</span>
                            </li>
                        </ul>
                        <p class="pt-4 border-t border-champagne-500/10">
                            Requests should be submitted in writing to the contact details provided below. The Group will respond within applicable statutory timeframes, typically 30 days from receipt of a valid request.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 9 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        9. International Data Transfers
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            As an infrastructure platform operating within the global halal economy, the Group may transfer personal information across international borders to affiliated entities, service providers, and business partners located in various jurisdictions.
                        </p>
                        <p>
                            All international transfers are conducted in accordance with applicable data protection laws and are subject to appropriate safeguards, including standard contractual clauses, adequacy decisions, or other legally recognized transfer mechanisms.
                        </p>
                        <p>
                            Recipients of transferred data are contractually obligated to maintain equivalent data protection standards and comply with applicable privacy regulations.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 10 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        10. Policy Updates
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            This Privacy Policy may be updated periodically to reflect changes in legal requirements, business operations, or data protection practices. Material changes will be communicated to affected parties through appropriate channels.
                        </p>
                        <p>
                            The "Last Updated" date at the top of this Policy indicates the most recent revision. Continued engagement with the Group following policy updates constitutes acceptance of the revised terms.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 11 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        11. Contact Information
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            For privacy-related inquiries, requests to exercise individual rights, or concerns regarding data protection practices, please contact:
                        </p>
                        <div class="mt-6 p-8 bg-obsidian-950/60 border border-champagne-500/20 rounded-xl relative overflow-hidden">
                            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                            <div class="relative z-10">
                                <p class="font-semibold text-champagne-500 mb-4 font-serif text-lg">Data Protection Officer</p>
                                <p class="text-platinum-50 font-medium">Unggul Bronto Sdn. Bhd.</p>
                                <p class="text-platinum-200">Kuala Lumpur, Malaysia</p>
                                <p class="mt-4 text-platinum-100">
                                    Email: <a href="mailto:privacy@unggulaxiom.com" class="text-champagne-400 hover:text-champagne-300 hover:underline transition-colors">privacy@unggulaxiom.com</a>
                                </p>
                            </div>
                        </div>
                        <p class="pt-6 text-sovereign-400">
                            The Group is committed to addressing privacy concerns promptly and transparently. All inquiries will receive a response within reasonable timeframes in accordance with applicable legal requirements.
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
