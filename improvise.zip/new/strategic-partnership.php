<?php
/**
 * ============================================
 * STRATEGIC PARTNERSHIP PAGE
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Strategic Partnership';

require_once INCLUDES_PATH . '/header.php';

// Check for success/error messages
$success = isset($_GET['success']) && $_GET['success'] == '1';
$error = isset($_GET['error']) && $_GET['error'] == '1';
?>

<?php if ($success): ?>
<div class="fixed top-4 right-4 z-50 max-w-md bg-green-900/90 border border-green-500 text-green-100 px-6 py-4 rounded shadow-lg" x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 5000)">
    <div class="flex items-start gap-3">
        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <div>
            <p class="font-semibold">Partnership inquiry submitted successfully</p>
            <p class="text-sm text-green-200 mt-1">Our team will review your submission and respond within 5-7 business days.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="fixed top-4 right-4 z-50 max-w-md bg-red-900/90 border border-red-500 text-red-100 px-6 py-4 rounded shadow-lg" x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 8000)">
    <div class="flex items-start gap-3">
        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
        </svg>
        <div>
            <p class="font-semibold">Submission failed</p>
            <p class="text-sm text-red-200 mt-1">There was an error processing your request. Please try again or contact partnership@unggulaxiom.com directly.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- HERO SECTION -->
<section class="min-h-[50vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-5xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                INSTITUTIONAL COLLABORATION
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-editorial leading-tight font-extrabold">
                Strategic Partnership
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto">
                Unggul Axiom Group engages with institutional partners and qualified professionals to advance halal infrastructure development across production, certification, logistics, and market access.
            </p>
        </div>
    </div>
</section>

<!-- PARTNERSHIP FORM SECTION -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-4xl mx-auto">

            <!-- Partnership Type Selector -->
            <div class="mb-12 text-center" x-data="{ partnerType: 'corporate' }" x-init="$watch('partnerType', value => {
                // Disable validation for hidden form
                const corporateInputs = document.querySelectorAll('[x-show=\'partnerType === \\\'corporate\\\'\'] input, [x-show=\'partnerType === \\\'corporate\\\'\'] select, [x-show=\'partnerType === \\\'corporate\\\'\'] textarea');
                const individualInputs = document.querySelectorAll('[x-show=\'partnerType === \\\'individual\\\'\'] input, [x-show=\'partnerType === \\\'individual\\\'\'] select, [x-show=\'partnerType === \\\'individual\\\'\'] textarea');

                if (value === 'corporate') {
                    corporateInputs.forEach(el => el.disabled = false);
                    individualInputs.forEach(el => el.disabled = true);
                } else {
                    corporateInputs.forEach(el => el.disabled = true);
                    individualInputs.forEach(el => el.disabled = false);
                }
            })">

                <!-- Toggle Tabs as Premium Glassmorphic Pills -->
                <div class="inline-flex p-1.5 bg-obsidian-950/80 border border-champagne-500/20 rounded-full shadow-2xl mb-16 relative z-10 mx-auto">
                    <button
                        type="button"
                        @click="partnerType = 'corporate'"
                        :class="partnerType === 'corporate' ? 'bg-gradient-to-r from-champagne-600 to-champagne-500 text-obsidian-950 shadow-lg' : 'text-sovereign-300 hover:text-platinum-100'"
                        class="px-8 py-3 rounded-full text-xs font-bold tracking-wider transition-all duration-300 uppercase">
                        Corporate Entity
                    </button>
                    <button
                        type="button"
                        @click="partnerType = 'individual'"
                        :class="partnerType === 'individual' ? 'bg-gradient-to-r from-champagne-600 to-champagne-500 text-obsidian-950 shadow-lg' : 'text-sovereign-300 hover:text-platinum-100'"
                        class="px-8 py-3 rounded-full text-xs font-bold tracking-wider transition-all duration-300 uppercase">
                        Individual Professional
                    </button>
                </div>

                <!-- Form Container -->
                <form action="/process-partnership.php" method="POST" enctype="multipart/form-data" class="space-y-8">

                    <!-- CORPORATE ENTITY FORM -->
                    <div x-show="partnerType === 'corporate'" x-transition:enter="transition ease-out duration-300" class="space-y-8 text-left">

                        <!-- Company Information -->
                        <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                            <div class="relative z-10 space-y-6">
                                <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Corporate Information</h3>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Company Name *</label>
                                    <input type="text" name="company_name" required
                                        class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Corporate Registration Number</label>
                                    <input type="text" name="registration_number"
                                        class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Corporate Website *</label>
                                    <input type="url" name="website" required
                                        class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500"
                                        placeholder="https://www.company.com">
                                </div>

                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Industry Sector *</label>
                                        <select name="industry_sector" required
                                            class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                            <option value="" class="bg-obsidian-950 text-sovereign-300">Select Sector</option>
                                            <option value="agriculture" class="bg-obsidian-950 text-platinum-100">Agriculture & Food Production</option>
                                            <option value="technology" class="bg-obsidian-950 text-platinum-100">Technology & Software</option>
                                            <option value="logistics" class="bg-obsidian-950 text-platinum-100">Logistics & Supply Chain</option>
                                            <option value="pharmaceutical" class="bg-obsidian-950 text-platinum-100">Pharmaceutical & Healthcare</option>
                                            <option value="certification" class="bg-obsidian-950 text-platinum-100">Certification & Compliance</option>
                                            <option value="finance" class="bg-obsidian-950 text-platinum-100">Financial Services</option>
                                            <option value="manufacturing" class="bg-obsidian-950 text-platinum-100">Manufacturing & Processing</option>
                                            <option value="trading" class="bg-obsidian-950 text-platinum-100">International Trade</option>
                                            <option value="other" class="bg-obsidian-950 text-platinum-100">Other</option>
                                        </select>
                                    </div>

                                    <div>
                                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Company Size *</label>
                                        <select name="company_size" required
                                            class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                            <option value="" class="bg-obsidian-950 text-sovereign-300">Select Size</option>
                                            <option value="startup" class="bg-obsidian-950 text-platinum-100">Startup (1-50 employees)</option>
                                            <option value="sme" class="bg-obsidian-950 text-platinum-100">SME (51-250 employees)</option>
                                            <option value="midmarket" class="bg-obsidian-950 text-platinum-100">Mid-Market (251-1000 employees)</option>
                                            <option value="enterprise" class="bg-obsidian-950 text-platinum-100">Enterprise (1000+ employees)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Representative Information -->
                        <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                            <div class="relative z-10 space-y-6">
                                <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Authorized Representative</h3>

                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Full Name *</label>
                                        <input type="text" name="rep_name" required
                                            class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                    </div>

                                    <div>
                                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Executive Title *</label>
                                        <input type="text" name="rep_title" required
                                            class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500"
                                            placeholder="e.g., Chief Executive Officer">
                                    </div>
                                </div>

                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Corporate Email Address *</label>
                                        <input type="email" name="rep_email" required
                                            class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <p class="text-xs text-sovereign-400 mt-1">Corporate domain email preferred</p>
                                    </div>

                                    <div>
                                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Direct Contact Number *</label>
                                        <input type="tel" name="rep_phone" required
                                            class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500"
                                            placeholder="+60 3 1234 5678">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Partnership Details -->
                        <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                            <div class="relative z-10 space-y-6">
                                <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Partnership Proposal</h3>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Proposed Partnership Model *</label>
                                    <select name="partnership_model" required
                                        class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Partnership Type</option>
                                        <option value="joint_venture" class="bg-obsidian-950 text-platinum-100">Joint Venture Development</option>
                                        <option value="strategic_investment" class="bg-obsidian-950 text-platinum-100">Strategic Investment</option>
                                        <option value="technology_integration" class="bg-obsidian-950 text-platinum-100">Technology Integration & Licensing</option>
                                        <option value="market_expansion" class="bg-obsidian-950 text-platinum-100">Market Expansion & Distribution</option>
                                        <option value="supply_chain" class="bg-obsidian-950 text-platinum-100">Supply Chain & Procurement</option>
                                        <option value="rd_collaboration" class="bg-obsidian-950 text-platinum-100">R&D Collaboration</option>
                                        <option value="certification" class="bg-obsidian-950 text-platinum-100">Certification & Compliance Services</option>
                                        <option value="infrastructure" class="bg-obsidian-950 text-platinum-100">Infrastructure Development</option>
                                        <option value="other" class="bg-obsidian-950 text-platinum-100">Other Strategic Collaboration</option>
                                    </select>
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Geographic Focus *</label>
                                    <select name="geographic_focus" required
                                        class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Region</option>
                                        <option value="malaysia" class="bg-obsidian-950 text-platinum-100">Malaysia</option>
                                        <option value="southeast_asia" class="bg-obsidian-950 text-platinum-100">Southeast Asia</option>
                                        <option value="middle_east" class="bg-obsidian-950 text-platinum-100">Middle East</option>
                                        <option value="east_asia" class="bg-obsidian-950 text-platinum-100">East Asia</option>
                                        <option value="south_asia" class="bg-obsidian-950 text-platinum-100">South Asia</option>
                                        <option value="global" class="bg-obsidian-950 text-platinum-100">Global</option>
                                    </select>
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Executive Summary *</label>
                                    <textarea name="executive_summary" rows="6" required
                                        class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500 resize-none"
                                        placeholder="Outline the strategic rationale, mutual value proposition, and alignment with halal infrastructure development objectives. Include relevant experience, capabilities, and proposed collaboration structure."></textarea>
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Investment Capacity (if applicable)</label>
                                    <select name="investment_capacity"
                                        class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Range</option>
                                        <option value="under_1m" class="bg-obsidian-950 text-platinum-100">Under USD 1 Million</option>
                                        <option value="1m_5m" class="bg-obsidian-950 text-platinum-100">USD 1-5 Million</option>
                                        <option value="5m_10m" class="bg-obsidian-950 text-platinum-100">USD 5-10 Million</option>
                                        <option value="10m_25m" class="bg-obsidian-950 text-platinum-100">USD 10-25 Million</option>
                                        <option value="25m_50m" class="bg-obsidian-950 text-platinum-100">USD 25-50 Million</option>
                                        <option value="over_50m" class="bg-obsidian-950 text-platinum-100">Over USD 50 Million</option>
                                        <option value="not_applicable" class="bg-obsidian-950 text-platinum-100">Not Applicable</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Document Upload -->
                        <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                            <div class="relative z-10 space-y-6">
                                <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Supporting Documentation</h3>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-3 font-medium">
                                        Corporate Profile / Pitch Deck <span class="text-sovereign-400 text-xs normal-case">(PDF - Max 10MB)</span>
                                    </label>
                                    <div class="relative group mt-1" x-data="{ fileName: '' }">
                                        <input type="file" name="corporate_document" accept=".pdf"
                                               @change="fileName = $event.target.files[0] ? $event.target.files[0].name : ''"
                                               class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
                                        <div class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-sovereign-300 rounded-lg px-4 py-8 text-center group-hover:border-champagne-500/40 transition-all duration-300 flex flex-col items-center justify-center gap-2">
                                            <svg class="w-10 h-10 text-champagne-500/70 group-hover:text-champagne-500 transition-colors duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                                            </svg>
                                            <span class="text-sm font-medium text-platinum-100 animate-pulse" x-text="fileName || 'Click to upload or drag & drop corporate document'">Click to upload or drag & drop corporate document</span>
                                            <span class="text-xs text-sovereign-400">PDF up to 10MB</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- INDIVIDUAL PROFESSIONAL FORM -->
                    <div x-show="partnerType === 'individual'" x-transition:enter="transition ease-out duration-300" class="space-y-8 text-left" style="display: none;">

                        <!-- Professional Information -->
                        <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                            <div class="relative z-10 space-y-6">
                                <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Professional Profile</h3>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Full Name *</label>
                                    <input type="text" name="individual_name"
                                        class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Core Expertise / Professional Title *</label>
                                    <input type="text" name="professional_title"
                                        class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500"
                                        placeholder="e.g., Halal Certification Specialist, Agricultural Technology Consultant">
                                </div>

                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Professional Email Address *</label>
                                        <input type="email" name="individual_email"
                                            class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                    </div>

                                    <div>
                                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Direct Contact Number *</label>
                                        <input type="tel" name="individual_phone"
                                            class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500"
                                            placeholder="+60 12 345 6789">
                                    </div>
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">LinkedIn Profile URL</label>
                                    <input type="url" name="linkedin_url"
                                        class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500"
                                        placeholder="https://www.linkedin.com/in/yourprofile">
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Area of Specialization *</label>
                                    <select name="specialization"
                                        class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Specialization</option>
                                        <option value="halal_certification" class="bg-obsidian-950 text-platinum-100">Halal Certification & Compliance</option>
                                        <option value="agritech" class="bg-obsidian-950 text-platinum-100">Agricultural Technology</option>
                                        <option value="food_science" class="bg-obsidian-950 text-platinum-100">Food Science & Processing</option>
                                        <option value="supply_chain" class="bg-obsidian-950 text-platinum-100">Supply Chain Management</option>
                                        <option value="quality_assurance" class="bg-obsidian-950 text-platinum-100">Quality Assurance & Food Safety</option>
                                        <option value="logistics" class="bg-obsidian-950 text-platinum-100">Logistics & Distribution</option>
                                        <option value="islamic_finance" class="bg-obsidian-950 text-platinum-100">Islamic Finance & Investment</option>
                                        <option value="market_development" class="bg-obsidian-950 text-platinum-100">Market Development & Trade</option>
                                        <option value="regulatory" class="bg-obsidian-950 text-platinum-100">Regulatory Affairs</option>
                                        <option value="technology" class="bg-obsidian-950 text-platinum-100">Technology & Digital Systems</option>
                                        <option value="other" class="bg-obsidian-950 text-platinum-100">Other</option>
                                    </select>
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Years of Experience *</label>
                                    <select name="experience_years"
                                        class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Range</option>
                                        <option value="3-5" class="bg-obsidian-950 text-platinum-100">3-5 years</option>
                                        <option value="5-10" class="bg-obsidian-950 text-platinum-100">5-10 years</option>
                                        <option value="10-15" class="bg-obsidian-950 text-platinum-100">10-15 years</option>
                                        <option value="15-20" class="bg-obsidian-950 text-platinum-100">15-20 years</option>
                                        <option value="20+" class="bg-obsidian-950 text-platinum-100">20+ years</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Collaboration Proposal -->
                        <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                            <div class="relative z-10 space-y-6">
                                <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Collaboration Proposal</h3>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Engagement Type *</label>
                                    <select name="engagement_type"
                                        class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Type</option>
                                        <option value="consulting" class="bg-obsidian-950 text-platinum-100">Consulting Services</option>
                                        <option value="advisory" class="bg-obsidian-950 text-platinum-100">Advisory Board / Strategic Advisor</option>
                                        <option value="technical" class="bg-obsidian-950 text-platinum-100">Technical Specialist</option>
                                        <option value="project_based" class="bg-obsidian-950 text-platinum-100">Project-Based Engagement</option>
                                        <option value="training" class="bg-obsidian-950 text-platinum-100">Training & Capacity Building</option>
                                        <option value="research" class="bg-obsidian-950 text-platinum-100">Research & Development</option>
                                        <option value="other" class="bg-obsidian-950 text-platinum-100">Other Collaboration</option>
                                    </select>
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Value Proposition *</label>
                                    <textarea name="value_proposition" rows="6"
                                        class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500 resize-none"
                                        placeholder="Describe your specialized capabilities, relevant experience, and how your expertise aligns with halal infrastructure development. Include specific areas where you can contribute value to Unggul Axiom Group operations."></textarea>
                                </div>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">Availability *</label>
                                    <select name="availability"
                                        class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                        <option value="" class="bg-obsidian-950 text-sovereign-300">Select Availability</option>
                                        <option value="immediate" class="bg-obsidian-950 text-platinum-100">Immediate</option>
                                        <option value="1_month" class="bg-obsidian-950 text-platinum-100">Within 1 month</option>
                                        <option value="2_3_months" class="bg-obsidian-950 text-platinum-100">2-3 months</option>
                                        <option value="flexible" class="bg-obsidian-950 text-platinum-100">Flexible</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Document Upload -->
                        <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                            <div class="relative z-10 space-y-6">
                                <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Professional Documentation</h3>

                                <div>
                                    <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-3 font-medium">
                                        Portfolio / Curriculum Vitae <span class="text-sovereign-400 text-xs normal-case">(PDF - Max 10MB)</span>
                                    </label>
                                    <div class="relative group mt-1" x-data="{ fileName: '' }">
                                        <input type="file" name="professional_document" accept=".pdf"
                                               @change="fileName = $event.target.files[0] ? $event.target.files[0].name : ''"
                                               class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
                                        <div class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-sovereign-300 rounded-lg px-4 py-8 text-center group-hover:border-champagne-500/40 transition-all duration-300 flex flex-col items-center justify-center gap-2">
                                            <svg class="w-10 h-10 text-champagne-500/70 group-hover:text-champagne-500 transition-colors duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                                            </svg>
                                            <span class="text-sm font-medium text-platinum-100" x-text="fileName || 'Drop PDF file here or click to upload'">Drop PDF file here or click to upload</span>
                                            <span class="text-xs text-sovereign-400">PDF up to 10MB</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- Submit Button -->
                    <div class="text-center pt-8 border-t border-champagne-500/10 gsap-fade-up">
                        <button type="submit"
                                class="inline-flex items-center gap-3 px-10 py-4 rounded-lg bg-gradient-to-r from-champagne-600 to-champagne-500 text-obsidian-950 text-sm font-semibold tracking-wider uppercase hover:from-champagne-500 hover:to-champagne-400 transition-all duration-300 hover:shadow-[0_0_25px_rgba(201,169,97,0.35)] shadow-lg transform hover:-translate-y-0.5">
                            <span>Submit Partnership Inquiry</span>
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                            </svg>
                        </button>
                        <p class="text-xs text-sovereign-400 mt-4">
                            All submissions are reviewed by our business development team. Qualified inquiries will receive a response within 5-7 business days.
                        </p>
                    </div>

                </form>

            </div>

        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
