/**
 * ============================================
 * UNGGUL AXIOM GROUP - ANIMATION ENGINE
 * ============================================
 * Defensive GSAP + Lenis integration
 * Null-checks prevent console errors on pages without targets
 * ============================================
 */

class SovereignAnimationEngine {
    constructor() {
        this.lenis = null;
        this.isVisible = true;
        this.isMobile = this.detectMobile();
        this.prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        this.init();
    }

    detectMobile() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
               (window.matchMedia && window.matchMedia('(max-width: 768px)').matches);
    }

    initLenis() {
        if (this.prefersReducedMotion) {
            console.log('[Sovereign] Reduced motion detected - Lenis disabled');
            return;
        }

        if (this.isMobile) {
            this.lenis = new Lenis({
                duration: 0.8,
                easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
                orientation: 'vertical',
                smoothWheel: false,
                smoothTouch: false,
            });
        } else {
            this.lenis = new Lenis({
                duration: 1.0,
                easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
                orientation: 'vertical',
                smoothWheel: true,
                smoothTouch: false,
            });
        }

        const raf = (time) => {
            if (this.isVisible && this.lenis) {
                this.lenis.raf(time);
            }
            requestAnimationFrame(raf);
        };
        requestAnimationFrame(raf);
    }

    initScrollReveals() {
        // Register ScrollTrigger plugin safely
        if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
            gsap.registerPlugin(ScrollTrigger);

            if (this.lenis) {
                this.lenis.on('scroll', ScrollTrigger.update);
            }

            if (this.prefersReducedMotion) {
                gsap.set('[data-gsap-fade-up], .gsap-fade-up', { opacity: 1, y: 0 });
                return;
            }

            // High-end entrance reveals: fade-up
            const fadeUpElements = document.querySelectorAll('[data-gsap-fade-up], .gsap-fade-up');
            fadeUpElements.forEach((el) => {
                const delay = parseFloat(el.getAttribute('data-gsap-delay')) || 0;
                gsap.set(el, { opacity: 0, y: 30 });
                gsap.to(el, {
                    opacity: 1,
                    y: 0,
                    duration: 1.2,
                    delay: delay,
                    ease: 'power3.out',
                    scrollTrigger: {
                        trigger: el,
                        start: 'top 88%',
                        toggleActions: 'play none none none'
                    }
                });
            });

            // Line draw effects for separators
            const lineDrawElements = document.querySelectorAll('[data-gsap-line-draw], .gsap-line-draw');
            lineDrawElements.forEach((el) => {
                const delay = parseFloat(el.getAttribute('data-gsap-delay')) || 0;
                gsap.set(el, { scaleX: 0, transformOrigin: 'left center' });
                gsap.to(el, {
                    scaleX: 1,
                    duration: 1.5,
                    delay: delay,
                    ease: 'power4.out',
                    scrollTrigger: {
                        trigger: el,
                        start: 'top 92%',
                        toggleActions: 'play none none none'
                    }
                });
            });
        }
    }

    initVisibilityControl() {
        document.addEventListener('visibilitychange', () => {
            this.isVisible = !document.hidden;
            if (document.hidden && this.lenis) {
                this.lenis.stop();
            } else if (this.lenis) {
                this.lenis.start();
            }
        });
    }

    init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.start());
        } else {
            this.start();
        }
    }

    start() {
        this.initLenis();
        this.initScrollReveals();
        this.initVisibilityControl();

        // Refresh ScrollTrigger after web fonts finish loading to prevent layout-shift trigger misalignment bugs
        if (document.fonts) {
            document.fonts.ready.then(() => {
                if (typeof ScrollTrigger !== 'undefined') {
                    ScrollTrigger.refresh();
                    console.log('[Sovereign] Fonts loaded, refreshed ScrollTrigger');
                }
            });
        }
    }
}

const animationEngine = new SovereignAnimationEngine();
window.SovereignAnimations = animationEngine;
