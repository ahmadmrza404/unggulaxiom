<?php
/**
 * ============================================
 * HEADER PARTIAL - HTML HEAD & OPENING BODY
 * ============================================
 * Purpose: Consistent HTML head across all pages
 * Usage: Include after config.php with $page_title variable set
 * Example:
 *   $page_title = 'About Us';
 *   require_once 'includes/header.php';
 * ============================================
 */

// Ensure config is loaded
if (!defined('SITE_NAME')) {
    die('Configuration not loaded. Include config.php first.');
}

// Load SEO configuration
require_once INCLUDES_PATH . '/seo-config.php';

// Set default page title if not provided
if (!isset($page_title)) {
    $page_title = SITE_NAME;
} else {
    $page_title = esc($page_title) . ' | ' . SITE_NAME;
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <!-- ============================================ -->
    <!-- META TAGS -->
    <!-- ============================================ -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo esc($meta_description); ?>">
    <meta name="keywords" content="<?php echo esc($meta_keywords); ?>">
    <meta name="author" content="<?php echo esc(SITE_NAME); ?>">
    <meta name="geo.region" content="MY">
    <meta name="geo.placename" content="Kuala Lumpur">

    <!-- Open Graph / Social Media -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo url($_SERVER['REQUEST_URI']); ?>">
    <meta property="og:title" content="<?php echo $page_title; ?>">
    <meta property="og:description" content="<?php echo esc($meta_description); ?>">
    <meta property="og:image" content="<?php echo $og_image; ?>">
    <meta property="og:locale" content="en_MY">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $page_title; ?>">
    <meta name="twitter:description" content="<?php echo esc($meta_description); ?>">
    <meta name="twitter:image" content="<?php echo $og_image; ?>">

    <!-- Page Title -->
    <title><?php echo $page_title; ?></title>

    <!-- ============================================ -->
    <!-- FAVICON -->
    <!-- ============================================ -->
    <link rel="icon" type="image/svg+xml" href="<?php echo url('/favicon.svg'); ?>">

    <!-- ============================================ -->
    <!-- TAILWIND CSS CDN WITH CUSTOM CONFIGURATION -->
    <!-- ============================================ -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // CORPORATE COLOR PSYCHOLOGY - Trust, Stability, Premium
        // Navy blue (trust/authority) + warm cream (approachability) + bronze accents (premium)
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        // Deep navy backgrounds - conveys trust, stability, authority
                        obsidian: {
                            950: '#0A1628',
                            900: '#0F1E33',
                            800: '#1A2942',
                            700: '#243651',
                        },
                        // Warm cream text - reduces eye strain, sophisticated
                        platinum: {
                            50: '#F8F6F1',
                            100: '#EDE9E0',
                            200: '#D9D3C5',
                            300: '#B8B0A0',
                        },
                        // Bronze/copper accents - premium, warm, trustworthy
                        champagne: {
                            600: '#B87333',
                            500: '#CD7F32',
                            400: '#D4915A',
                            300: '#E0A876',
                        },
                        // Muted blue-grays - professional supporting colors
                        sovereign: {
                            900: '#2C3E50',
                            800: '#34495E',
                            700: '#4A5F7F',
                            600: '#5D7A9E',
                            500: '#7B93B0',
                            400: '#A0B4C8',
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'system-ui', 'sans-serif'],
                        serif: ['Playfair Display', 'Georgia', 'Cambria', 'serif'],
                    },
                    letterSpacing: {
                        'editorial': '0.02em',
                        'institutional': '0.05em',
                        'sovereign': '0.08em',
                        'ultra-wide': '0.12em',
                    },
                    lineHeight: {
                        'editorial': '1.65',
                        'institutional': '1.75',
                    },
                    fontSize: {
                        'sovereign-xs': ['0.6875rem', { lineHeight: '1.2', letterSpacing: '0.08em' }],
                        'sovereign-sm': ['0.8125rem', { lineHeight: '1.4', letterSpacing: '0.05em' }],
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.8s ease-out',
                        'slide-up': 'slideUp 1s ease-out',
                        'reveal': 'reveal 1.2s cubic-bezier(0.77, 0, 0.175, 1)',
                    },
                    keyframes: {
                        fadeIn: {
                            '0%': { opacity: '0' },
                            '100%': { opacity: '1' },
                        },
                        slideUp: {
                            '0%': { transform: 'translateY(40px)', opacity: '0' },
                            '100%': { transform: 'translateY(0)', opacity: '1' },
                        },
                        reveal: {
                            '0%': { transform: 'translateY(60px)', opacity: '0' },
                            '100%': { transform: 'translateY(0)', opacity: '1' },
                        }
                    }
                }
            }
        }
    </script>

    <!-- ============================================ -->
    <!-- GOOGLE FONTS - INSTITUTIONAL PAIRING -->
    <!-- ============================================ -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400&family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- ============================================ -->
    <!-- GSAP (GREENSOCK) ANIMATION LIBRARY -->
    <!-- ============================================ -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>

    <!-- ============================================ -->
    <!-- ALPINE.JS (Lightweight Reactivity) -->
    <!-- ============================================ -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.5/dist/cdn.min.js"></script>

    <!-- Mobile Menu Script -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var btn = document.getElementById('mobile-menu-btn');
        var closeBtn = document.getElementById('mobile-menu-close');
        var overlay = document.getElementById('mobile-menu-overlay');
        var iconHamburger = document.getElementById('icon-hamburger');
        var iconClose = document.getElementById('icon-close');

        if (!btn || !overlay) return;

        function openMenu() {
            overlay.classList.remove('hidden');
            overlay.style.display = 'block';
            iconHamburger.classList.add('hidden');
            iconClose.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }

        function closeMenu() {
            overlay.classList.add('hidden');
            overlay.style.display = 'none';
            iconHamburger.classList.remove('hidden');
            iconClose.classList.add('hidden');
            document.body.style.overflow = '';
        }

        btn.addEventListener('click', function() {
            if (overlay.classList.contains('hidden')) {
                openMenu();
            } else {
                closeMenu();
            }
        });

        if (closeBtn) closeBtn.addEventListener('click', closeMenu);

        overlay.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('click', closeMenu);
        });

        // Floating Nav Scroll Class
        var navContainer = document.querySelector('.floating-nav-container');
        if (navContainer) {
            function handleScroll() {
                if (window.scrollY > 20) {
                    navContainer.classList.add('scrolled', 'lg:top-2');
                    navContainer.classList.remove('lg:top-4');
                } else {
                    navContainer.classList.remove('scrolled', 'lg:top-2');
                    navContainer.classList.add('lg:top-4');
                }
            }
            window.addEventListener('scroll', handleScroll);
            handleScroll(); // Initial check
        }
    });
    </script>

    <!-- ============================================ -->
    <!-- GLOBAL DESIGN SYSTEM STYLES -->
    <!-- ============================================ -->
    <link rel="stylesheet" href="<?php echo url('/assets/css/styles.css'); ?>">
    <link rel="stylesheet" href="<?php echo url('/assets/css/custom.css'); ?>">
    <link rel="stylesheet" href="<?php echo url('/assets/css/micro-interactions.css'); ?>">
</head>

<!-- ============================================ -->
<!-- BODY TAG - Light Background -->
<!-- ============================================ -->
<body class="bg-obsidian-950 text-platinum-50 font-sans antialiased">

    <!-- ============================================ -->
    <!-- INSTITUTIONAL NAVIGATION -->
    <!-- ============================================ -->
    <nav class="floating-nav-container fixed top-0 lg:top-4 left-1/2 -translate-x-1/2 w-full lg:w-[calc(100%-2rem)] max-w-7xl z-40 bg-obsidian-900/90 backdrop-blur-md border-b lg:border border-champagne-500/10 lg:rounded-xl transition-all duration-300">
        <div class="container-sovereign">
            <div class="flex items-center justify-between h-20">

                <!-- LOGO / BRAND MARK -->
                <a href="<?php echo route('home'); ?>" class="flex items-center space-x-3 group">
                    <img src="<?php echo url('/favicon.svg'); ?>" alt="Unggul Axiom" class="h-10 w-auto transition-opacity duration-300 group-hover:opacity-80">
                    <span class="font-serif text-xl tracking-institutional text-platinum-50 transition-colors duration-300 group-hover:text-champagne-400">
                        UNGGUL AXIOM
                    </span>
                </a>

                <!-- DESKTOP NAVIGATION -->
                <div class="hidden lg:flex items-center space-x-8">
                    <!-- Primary Navigation Links -->
                    <a href="<?php echo route('about'); ?>"
                       class="<?php echo nav_link_classes('about'); ?>">
                        About
                    </a>
                    <a href="<?php echo route('systems'); ?>"
                       class="<?php echo nav_link_classes('systems'); ?>">
                        Systems
                    </a>
                    <a href="<?php echo route('sectors'); ?>"
                       class="<?php echo nav_link_classes('sectors'); ?>">
                        Sectors
                    </a>
                    <a href="<?php echo route('cipu'); ?>"
                       class="<?php echo nav_link_classes('cipu'); ?>">
                        CIPU
                    </a>
                    <a href="<?php echo route('capital'); ?>"
                       class="<?php echo nav_link_classes('capital'); ?>">
                        Capital
                    </a>
                    <a href="<?php echo route('governance'); ?>"
                       class="<?php echo nav_link_classes('governance'); ?>">
                        Governance
                    </a>
                    <a href="<?php echo route('contact'); ?>"
                       class="<?php echo nav_link_classes('contact'); ?>">
                        Contact
                    </a>

                    <!-- CTA Button -->
                    <a href="<?php echo url('/investor-landing'); ?>"
                       class="px-6 py-2.5 bg-champagne-500 text-obsidian-950 text-sm font-semibold hover:bg-champagne-400 transition-all duration-300 rounded btn-shine-hover shadow-lg shadow-champagne-500/10 hover:shadow-champagne-500/20">
                        Investor Relations
                    </a>
                </div>

                <!-- MOBILE MENU TRIGGER -->
                <button id="mobile-menu-btn"
                        class="lg:hidden p-2 text-platinum-200 hover:text-champagne-400 transition-colors duration-300"
                        aria-label="Toggle mobile menu">
                    <svg id="icon-hamburger" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="square" stroke-linejoin="miter" stroke-width="1.5" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                    <svg id="icon-close" class="w-6 h-6 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="square" stroke-linejoin="miter" stroke-width="1.5" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
    </nav>

    <!-- MOBILE MENU OVERLAY (outside nav so it covers full viewport) -->
    <div id="mobile-menu-overlay"
         class="hidden lg:hidden"
         style="position:fixed;top:0;left:0;width:100%;height:100%;background:#0d0d14;z-index:9999;overflow-y:auto;">

        <!-- Close button -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding:20px 32px;border-bottom:1px solid rgba(197,160,81,0.2);">
            <span style="font-family:serif;font-size:1.1rem;color:#f0ebe0;letter-spacing:0.15em;">UNGGUL AXIOM</span>
            <button id="mobile-menu-close" style="color:#c5a051;background:none;border:none;cursor:pointer;padding:8px;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
                    <path stroke-linecap="square" stroke-linejoin="miter" stroke-width="1.5" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>

        <div style="display:flex;flex-direction:column;padding:40px 32px;gap:28px;">
            <a href="<?php echo route('about'); ?>" style="font-family:serif;font-size:1.75rem;color:#f0ebe0;text-decoration:none;letter-spacing:0.02em;border-bottom:1px solid rgba(197,160,81,0.1);padding-bottom:28px;">About</a>
            <a href="<?php echo route('systems'); ?>" style="font-family:serif;font-size:1.75rem;color:#f0ebe0;text-decoration:none;letter-spacing:0.02em;border-bottom:1px solid rgba(197,160,81,0.1);padding-bottom:28px;">Systems</a>
            <a href="<?php echo route('sectors'); ?>" style="font-family:serif;font-size:1.75rem;color:#f0ebe0;text-decoration:none;letter-spacing:0.02em;border-bottom:1px solid rgba(197,160,81,0.1);padding-bottom:28px;">Sectors</a>
            <a href="<?php echo route('cipu'); ?>" style="font-family:serif;font-size:1.75rem;color:#f0ebe0;text-decoration:none;letter-spacing:0.02em;border-bottom:1px solid rgba(197,160,81,0.1);padding-bottom:28px;">CIPU</a>
            <a href="<?php echo route('capital'); ?>" style="font-family:serif;font-size:1.75rem;color:#f0ebe0;text-decoration:none;letter-spacing:0.02em;border-bottom:1px solid rgba(197,160,81,0.1);padding-bottom:28px;">Capital</a>
            <a href="<?php echo route('governance'); ?>" style="font-family:serif;font-size:1.75rem;color:#f0ebe0;text-decoration:none;letter-spacing:0.02em;border-bottom:1px solid rgba(197,160,81,0.1);padding-bottom:28px;">Governance</a>
            <a href="<?php echo route('contact'); ?>" style="font-family:serif;font-size:1.75rem;color:#f0ebe0;text-decoration:none;letter-spacing:0.02em;">Contact</a>
        </div>

        <div style="margin:0 32px;padding-top:32px;border-top:1px solid rgba(197,160,81,0.2);">
            <a href="<?php echo url('/investor-landing'); ?>"
               style="display:block;width:100%;padding:16px;text-align:center;background:#c5a051;color:#0d0d14;font-weight:700;font-size:0.875rem;text-decoration:none;border-radius:2px;letter-spacing:0.08em;">
                INVESTOR RELATIONS
            </a>
        </div>

        <div style="text-align:center;padding:32px;color:#6b7280;font-size:0.7rem;letter-spacing:0.15em;">
            KUALA LUMPUR, MALAYSIA
        </div>
    </div>

    <!-- SPACER FOR FIXED NAVIGATION -->
    <div class="h-20"></div>
