<?php
/**
 * ============================================
 * LEADERSHIP PROFILE - EXECUTIVE DOSSIER
 * ============================================
 * Purpose: Comprehensive executive profile
 * ============================================
 */

require_once __DIR__ . '/config.php';

$member_id = $_GET['id'] ?? '';
$leadership_data = json_decode(file_get_contents(__DIR__ . '/data/leadership.json'), true);

$member = null;
$member_group = '';

$all_groups = ['board_of_directors', 'executives', 'senior_management', 'department_heads',
               'operations', 'finance', 'legal_compliance', 'human_resources',
               'technology', 'marketing_communications', 'business_development', 'advisors'];

foreach ($all_groups as $group) {
    if (!empty($leadership_data[$group])) {
        foreach ($leadership_data[$group] as $person) {
            if ($person['id'] === $member_id) {
                $member = $person;
                $member_group = $group;
                break 2;
            }
        }
    }
}

if (!$member) {
    header('Location: leadership.php');
    exit;
}

$profile_file = __DIR__ . '/data/profiles/' . $member_id . '.json';
$profile = file_exists($profile_file) ? json_decode(file_get_contents($profile_file), true) : [];

$page_title = $member['name'] . ' - Leadership';

require_once INCLUDES_PATH . '/header.php';
?>

<<!-- EXECUTIVE HEADER -->
<section class="py-24 bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign relative z-10">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">

            <!-- Executive Portrait -->
            <div class="lg:col-span-4 gsap-fade-up">
                <div class="glass-panel p-3 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <?php if (!empty($member['image']) && file_exists(__DIR__ . '/' . $member['image'])): ?>
                    <div class="aspect-[3/4] rounded-xl overflow-hidden bg-obsidian-900 relative z-10">
                        <img src="<?= htmlspecialchars($member['image']) ?>" alt="<?= htmlspecialchars($member['name']) ?>" class="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700">
                    </div>
                    <?php else: ?>
                    <div class="aspect-[3/4] rounded-xl bg-obsidian-900/80 border border-champagne-500/10 flex items-center justify-center relative z-10">
                        <span class="font-serif text-7xl text-champagne-600/30"><?= !empty($member['name']) ? strtoupper(substr($member['name'], 0, 1)) : 'U' ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Executive Information -->
            <div class="lg:col-span-8 gsap-fade-up">
                <p class="font-mono text-xs text-champagne-500 tracking-[0.25em] uppercase mb-4"><?= htmlspecialchars($member['id']) ?></p>

                <h1 class="font-serif text-4xl md:text-5xl lg:text-6xl text-platinum-50 mb-3 tracking-tight font-extrabold leading-tight">
                    <?= htmlspecialchars($member['name']) ?>
                </h1>

                <h2 class="text-xl md:text-2xl text-champagne-400 font-medium mb-6 tracking-wide">
                    <?= htmlspecialchars($member['title']) ?>
                </h2>

                <div class="w-16 h-0.5 bg-champagne-500 mb-8"></div>

                <p class="text-base md:text-lg text-sovereign-300 leading-institutional mb-8 max-w-3xl">
                    <?= htmlspecialchars($member['description']) ?>
                </p>

                <!-- Executive Contact -->
                <div class="flex flex-wrap gap-4">
                    <?php if (!empty($member['email'])): ?>
                    <a href="mailto:<?= htmlspecialchars($member['email']) ?>" class="inline-flex items-center gap-3 px-6 py-3.5 bg-obsidian-950/40 border border-champagne-500/15 hover:border-champagne-500/40 text-platinum-50 hover:text-champagne-400 text-sm tracking-wide rounded-lg transition-all duration-300 hover:shadow-[0_0_15px_rgba(201,169,97,0.05)]">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/></svg>
                        <span>Email Address</span>
                    </a>
                    <?php endif; ?>

                    <?php if (!empty($member['linkedin'])): ?>
                    <a href="<?= htmlspecialchars($member['linkedin']) ?>" target="_blank" class="inline-flex items-center gap-3 px-6 py-3.5 bg-obsidian-950/40 border border-champagne-500/15 hover:border-champagne-500/40 text-platinum-50 hover:text-champagne-400 text-sm tracking-wide rounded-lg transition-all duration-300 hover:shadow-[0_0_15px_rgba(201,169,97,0.05)]">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M16.338 16.338H13.67V12.16c0-.995-.017-2.277-1.387-2.277-1.39 0-1.601 1.086-1.601 2.207v4.248H8.014v-8.59h2.559v1.174h.037c.356-.675 1.227-1.387 2.526-1.387 2.703 0 3.203 1.778 3.203 4.092v4.711zM5.005 6.575a1.548 1.548 0 11-.003-3.096 1.548 1.548 0 01.003 3.096zm-1.337 9.763H6.34v-8.59H3.667v8.59zM17.668 1H2.328C1.595 1 1 1.581 1 2.298v15.403C1 18.418 1.595 19 2.328 19h15.34c.734 0 1.332-.582 1.332-1.299V2.298C19 1.581 18.402 1 17.668 1z"/></svg>
                        <span>LinkedIn Network</span>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- EXECUTIVE PROFILE -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-6xl mx-auto">

            <?php if (!empty($profile['biography'])): ?>
            <!-- Executive Summary -->
            <div class="mb-20 glass-panel p-8 md:p-12 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6 uppercase">
                        EXECUTIVE DOSSIER
                    </span>
                    <p class="text-base md:text-lg text-platinum-100 leading-institutional whitespace-pre-line">
                        <?= htmlspecialchars($profile['biography']) ?>
                    </p>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">

                <!-- Left Column -->
                <div class="space-y-12">

                    <?php if (!empty($profile['experience'])): ?>
                    <!-- Career Trajectory -->
                    <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                        <div class="relative z-10">
                            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-8 uppercase">
                                CAREER TRAJECTORY
                            </span>
                            <div class="space-y-8 relative">
                                <!-- Vertical Timeline Line -->
                                <div class="absolute left-3 top-2 bottom-2 w-0.5 bg-champagne-500/10"></div>

                                <?php foreach ($profile['experience'] as $exp): ?>
                                <div class="relative pl-10">
                                    <!-- Bullet -->
                                    <div class="absolute left-2 top-1.5 w-2.5 h-2.5 bg-champagne-500 rounded-full ring-4 ring-obsidian-950 border border-champagne-500/30"></div>
                                    
                                    <div class="flex justify-between items-start mb-2 gap-4">
                                        <h4 class="font-serif text-lg text-platinum-50 font-bold">
                                            <?= htmlspecialchars($exp['position']) ?>
                                        </h4>
                                        <?php if (!empty($exp['period'])): ?>
                                        <span class="font-mono text-xs text-champagne-500 font-semibold tracking-wider flex-shrink-0">
                                            <?= htmlspecialchars($exp['period']) ?>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <p class="text-sm text-champagne-400/80 mb-3 font-semibold">
                                        <?= htmlspecialchars($exp['company']) ?>
                                    </p>
                                    <?php if (!empty($exp['description'])): ?>
                                    <p class="text-sm text-sovereign-300 leading-relaxed">
                                        <?= htmlspecialchars($exp['description']) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($profile['education'])): ?>
                    <!-- Academic Credentials -->
                    <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                        <div class="relative z-10">
                            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-8 uppercase">
                                ACADEMIC CREDENTIALS
                            </span>
                            <div class="space-y-6">
                                <?php foreach ($profile['education'] as $edu): ?>
                                <div class="p-6 rounded-xl bg-obsidian-950/40 border border-champagne-500/10 hover:border-champagne-500/25 transition-all duration-300">
                                    <h4 class="font-serif text-base text-platinum-50 mb-2 font-bold">
                                        <?= htmlspecialchars($edu['degree']) ?>
                                    </h4>
                                    <p class="text-sm text-champagne-400 mb-2 font-semibold">
                                        <?= htmlspecialchars($edu['institution']) ?>
                                    </p>
                                    <?php if (!empty($edu['year'])): ?>
                                    <p class="font-mono text-xs text-sovereign-400">
                                        Class of <?= htmlspecialchars($edu['year']) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>

                <!-- Right Column -->
                <div class="space-y-12">

                    <?php if (!empty($profile['achievements'])): ?>
                    <!-- Strategic Achievements -->
                    <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                        <div class="relative z-10">
                            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-8 uppercase">
                                STRATEGIC ACHIEVEMENTS
                            </span>
                            <div class="space-y-4">
                                <?php foreach ($profile['achievements'] as $achievement): ?>
                                <div class="flex gap-4">
                                    <div class="w-1.5 h-1.5 bg-champagne-500 rounded-full mt-2.5 flex-shrink-0"></div>
                                    <p class="text-sm md:text-base text-sovereign-300 leading-relaxed">
                                        <?= htmlspecialchars($achievement) ?>
                                    </p>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($profile['certifications'])): ?>
                    <!-- Professional Certifications -->
                    <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                        <div class="relative z-10">
                            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-8 uppercase">
                                PROFESSIONAL CERTIFICATIONS
                            </span>
                            <div class="space-y-4">
                                <?php foreach ($profile['certifications'] as $cert): ?>
                                <div class="p-5 rounded-xl bg-obsidian-950/40 border border-champagne-500/10 hover:border-champagne-500/25 transition-all duration-300">
                                    <h4 class="text-base text-platinum-50 font-bold mb-2">
                                        <?= htmlspecialchars($cert['name']) ?>
                                    </h4>
                                    <p class="text-sm text-champagne-400 mb-2 font-semibold">
                                        <?= htmlspecialchars($cert['issuer']) ?>
                                    </p>
                                    <?php if (!empty($cert['year'])): ?>
                                    <p class="font-mono text-xs text-sovereign-400">
                                        Issued: <?= htmlspecialchars($cert['year']) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($profile['expertise'])): ?>
                    <!-- Core Competencies -->
                    <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                        <div class="relative z-10">
                            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-8 uppercase">
                                CORE COMPETENCIES
                            </span>
                            <div class="flex flex-wrap gap-2.5">
                                <?php foreach ($profile['expertise'] as $skill): ?>
                                <span class="px-4 py-2 bg-obsidian-950/60 border border-champagne-500/15 text-xs md:text-sm text-platinum-200 tracking-wide rounded-md hover:border-champagne-500/35 transition-colors duration-300">
                                    <?= htmlspecialchars($skill) ?>
                                </span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>

            </div>

        </div>
    </div>
</section>

<!-- NAVIGATION -->
<section class="py-12 bg-obsidian-950 border-t border-champagne-500/10 relative overflow-hidden isolate">
    <div class="container-sovereign">
        <a href="leadership.php" class="inline-flex items-center gap-3 text-sm text-champagne-500 hover:text-champagne-400 transition-colors tracking-wide font-medium group">
            <svg class="w-4 h-4 transform group-hover:-translate-x-1.5 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
            <span>Return to Command Structure</span>
        </a>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
