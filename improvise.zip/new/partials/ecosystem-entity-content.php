<?php
/**
 * Shared render template for all 5 ecosystem entity pages.
 * Caller must set $__entity_data before including this file.
 * $__entity_data = json_decode(file_get_contents(...), true);
 */
$_d = $__entity_data;
?>

<!-- HERO SECTION -->
<section class="min-h-[50vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-4xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                <?= htmlspecialchars($_d['hero']['label']) ?>
            </span>
            <h1 class="font-serif text-5xl md:text-6xl text-platinum-50 mb-6 tracking-editorial leading-tight font-extrabold">
                <?= htmlspecialchars($_d['hero']['title']) ?>
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto">
                <?= htmlspecialchars($_d['hero']['tagline']) ?>
            </p>
        </div>
    </div>
</section>

<!-- CONTENT SECTIONS -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-4xl mx-auto space-y-8">

            <?php foreach ($_d['sections'] as $section): ?>
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        <?= htmlspecialchars($section['title']) ?>
                    </h2>

                    <?php if (!empty($section['subsections'])): ?>
                        <?php if (!empty($section['paragraphs'])): ?>
                            <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed mb-6">
                                <?php foreach ($section['paragraphs'] as $para): ?>
                                    <p><?= htmlspecialchars($para) ?></p>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <div class="space-y-6 text-sm md:text-base text-platinum-200 leading-relaxed">
                            <?php foreach ($section['subsections'] as $sub): ?>
                            <div class="pt-4 border-t border-champagne-500/10">
                                <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold"><?= htmlspecialchars($sub['subtitle']) ?></h3>
                                <p><?= htmlspecialchars($sub['text']) ?></p>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                            <?php foreach ($section['paragraphs'] as $para): ?>
                                <p><?= htmlspecialchars($para) ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>

        </div>
    </div>
</section>
