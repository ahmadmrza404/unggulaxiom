<section class="py-32 bg-gradient-to-b from-obsidian-900 to-obsidian-950 border-t border-champagne-500/10 relative overflow-hidden isolate">

    <div class="tech-grid absolute inset-0 opacity-10 pointer-events-none"></div>
    <div class="ambient-spotlight -top-40 right-20 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- REPLICATION HEADER -->
        <div class="mb-16 gsap-fade-up">
            <div class="flex flex-col md:flex-row md:items-center gap-6 mb-6">
                <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide uppercase">
                    REPLICATION
                </span>
                <div class="hidden md:block flex-1 h-px bg-champagne-500/20"></div>
                <span class="text-xs text-champagne-500/60 font-mono tracking-wider flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-champagne-500/60"></span>PHASE II — NATIONAL DEPLOYMENT</span>
            </div>
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div class="lg:col-span-8">
                    <h3 class="text-4xl font-serif text-platinum-50 leading-tight mb-4 font-bold">
                        Nationwide Expansion <span class="text-champagne-400">Across Malaysia</span>
                    </h3>
                    <p class="text-base text-sovereign-300 max-w-xl leading-relaxed">
                        Strategic poultry production expansion framework designed for nationwide deployment across key Malaysian regions — engineered for sovereign-grade scale, operational consistency, and 100% halal-certified output at every facility.
                    </p>
                </div>
                <div class="lg:col-span-4 grid grid-cols-2 gap-4">
                    <div class="glass-panel border border-champagne-500/15 p-5 rounded-xl hover:border-champagne-500/35 transition-all duration-300">
                        <div class="text-[0.65rem] text-champagne-500 font-mono uppercase tracking-widest mb-2">Phase I</div>
                        <div class="text-lg font-mono font-bold text-platinum-50">Kelantan</div>
                        <div class="text-[0.65rem] text-sovereign-400 mt-1">Operational · 2024</div>
                        <div class="w-2 h-2 bg-green-400 rounded-full mt-3 inline-block" style="box-shadow: 0 0 10px rgba(74, 222, 128, 0.7)"></div>
                    </div>
                    <div class="glass-panel border border-champagne-500/15 p-5 rounded-xl hover:border-champagne-500/35 transition-all duration-300">
                        <div class="text-[0.65rem] text-champagne-500 font-mono uppercase tracking-widest mb-2">Phase II</div>
                        <div class="text-lg font-mono font-bold text-platinum-50">7–11 Sites</div>
                        <div class="text-[0.65rem] text-sovereign-400 mt-1">Planning · 2026–2029</div>
                        <div class="w-2 h-2 bg-champagne-500 rounded-full mt-3 inline-block" style="box-shadow: 0 0 10px rgba(212,175,55,0.7)"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- GRAPHS + RIGHT PANEL -->
        <div class="grid grid-cols-1 xl:grid-cols-5 gap-8 mb-16">

            <!-- PRODUCTION CAPACITY & REGIONAL GRAPHS — 3/5 width -->
            <div class="xl:col-span-3 space-y-6">

                <!-- Production Capacity Growth Chart -->
                <div class="gsap-fade-up">
                    <div class="glass-panel rounded-2xl border border-champagne-500/15 overflow-hidden shadow-2xl relative" style="background: radial-gradient(ellipse at 30% 40%, rgba(212,175,55,0.03) 0%, transparent 70%), rgba(10,22,40,0.5);">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>

                        <!-- Chart header -->
                        <div class="flex items-center justify-between px-6 py-4 border-b border-champagne-500/15 relative z-10">
                            <div class="flex items-center gap-3">
                                <div class="w-2 h-2 rounded-full bg-champagne-500" style="box-shadow:0 0 8px rgba(212,175,55,0.8)"></div>
                                <span class="text-xs font-mono text-sovereign-300 tracking-wider">PRODUCTION CAPACITY PROJECTION</span>
                            </div>
                            <div class="text-[0.65rem] font-mono text-champagne-500/70 tracking-widest">MILLION BIRDS/YEAR</div>
                        </div>

                        <!-- Bar Chart SVG -->
                        <div class="p-8 relative z-10">
                            <svg viewBox="0 0 800 400" class="w-full" xmlns="http://www.w3.org/2000/svg">
                                <defs>
                                    <linearGradient id="barGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                                        <stop offset="0%" stop-color="rgba(212,175,55,0.8)"/>
                                        <stop offset="100%" stop-color="rgba(212,175,55,0.3)"/>
                                    </linearGradient>
                                    <filter id="barGlow">
                                        <feGaussianBlur stdDeviation="3" result="blur"/>
                                        <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
                                    </filter>
                                </defs>

                                <!-- Grid lines -->
                                <line x1="80" y1="50" x2="80" y2="320" stroke="rgba(212,175,55,0.2)" stroke-width="1"/>
                                <line x1="80" y1="320" x2="750" y2="320" stroke="rgba(212,175,55,0.2)" stroke-width="1"/>

                                <!-- Horizontal grid -->
                                <line x1="80" y1="270" x2="750" y2="270" stroke="rgba(212,175,55,0.05)" stroke-width="1" stroke-dasharray="4,4"/>
                                <line x1="80" y1="220" x2="750" y2="220" stroke="rgba(212,175,55,0.05)" stroke-width="1" stroke-dasharray="4,4"/>
                                <line x1="80" y1="170" x2="750" y2="170" stroke="rgba(212,175,55,0.05)" stroke-width="1" stroke-dasharray="4,4"/>
                                <line x1="80" y1="120" x2="750" y2="120" stroke="rgba(212,175,55,0.05)" stroke-width="1" stroke-dasharray="4,4"/>
                                <line x1="80" y1="70" x2="750" y2="70" stroke="rgba(212,175,55,0.05)" stroke-width="1" stroke-dasharray="4,4"/>

                                <!-- Y-axis labels -->
                                <text x="70" y="325" fill="rgba(212,175,55,0.5)" font-size="11" font-family="monospace" text-anchor="end">0</text>
                                <text x="70" y="275" fill="rgba(212,175,55,0.5)" font-size="11" font-family="monospace" text-anchor="end">30M</text>
                                <text x="70" y="225" fill="rgba(212,175,55,0.5)" font-size="11" font-family="monospace" text-anchor="end">60M</text>
                                <text x="70" y="175" fill="rgba(212,175,55,0.5)" font-size="11" font-family="monospace" text-anchor="end">90M</text>
                                <text x="70" y="125" fill="rgba(212,175,55,0.5)" font-size="11" font-family="monospace" text-anchor="end">120M</text>
                                <text x="70" y="75" fill="rgba(212,175,55,0.5)" font-size="11" font-family="monospace" text-anchor="end">150M</text>

                                <!-- Bars with animation -->
                                <!-- 2024 - Kelantan Phase I: 12M -->
                                <rect x="120" y="280" width="80" height="40" fill="url(#barGradient)" filter="url(#barGlow)" opacity="0">
                                    <animate attributeName="opacity" from="0" to="1" dur="0.5s" begin="0.2s" fill="freeze"/>
                                    <animate attributeName="height" from="0" to="40" dur="0.8s" begin="0.2s" fill="freeze"/>
                                    <animate attributeName="y" from="320" to="280" dur="0.8s" begin="0.2s" fill="freeze"/>
                                </rect>
                                <text x="160" y="270" fill="#F4E4C1" font-size="12" font-family="monospace" font-weight="600" text-anchor="middle">12M</text>
                                <text x="160" y="345" fill="rgba(212,175,55,0.7)" font-size="11" font-family="monospace" text-anchor="middle">2024</text>
                                <text x="160" y="360" fill="rgba(212,175,55,0.5)" font-size="9" font-family="monospace" text-anchor="middle">Kelantan</text>

                                <!-- 2026 - Phase II Start: 36M -->
                                <rect x="240" y="220" width="80" height="100" fill="url(#barGradient)" filter="url(#barGlow)" opacity="0">
                                    <animate attributeName="opacity" from="0" to="1" dur="0.5s" begin="0.4s" fill="freeze"/>
                                    <animate attributeName="height" from="0" to="100" dur="0.8s" begin="0.4s" fill="freeze"/>
                                    <animate attributeName="y" from="320" to="220" dur="0.8s" begin="0.4s" fill="freeze"/>
                                </rect>
                                <text x="280" y="210" fill="#F4E4C1" font-size="12" font-family="monospace" font-weight="600" text-anchor="middle">36M</text>
                                <text x="280" y="345" fill="rgba(212,175,55,0.7)" font-size="11" font-family="monospace" text-anchor="middle">2026</text>
                                <text x="280" y="360" fill="rgba(212,175,55,0.5)" font-size="9" font-family="monospace" text-anchor="middle">+3 Sites</text>

                                <!-- 2027 - Expansion: 72M -->
                                <rect x="360" y="140" width="80" height="180" fill="url(#barGradient)" filter="url(#barGlow)" opacity="0">
                                    <animate attributeName="opacity" from="0" to="1" dur="0.5s" begin="0.6s" fill="freeze"/>
                                    <animate attributeName="height" from="0" to="180" dur="0.8s" begin="0.6s" fill="freeze"/>
                                    <animate attributeName="y" from="320" to="140" dur="0.8s" begin="0.6s" fill="freeze"/>
                                </rect>
                                <text x="400" y="130" fill="#F4E4C1" font-size="12" font-family="monospace" font-weight="600" text-anchor="middle">72M</text>
                                <text x="400" y="345" fill="rgba(212,175,55,0.7)" font-size="11" font-family="monospace" text-anchor="middle">2027</text>
                                <text x="400" y="360" fill="rgba(212,175,55,0.5)" font-size="9" font-family="monospace" text-anchor="middle">+3 Sites</text>

                                <!-- 2028 - Peak: 108M -->
                                <rect x="480" y="90" width="80" height="230" fill="url(#barGradient)" filter="url(#barGlow)" opacity="0">
                                    <animate attributeName="opacity" from="0" to="1" dur="0.5s" begin="0.8s" fill="freeze"/>
                                    <animate attributeName="height" from="0" to="230" dur="0.8s" begin="0.8s" fill="freeze"/>
                                    <animate attributeName="y" from="320" to="90" dur="0.8s" begin="0.8s" fill="freeze"/>
                                </rect>
                                <text x="520" y="80" fill="#F4E4C1" font-size="12" font-family="monospace" font-weight="600" text-anchor="middle">108M</text>
                                <text x="520" y="345" fill="rgba(212,175,55,0.7)" font-size="11" font-family="monospace" text-anchor="middle">2028</text>
                                <text x="520" y="360" fill="rgba(212,175,55,0.5)" font-size="9" font-family="monospace" text-anchor="middle">+2 Sites</text>

                                <!-- 2029 - Full Capacity: 132M -->
                                <rect x="600" y="60" width="80" height="260" fill="url(#barGradient)" filter="url(#barGlow)" opacity="0">
                                    <animate attributeName="opacity" from="0" to="1" dur="0.5s" begin="1s" fill="freeze"/>
                                    <animate attributeName="height" from="0" to="260" dur="0.8s" begin="1s" fill="freeze"/>
                                    <animate attributeName="y" from="320" to="60" dur="0.8s" begin="1s" fill="freeze"/>
                                </rect>
                                <text x="640" y="50" fill="#F4E4C1" font-size="12" font-family="monospace" font-weight="600" text-anchor="middle">132M</text>
                                <text x="640" y="345" fill="rgba(212,175,55,0.7)" font-size="11" font-family="monospace" text-anchor="middle">2029</text>
                                <text x="640" y="360" fill="rgba(212,175,55,0.5)" font-size="9" font-family="monospace" text-anchor="middle">Full Scale</text>

                                <!-- Growth trend line -->
                                <polyline points="160,300 280,240 400,160 520,110 640,80"
                                          fill="none"
                                          stroke="rgba(212,175,55,0.4)"
                                          stroke-width="2"
                                          stroke-dasharray="5,5"
                                          opacity="0">
                                    <animate attributeName="opacity" from="0" to="1" dur="0.5s" begin="1.2s" fill="freeze"/>
                                </polyline>
                            </svg>
                        </div>

                        <!-- Chart footer -->
                        <div class="px-6 py-4 border-t border-champagne-500/15 bg-obsidian-950/80 relative z-10">
                            <div class="flex items-center justify-between text-xs">
                                <span class="text-soveraing-400 font-mono">11x growth from Phase I to full deployment</span>
                                <span class="text-champagne-500 font-mono">CAGR: 62%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Regional Deployment Matrix (Replacing Inaccurate SVG Map) — 2/5 width -->
            <div class="xl:col-span-2 gsap-fade-up">
                <div class="glass-panel rounded-2xl border border-champagne-500/15 overflow-hidden shadow-2xl relative h-full" style="background: radial-gradient(ellipse at 70% 60%, rgba(212,175,55,0.03) 0%, transparent 70%), rgba(10,22,40,0.5);">
                        <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>

                        <!-- Header -->
                        <div class="flex items-center justify-between px-6 py-5 border-b border-champagne-500/15 relative z-10">
                            <div class="flex items-center gap-3">
                                <div class="w-2 h-2 rounded-full bg-champagne-500" style="box-shadow:0 0 8px rgba(212,175,55,0.8)"></div>
                                <span class="text-xs font-mono text-sovereign-300 tracking-wider uppercase">REGIONAL DEPLOYMENT MATRIX</span>
                            </div>
                            <div class="text-[0.65rem] font-mono text-champagne-500/70 tracking-widest">NATIONWIDE STRATEGIC HUBS</div>
                        </div>

                        <!-- Dossier Grid -->
                        <div class="p-8 relative z-10 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-1 gap-6">
                            
                            <!-- Hub 1 -->
                            <div class="p-5 rounded-xl bg-obsidian-950/40 border border-champagne-500/10 hover:border-champagne-500/30 transition-all duration-300 flex flex-col justify-between">
                                <div>
                                    <div class="flex items-center justify-between mb-3">
                                        <span class="text-[0.65rem] font-mono text-green-400 font-semibold tracking-wider flex items-center gap-1.5">
                                            <span class="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>OPERATIONAL · PHASE I
                                        </span>
                                        <span class="text-xs font-mono text-champagne-500">12M birds/yr</span>
                                    </div>
                                    <h4 class="text-lg font-serif text-platinum-50 font-bold mb-1">East Coast Hub (Kelantan)</h4>
                                    <p class="text-xs text-sovereign-400 mb-4">Core pilot asset validating industrial scale, sovereign food security, and regional feed supply alignment.</p>
                                </div>
                                <div class="border-t border-champagne-500/5 pt-3 mt-auto flex items-center justify-between text-[0.65rem] font-mono text-sovereign-500">
                                    <span>Focus: Halal Export Base</span>
                                    <span>Est. Capex: RM15M</span>
                                </div>
                            </div>

                            <!-- Hub 2 -->
                            <div class="p-5 rounded-xl bg-obsidian-950/40 border border-champagne-500/10 hover:border-champagne-500/30 transition-all duration-300 flex flex-col justify-between">
                                <div>
                                    <div class="flex items-center justify-between mb-3">
                                        <span class="text-[0.65rem] font-mono text-champagne-500/80 font-semibold tracking-wider flex items-center gap-1.5">
                                            <span class="w-1.5 h-1.5 rounded-full bg-champagne-500/60"></span>PLANNED · PHASE II
                                        </span>
                                        <span class="text-xs font-mono text-champagne-500">36M birds/yr</span>
                                    </div>
                                    <h4 class="text-lg font-serif text-platinum-50 font-bold mb-1">Southern Corridor (Johor)</h4>
                                    <p class="text-xs text-sovereign-400 mb-4">Strategic cross-border trade facility providing direct market access to Singapore and southern metropolitan areas.</p>
                                </div>
                                <div class="border-t border-champagne-500/5 pt-3 mt-auto flex items-center justify-between text-[0.65rem] font-mono text-sovereign-500">
                                    <span>Focus: Cross-Border Logistics</span>
                                    <span>Est. Capex: RM45M</span>
                                </div>
                            </div>

                            <!-- Hub 3 -->
                            <div class="p-5 rounded-xl bg-obsidian-950/40 border border-champagne-500/10 hover:border-champagne-500/30 transition-all duration-300 flex flex-col justify-between">
                                <div>
                                    <div class="flex items-center justify-between mb-3">
                                        <span class="text-[0.65rem] font-mono text-champagne-500/80 font-semibold tracking-wider flex items-center gap-1.5">
                                            <span class="w-1.5 h-1.5 rounded-full bg-champagne-500/60"></span>PLANNED · PHASE II
                                        </span>
                                        <span class="text-xs font-mono text-champagne-500">36M birds/yr</span>
                                    </div>
                                    <h4 class="text-lg font-serif text-platinum-50 font-bold mb-1">Northern Hub (Perak / Kedah)</h4>
                                    <p class="text-xs text-sovereign-400 mb-4">High-efficiency processing cluster integrated with regional grain ports and feedmill infrastructure.</p>
                                </div>
                                <div class="border-t border-champagne-500/5 pt-3 mt-auto flex items-center justify-between text-[0.65rem] font-mono text-sovereign-500">
                                    <span>Focus: Feedmill Integration</span>
                                    <span>Est. Capex: RM40M</span>
                                </div>
                            </div>

                            <!-- Hub 4 -->
                            <div class="p-5 rounded-xl bg-obsidian-950/40 border border-champagne-500/10 hover:border-champagne-500/30 transition-all duration-300 flex flex-col justify-between">
                                <div>
                                    <div class="flex items-center justify-between mb-3">
                                        <span class="text-[0.65rem] font-mono text-champagne-500/80 font-semibold tracking-wider flex items-center gap-1.5">
                                            <span class="w-1.5 h-1.5 rounded-full bg-champagne-500/60"></span>PLANNED · PHASE II
                                        </span>
                                        <span class="text-xs font-mono text-champagne-500">24M birds/yr</span>
                                    </div>
                                    <h4 class="text-lg font-serif text-platinum-50 font-bold mb-1">Central Demand Hub (Selangor)</h4>
                                    <p class="text-xs text-sovereign-400 mb-4">Urban demand matching hub focused on high-throughput cold-chain distribution and rapid delivery networks.</p>
                                </div>
                                <div class="border-t border-champagne-500/5 pt-3 mt-auto flex items-center justify-between text-[0.65rem] font-mono text-sovereign-500">
                                    <span>Focus: Urban Distribution</span>
                                    <span>Est. Capex: RM30M</span>
                                </div>
                            </div>

                        </div>

                        <!-- Footer -->
                        <div class="px-6 py-4 border-t border-champagne-500/15 bg-obsidian-950/80 relative z-10">
                            <div class="flex items-center justify-between text-xs">
                                <span class="text-sovereign-400 font-mono">Strategic site selection based on logistics, feed supply, and market proximity</span>
                                <span class="text-champagne-500 font-mono">Coverage: Nationwide</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
