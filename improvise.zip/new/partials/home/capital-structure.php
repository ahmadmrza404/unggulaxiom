<section class="py-32 bg-gradient-to-b from-obsidian-905 to-obsidian-950 border-t border-champagne-500/10 relative overflow-hidden isolate">

    <div class="tech-grid absolute inset-0 opacity-10 pointer-events-none"></div>
    <div class="ambient-spotlight bottom-0 right-10 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- HEADER BLOCK -->
        <div class="mb-20 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                CAPITAL ENGAGEMENT
            </span>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-editorial font-extrabold">
                Capital Participation Structures
            </h2>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto my-4"></div>
            <p class="text-sm text-sovereign-400 tracking-institutional max-w-2xl mx-auto">
                Institutional framework for systematic infrastructure development and funding
            </p>
        </div>

        <!-- PARTICIPATION GRID: 3-COLUMN DATA ROOM -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">

            <!-- Column 1: Equity Participation -->
            <div class="group glass-panel p-8 lg:p-10 rounded-2xl border border-champagne-500/15 transition-all duration-500 hover:border-champagne-500/35 hover:bg-obsidian-900/60 shadow-xl relative overflow-hidden"
                 style="will-change: opacity, transform;"
                 onmouseenter="this.parentElement.querySelectorAll('.group').forEach(el => el !== this && el.classList.add('dimmed'))"
                 onmouseleave="this.parentElement.querySelectorAll('.group').forEach(el => el.classList.remove('dimmed'))">

                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>

                <div class="flex items-center justify-between mb-8 pb-4 border-b border-champagne-500/10">
                    <span class="text-xs text-champagne-500 font-mono tracking-widest flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>DIRECT STAKE</span>
                    <span class="w-2 h-2 rounded-full bg-champagne-500"></span>
                </div>

                <h3 class="font-serif text-2xl text-platinum-50 mb-4 font-bold group-hover:text-champagne-400 transition-colors duration-300">
                    Equity Participation
                </h3>

                <p class="text-sm text-sovereign-300 leading-relaxed mb-8 group-hover:text-platinum-200 transition-colors duration-300">
                    Direct ownership structures enabling institutional investors to participate in infrastructure development with aligned governance frameworks.
                </p>

                <div class="space-y-3 pt-6 border-t border-champagne-500/10">
                    <div class="flex items-center gap-3">
                        <span class="text-champagne-500 font-bold text-xs">→</span>
                        <span class="text-xs text-sovereign-300 group-hover:text-platinum-200">Minority stake options</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="text-champagne-500 font-bold text-xs">→</span>
                        <span class="text-xs text-sovereign-300 group-hover:text-platinum-200">Board representation rights</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="text-champagne-500 font-bold text-xs">→</span>
                        <span class="text-xs text-sovereign-300 group-hover:text-platinum-200">Dividend distribution models</span>
                    </div>
                </div>
            </div>

            <!-- Column 2: Joint Venture Systems -->
            <div class="group glass-panel p-8 lg:p-10 rounded-2xl border border-champagne-500/15 transition-all duration-500 hover:border-champagne-500/35 hover:bg-obsidian-900/60 shadow-xl relative overflow-hidden"
                 style="will-change: opacity, transform;"
                 onmouseenter="this.parentElement.querySelectorAll('.group').forEach(el => el !== this && el.classList.add('dimmed'))"
                 onmouseleave="this.parentElement.querySelectorAll('.group').forEach(el => el.classList.remove('dimmed'))">

                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>

                <div class="flex items-center justify-between mb-8 pb-4 border-b border-champagne-500/10">
                    <span class="text-xs text-champagne-500 font-mono tracking-widest flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>COLLABORATION</span>
                    <span class="w-2 h-2 rounded-full bg-champagne-500"></span>
                </div>

                <h3 class="font-serif text-2xl text-platinum-50 mb-4 font-bold group-hover:text-champagne-400 transition-colors duration-300">
                    Joint Venture Systems
                </h3>

                <p class="text-sm text-sovereign-300 leading-relaxed mb-8 group-hover:text-platinum-200 transition-colors duration-300">
                    Strategic partnerships combining operational expertise with capital deployment for shared risk and value creation across the ecosystem.
                </p>

                <div class="space-y-3 pt-6 border-t border-champagne-500/10">
                    <div class="flex items-center gap-3">
                        <span class="text-champagne-500 font-bold text-xs">→</span>
                        <span class="text-xs text-sovereign-300 group-hover:text-platinum-200">50/50 partnership structures</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="text-champagne-500 font-bold text-xs">→</span>
                        <span class="text-xs text-sovereign-300 group-hover:text-platinum-200">Shared operational control</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="text-champagne-500 font-bold text-xs">→</span>
                        <span class="text-xs text-sovereign-300 group-hover:text-platinum-200">Technology transfer models</span>
                    </div>
                </div>
            </div>

            <!-- Column 3: Project-Based Financing -->
            <div class="group glass-panel p-8 lg:p-10 rounded-2xl border border-champagne-500/15 transition-all duration-500 hover:border-champagne-500/35 hover:bg-obsidian-900/60 shadow-xl relative overflow-hidden"
                 style="will-change: opacity, transform;"
                 onmouseenter="this.parentElement.querySelectorAll('.group').forEach(el => el !== this && el.classList.add('dimmed'))"
                 onmouseleave="this.parentElement.querySelectorAll('.group').forEach(el => el.classList.remove('dimmed'))">

                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>

                <div class="flex items-center justify-between mb-8 pb-4 border-b border-champagne-500/10">
                    <span class="text-xs text-champagne-500 font-mono tracking-widest flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>PROJECT DEBT</span>
                    <span class="w-2 h-2 rounded-full bg-champagne-500"></span>
                </div>

                <h3 class="font-serif text-2xl text-platinum-50 mb-4 font-bold group-hover:text-champagne-400 transition-colors duration-300">
                    Project-Based Financing
                </h3>

                <p class="text-sm text-sovereign-300 leading-relaxed mb-8 group-hover:text-platinum-200 transition-colors duration-300">
                    Non-recourse debt structures secured against specific project assets and cash flows, optimizing capital efficiency and risk allocation.
                </p>

                <div class="space-y-3 pt-6 border-t border-champagne-500/10">
                    <div class="flex items-center gap-3">
                        <span class="text-champagne-500 font-bold text-xs">→</span>
                        <span class="text-xs text-sovereign-300 group-hover:text-platinum-200">Asset-backed security structure</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="text-champagne-500 font-bold text-xs">→</span>
                        <span class="text-xs text-sovereign-300 group-hover:text-platinum-200">Revenue-based amortization</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="text-champagne-500 font-bold text-xs">→</span>
                        <span class="text-xs text-sovereign-300 group-hover:text-platinum-200">Institutional credit facilities</span>
                    </div>
                </div>
            </div>

        </div>

        <!-- INSTITUTIONAL FOOTER BLOCK -->
        <div class="border-t border-champagne-500/15 pt-12 text-center gsap-fade-up">
            <p class="text-xs text-champagne-500 font-mono uppercase tracking-[0.15em] bg-champagne-500/5 border border-champagne-500/20 px-6 py-2.5 inline-block rounded-full backdrop-blur-sm">
                Strategic institutional alignment. Capital engagement is structured through institutional channels.
            </p>
        </div>

    </div>

    <style>
        .group.dimmed {
            opacity: 0.35 !important;
            transform: scale(0.98);
        }
    </style>

</section>
