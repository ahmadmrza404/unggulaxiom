<section class="py-32 bg-gradient-to-b from-obsidian-900 to-obsidian-950 border-t border-champagne-500/10 relative overflow-hidden isolate">

    <div class="tech-grid absolute inset-0 opacity-10 pointer-events-none"></div>
    <div class="ambient-spotlight -bottom-40 right-10 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- SECTION HEADER -->
        <div class="mb-20 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                INTEGRATED INFRASTRUCTURE
            </span>
            <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 tracking-editorial font-extrabold max-w-xl mx-auto">
                Systematic Deployment Matrix
            </h2>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto my-4"></div>
            <p class="text-sm text-sovereign-400 tracking-institutional">
                Operational coordination across functional systems and market sectors
            </p>
        </div>

        <!-- INFRASTRUCTURE MATRIX GRID -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">

            <!-- LEFT BLOCK: SYSTEMS -->
            <div class="glass-panel rounded-2xl border border-champagne-500/15 overflow-hidden shadow-2xl">

                <!-- Systems Header -->
                <div class="border-b border-champagne-500/15 p-8 bg-obsidian-900/50">
                    <h3 class="font-serif text-3xl text-platinum-50 tracking-editorial font-bold flex items-center justify-between">
                        <span>SYSTEMS</span>
                        <span class="text-xs text-champagne-500 font-mono tracking-widest flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-champagne-500/80"></span>FUNCTIONAL ENGINE</span>
                    </h3>
                </div>

                <!-- Systems Grid -->
                <div class="divide-y divide-champagne-500/10 bg-obsidian-950/20">

                    <!-- System Item 1 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M14.25 9.75L16.5 12l-2.25 2.25m-4.5 0L7.5 12l2.25-2.25M6 20.25h12A2.25 2.25 0 0020.25 18V6A2.25 2.25 0 0018 3.75H6A2.25 2.25 0 003.75 6v12A2.25 2.25 0 006 20.25z" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Production Systems
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">01</span>
                    </div>

                    <!-- System Item 2 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12a7.5 7.5 0 0015 0m-15 0a7.5 7.5 0 1115 0m-15 0H3m16.5 0H21m-1.5 0H12m-8.457 3.077l1.41-1.41m12.102-12.102l1.41-1.41M9 10.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm12 0a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Industrial Systems
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">02</span>
                    </div>

                    <!-- System Item 3 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Compliance Systems
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">03</span>
                    </div>

                    <!-- System Item 4 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.099-1.124a17.902 17.902 0 00-3.213-9.193 2.056 2.056 0 00-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 00-10.026 0 1.106 1.106 0 00-.987 1.106v7.635m12-6.677v6.677m0 0h-3.75" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Logistics Systems
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">04</span>
                    </div>

                    <!-- System Item 5 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v12m-3-2.818l.214-.114 2.572-1.357a1.024 1.024 0 00.572-.917V6.098a1.024 1.024 0 00-.572-.917L8.214 3.824a1.024 1.024 0 00-1.102 0L3.626 5.181a1.024 1.024 0 00-.572.917v7.014c0 .382.214.726.572.917l2.572 1.357.214.114m12 0l.214-.114 2.572-1.357a1.024 1.024 0 00.572-.917V6.098a1.024 1.024 0 00-.572-.917L18.214 3.824a1.024 1.024 0 00-1.102 0l-2.486 1.357a1.024 1.024 0 00-.572.917v7.014c0 .382.214.726.572.917l2.572 1.357.214.114" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Finance Systems
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">05</span>
                    </div>

                    <!-- System Item 6 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-.778.099-1.533.284-2.253" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Trade Systems
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">06</span>
                    </div>

                </div>
            </div>

            <!-- RIGHT BLOCK: SECTORS -->
            <div class="glass-panel rounded-2xl border border-champagne-500/15 overflow-hidden shadow-2xl">

                <!-- Sectors Header -->
                <div class="border-b border-champagne-500/15 p-8 bg-obsidian-900/50">
                    <h3 class="font-serif text-3xl text-platinum-50 tracking-editorial font-bold flex items-center justify-between">
                        <span>SECTORS</span>
                        <span class="text-xs text-champagne-500 font-mono tracking-widest flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-champagne-500/80"></span>MARKET DOMAINS</span>
                    </h3>
                </div>

                <!-- Sectors Grid -->
                <div class="divide-y divide-champagne-500/10 bg-obsidian-950/20">

                    <!-- Sector Item 1 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Food & Agriculture
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">01</span>
                    </div>

                    <!-- Sector Item 2 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.03 0 1.9.732 2.076 1.719M9 12h.008v.008H9V12zm0 3h.008v.008H9V15zm0 3h.008v.008H9V18z" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Pharmaceuticals & Wellness
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">02</span>
                    </div>

                    <!-- Sector Item 3 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0021 17.25l-5.877-5.877M11.42 15.17L2.25 6m9.17 9.17a2.25 2.25 0 01-3.179-3.179L12 6m-3.92 6.08L1.75 18a2.25 2.25 0 002.25 2.25l6.08-6.171m-6.08 6.171L18 3.75M18 3.75L21 6.75m-3-3L15 6.75" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Manufacturing
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">03</span>
                    </div>

                    <!-- Sector Item 4 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5zM3 19.5h18" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Logistics & Distribution
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">04</span>
                    </div>

                    <!-- Sector Item 5 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5h.007m-.007 3h.007m-.007 3h.007m3-3h.007m-.007 3h.007m-.007 3h.007m3-6h.007m-.007 3h.007m-.007 3h.007m3-3h.007m-.007 3h.007m-.007 3h.007M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Islamic Finance
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">05</span>
                    </div>

                    <!-- Sector Item 6 -->
                    <div class="matrix-card group p-6 flex items-center justify-between hover:bg-obsidian-900/40 border-l-2 border-transparent hover:border-champagne-500 transition-all duration-300">
                        <div class="flex items-center gap-5">
                            <span class="w-10 h-10 rounded-lg bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center text-champagne-500 group-hover:bg-champagne-500/10 transition-colors duration-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918" />
                                </svg>
                            </span>
                            <span class="text-base font-semibold text-sovereign-300 group-hover:text-platinum-50 transition-colors duration-300">
                                Global Trade
                            </span>
                        </div>
                        <span class="font-mono text-xs text-sovereign-500 group-hover:text-champagne-500 transition-colors duration-300">06</span>
                    </div>

                </div>
            </div>

        </div>

        <!-- INTEGRATION STATEMENT -->
        <div class="mt-16 text-center gsap-fade-up">
            <p class="text-[0.7rem] text-champagne-500 tracking-[0.2em] font-mono uppercase bg-champagne-500/5 border border-champagne-500/20 px-6 py-2.5 inline-block rounded-full backdrop-blur-sm">
                Systems Architecture × Sector Deployment = Operational Integration
            </p>
        </div>

    </div>

</section>
