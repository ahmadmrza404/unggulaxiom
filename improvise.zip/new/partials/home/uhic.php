<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$uhic = $homepage_data['uhic'] ?? [];
?>
<section class="py-32 bg-gradient-to-b from-obsidian-900 to-obsidian-950 border-t border-champagne-500/10 relative overflow-hidden isolate animate-fade-in">

    <div class="tech-grid absolute inset-0 opacity-10 pointer-events-none"></div>
    <div class="ambient-spotlight -top-40 left-10 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- UHIC HEADER -->
        <div class="mb-20 gsap-fade-up">
            <span class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6 block uppercase">
                <?= htmlspecialchars($uhic['section_label'] ?? 'UHIC (UNGGUL HALAL INTEGRATED CENTRE)') ?>
            </span>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-editorial font-extrabold max-w-4xl">
                <?= htmlspecialchars($uhic['title'] ?? '') ?>
            </h2>
            <div class="w-24 h-0.5 bg-gradient-to-r from-champagne-500 to-transparent mt-6"></div>
        </div>

        <!-- DESCRIPTION BLOCK -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
            <div class="gsap-fade-up">
                <p class="text-xl text-platinum-100 leading-editorial font-serif mb-6">
                    <?= htmlspecialchars($uhic['intro_text'] ?? '') ?>
                </p>
                <p class="text-base text-sovereign-300 leading-institutional">
                    <?= htmlspecialchars($uhic['description'] ?? '') ?>
                </p>
            </div>
            <div class="gsap-fade-up">
                <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 relative">
                    <h3 class="text-champagne-400 text-xs font-mono uppercase tracking-widest mb-6 border-b border-champagne-500/10 pb-4"><?= htmlspecialchars($uhic['objectives_label'] ?? 'Platform Objectives') ?></h3>
                    <ul class="space-y-4 text-sovereign-300">
                        <?php foreach (($uhic['objectives'] ?? []) as $objective): ?>
                        <li class="flex items-start gap-4">
                            <span class="flex-shrink-0 w-5 h-5 rounded-full bg-champagne-500/10 flex items-center justify-center text-champagne-500 text-xs font-bold">✓</span>
                            <span class="text-sm md:text-base text-platinum-200"><?= htmlspecialchars($objective) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- PLATFORM MODULES -->
        <div class="mb-24 gsap-fade-up">
            <h3 class="font-serif text-3xl text-platinum-50 mb-12 text-center font-bold"><?= htmlspecialchars($uhic['modules_title'] ?? 'Core Platform Modules') ?></h3>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

                <?php foreach (($uhic['modules'] ?? []) as $module): ?>
                <div class="glass-panel p-8 rounded-2xl border border-champagne-500/10 hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/50 group shadow-md hover:shadow-2xl flex flex-col justify-between">
                    <div>
                        <div class="w-12 h-12 rounded-xl bg-champagne-500/5 border border-champagne-500/15 flex items-center justify-center mb-6 text-champagne-500 group-hover:bg-champagne-500 group-hover:text-obsidian-950 transition-colors duration-300">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                            </svg>
                        </div>
                        <h4 class="text-xl font-serif text-platinum-50 mb-3 group-hover:text-champagne-400 transition-colors duration-300 font-bold"><?= htmlspecialchars($module['name']) ?></h4>
                        <p class="text-sm text-sovereign-300 mb-6 leading-relaxed group-hover:text-platinum-200 transition-colors duration-300"><?= htmlspecialchars($module['description']) ?></p>
                    </div>
                    <div class="text-[0.7rem] text-champagne-500 font-mono border-t border-champagne-500/5 pt-4 mt-auto tracking-wider uppercase"><?= htmlspecialchars($module['tech_stack']) ?></div>
                </div>
                <?php endforeach; ?>

            </div>
        </div>

        <!-- DEPLOYMENT SECTORS -->
        <div class="glass-panel p-10 rounded-2xl border border-champagne-500/15 gsap-fade-up relative overflow-hidden shadow-2xl">
            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
            <h3 class="text-xs font-mono text-champagne-500 uppercase tracking-widest mb-6 text-center border-b border-champagne-500/10 pb-4"><?= htmlspecialchars($uhic['deployment_title'] ?? 'Multi-Sector Deployment Framework') ?></h3>
            <p class="text-center text-sovereign-300 mb-10 max-w-3xl mx-auto leading-relaxed">
                <?= htmlspecialchars($uhic['deployment_description'] ?? '') ?>
            </p>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php foreach (($uhic['deployment_sectors'] ?? []) as $sector): ?>
                <div class="text-center p-6 border border-champagne-500/10 bg-obsidian-900/40 rounded-xl hover:border-champagne-500/40 transition-colors duration-300">
                    <div class="text-xl font-serif text-platinum-50 mb-2 font-bold"><?= htmlspecialchars($sector['name']) ?></div>
                    <div class="text-[0.65rem] text-champagne-500 font-mono tracking-wider uppercase"><?= htmlspecialchars($sector['status']) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>

</section>
