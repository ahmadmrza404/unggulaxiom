<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$hero = $homepage_data['hero'] ?? [];
?>
<section class="min-h-[100dvh] flex items-center justify-center relative overflow-hidden bg-obsidian-950 isolate">

    <!-- TECH GRID BACKGROUND -->
    <div class="tech-grid absolute inset-0 opacity-20 pointer-events-none z-0"></div>

    <!-- radial gradient glow spotlight -->
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-60 z-0"></div>



    <div class="container-sovereign relative z-10 mt-10 lg:mt-0">
        <div class="max-w-6xl mx-auto text-center">

            <!-- Premium top badge -->
            <div class="inline-flex items-center gap-2 px-3 py-1 mb-8 border border-champagne-500/30 bg-champagne-500/5 rounded-full backdrop-blur-sm gsap-fade-up">
                <span class="w-1.5 h-1.5 rounded-full bg-champagne-500 animate-pulse"></span>
                <span class="text-sovereign-xs text-champagne-400 font-semibold tracking-ultra-wide uppercase">Emerging Infrastructure System</span>
            </div>

            <h1 class="split-hero-title font-serif text-5xl md:text-7xl lg:text-8xl text-platinum-50 mb-10 tracking-tight leading-none reveal-mask font-extrabold">
                <?= htmlspecialchars($hero['title'] ?? 'Unggul Axiom Group') ?>
            </h1>

            <div class="mb-8 gsap-fade-up">
                <h2 class="text-xl md:text-2xl lg:text-3xl font-sans text-platinum-100 tracking-wide leading-tight mb-4">
                    <?= htmlspecialchars($hero['subtitle'] ?? 'Emerging Infrastructure Systems Platform') ?>
                </h2>
                <p class="text-base md:text-lg text-sovereign-400 leading-relaxed max-w-3xl mx-auto">
                    <?= htmlspecialchars($hero['tagline'] ?? 'Global Halal Economy Architecture') ?>
                </p>
            </div>

            <div class="w-24 h-px bg-champagne-500/60 mx-auto mb-10 gsap-fade-up"></div>

            <div class="flex flex-col sm:flex-row gap-6 justify-center mt-12 gsap-fade-up">
                <a href="<?= url($hero['cta_primary']['url'] ?? '/systems') ?>"
                   class="px-10 py-4 bg-champagne-500 text-obsidian-950 text-sm font-semibold hover:bg-champagne-400 transition-all duration-300 rounded btn-shine-hover shadow-lg shadow-champagne-500/10 hover:shadow-champagne-500/25">
                    <?= htmlspecialchars($hero['cta_primary']['text'] ?? 'View Systems') ?>
                </a>
                <a href="<?= url($hero['cta_secondary']['url'] ?? '/capital') ?>"
                   class="px-10 py-4 border border-champagne-500/40 text-champagne-400 text-sm font-semibold hover:bg-champagne-500/10 hover:border-champagne-500 transition-all duration-300 rounded backdrop-blur-sm">
                    <?= htmlspecialchars($hero['cta_secondary']['text'] ?? 'Capital Structure') ?>
                </a>
            </div>

        </div>
    </div>

    <!-- Scroll down indicator -->
    <div class="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 gsap-fade-up">
        <span class="text-[0.65rem] text-sovereign-400 uppercase tracking-[0.2em]">Explore</span>
        <div class="w-[20px] h-[32px] border border-sovereign-500/55 rounded-full p-1 flex justify-center">
            <span class="w-[3px] h-[6px] bg-champagne-500 rounded-full animate-bounce"></span>
        </div>
    </div>

</section>
