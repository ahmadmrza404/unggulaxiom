<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$positioning = $homepage_data['positioning'] ?? [];
?>
<section class="py-32 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-t border-champagne-500/10 relative overflow-hidden isolate">

    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- 12-COLUMN ASYMMETRICAL GRID -->
        <div class="grid grid-cols-12 gap-8 lg:gap-16 items-center">

            <!-- POSITION BLOCK: LEFT-WEIGHTED (COLUMNS 2-6) -->
            <div class="col-span-12 lg:col-start-2 lg:col-span-5 gsap-fade-up">

                <div class="mb-8">
                    <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                        <?= htmlspecialchars($positioning['position_label'] ?? 'POSITION') ?>
                    </span>
                    <h3 class="text-xs text-sovereign-400 font-mono tracking-widest uppercase mb-4 flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-champagne-500/80"></span>STRATEGIC DIRECTIVE</h3>
                    <div class="w-16 h-0.5 bg-gradient-to-r from-champagne-500 to-transparent"></div>
                </div>

                <div class="space-y-6">
                    <p class="text-xl text-platinum-50 leading-editorial font-serif">
                        <?= htmlspecialchars($positioning['position_text_1'] ?? '') ?>
                    </p>
                    <p class="text-base text-sovereign-300 leading-institutional font-sans">
                        <?= htmlspecialchars($positioning['position_text_2'] ?? '') ?>
                    </p>
                </div>

            </div>

            <!-- PRINCIPLE BLOCK: RIGHT-WEIGHTED (COLUMNS 8-13) -->
            <div class="col-span-12 lg:col-start-8 lg:col-span-4 gsap-fade-up">
                <div class="glass-panel p-10 rounded-2xl border border-champagne-500/15 shadow-[0_20px_50px_rgba(0,0,0,0.3)] hover:border-champagne-500/30 transition-all duration-500 relative group overflow-hidden">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    
                    <div class="relative z-10">
                        <div class="mb-6">
                            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                                <?= htmlspecialchars($positioning['principle_label'] ?? 'PRINCIPLE') ?>
                            </span>
                            <div class="w-12 h-0.5 bg-gradient-to-r from-champagne-500 to-transparent"></div>
                        </div>

                        <div class="border-l-2 border-champagne-500 pl-6 my-4">
                            <h3 class="font-serif text-3xl md:text-4xl text-platinum-50 leading-tight tracking-tight">
                                <?= htmlspecialchars($positioning['principle_statement'] ?? '') ?>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</section>
