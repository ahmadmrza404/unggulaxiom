<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$framework = $homepage_data['framework'] ?? [];
?>
<section id="framework" class="py-32 bg-gradient-to-b from-obsidian-950 to-obsidian-900 text-platinum-50 border-t border-champagne-500/10 relative overflow-hidden isolate">

    <div class="tech-grid absolute inset-0 opacity-10 pointer-events-none"></div>
    <div class="ambient-spotlight top-1/3 -right-60 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- STICKY SCROLL LAYOUT: 12-COLUMN GRID -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-16 relative">

            <!-- LEFT COLUMN: STICKY HEADER (4 COLS) -->
            <div class="md:col-span-4">
                <div class="md:sticky md:top-36">
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block uppercase" data-gsap-fade-up>
                        <?= htmlspecialchars($framework['section_label'] ?? 'INFRASTRUCTURE ARCHITECTURE') ?>
                    </span>
                    <h2 class="font-serif text-4xl lg:text-5xl text-platinum-50 tracking-editorial mb-8 leading-tight font-extrabold" data-gsap-fade-up data-gsap-delay="0.2">
                        <?= htmlspecialchars($framework['title'] ?? 'THE AXIOM-8 FRAMEWORK') ?>
                    </h2>
                    <div class="w-16 h-0.5 bg-gradient-to-r from-champagne-500 to-transparent mb-8"></div>
                    <p class="text-base text-sovereign-300 leading-institutional" data-gsap-fade-up data-gsap-delay="0.3">
                        <?= htmlspecialchars($framework['description'] ?? '') ?>
                    </p>
                </div>
            </div>

            <!-- RIGHT COLUMN: 8 PILLARS (8 COLS) -->
            <div class="md:col-span-8">
                <div class="space-y-4">

                    <?php foreach (($framework['pillars'] ?? []) as $pillar): ?>
                    <!-- PILLAR: GLASS DRAWER CARD -->
                    <div class="pillar-item glass-panel p-6 md:p-8 rounded-xl border border-champagne-500/10 hover:border-champagne-500/30 transition-all duration-300 hover:bg-obsidian-900/60 group shadow-md hover:shadow-[0_15px_30px_rgba(0,0,0,0.4)]">
                        <div class="flex items-start gap-6">
                            <span class="font-mono text-champagne-500 text-sm tracking-wider font-semibold border border-champagne-500/20 rounded px-2.5 py-1 bg-champagne-500/5 group-hover:bg-champagne-500 group-hover:text-obsidian-950 transition-colors duration-300">
                                <?= htmlspecialchars($pillar['number']) ?>
                            </span>
                            <div class="flex-1">
                                <h3 class="font-serif text-2xl text-platinum-50 tracking-editorial mb-3 group-hover:text-champagne-400 transition-colors duration-300">
                                    <?= htmlspecialchars($pillar['name']) ?>
                                </h3>
                                <p class="text-sm md:text-base text-sovereign-300 leading-institutional group-hover:text-platinum-100 transition-colors duration-300">
                                    <?= htmlspecialchars($pillar['description']) ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>

                </div>
            </div>

        </div>

    </div>
</section>
