<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$ecosystem = $homepage_data['ecosystem'] ?? [];
?>
<section id="ecosystem" class="py-32 bg-gradient-to-b from-obsidian-950 to-obsidian-900 text-platinum-50 border-t border-champagne-500/10 relative overflow-hidden isolate">

    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="ambient-spotlight top-10 right-20 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- SECTION HEADER -->
        <div class="mb-20 max-w-4xl" data-gsap-fade-up>
            <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block uppercase">
                <?= htmlspecialchars($ecosystem['section_label'] ?? 'OUR ECOSYSTEM') ?>
            </span>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-editorial font-extrabold">
                <?= htmlspecialchars($ecosystem['title'] ?? 'Integrated Infrastructure Platform') ?>
            </h2>
            <div class="w-16 h-0.5 bg-gradient-to-r from-champagne-500 to-transparent mt-6 mb-8"></div>
            <p class="text-base text-sovereign-300 max-w-2xl leading-relaxed">
                <?= htmlspecialchars($ecosystem['description'] ?? '') ?>
            </p>
        </div>

        <!-- ENTITY CARDS GRID -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

            <?php foreach (($ecosystem['entities'] ?? []) as $index => $entity): ?>
            <!-- ENTITY CARD -->
            <a href="<?= url($entity['url'] ?? '#') ?>"
               class="glass-panel p-8 rounded-2xl border border-champagne-500/10 hover:border-champagne-500/35 hover:bg-obsidian-900/60 transition-all duration-500 group shadow-lg flex flex-col justify-between min-h-[280px]"
               x-data="{ hover: false }"
               @mouseenter="hover = true"
               @mouseleave="hover = false">
                
                <div>
                    <!-- MONOSPACE INDEX & SMALL SYMBOL -->
                    <div class="flex items-center justify-between mb-6">
                        <span class="font-mono text-xs text-champagne-500/50 group-hover:text-champagne-500 transition-colors duration-300">
                            <?= sprintf('%02d', $index + 1) ?>
                        </span>
                        <span class="w-1.5 h-1.5 rounded-full bg-champagne-500/30 group-hover:bg-champagne-500 transition-all duration-300"></span>
                    </div>

                    <!-- ENTITY NAME -->
                    <h3 class="font-serif text-3xl text-platinum-100 group-hover:text-champagne-400 tracking-tight transition-colors duration-300 mb-4 font-bold">
                        <?= htmlspecialchars($entity['name']) ?>
                    </h3>

                    <!-- DESCRIPTION -->
                    <p class="text-sm text-sovereign-300 leading-relaxed group-hover:text-platinum-100 transition-colors duration-300">
                        <?= htmlspecialchars($entity['description']) ?>
                    </p>
                </div>

                <!-- VIEW dossier LINK -->
                <div class="pt-6 border-t border-champagne-500/5 flex items-center justify-between mt-auto">
                    <span class="text-xs text-champagne-500 font-mono tracking-wider uppercase group-hover:text-champagne-400 transition-colors duration-300">
                        Access Dossier
                    </span>
                    <span class="text-champagne-500 transform group-hover:translate-x-2 transition-transform duration-300">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3" />
                        </svg>
                    </span>
                </div>

            </a>
            <?php endforeach; ?>

        </div>

    </div>
</section>
