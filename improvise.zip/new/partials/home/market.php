<?php
$homepage_data = json_decode(file_get_contents(__DIR__ . '/../../data/homepage.json'), true);
$market = $homepage_data['market'] ?? [];
?>
<section id="global-market" class="py-32 bg-gradient-to-b from-obsidian-900 to-obsidian-950 text-platinum-50 border-t border-champagne-500/10 relative overflow-hidden isolate">

    <div class="ambient-spotlight bottom-10 left-10 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- 12-COLUMN ASYMMETRIC GRID -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-16">

            <!-- LEFT COLUMN: SECTION HEADER & THESIS (4 COLS) -->
            <div class="md:col-span-4">
                <div class="md:sticky md:top-32">
                    <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 block" data-gsap-fade-up>
                        <?= htmlspecialchars($market['section_label'] ?? 'GLOBAL MARKET OPPORTUNITY') ?>
                    </span>
                    <h2 class="font-serif text-4xl lg:text-5xl text-platinum-50 tracking-editorial mb-8 leading-tight font-extrabold" data-gsap-fade-up data-gsap-delay="0.2">
                        <?= htmlspecialchars($market['headline'] ?? '') ?>
                    </h2>
                    <div class="w-16 h-0.5 bg-gradient-to-r from-champagne-500 to-transparent mb-8"></div>
                </div>
            </div>

            <!-- RIGHT COLUMN: DATA & MARKET REALITY (8 COLS) -->
            <div class="md:col-span-8">

                <!-- MASSIVE STAT: TYPOGRAPHIC ART IN GLASS CARD -->
                <div class="glass-panel p-10 rounded-2xl border border-champagne-500/15 mb-16 relative overflow-hidden shadow-2xl hover:border-champagne-500/30 transition-all duration-500" data-gsap-fade-up data-gsap-delay="0.3">
                    <div class="tech-grid absolute inset-0 opacity-10 pointer-events-none"></div>
                    <div class="ambient-spotlight -right-20 -top-20 opacity-40"></div>

                    <div class="relative z-10">
                        <div class="font-serif text-5xl md:text-7xl text-platinum-50 leading-none tracking-tight mb-4 font-extrabold">
                            <span class="block text-champagne-500 text-3xl tracking-institutional mb-3 font-semibold">USD</span>
                            <span class="block"><?= htmlspecialchars($market['market_size'] ?? '10 TRILLION') ?></span>
                        </div>
                        <div class="w-20 h-px bg-champagne-500/40 my-4"></div>
                        <p class="text-sovereign-sm text-platinum-200 tracking-institutional uppercase">
                            <?= htmlspecialchars($market['market_size_label'] ?? 'GLOBAL HALAL ECONOMY (2030)') ?>
                        </p>
                    </div>
                </div>

                <!-- DATA POINTS: STYLISH LIST -->
                <div class="mb-16" data-gsap-fade-up data-gsap-delay="0.4">
                    <ul class="space-y-4">
                        <?php foreach (($market['data_points'] ?? []) as $point): ?>
                        <li class="p-6 bg-obsidian-900/50 border border-champagne-500/10 rounded-xl flex items-start gap-5 hover:border-champagne-500/30 transition-all duration-300">
                            <span class="flex-shrink-0 w-8 h-8 rounded-full bg-champagne-500/10 border border-champagne-500/30 flex items-center justify-center text-champagne-500 mt-0.5">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                                </svg>
                            </span>
                            <div>
                                <p class="text-lg md:text-xl font-serif text-platinum-50 tracking-editorial">
                                    <?= htmlspecialchars($point) ?>
                                </p>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- MARKET REALITY SUB-SECTION -->
                <div class="mb-12" data-gsap-fade-up data-gsap-delay="0.5">
                    <h3 class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-6 uppercase">
                        <?= htmlspecialchars($market['market_reality_label'] ?? 'MARKET REALITY') ?>
                    </h3>
                    <p class="text-base text-sovereign-300 leading-institutional">
                        <?= htmlspecialchars($market['market_reality_text'] ?? '') ?>
                    </p>
                </div>

                <!-- POSITIONING BLOCK: INSET GLASS BOX -->
                <div class="glass-panel border-l-4 border-l-champagne-500 border-t-0 border-r-0 border-b-0 pl-8 pr-6 py-8 rounded-r-xl" data-gsap-fade-up data-gsap-delay="0.6">
                    <p class="text-xl md:text-2xl font-serif text-platinum-100 leading-editorial italic">
                        "<?= htmlspecialchars($market['positioning_statement'] ?? '') ?>"
                    </p>
                </div>

            </div>

        </div>

    </div>
</section>
