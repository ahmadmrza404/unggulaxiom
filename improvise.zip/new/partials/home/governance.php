<section class="py-32 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-t border-champagne-500/10 relative overflow-hidden isolate">

    <div class="tech-grid absolute inset-0 opacity-10 pointer-events-none"></div>
    <div class="ambient-spotlight -bottom-40 left-10 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- GOVERNANCE HEADER -->
        <div class="mb-20 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                CORPORATE GOVERNANCE
            </span>
            <h2 class="font-serif text-4xl md:text-5xl text-platinum-50 tracking-editorial font-extrabold">
                Governance & Investment Strategy
            </h2>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto my-4"></div>
        </div>

        <!-- GOVERNANCE CONTENT -->
        <div class="max-w-4xl mx-auto text-center mb-16 gsap-fade-up">
            <div class="glass-panel p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                <div class="ambient-spotlight -right-20 -top-20 opacity-40"></div>
                <h3 class="font-serif text-3xl text-platinum-50 mb-4 font-bold">
                    UNGGUL BRONTO SDN. BHD.
                </h3>
                <p class="text-xs text-champagne-500 font-mono tracking-widest uppercase mb-6">Platform Administrator · Kuala Lumpur, Malaysia</p>
                <p class="text-base text-sovereign-300 leading-institutional max-w-2xl mx-auto">
                    A registered Malaysian entity built on institutional-grade governance principles. We maintain rigorous financial controls and transparent reporting structures that meet the standards institutional investors expect.
                </p>
            </div>
        </div>

        <!-- PRINCIPLE BLOCK -->
        <div class="max-w-4xl mx-auto glass-panel border-l-4 border-l-champagne-500 border-t-0 border-r-0 border-b-0 pl-10 pr-6 py-8 rounded-r-2xl mb-16 gsap-fade-up">
            <p class="text-2xl md:text-3xl font-serif text-platinum-100 leading-editorial italic">
                "System integration creates long term economic resilience."
            </p>
        </div>

        <!-- INVESTMENT HIGHLIGHTS -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 gsap-fade-up">

            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/50 transition-all duration-300 group shadow-md flex flex-col justify-between">
                <div>
                    <div class="text-champagne-500 text-xs font-mono uppercase tracking-widest mb-4 flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>01 · FEASIBILITY</div>
                    <h4 class="text-platinum-50 text-xl font-serif font-bold mb-3 group-hover:text-champagne-400 transition-colors duration-300">Proven Model</h4>
                    <p class="text-sm text-sovereign-300 leading-relaxed">
                        Our CIPU pilot has validated the operational model. The numbers work, the systems are in place, and we have a clear roadmap for replication across regions.
                    </p>
                </div>
            </div>

            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/50 transition-all duration-300 group shadow-md flex flex-col justify-between">
                <div>
                    <div class="text-champagne-500 text-xs font-mono uppercase tracking-widest mb-4 flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>02 · LEADERSHIP</div>
                    <h4 class="text-platinum-50 text-xl font-serif font-bold mb-3 group-hover:text-champagne-400 transition-colors duration-300">Market Position</h4>
                    <p class="text-sm text-sovereign-300 leading-relaxed">
                        We're building at the intersection of production, technology, and compliance in Malaysia's strategic halal sector—a position that's difficult to replicate.
                    </p>
                </div>
            </div>

            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 hover:bg-obsidian-900/50 transition-all duration-300 group shadow-md flex flex-col justify-between">
                <div>
                    <div class="text-champagne-500 text-xs font-mono uppercase tracking-widest mb-4 flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>03 · PROTECTION</div>
                    <h4 class="text-platinum-50 text-xl font-serif font-bold mb-3 group-hover:text-champagne-400 transition-colors duration-300">Risk Mitigation</h4>
                    <p class="text-sm text-sovereign-300 leading-relaxed">
                        Revenue flows from production, processing, and platform services. Every facility represents tangible infrastructure assets that secure the investment.
                    </p>
                </div>
            </div>

        </div>

        <!-- VALUE PROPOSITION -->
        <div class="mt-8 glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 gsap-fade-up relative overflow-hidden shadow-2xl">
            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
            <h3 class="text-xs font-mono text-champagne-400 uppercase tracking-widest mb-8 text-center border-b border-champagne-500/10 pb-4">Investment Value Proposition</h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">

                <div>
                    <h4 class="text-champagne-500 text-xs font-mono uppercase tracking-wider mb-4 border-l border-champagne-500 pl-4">Growth Trajectory</h4>
                    <ul class="space-y-4">
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 font-bold text-xs mt-0.5">→</span>
                            <span class="text-sovereign-300 text-sm md:text-base">Deploying 7-11 facilities across Malaysia over the next five years</span>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 font-bold text-xs mt-0.5">→</span>
                            <span class="text-sovereign-300 text-sm md:text-base">Scaling to 84-132M units of annual production capacity</span>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 font-bold text-xs mt-0.5">→</span>
                            <span class="text-sovereign-300 text-sm md:text-base">Expanding the platform beyond poultry into livestock, seafood, and F&B</span>
                        </li>
                    </ul>
                </div>

                <div>
                    <h4 class="text-champagne-500 text-xs font-mono uppercase tracking-wider mb-4 border-l border-champagne-500 pl-4">Competitive Advantages</h4>
                    <ul class="space-y-4">
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 font-bold text-xs mt-0.5">→</span>
                            <span class="text-sovereign-300 text-sm md:text-base">Vertical integration captures margins typically lost to intermediaries</span>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 font-bold text-xs mt-0.5">→</span>
                            <span class="text-sovereign-300 text-sm md:text-base">Our UHIC platform creates network effects that strengthen with each new participant</span>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="text-champagne-500 font-bold text-xs mt-0.5">→</span>
                            <span class="text-sovereign-300 text-sm md:text-base">Deep expertise in halal certification and compliance infrastructure</span>
                        </li>
                    </ul>
                </div>

            </div>
        </div>

    </div>

</section>
