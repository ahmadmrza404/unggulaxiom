<section class="py-32 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-t border-champagne-500/10 relative overflow-hidden isolate">

    <div class="tech-grid absolute inset-0 opacity-10 pointer-events-none"></div>
    <div class="ambient-spotlight top-1/4 -left-40 opacity-30"></div>

    <div class="container-sovereign relative z-10">

        <!-- CIPU FINANCIAL SNAPSHOT HEADER -->
        <div class="mb-20 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                CIPU FINANCIAL SNAPSHOT
            </span>
            <h2 class="font-serif text-3xl md:text-4xl text-platinum-50 tracking-editorial font-extrabold max-w-2xl mx-auto">
                Projected Financial Performance
            </h2>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto my-4"></div>
            <p class="text-sm text-sovereign-400 tracking-institutional max-w-xl mx-auto">
                Estimated operating metrics and feasibility parameters for a single facility deployment
            </p>
        </div>

        <!-- FINANCIAL GRID -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">

            <!-- PRODUCTION -->
            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 shadow-lg hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/50 group gsap-fade-up">
                <span class="text-xs text-champagne-500 font-mono tracking-widest block mb-4 flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>CAPACITY</span>
                <h3 class="text-sovereign-xs text-sovereign-400 font-semibold tracking-ultra-wide mb-2">PRODUCTION</h3>
                <p class="text-3xl lg:text-4xl font-serif text-platinum-50 mb-2 font-bold group-hover:text-champagne-400 transition-colors duration-300">12 Million</p>
                <p class="text-xs text-sovereign-400 uppercase tracking-wider">chickens per annum</p>
            </div>

            <!-- NET PROFIT -->
            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 shadow-lg hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/50 group gsap-fade-up">
                <span class="text-xs text-champagne-500 font-mono tracking-widest block mb-4 flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>RETURNS</span>
                <h3 class="text-sovereign-xs text-sovereign-400 font-semibold tracking-ultra-wide mb-2">NET PROFIT</h3>
                <p class="text-2xl lg:text-3xl font-serif text-platinum-50 mb-2 font-bold group-hover:text-champagne-400 transition-colors duration-300">RM7.2M - RM30.6M</p>
                <p class="text-xs text-sovereign-400 uppercase tracking-wider mb-2">Target Range</p>
                <div class="inline-block px-2.5 py-1 bg-champagne-500/10 border border-champagne-500/30 rounded text-xs text-champagne-400 font-mono">Base: RM19.8M</div>
            </div>

            <!-- CAPEX -->
            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 shadow-lg hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/50 group gsap-fade-up">
                <span class="text-xs text-champagne-500 font-mono tracking-widest block mb-4 flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>INVESTMENT</span>
                <h3 class="text-sovereign-xs text-sovereign-400 font-semibold tracking-ultra-wide mb-2">CAPEX</h3>
                <p class="text-3xl lg:text-4xl font-serif text-platinum-50 mb-2 font-bold group-hover:text-champagne-400 transition-colors duration-300">RM12M - RM18M</p>
                <p class="text-xs text-sovereign-400 uppercase tracking-wider">Estimated Outlay</p>
            </div>

            <!-- PAYBACK -->
            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 shadow-lg hover:border-champagne-500/35 transition-all duration-300 hover:bg-obsidian-900/50 group gsap-fade-up">
                <span class="text-xs text-champagne-500 font-mono tracking-widest block mb-4 flex items-center gap-1.5"><span class="w-1 h-1 rounded-full bg-champagne-500/80"></span>FEASIBILITY</span>
                <h3 class="text-sovereign-xs text-sovereign-400 font-semibold tracking-ultra-wide mb-2">PAYBACK</h3>
                <p class="text-3xl lg:text-4xl font-serif text-platinum-50 mb-2 font-bold group-hover:text-champagne-400 transition-colors duration-300">1 to 2 Years</p>
                <p class="text-xs text-sovereign-400 uppercase tracking-wider">(Target amortization)</p>
            </div>

        </div>

        <!-- ADDITIONAL FINANCIAL DETAILS -->
        <div class="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 gsap-fade-up">

            <!-- Revenue Breakdown -->
            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15">
                <h3 class="text-xs font-mono text-champagne-400 uppercase tracking-widest mb-6 border-b border-champagne-500/10 pb-4">Revenue Stream Dynamics</h3>
                <div class="space-y-4">
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/5">
                        <span class="text-sm text-sovereign-300">Live bird sales</span>
                        <span class="text-platinum-50 font-mono font-bold">65%</span>
                    </div>
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/5">
                        <span class="text-sm text-sovereign-300">Processed products</span>
                        <span class="text-platinum-50 font-mono font-bold">25%</span>
                    </div>
                    <div class="flex justify-between items-center pb-3">
                        <span class="text-sm text-sovereign-300">By-products & feed</span>
                        <span class="text-platinum-50 font-mono font-bold">10%</span>
                    </div>
                </div>
            </div>

            <!-- Operating Metrics -->
            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15">
                <h3 class="text-xs font-mono text-champagne-400 uppercase tracking-widest mb-6 border-b border-champagne-500/10 pb-4">Efficiency Benchmarks</h3>
                <div class="space-y-4">
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/5">
                        <span class="text-sm text-sovereign-300">Gross margin</span>
                        <span class="text-platinum-50 font-mono font-bold">28 - 35%</span>
                    </div>
                    <div class="flex justify-between items-center pb-3 border-b border-champagne-500/5">
                        <span class="text-sm text-sovereign-300">EBITDA margin</span>
                        <span class="text-platinum-50 font-mono font-bold">22 - 28%</span>
                    </div>
                    <div class="flex justify-between items-center pb-3">
                        <span class="text-sm text-sovereign-300">Operating cycle</span>
                        <span class="text-platinum-50 font-mono font-bold">42 Days</span>
                    </div>
                </div>
            </div>

        </div>

        <!-- KEY ASSUMPTIONS -->
        <div class="mt-8 glass-panel p-8 rounded-2xl border border-champagne-500/15 gsap-fade-up relative overflow-hidden">
            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
            <h3 class="text-xs font-mono text-champagne-400 uppercase tracking-widest mb-6 text-center border-b border-champagne-500/10 pb-4">Key Financial Assumptions</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="text-center p-4">
                    <div class="text-2xl font-serif text-platinum-50 mb-2 font-bold">RM6.50</div>
                    <div class="text-[0.65rem] text-sovereign-400 uppercase tracking-wider">Average selling price per kg</div>
                </div>
                <div class="text-center p-4 border-t md:border-t-0 md:border-l md:border-r border-champagne-500/10">
                    <div class="text-2xl font-serif text-platinum-50 mb-2 font-bold">1.65kg</div>
                    <div class="text-[0.65rem] text-sovereign-400 uppercase tracking-wider">Average weight per bird</div>
                </div>
                <div class="text-center p-4">
                    <div class="text-2xl font-serif text-platinum-50 mb-2 font-bold">95%</div>
                    <div class="text-[0.65rem] text-sovereign-400 uppercase tracking-wider">Production survival target</div>
                </div>
            </div>
        </div>

        <!-- FOOTER NOTE -->
        <div class="mt-12 text-center gsap-fade-up">
            <p class="text-[0.65rem] text-champagne-500/60 uppercase tracking-[0.2em] font-mono">
                * Models scaled to system configuration
            </p>
        </div>

    </div>

</section>
