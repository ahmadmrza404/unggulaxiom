<?php
/**
 * ============================================
 * CAREERS PAGE - UNGGUL AXIOM GROUP
 * ============================================
 */

require_once __DIR__ . '/config.php';

$_careers = json_decode(file_get_contents(DATA_PATH . '/careers.json'), true);
$page_title = 'Careers';

require_once INCLUDES_PATH . '/header.php';

// Check for success/error messages
$success = isset($_GET['success']) && $_GET['success'] == '1';
$error = isset($_GET['error']) && $_GET['error'] == '1';
?>

<?php if ($success): ?>
<div class="fixed top-4 right-4 z-50 max-w-md bg-green-900/90 border border-green-500 text-green-100 px-6 py-4 rounded shadow-lg" x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 5000)">
    <div class="flex items-start gap-3">
        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <div>
            <p class="font-semibold">Application submitted successfully</p>
            <p class="text-sm text-green-200 mt-1">We'll review your application and contact qualified candidates within two weeks.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="fixed top-4 right-4 z-50 max-w-md bg-red-900/90 border border-red-500 text-red-100 px-6 py-4 rounded shadow-lg" x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 8000)">
    <div class="flex items-start gap-3">
        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
        </svg>
        <div>
            <p class="font-semibold">Submission failed</p>
            <p class="text-sm text-red-200 mt-1">There was an error processing your application. Please try again or email careers@unggulaxiom.com directly.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- HERO SECTION -->
<section class="min-h-[50vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-5xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                CAREERS
            </span>
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-8 tracking-editorial leading-tight font-extrabold">
                <?= htmlspecialchars($_careers['careers']['title']) ?>
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto">
                <?= htmlspecialchars($_careers['careers']['headline']) ?>
            </p>
        </div>
    </div>
</section>

<!-- COMPANY CULTURE -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <div class="mb-16 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                WHY UNGGUL AXIOM
            </span>
            <div class="w-16 h-px bg-gradient-to-r from-champagne-500 to-transparent mx-auto"></div>
        </div>

        <div class="max-w-5xl mx-auto mb-16">
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="border-l-2 border-champagne-500 pl-6 md:pl-8 relative z-10">
                    <h3 class="text-2xl font-serif text-platinum-50 mb-4 font-bold">Our Mission</h3>
                    <p class="text-sovereign-300 leading-institutional text-lg">
                        <?= htmlspecialchars($_careers['careers']['mission']) ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- VALUES -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto gsap-fade-up">
            <?php foreach ($_careers['careers']['core_values'] as $value): ?>
            <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 shadow-xl relative overflow-hidden hover:border-champagne-500/35 transition-all duration-300">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <div class="text-champagne-500 text-xs font-semibold tracking-ultra-wide uppercase mb-4">
                        <?= htmlspecialchars($value['name']) ?>
                    </div>
                    <p class="text-sovereign-300 text-sm md:text-base leading-relaxed"><?= htmlspecialchars($value['description']) ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- CAREER OPPORTUNITIES -->
<section class="py-24 bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">

        <div class="mb-16 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                OPEN POSITIONS
            </span>
            <div class="w-16 h-px bg-gradient-to-r from-champagne-500 to-transparent mx-auto"></div>
        </div>

        <div class="max-w-5xl mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 gsap-fade-up">
                <?php foreach ($_careers['careers']['opportunities'] as $opportunity): ?>
                <div class="glass-panel p-6 rounded-xl border border-champagne-500/10 hover:border-champagne-500/30 transition-all duration-300">
                    <div class="flex items-center gap-4 relative z-10">
                        <div class="w-8 h-8 rounded-full bg-champagne-500/10 border border-champagne-500/20 flex items-center justify-center text-champagne-500 font-bold">
                            →
                        </div>
                        <span class="text-platinum-100 text-base font-semibold tracking-wide"><?= htmlspecialchars($opportunity) ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</section>

<!-- BENEFITS -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">

        <div class="mb-16 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                EMPLOYEE BENEFITS
            </span>
            <div class="w-16 h-px bg-gradient-to-r from-champagne-500 to-transparent mx-auto"></div>
        </div>

        <div class="max-w-5xl mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 gsap-fade-up">
                <?php foreach ($_careers['careers']['benefits'] as $benefit): ?>
                <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 hover:border-champagne-500/35 transition-all duration-300">
                    <div class="relative z-10">
                        <h3 class="text-platinum-50 text-lg font-semibold tracking-wide mb-3"><?= htmlspecialchars($benefit['category']) ?></h3>
                        <p class="text-sovereign-300 text-sm leading-relaxed"><?= htmlspecialchars($benefit['description']) ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</section>

<!-- APPLICATION FORM -->
<section class="py-24 bg-obsidian-950 relative overflow-hidden isolate">
    <div class="ambient-spotlight -top-40 right-10 opacity-30"></div>
    <div class="container-sovereign relative z-10">

        <div class="mb-16 text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-3 uppercase">
                <?= htmlspecialchars($_careers['careers']['application_form']['section_title'] ?? 'JOIN OUR TEAM') ?>
            </span>
            <div class="w-16 h-px bg-gradient-to-r from-champagne-500 to-transparent mx-auto mb-8"></div>
            <p class="text-sovereign-300 max-w-2xl mx-auto leading-relaxed text-base">
                <?= htmlspecialchars($_careers['careers']['application_form']['section_description'] ?? 'Submit your application below. We review all submissions and will contact qualified candidates within two weeks.') ?>
            </p>
        </div>

        <div class="max-w-4xl mx-auto">

            <form id="careerForm" class="space-y-8 gsap-fade-up" method="POST" action="process-career-application.php" enctype="multipart/form-data">

                <!-- Personal Information -->
                <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Personal Information</h3>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                    Full Name *
                                </label>
                                <input type="text" name="full_name" required
                                       class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                            </div>

                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                    Email Address *
                                </label>
                                <input type="email" name="email" required
                                       class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                    Phone Number *
                                </label>
                                <input type="tel" name="phone" required
                                       class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                            </div>

                            <div>
                                <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                    Location *
                                </label>
                                <input type="text" name="location" required placeholder="City, State"
                                       class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500">
                            </div>
                        </div>

                        <div class="mt-6">
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                LinkedIn Profile
                            </label>
                            <input type="url" name="linkedin"
                                   class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                        </div>
                    </div>
                </div>

                <!-- Position Details -->
                <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Position Details</h3>

                        <div class="mb-6">
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                Position of Interest *
                            </label>
                            <select name="position" required
                                    class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                <option value="" class="bg-obsidian-950 text-sovereign-300">Select a position</option>
                                <?php foreach ($_careers['careers']['opportunities'] as $opportunity): ?>
                                <option value="<?= htmlspecialchars(strtolower(str_replace(' ', '-', $opportunity))) ?>" class="bg-obsidian-950 text-platinum-100"><?= htmlspecialchars($opportunity) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-6">
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                Availability *
                            </label>
                            <select name="availability" required
                                    class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                <option value="" class="bg-obsidian-950 text-sovereign-300">Select availability</option>
                                <?php foreach ($_careers['careers']['application_form']['availability_options'] ?? ['Immediate', '2 weeks notice', '1 month notice', '2+ months'] as $option): ?>
                                <option value="<?= htmlspecialchars(strtolower(str_replace(' ', '-', $option))) ?>" class="bg-obsidian-950 text-platinum-100"><?= htmlspecialchars($option) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div>
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                Expected Salary Range (RM) *
                            </label>
                            <input type="text" name="salary_expectation" required placeholder="e.g., 5,000 - 7,000"
                                   class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500">
                        </div>
                    </div>
                </div>

                <!-- Professional Background -->
                <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Professional Background</h3>

                        <div class="mb-6">
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                Years of Experience *
                            </label>
                            <select name="experience_years" required
                                    class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                <option value="" class="bg-obsidian-950 text-sovereign-300">Select experience level</option>
                                <?php foreach ($_careers['careers']['application_form']['experience_options'] ?? ['0-2 years', '3-5 years', '6-10 years', '10+ years'] as $option): ?>
                                <option value="<?= htmlspecialchars($option) ?>" class="bg-obsidian-950 text-platinum-100"><?= htmlspecialchars($option) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-6">
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                Highest Education Level *
                            </label>
                            <select name="education" required
                                    class="w-full bg-obsidian-950 border border-champagne-500/15 text-platinum-100 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                                <option value="" class="bg-obsidian-950 text-sovereign-300">Select education level</option>
                                <?php foreach ($_careers['careers']['application_form']['education_options'] ?? ['Diploma', "Bachelor's Degree", "Master's Degree", 'PhD', 'Other'] as $option): ?>
                                <option value="<?= htmlspecialchars(strtolower(str_replace("'", '', str_replace(' ', '-', $option)))) ?>" class="bg-obsidian-950 text-platinum-100"><?= htmlspecialchars($option) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-6">
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                Field of Study
                            </label>
                            <input type="text" name="field_of_study"
                                   class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base">
                        </div>

                        <div>
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                Relevant Skills & Expertise *
                            </label>
                            <textarea name="skills" required rows="4" placeholder="List your key skills, certifications, and areas of expertise"
                                      class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500"></textarea>
                        </div>
                    </div>
                </div>

                <!-- Application Statement -->
                <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Application Statement</h3>

                        <div>
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2 font-medium">
                                Why do you want to join Unggul Axiom? *
                            </label>
                            <textarea name="cover_letter" required rows="6" placeholder="Tell us about your interest in this role and what you would bring to our team"
                                      class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-platinum-50 rounded-lg px-4 py-3.5 focus:outline-none focus:border-champagne-500/60 focus:shadow-[0_0_15px_rgba(201,169,97,0.05)] transition-all duration-300 text-sm md:text-base placeholder:text-sovereign-500"></textarea>
                        </div>
                    </div>
                </div>

                <!-- Documents -->
                <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden">
                    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                    <div class="relative z-10">
                        <h3 class="text-xl font-serif text-platinum-50 mb-6 font-bold tracking-wide">Documents</h3>

                        <div class="mb-6">
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-3 font-medium">
                                Resume / CV * <span class="text-sovereign-400 text-xs normal-case">(PDF, DOC, DOCX - Max 5MB)</span>
                            </label>
                            <div class="relative group mt-1" x-data="{ fileName: '' }">
                                <input type="file" name="resume" required accept=".pdf,.doc,.docx"
                                       @change="fileName = $event.target.files[0] ? $event.target.files[0].name : ''"
                                       class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
                                <div class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-sovereign-300 rounded-lg px-4 py-6 text-center group-hover:border-champagne-500/40 transition-all duration-300 flex flex-col items-center justify-center gap-2">
                                    <svg class="w-8 h-8 text-champagne-500/70 group-hover:text-champagne-500 transition-colors duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                                    </svg>
                                    <span class="text-sm font-medium text-platinum-100" x-text="fileName || 'Click to upload or drag & drop'">Click to upload or drag & drop</span>
                                    <span class="text-xs text-sovereign-400">PDF, DOC, DOCX up to 5MB</span>
                                </div>
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-3 font-medium">
                                Additional Documents <span class="text-sovereign-400 text-xs normal-case">(Optional - PDF, DOC, DOCX - Max 5MB)</span>
                            </label>
                            <div class="relative group mt-1" x-data="{ fileName: '' }">
                                <input type="file" name="additional_doc" accept=".pdf,.doc,.docx"
                                       @change="fileName = $event.target.files[0] ? $event.target.files[0].name : ''"
                                       class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
                                <div class="w-full bg-obsidian-950/40 border border-champagne-500/15 text-sovereign-300 rounded-lg px-4 py-6 text-center group-hover:border-champagne-500/40 transition-all duration-300 flex flex-col items-center justify-center gap-2">
                                    <svg class="w-8 h-8 text-champagne-500/70 group-hover:text-champagne-500 transition-colors duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                                    </svg>
                                    <span class="text-sm font-medium text-platinum-100" x-text="fileName || 'Click to upload or drag & drop (Optional)'">Click to upload or drag & drop (Optional)</span>
                                    <span class="text-xs text-sovereign-400">PDF, DOC, DOCX up to 5MB</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Consent -->
                <div class="glass-panel p-8 rounded-2xl border border-champagne-500/15 shadow-xl relative overflow-hidden">
                    <label class="flex items-start gap-4 cursor-pointer group select-none relative z-10">
                        <div class="relative flex items-center justify-center w-5 h-5 rounded border border-champagne-500/30 bg-obsidian-950/60 group-hover:border-champagne-500/60 transition-all duration-300 mt-0.5">
                            <input type="checkbox" name="consent" required class="peer absolute inset-0 opacity-0 cursor-pointer w-full h-full">
                            <svg class="w-3 h-3 text-champagne-500 opacity-0 peer-checked:opacity-100 transition-opacity duration-300 pointer-events-none" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                        <span class="text-sm text-sovereign-300 leading-relaxed group-hover:text-platinum-100 transition-colors duration-300">
                            I consent to the collection and processing of my personal data for recruitment purposes. I understand that Unggul Axiom Group will handle my information in accordance with applicable data protection regulations. *
                        </span>
                    </label>
                </div>

                <!-- Submit Button -->
                <div class="text-center pt-4">
                    <button type="submit"
                            class="inline-flex items-center gap-3 px-10 py-4 rounded-lg bg-gradient-to-r from-champagne-600 to-champagne-500 text-obsidian-950 text-sm font-semibold tracking-wider uppercase hover:from-champagne-500 hover:to-champagne-400 transition-all duration-300 hover:shadow-[0_0_25px_rgba(201,169,97,0.35)] shadow-lg transform hover:-translate-y-0.5">
                        <span>Submit Application</span>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                        </svg>
                    </button>
                    <p class="text-xs text-sovereign-400 mt-4">* Required fields</p>
                </div>

            </form>

        </div>

    </div>
</section>

<script src="assets/js/career-form.js"></script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
