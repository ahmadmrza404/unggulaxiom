<?php
/**
 * ============================================
 * TERMS OF SERVICE PAGE
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Terms of Service';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO SECTION -->
<section class="min-h-[50vh] flex items-center justify-center bg-obsidian-950 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-15 pointer-events-none"></div>
    <div class="ambient-spotlight left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40"></div>

    <div class="container-sovereign py-32 relative z-10">
        <div class="max-w-4xl mx-auto text-center gsap-fade-up">
            <span class="inline-block text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-4 uppercase">
                LEGAL FRAMEWORK
            </span>
            <h1 class="font-serif text-5xl md:text-6xl text-platinum-50 mb-6 tracking-editorial leading-tight font-extrabold">
                Terms of Service
            </h1>
            <div class="w-16 h-0.5 bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 tracking-institutional max-w-3xl mx-auto mb-6">
                These Terms govern access to and use of Unggul Axiom Group platforms, services, and institutional engagement frameworks.
            </p>
            <div class="text-xs text-champagne-500/80 font-mono tracking-wider uppercase">
                Effective Date: <?php echo date('F j, Y'); ?>
            </div>
        </div>
    </div>
</section>

<!-- CONTENT SECTIONS -->
<section class="py-24 bg-gradient-to-b from-obsidian-950 to-obsidian-900 border-b border-champagne-500/10 relative overflow-hidden isolate">
    <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
    <div class="container-sovereign relative z-10">
        <div class="max-w-4xl mx-auto space-y-8">

            <!-- Section 1 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        1. Agreement to Terms
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            By accessing or utilizing any platform, service, or communication channel operated by Unggul Bronto Sdn. Bhd. (Registration No: 202301027920) and its affiliated entities under the Unggul Axiom Group designation, you acknowledge and agree to be bound by these Terms of Service, all applicable laws and regulations, and any additional terms and conditions referenced herein.
                        </p>
                        <p>
                            The Group operates as an investment holding company focused on halal infrastructure development across multiple sectors including halal food production, halal agri-tech, pharmaceuticals, logistics, halal supply chain certification, smart agriculture, food security systems, livestock integration, and agri-technology innovation. Business activities encompass investment holding, venture building, project development, and strategic partnerships within the global halal economy.
                        </p>
                        <p>
                            If you do not agree with any provision of these Terms, you must immediately discontinue access to and use of all Group platforms and services. Continued use following any modification to these Terms constitutes acceptance of such modifications.
                        </p>
                        <p>
                            These Terms constitute a legally binding agreement between you (whether as an individual, corporate entity, or institutional representative) and Unggul Axiom Group. Your authority to bind any entity you represent is warranted through your access and use.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 2 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        2. Eligibility and Access Restrictions
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <div>
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">2.1 Institutional Access</h3>
                            <p>
                                Unggul Axiom Group platforms are designed exclusively for institutional, corporate, and accredited investor engagement. Access is restricted to qualified entities and authorized representatives acting in professional capacities. Individual consumer access is not permitted.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">2.2 Jurisdictional Compliance</h3>
                            <p>
                                Users must ensure their access and use complies with all applicable laws, regulations, and licensing requirements in their jurisdiction of operation. The Group does not represent that platform content or services are appropriate or available for use in all jurisdictions.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">2.3 Prohibited Access</h3>
                            <p>
                                Access is prohibited for entities or individuals subject to economic sanctions, export controls, or other legal restrictions. Users warrant they are not located in, organized under the laws of, or owned or controlled by persons or entities in any jurisdiction subject to comprehensive sanctions programs.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 3 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        3. Platform Use and Conduct Standards
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            Users agree to access and utilize Group platforms solely for legitimate business purposes consistent with the Group's institutional infrastructure mandate. Prohibited activities include:
                        </p>
                        <ul class="space-y-3 pl-4">
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Unauthorized access attempts, security testing, or penetration activities without explicit written authorization.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Automated data extraction, scraping, crawling, or systematic retrieval of platform content.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Transmission of malicious code, viruses, or any technology designed to disrupt platform operations.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Misrepresentation of identity, affiliation, or authority to act on behalf of any entity.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Circumvention of access controls, authentication mechanisms, or security measures.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Use of platform content for competitive intelligence, market analysis, or commercial purposes unrelated to legitimate partnership evaluation.</span>
                            </li>
                        </ul>
                        <p class="pt-4 border-t border-champagne-500/10 text-sovereign-400">
                            Violation of these conduct standards may result in immediate access termination, legal action, and notification to relevant regulatory authorities.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 4 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        4. Intellectual Property Rights
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <div>
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">4.1 Group Proprietary Rights</h3>
                            <p>
                                All content, materials, trademarks, service marks, trade names, logos, and intellectual property displayed on or accessible through Group platforms remain the exclusive property of Unggul Axiom Group or its licensors. This includes but is not limited to: platform architecture, business methodologies, analytical frameworks, proprietary data, and visual design elements.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">4.2 Limited License</h3>
                            <p>
                                Subject to compliance with these Terms, the Group grants users a limited, non-exclusive, non-transferable, revocable license to access and view platform content solely for evaluation of potential business relationships. This license does not permit reproduction, distribution, modification, public display, or creation of derivative works without explicit written authorization.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">4.3 Trademark Usage</h3>
                            <p>
                                "Unggul Axiom Group," "Axiom," and related marks are proprietary trademarks. Unauthorized use of Group trademarks in connection with any product, service, or manner that may cause confusion or disparagement is strictly prohibited.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 5 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        5. Confidentiality Obligations
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            Certain platform content, including but not limited to financial projections, operational metrics, strategic initiatives, partnership structures, and proprietary methodologies, constitutes confidential information of the Group.
                        </p>
                        <p>
                            Users agree to maintain the confidentiality of all non-public information accessed through Group platforms and to use such information solely for the purpose of evaluating potential business relationships with the Group. Confidential information may not be disclosed to third parties without prior written consent.
                        </p>
                        <p class="pt-4 border-t border-champagne-500/10 text-sovereign-400">
                            These confidentiality obligations survive termination of platform access and continue for a period of five years from the date of disclosure, or until such information becomes publicly available through no fault of the receiving party.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 6 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        6. Investment Disclaimers
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            Platform content does not constitute an offer to sell, solicitation of an offer to buy, or recommendation of any security, investment product, or investment strategy. No content should be construed as investment, legal, tax, or financial advice.
                        </p>
                        <p>
                            Investment opportunities presented through the Group are available exclusively to accredited investors and qualified institutional buyers as defined under applicable securities regulations. All investments carry inherent risks, including potential loss of principal.
                        </p>
                        <p>
                            Past performance information, if presented, is not indicative of future results. Forward-looking statements are subject to risks, uncertainties, and assumptions that may cause actual results to differ materially from projections.
                        </p>
                        <p class="pt-4 border-t border-champagne-500/10 text-sovereign-400">
                            Prospective investors must conduct independent due diligence and consult with qualified professional advisors before making investment decisions. The Group makes no representations regarding the suitability of any investment for any particular investor.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 7 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        7. Limitation of Liability
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            To the maximum extent permitted by applicable law, Unggul Axiom Group and its affiliates, directors, officers, employees, and agents shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from or related to platform access or use, including but not limited to loss of profits, data, business opportunities, or goodwill.
                        </p>
                        <p>
                            The Group's aggregate liability for all claims arising from these Terms or platform use shall not exceed the amount paid by the user to the Group in the twelve months preceding the claim, or one thousand Malaysian Ringgit (MYR 1,000), whichever is greater.
                        </p>
                        <p class="pt-4 border-t border-champagne-500/10 text-sovereign-400">
                            These limitations apply regardless of the legal theory upon which liability is based, whether in contract, tort, negligence, strict liability, or otherwise, and even if the Group has been advised of the possibility of such damages.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 8 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        8. Indemnification
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            Users agree to indemnify, defend, and hold harmless Unggul Axiom Group and its affiliates, directors, officers, employees, agents, and representatives from and against any claims, liabilities, damages, losses, costs, or expenses (including reasonable legal fees) arising from:
                        </p>
                        <ul class="space-y-3 pl-4">
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Violation of these Terms or applicable laws and regulations.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Infringement of intellectual property or proprietary rights.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Breach of confidentiality obligations.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Misrepresentation of authority or unauthorized access.</span>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="text-champagne-500 font-bold">→</span>
                                <span>Any third-party claims resulting from user's platform access or use.</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Section 9 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        9. Dispute Resolution and Governing Law
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <div>
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">9.1 Governing Law</h3>
                            <p>
                                These Terms shall be governed by and construed in accordance with the laws of Malaysia, without regard to conflict of law principles.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">9.2 Arbitration</h3>
                            <p>
                                Any dispute, controversy, or claim arising out of or relating to these Terms, including their formation, interpretation, breach, or termination, shall be resolved through binding arbitration administered by the Asian International Arbitration Centre (AIAC) in accordance with its arbitration rules.
                            </p>
                            <p class="mt-2 text-sovereign-400">
                                Arbitration shall be conducted in Kuala Lumpur, Malaysia, in the English language, before a single arbitrator.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">9.3 Exceptions to Arbitration</h3>
                            <p>
                                Notwithstanding the arbitration provision, either party may seek injunctive or equitable relief in any court of competent jurisdiction to protect intellectual property rights or confidential information.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 10 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        10. Modifications and Termination
                    </h2>
                    <div class="space-y-6 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <div>
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">10.1 Terms Modifications</h3>
                            <p>
                                The Group reserves the right to modify these Terms at any time without prior notice. Modifications become effective upon posting to the platform. Users are responsible for regularly reviewing these Terms.
                            </p>
                        </div>
                        <div class="pt-4 border-t border-champagne-500/10">
                            <h3 class="text-lg text-champagne-500 mb-2 font-serif font-bold">10.2 Access Termination</h3>
                            <p>
                                The Group may suspend or terminate platform access at any time, with or without cause, with or without notice. Provisions regarding intellectual property, confidentiality, limitation of liability, indemnification, and dispute resolution survive termination.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 11 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        11. General Provisions
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            <strong>Entire Agreement:</strong> These Terms, together with the Privacy Policy and any additional agreements executed between parties, constitute the entire agreement regarding platform access and use.
                        </p>
                        <p>
                            <strong>Severability:</strong> If any provision is found invalid or unenforceable, the remaining provisions continue in full force and effect.
                        </p>
                        <p>
                            <strong>Waiver:</strong> Failure to enforce any provision does not constitute a waiver of that provision or any other provision.
                        </p>
                        <p>
                            <strong>Assignment:</strong> Users may not assign or transfer these Terms. The Group may assign these Terms to any affiliate or successor entity without restriction.
                        </p>
                        <p>
                            <strong>Force Majeure:</strong> Neither party shall be liable for failure to perform obligations due to circumstances beyond reasonable control, including natural disasters, war, terrorism, or governmental actions.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Section 12 -->
            <div class="glass-panel p-8 md:p-10 rounded-2xl border border-champagne-500/15 shadow-2xl relative overflow-hidden gsap-fade-up">
                <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                <div class="relative z-10">
                    <h2 class="font-serif text-2xl md:text-3xl text-platinum-50 tracking-tight mb-6 font-bold">
                        12. Contact Information
                    </h2>
                    <div class="space-y-4 text-sm md:text-base text-platinum-200 leading-relaxed">
                        <p>
                            For questions regarding these Terms of Service or to request clarification on any provision, please contact:
                        </p>
                        <div class="mt-6 p-8 bg-obsidian-950/60 border border-champagne-500/20 rounded-xl relative overflow-hidden">
                            <div class="tech-grid absolute inset-0 opacity-5 pointer-events-none"></div>
                            <div class="relative z-10">
                                <p class="font-semibold text-champagne-500 mb-4 font-serif text-lg">Legal Department</p>
                                <p class="text-platinum-50 font-medium">Unggul Bronto Sdn. Bhd.</p>
                                <p class="text-sovereign-300 text-xs">Registration No: 202301027920 (1521843-P)</p>
                                <p class="text-platinum-200">Kuala Lumpur, Malaysia</p>
                                <p class="mt-4 text-platinum-100">
                                    Email: <a href="mailto:legal@unggulaxiom.com" class="text-champagne-400 hover:text-champagne-300 hover:underline transition-colors">legal@unggulaxiom.com</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
