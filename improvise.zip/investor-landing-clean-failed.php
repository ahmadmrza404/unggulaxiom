<?php
/**
 * ============================================
 * INVESTOR RELATIONS - UNGGUL AXIOM GROUP
 * ============================================
 * Purpose: Institutional investment opportunity
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Investor Relations';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- HERO -->
<section class="min-h-[80vh] flex items-center justify-center bg-obsidian-950 py-32">
    <div class="container-sovereign">
        <div class="max-w-4xl mx-auto text-center">
            <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-8 block">
                INVESTOR RELATIONS
            </span>
            <h1 class="font-serif text-6xl md:text-7xl text-platinum-50 tracking-tight leading-none mb-8">
                Institutional Investment Opportunity
            </h1>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-12"></div>
            <p class="text-xl text-platinum-200 leading-institutional max-w-3xl mx-auto">
                South Korean government backed halal infrastructure platform with AI and IoT technology transfer
            </p>
        </div>
    </div>
</section>

<!-- INVESTMENT HIGHLIGHTS -->
<section class="py-32 bg-platinum-50">
    <div class="container-sovereign">
        <div class="max-w-4xl mx-auto">
            <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-12 block">
                INVESTMENT HIGHLIGHTS
            </span>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
                <div class="border-l-2 border-champagne-600 pl-6">
                    <p class="text-4xl font-serif text-obsidian-950 mb-2">USD 10M</p>
                    <p class="text-sm text-obsidian-700">Government Grant</p>
                </div>
                <div class="border-l-2 border-champagne-600 pl-6">
                    <p class="text-4xl font-serif text-obsidian-950 mb-2">RM19.8M</p>
                    <p class="text-sm text-obsidian-700">Base Net Profit</p>
                </div>
                <div class="border-l-2 border-champagne-600 pl-6">
                    <p class="text-4xl font-serif text-obsidian-950 mb-2">1-2 Years</p>
                    <p class="text-sm text-obsidian-700">Payback Period</p>
                </div>
            </div>

            <div class="space-y-6">
                <div class="flex items-start gap-4">
                    <span class="text-champagne-600 mt-1">•</span>
                    <p class="text-lg text-obsidian-800 leading-institutional">
                        South Korean government technology transfer with AI and IoT systems
                    </p>
                </div>
                <div class="flex items-start gap-4">
                    <span class="text-champagne-600 mt-1">•</span>
                    <p class="text-lg text-obsidian-800 leading-institutional">
                        Complete operational independence with zero ongoing dependencies
                    </p>
                </div>
                <div class="flex items-start gap-4">
                    <span class="text-champagne-600 mt-1">•</span>
                    <p class="text-lg text-obsidian-800 leading-institutional">
                        Scalable infrastructure model across Asia markets
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- GOVERNMENT BACKING -->
<section class="py-32 bg-obsidian-950">
    <div class="container-sovereign">
        <div class="max-w-4xl mx-auto">
            <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-12 block">
                GOVERNMENT BACKING
            </span>

            <h2 class="text-4xl font-serif text-platinum-50 mb-8 leading-tight">
                South Korean Government Support
            </h2>

            <div class="border-l-4 border-champagne-500 pl-8 py-6 mb-12">
                <p class="text-2xl font-serif text-platinum-50 mb-4">
                    USD 10 Million Grant Commitment
                </p>
                <p class="text-lg text-platinum-200 leading-institutional">
                    South Korean government committed to providing USD 10 million grant upon successful completion and validation of first farm deployment in Malaysia.
                </p>
            </div>

            <div class="space-y-8">
                <div>
                    <h3 class="text-xl font-serif text-platinum-50 mb-4">AI and IoT Technology Transfer</h3>
                    <p class="text-base text-platinum-200 leading-institutional">
                        Complete transfer of advanced poultry production technology powered by artificial intelligence and Internet of Things systems. Technology significantly outperforms all existing chicken farming systems in Malaysia across feed conversion efficiency, disease prevention, growth optimization, and production yield.
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-serif text-platinum-50 mb-4">Operational Independence</h3>
                    <p class="text-base text-platinum-200 leading-institutional">
                        Full technology transfer includes parent stock breeding, exclusive feed formula with 100% usage rights, and complete operational systems. No reliance on external companies for any operational component.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FINANCIAL SNAPSHOT -->
<section class="py-32 bg-platinum-50">
    <div class="container-sovereign">
        <div class="max-w-4xl mx-auto">
            <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-12 block">
                FINANCIAL SNAPSHOT
            </span>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="border border-champagne-500/20 p-8">
                    <h3 class="text-sm text-champagne-600 tracking-wider mb-4">PRODUCTION</h3>
                    <p class="text-3xl font-serif text-obsidian-950 mb-2">3.6M chickens</p>
                    <p class="text-sm text-obsidian-700">per year per node</p>
                </div>

                <div class="border border-champagne-500/20 p-8">
                    <h3 class="text-sm text-champagne-600 tracking-wider mb-4">NET PROFIT</h3>
                    <p class="text-3xl font-serif text-obsidian-950 mb-2">RM7.2M to RM30.6M</p>
                    <p class="text-sm text-obsidian-700">Base: RM19.8M</p>
                </div>

                <div class="border border-champagne-500/20 p-8">
                    <h3 class="text-sm text-champagne-600 tracking-wider mb-4">CAPEX</h3>
                    <p class="text-3xl font-serif text-obsidian-950 mb-2">RM12M to RM18M</p>
                    <p class="text-sm text-obsidian-700">per node</p>
                </div>

                <div class="border border-champagne-500/20 p-8">
                    <h3 class="text-sm text-champagne-600 tracking-wider mb-4">PAYBACK</h3>
                    <p class="text-3xl font-serif text-obsidian-950 mb-2">1 to 2 years</p>
                    <p class="text-sm text-obsidian-700">target range</p>
                </div>
            </div>
        </div>
    </div>
</section>

