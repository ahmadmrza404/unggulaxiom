/**
 * Career Application Form Handler
 */

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('careerForm');

    if (!form) return;

    form.addEventListener('submit', async function(e) {
        e.preventDefault();

        // Disable submit button and show loading state
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.textContent = 'SUBMITTING...';

        // Create FormData object
        const formData = new FormData(form);

        try {
            const response = await fetch('process-career-application.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                // Show success message
                showMessage('success', result.message);

                // Reset form
                form.reset();

                // Scroll to top
                window.scrollTo({ top: 0, behavior: 'smooth' });
            } else {
                // Show error message
                const errorMsg = result.errors
                    ? result.errors.join('<br>')
                    : result.message || 'An error occurred. Please try again.';
                showMessage('error', errorMsg);
            }
        } catch (error) {
            console.error('Form submission error:', error);
            showMessage('error', 'Network error. Please check your connection and try again.');
        } finally {
            // Re-enable submit button
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;
        }
    });

    // File upload validation
    const resumeInput = form.querySelector('input[name="resume"]');
    const additionalDocInput = form.querySelector('input[name="additional_doc"]');

    if (resumeInput) {
        resumeInput.addEventListener('change', function() {
            validateFile(this, 'Resume');
        });
    }

    if (additionalDocInput) {
        additionalDocInput.addEventListener('change', function() {
            validateFile(this, 'Additional document');
        });
    }

    function validateFile(input, label) {
        const file = input.files[0];
        if (!file) return;

        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

        if (file.size > maxSize) {
            alert(`${label} file size must be less than 5MB`);
            input.value = '';
            return;
        }

        if (!allowedTypes.includes(file.type)) {
            alert(`${label} must be PDF, DOC, or DOCX format`);
            input.value = '';
            return;
        }
    }

    function showMessage(type, message) {
        // Remove existing messages
        const existingMsg = document.querySelector('.form-message');
        if (existingMsg) {
            existingMsg.remove();
        }

        // Create message element
        const messageDiv = document.createElement('div');
        messageDiv.className = `form-message ${type}`;
        messageDiv.innerHTML = message;

        // Style based on type
        if (type === 'success') {
            messageDiv.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: #d4af37;
                color: #1a2332;
                padding: 20px 40px;
                border-radius: 4px;
                font-family: monospace;
                font-size: 14px;
                z-index: 10000;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                max-width: 90%;
                text-align: center;
            `;
        } else {
            messageDiv.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: #dc3545;
                color: white;
                padding: 20px 40px;
                border-radius: 4px;
                font-family: monospace;
                font-size: 14px;
                z-index: 10000;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                max-width: 90%;
                text-align: center;
            `;
        }

        document.body.appendChild(messageDiv);

        // Auto-remove after 5 seconds
        setTimeout(() => {
            messageDiv.style.opacity = '0';
            messageDiv.style.transition = 'opacity 0.3s';
            setTimeout(() => messageDiv.remove(), 300);
        }, 5000);
    }
});
