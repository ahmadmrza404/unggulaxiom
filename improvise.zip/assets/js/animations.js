/**
 * ============================================
 * UNGGUL AXIOM GROUP - ANIMATION ENGINE
 * ============================================
 * Defensive GSAP + Lenis integration
 * Null-checks prevent console errors on pages without targets
 * ============================================
 */

class SovereignAnimationEngine {
    constructor() {
        this.lenis = null;
        this.isVisible = true;
        this.isMobile = this.detectMobile();
        this.prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        this.init();
    }

    detectMobile() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
               (window.matchMedia && window.matchMedia('(max-width: 768px)').matches);
    }

    initLenis() {
        if (this.prefersReducedMotion) {
            console.log('[Sovereign] Reduced motion detected - Lenis disabled');
            return;
        }

        if (this.isMobile) {
            this.lenis = new Lenis({
                duration: 0.8,
                easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
                orientation: 'vertical',
                smoothWheel: false,
                smoothTouch: false,
            });
        } else {
            this.lenis = new Lenis({
                duration: 1.0,
                easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
                orientation: 'vertical',
                smoothWheel: true,
                smoothTouch: false,
            });
        }

        const raf = (time) => {
            if (this.isVisible && this.lenis) {
                this.lenis.raf(time);
            }
            requestAnimationFrame(raf);
        };
        requestAnimationFrame(raf);
    }


    initVisibilityControl() {
        document.addEventListener('visibilitychange', () => {
            this.isVisible = !document.hidden;
            if (document.hidden && this.lenis) {
                this.lenis.stop();
            } else if (this.lenis) {
                this.lenis.start();
            }
        });
    }

    init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.start());
        } else {
            this.start();
        }
    }

    start() {
        this.initLenis();
        this.initVisibilityControl();
    }
}

const animationEngine = new SovereignAnimationEngine();
window.SovereignAnimations = animationEngine;
