/**
 * ============================================
 * BLUEPRINT ENGINE - DISABLED
 * ============================================
 * Heavy scroll-triggered animations removed
 * ============================================
 */

// Blueprint engine disabled for performance
console.log('[Blueprint] Heavy animations disabled');
