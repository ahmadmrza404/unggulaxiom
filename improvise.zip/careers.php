<?php
/**
 * ============================================
 * CAREERS PAGE - UNGGUL AXIOM GROUP
 * ============================================
 */

require_once __DIR__ . '/config.php';

$_careers = json_decode(file_get_contents(DATA_PATH . '/careers.json'), true);
$page_title = 'Careers';

require_once INCLUDES_PATH . '/header.php';

// Check for success/error messages
$success = isset($_GET['success']) && $_GET['success'] == '1';
$error = isset($_GET['error']) && $_GET['error'] == '1';
?>

<?php if ($success): ?>
<div class="fixed top-4 right-4 z-50 max-w-md bg-green-900/90 border border-green-500 text-green-100 px-6 py-4 rounded shadow-lg" x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 5000)">
    <div class="flex items-start gap-3">
        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <div>
            <p class="font-semibold">Application submitted successfully</p>
            <p class="text-sm text-green-200 mt-1">We'll review your application and contact qualified candidates within two weeks.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="fixed top-4 right-4 z-50 max-w-md bg-red-900/90 border border-red-500 text-red-100 px-6 py-4 rounded shadow-lg" x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 8000)">
    <div class="flex items-start gap-3">
        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
        </svg>
        <div>
            <p class="font-semibold">Submission failed</p>
            <p class="text-sm text-red-200 mt-1">There was an error processing your application. Please try again or email careers@unggulaxiom.com directly.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- HERO SECTION -->
<section class="py-32 bg-obsidian-900 border-t border-champagne-500/20">
    <div class="container-sovereign">
        <div class="max-w-4xl mx-auto text-center gsap-fade-up">
            <h1 class="font-serif text-5xl md:text-6xl lg:text-7xl text-platinum-50 mb-6 tracking-editorial">
                <?= htmlspecialchars($_careers['careers']['title']) ?>
            </h1>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-xl text-sovereign-300 leading-relaxed">
                <?= htmlspecialchars($_careers['careers']['headline']) ?>
            </p>
        </div>
    </div>
</section>

<!-- COMPANY CULTURE -->
<section class="py-24 bg-obsidian-800 border-t border-champagne-500/20">
    <div class="container-sovereign">

        <div class="mb-16 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                WHY UNGGUL AXIOM
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto"></div>
        </div>

        <div class="max-w-5xl mx-auto mb-16">
            <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8 gsap-fade-up">
                <h3 class="text-2xl font-serif text-platinum-50 mb-4">Our Mission</h3>
                <p class="text-sovereign-300 leading-institutional text-lg">
                    <?= htmlspecialchars($_careers['careers']['mission']) ?>
                </p>
            </div>
        </div>

        <!-- VALUES -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 gsap-fade-up">
            <?php foreach ($_careers['careers']['core_values'] as $value): ?>
            <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8 hover:border-champagne-500/40 transition-colors">
                <div class="text-champagne-500 text-xs font-semibold tracking-ultra-wide uppercase mb-4">
                    <?= htmlspecialchars($value['name']) ?>
                </div>
                <p class="text-sovereign-300 text-base leading-relaxed"><?= htmlspecialchars($value['description']) ?></p>
            </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- CAREER OPPORTUNITIES -->
<section class="py-24 bg-obsidian-900 border-t border-champagne-500/20">
    <div class="container-sovereign">

        <div class="mb-16 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                OPEN POSITIONS
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto"></div>
        </div>

        <div class="max-w-5xl mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php foreach ($_careers['careers']['opportunities'] as $opportunity): ?>
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-6 hover:border-champagne-500/40 transition-colors">
                    <div class="flex items-start gap-3">
                        <span class="text-champagne-500 mt-1">→</span>
                        <span class="text-sovereign-300 text-base"><?= htmlspecialchars($opportunity) ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</section>

<!-- BENEFITS -->
<section class="py-24 bg-obsidian-800 border-t border-champagne-500/20">
    <div class="container-sovereign">

        <div class="mb-16 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                EMPLOYEE BENEFITS
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto"></div>
        </div>

        <div class="max-w-5xl mx-auto">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 gsap-fade-up">
                <?php foreach ($_careers['careers']['benefits'] as $benefit): ?>
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-6 hover:border-champagne-500/40 transition-colors">
                    <h3 class="text-platinum-50 text-lg font-medium mb-3"><?= htmlspecialchars($benefit['category']) ?></h3>
                    <p class="text-sovereign-300 text-sm leading-relaxed"><?= htmlspecialchars($benefit['description']) ?></p>
                </div>
                <?php endforeach; ?>
            </div>

        </div>

    </div>
</section>

<!-- APPLICATION FORM -->
<section class="py-24 bg-obsidian-900 border-t border-champagne-500/20">
    <div class="container-sovereign">

        <div class="mb-16 text-center gsap-fade-up">
            <h2 class="text-sovereign-xs text-champagne-500 font-semibold tracking-ultra-wide mb-6">
                <?= htmlspecialchars($_careers['careers']['application_form']['section_title'] ?? 'JOIN OUR TEAM') ?>
            </h2>
            <div class="w-24 h-px bg-champagne-500 mx-auto mb-8"></div>
            <p class="text-sovereign-300 max-w-2xl mx-auto leading-relaxed">
                <?= htmlspecialchars($_careers['careers']['application_form']['section_description'] ?? 'Submit your application below. We review all submissions and will contact qualified candidates within two weeks.') ?>
            </p>
        </div>

        <div class="max-w-4xl mx-auto">

            <form id="careerForm" class="space-y-6 gsap-fade-up" method="POST" action="process-career-application.php" enctype="multipart/form-data">

                <!-- Personal Information -->
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                    <h3 class="text-xl font-serif text-platinum-50 mb-6">Personal Information</h3>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                                Full Name *
                            </label>
                            <input type="text" name="full_name" required
                                   class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                        </div>

                        <div>
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                                Email Address *
                            </label>
                            <input type="email" name="email" required
                                   class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                        <div>
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                                Phone Number *
                            </label>
                            <input type="tel" name="phone" required
                                   class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                        </div>

                        <div>
                            <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                                Location *
                            </label>
                            <input type="text" name="location" required placeholder="City, State"
                                   class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500">
                        </div>
                    </div>

                    <div class="mt-6">
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            LinkedIn Profile
                        </label>
                        <input type="url" name="linkedin"
                               class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                    </div>
                </div>

                <!-- Position Details -->
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                    <h3 class="text-xl font-serif text-platinum-50 mb-6">Position Details</h3>

                    <div class="mb-6">
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Position of Interest *
                        </label>
                        <select name="position" required
                                class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                            <option value="">Select a position</option>
                            <?php foreach ($_careers['careers']['opportunities'] as $opportunity): ?>
                            <option value="<?= htmlspecialchars(strtolower(str_replace(' ', '-', $opportunity))) ?>"><?= htmlspecialchars($opportunity) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-6">
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Availability *
                        </label>
                        <select name="availability" required
                                class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                            <option value="">Select availability</option>
                            <?php foreach ($_careers['careers']['application_form']['availability_options'] ?? ['Immediate', '2 weeks notice', '1 month notice', '2+ months'] as $option): ?>
                            <option value="<?= htmlspecialchars(strtolower(str_replace(' ', '-', $option))) ?>"><?= htmlspecialchars($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Expected Salary Range (RM) *
                        </label>
                        <input type="text" name="salary_expectation" required placeholder="e.g., 5,000 - 7,000"
                               class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500">
                    </div>
                </div>

                <!-- Professional Background -->
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                    <h3 class="text-xl font-serif text-platinum-50 mb-6">Professional Background</h3>

                    <div class="mb-6">
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Years of Experience *
                        </label>
                        <select name="experience_years" required
                                class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                            <option value="">Select experience level</option>
                            <?php foreach ($_careers['careers']['application_form']['experience_options'] ?? ['0-2 years', '3-5 years', '6-10 years', '10+ years'] as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>"><?= htmlspecialchars($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-6">
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Highest Education Level *
                        </label>
                        <select name="education" required
                                class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                            <option value="">Select education level</option>
                            <?php foreach ($_careers['careers']['application_form']['education_options'] ?? ['Diploma', "Bachelor's Degree", "Master's Degree", 'PhD', 'Other'] as $option): ?>
                            <option value="<?= htmlspecialchars(strtolower(str_replace("'", '', str_replace(' ', '-', $option)))) ?>"><?= htmlspecialchars($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-6">
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Field of Study
                        </label>
                        <input type="text" name="field_of_study"
                               class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors">
                    </div>

                    <div>
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Relevant Skills & Expertise *
                        </label>
                        <textarea name="skills" required rows="4" placeholder="List your key skills, certifications, and areas of expertise"
                                  class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500"></textarea>
                    </div>
                </div>

                <!-- Application Statement -->
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                    <h3 class="text-xl font-serif text-platinum-50 mb-6">Application Statement</h3>

                    <div>
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Why do you want to join Unggul Axiom? *
                        </label>
                        <textarea name="cover_letter" required rows="6" placeholder="Tell us about your interest in this role and what you would bring to our team"
                                  class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 transition-colors placeholder:text-sovereign-500"></textarea>
                    </div>
                </div>

                <!-- Documents -->
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                    <h3 class="text-xl font-serif text-platinum-50 mb-6">Documents</h3>

                    <div class="mb-6">
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Resume / CV * <span class="text-sovereign-400 text-xs normal-case">(PDF, DOC, DOCX - Max 5MB)</span>
                        </label>
                        <input type="file" name="resume" required accept=".pdf,.doc,.docx"
                               class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 file:mr-4 file:py-2 file:px-4 file:border-0 file:bg-champagne-500/10 file:text-champagne-500 file:cursor-pointer hover:file:bg-champagne-500/20 transition-colors">
                    </div>

                    <div>
                        <label class="block text-xs text-champagne-500 uppercase tracking-wider mb-2">
                            Additional Documents <span class="text-sovereign-400 text-xs normal-case">(Optional - PDF, DOC, DOCX - Max 5MB)</span>
                        </label>
                        <input type="file" name="additional_doc" accept=".pdf,.doc,.docx"
                               class="w-full bg-obsidian-900 border border-champagne-500/20 text-sovereign-300 px-4 py-3 focus:outline-none focus:border-champagne-500 file:mr-4 file:py-2 file:px-4 file:border-0 file:bg-champagne-500/10 file:text-champagne-500 file:cursor-pointer hover:file:bg-champagne-500/20 transition-colors">
                    </div>
                </div>

                <!-- Consent -->
                <div class="border border-champagne-500/20 bg-obsidian-950/50 p-8">
                    <label class="flex items-start gap-3 cursor-pointer group">
                        <input type="checkbox" name="consent" required class="mt-1 w-4 h-4 border-champagne-500/20 bg-obsidian-900 text-champagne-500 focus:ring-champagne-500">
                        <span class="text-sm text-sovereign-300 leading-relaxed">
                            I consent to the collection and processing of my personal data for recruitment purposes. I understand that Unggul Axiom Group will handle my information in accordance with applicable data protection regulations. *
                        </span>
                    </label>
                </div>

                <!-- Submit Button -->
                <div class="text-center pt-4">
                    <button type="submit"
                            class="inline-flex items-center gap-3 px-12 py-4 bg-champagne-500 text-obsidian-900 text-xs font-bold uppercase tracking-wider transition-all duration-300 hover:bg-champagne-400 hover:shadow-lg hover:shadow-champagne-500/20">
                        <span>Submit Application</span>
                        <span class="text-lg">→</span>
                    </button>
                    <p class="text-xs text-sovereign-400 mt-4">* Required fields</p>
                </div>

            </form>

        </div>

    </div>
</section>

<script src="assets/js/career-form.js"></script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
