<?php
$analytics_file = __DIR__ . '/data/analytics.json';
$analytics_data = file_exists($analytics_file) ? json_decode(file_get_contents($analytics_file), true) : [
    'page_views' => [],
    'unique_visitors' => [],
    'referrers' => [],
    'popular_pages' => [],
    'last_updated' => date('Y-m-d H:i:s')
];

$current_page = $_SERVER['REQUEST_URI'] ?? '/';
$visitor_ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$visitor_id = md5($visitor_ip . $_SERVER['HTTP_USER_AGENT'] ?? '');
$referrer = $_SERVER['HTTP_REFERER'] ?? 'direct';

$today = date('Y-m-d');

if (!isset($analytics_data['page_views'][$today])) {
    $analytics_data['page_views'][$today] = 0;
}
$analytics_data['page_views'][$today]++;

if (!isset($analytics_data['unique_visitors'][$visitor_id])) {
    $analytics_data['unique_visitors'][$visitor_id] = [
        'first_visit' => date('Y-m-d H:i:s'),
        'last_visit' => date('Y-m-d H:i:s'),
        'page_count' => 0
    ];
}
$analytics_data['unique_visitors'][$visitor_id]['last_visit'] = date('Y-m-d H:i:s');
$analytics_data['unique_visitors'][$visitor_id]['page_count']++;

if (!isset($analytics_data['popular_pages'][$current_page])) {
    $analytics_data['popular_pages'][$current_page] = 0;
}
$analytics_data['popular_pages'][$current_page]++;

$analytics_data['last_updated'] = date('Y-m-d H:i:s');

file_put_contents($analytics_file, json_encode($analytics_data, JSON_PRETTY_PRINT));
