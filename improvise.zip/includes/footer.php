    <!-- ============================================ -->
    <!-- INSTITUTIONAL FOOTER -->
    <!-- ============================================ -->
    <footer class="bg-sovereign-900 border-t border-champagne-500/30 mt-32">

        <!-- PRIMARY FOOTER CONTENT -->
        <div class="container-sovereign py-16">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8">

                <!-- COLUMN 1: BRAND STATEMENT -->
                <div class="lg:col-span-1">
                    <h3 class="font-serif text-2xl text-platinum-50 mb-4 tracking-editorial">
                        Unggul Axiom Group
                    </h3>
                    <p class="text-sovereign-400 text-sm leading-institutional mb-6">
                        Global halal economy architecture. Sovereign-level infrastructure across systems, sectors, and capital markets.
                    </p>
                    <div class="flex items-center space-x-4">
                        <a href="#" class="text-sovereign-400 hover:text-champagne-400 transition-colors duration-300" aria-label="LinkedIn">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                            </svg>
                        </a>
                    </div>
                </div>

                <!-- COLUMN 2: SYSTEMS & SECTORS -->
                <div class="lg:col-span-1">
                    <h4 class="text-sovereign-xs text-champagne-500 font-semibold mb-6 tracking-ultra-wide">
                        ARCHITECTURE
                    </h4>
                    <ul class="space-y-3">
                        <li>
                            <a href="<?php echo route('systems'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Systems
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('sectors'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Sectors
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('cipu'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                CIPU Pilot
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('capital'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Capital Structure
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- COLUMN 3: GOVERNANCE -->
                <div class="lg:col-span-1">
                    <h4 class="text-sovereign-xs text-champagne-500 font-semibold mb-6 tracking-ultra-wide">
                        GOVERNANCE
                    </h4>
                    <ul class="space-y-3">
                        <li>
                            <a href="<?php echo route('governance'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Framework
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('shariah_governance'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Shariah Oversight
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('compliance'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Compliance
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('privacy_policy'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Privacy Policy
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('terms_of_service'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Terms of Service
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- COLUMN 4: CORPORATE -->
                <div class="lg:col-span-1">
                    <h4 class="text-sovereign-xs text-champagne-500 font-semibold mb-6 tracking-ultra-wide">
                        CORPORATE
                    </h4>
                    <ul class="space-y-3">
                        <li>
                            <a href="<?php echo route('about'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                About
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('leadership'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Leadership
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('careers'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Careers
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('contact'); ?>"
                               class="text-sm text-platinum-200 hover:text-champagne-400 transition-colors duration-300">
                                Contact
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- COLUMN 5: CONTACT -->
                <div class="lg:col-span-1">
                    <h4 class="text-sovereign-xs text-champagne-500 font-semibold mb-6 tracking-ultra-wide">
                        CONTACT
                    </h4>
                    <div class="space-y-4">
                        <div>
                            <p class="text-xs text-champagne-500 tracking-wider mb-1">GENERAL INQUIRIES</p>
                            <a href="<?php echo route('contact'); ?>"
                               class="group flex items-center gap-2 text-sm text-platinum-200 transition-all duration-300">
                                <span>Get in Touch</span>
                                <span class="opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">→</span>
                            </a>
                        </div>
                        <div>
                            <p class="text-xs text-champagne-500 tracking-wider mb-1">PARTNERSHIPS</p>
                            <a href="<?php echo route('partnerships'); ?>"
                               class="group flex items-center gap-2 text-sm text-platinum-200 transition-all duration-300">
                                <span>Strategic Partnerships</span>
                                <span class="opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">→</span>
                            </a>
                        </div>
                    </div>
                    <div class="mt-8 pt-6 border-t border-champagne-500/10">
                        <p class="text-xs text-champagne-500 tracking-wider mb-2">HEADQUARTERS</p>
                        <p class="text-sm text-sovereign-400">Kuala Lumpur, Malaysia</p>
                    </div>
                </div>

            </div>
        </div>

        <!-- COMPLIANCE & LEGAL FOOTER -->
        <div class="border-t border-champagne-500/10">
            <div class="container-sovereign py-12">

                <div class="space-y-8 max-w-5xl">

                    <!-- LEGAL ENTITY -->
                    <div class="text-xs text-sovereign-400 leading-relaxed">
                        <strong class="text-sovereign-300">UNGGUL BRONTO SDN. BHD.</strong><br>
                        Registration No: 202301027920 (1521843-P)<br>
                        &copy; <?php echo date('Y'); ?> <?php echo esc(SITE_NAME); ?>. All rights reserved.
                    </div>

                    <!-- REGULATORY DISCLOSURE -->
                    <div class="text-xs text-sovereign-500 leading-relaxed">
                        <strong class="text-sovereign-400">Regulatory Disclosure:</strong>
                        Unggul Axiom Group and its subsidiaries operate under strict regulatory oversight.
                        Investment opportunities are subject to eligibility requirements and regulatory approval.
                        Past performance does not guarantee future results. All investments carry inherent risks.
                        This platform is intended for institutional and accredited investors only.
                    </div>

                    <!-- CAPITAL ENGAGEMENT STATEMENT -->
                    <div class="text-xs text-sovereign-400 leading-relaxed font-semibold">
                        Capital engagement is structured through institutional channels. Selective collaboration framework.
                    </div>

                </div>

            </div>
        </div>

    </footer>

    <!-- ============================================ -->
    <!-- ANIMATION ENGINE - CDN DEPENDENCIES -->
    <!-- ============================================ -->

    <!-- GSAP Core Library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>

    <!-- GSAP ScrollTrigger Plugin -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>

    <!-- Lenis Smooth Scroll -->
    <script src="https://cdn.jsdelivr.net/npm/@studio-freight/lenis@1.0.42/dist/lenis.min.js"></script>

    <!-- SplitType - Typography Splitting -->
    <script src="https://unpkg.com/split-type"></script>

    <!-- ============================================ -->
    <!-- CUSTOM JAVASCRIPT -->
    <!-- ============================================ -->
    <script src="<?php echo url('/assets/js/main.js'); ?>"></script>

    <!-- ============================================ -->
    <!-- CANVAS NETWORK ENGINE -->
    <!-- ============================================ -->
    <script src="<?php echo url('/assets/js/canvas-network.js'); ?>"></script>

    <!-- ============================================ -->
    <!-- BLUEPRINT ENGINE -->
    <!-- ============================================ -->
    <script src="<?php echo url('/assets/js/blueprint.js'); ?>"></script>

    <!-- ============================================ -->
    <!-- ANIMATION ENGINE INITIALIZATION -->
    <!-- ============================================ -->
    <script src="<?php echo url('/assets/js/animations.js'); ?>"></script>

    <?php require_once __DIR__ . '/cookies-consent.php'; ?>

</body>
</html>
