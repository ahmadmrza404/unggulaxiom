<?php
/**
 * Email Handler with SMTP Support
 * Uses PHPMailer for reliable email delivery
 */

// Check if PHPMailer is available
if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
    // Fallback to basic mail() function
    function send_form_email($to, $subject, $body, $reply_to = null, $attachments = []) {
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: Unggul Axiom <noreply@unggulaxiom.com>\r\n";

        if ($reply_to) {
            $headers .= "Reply-To: {$reply_to}\r\n";
        }

        // Note: Basic mail() cannot handle attachments easily
        return mail($to, $subject, $body, $headers);
    }
} else {
    // Use PHPMailer for better reliability
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    function send_form_email($to, $subject, $body, $reply_to = null, $attachments = []) {
        $mail = new PHPMailer(true);

        try {
            // Load SMTP settings if configured
            $smtp_config = __DIR__ . '/../config/smtp.php';
            if (file_exists($smtp_config)) {
                $smtp = require $smtp_config;

                $mail->isSMTP();
                $mail->Host = $smtp['host'];
                $mail->SMTPAuth = true;
                $mail->Username = $smtp['username'];
                $mail->Password = $smtp['password'];
                $mail->SMTPSecure = $smtp['encryption'] ?? PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = $smtp['port'] ?? 587;
            }

            // Sender
            $mail->setFrom('noreply@unggulaxiom.com', 'Unggul Axiom');

            // Recipient
            $mail->addAddress($to);

            // Reply-To
            if ($reply_to) {
                $mail->addReplyTo($reply_to);
            }

            // Attachments
            foreach ($attachments as $file) {
                if (file_exists($file)) {
                    $mail->addAttachment($file);
                }
            }

            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;
            $mail->CharSet = 'UTF-8';

            return $mail->send();

        } catch (Exception $e) {
            error_log("Email send failed: {$mail->ErrorInfo}");
            return false;
        }
    }
}

/**
 * Log email attempt for debugging
 */
function log_email_attempt($type, $to, $success, $details = '') {
    $log_file = __DIR__ . '/../logs/email-log.txt';
    $log_dir = dirname($log_file);

    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $status = $success ? 'SUCCESS' : 'FAILED';
    $timestamp = date('Y-m-d H:i:s');
    $entry = "[{$timestamp}] {$type} to {$to} - {$status}";

    if ($details) {
        $entry .= " - {$details}";
    }

    $entry .= "\n";

    file_put_contents($log_file, $entry, FILE_APPEND);
}
