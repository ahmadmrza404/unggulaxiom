<?php
/**
 * ============================================
 * IMAGE UTILITY FUNCTIONS
 * ============================================
 * Phase 18: WebP with fallback, lazy loading
 *
 * Usage:
 * echo responsive_image('/assets/images/hero.jpg', 'Hero Image', 'eager');
 * echo responsive_image('/assets/images/stat.jpg', 'Market Stat', 'lazy');
 * ============================================
 */

/**
 * Generate responsive image with WebP fallback
 *
 * @param string $image_path Path to image (without extension)
 * @param string $alt Alt text for accessibility
 * @param string $loading Loading strategy: 'eager' or 'lazy'
 * @param string $classes Additional CSS classes
 * @return string HTML picture element
 */
function responsive_image($image_path, $alt, $loading = 'lazy', $classes = '') {
    $path_info = pathinfo($image_path);
    $base_path = $path_info['dirname'] . '/' . $path_info['filename'];
    $extension = $path_info['extension'] ?? 'jpg';

    $webp_path = $base_path . '.webp';
    $fallback_path = $image_path;

    $html = '<picture>';
    $html .= '<source srcset="' . esc($webp_path) . '" type="image/webp">';
    $html .= '<img src="' . esc($fallback_path) . '" ';
    $html .= 'alt="' . esc($alt) . '" ';
    $html .= 'loading="' . esc($loading) . '" ';
    $html .= 'decoding="async" ';
    if ($classes) {
        $html .= 'class="' . esc($classes) . '" ';
    }
    $html .= '>';
    $html .= '</picture>';

    return $html;
}

/**
 * Generate lazy-loaded iframe
 *
 * @param string $src Iframe source URL
 * @param string $title Iframe title for accessibility
 * @param string $classes Additional CSS classes
 * @return string HTML iframe element
 */
function lazy_iframe($src, $title, $classes = '') {
    $html = '<iframe ';
    $html .= 'src="' . esc($src) . '" ';
    $html .= 'title="' . esc($title) . '" ';
    $html .= 'loading="lazy" ';
    if ($classes) {
        $html .= 'class="' . esc($classes) . '" ';
    }
    $html .= '></iframe>';

    return $html;
}
?>
