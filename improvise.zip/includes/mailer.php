<?php
/**
 * Email sending function using SMTP configuration
 */

function send_email($to, $subject, $body, $reply_to = null) {
    $smtp_config_file = __DIR__ . '/../config/smtp.php';

    if (!file_exists($smtp_config_file)) {
        error_log('SMTP config not found. Configure SMTP in admin panel.');
        return false;
    }

    $smtp = require $smtp_config_file;

    if (!$smtp['enabled']) {
        error_log('SMTP is disabled. Enable it in admin panel SMTP settings.');
        return false;
    }

    if (empty($smtp['host']) || empty($smtp['username']) || empty($smtp['password'])) {
        error_log('SMTP configuration incomplete. Check admin panel SMTP settings.');
        return false;
    }

    // Configure SMTP via ini_set for mail() function
    ini_set('SMTP', $smtp['host']);
    ini_set('smtp_port', $smtp['port']);
    ini_set('sendmail_from', $smtp['from_email']);

    // Build headers
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "From: {$smtp['from_name']} <{$smtp['from_email']}>\r\n";

    if ($reply_to) {
        $headers .= "Reply-To: {$reply_to}\r\n";
    }

    $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";

    // Attempt to send
    $result = @mail($to, $subject, $body, $headers);

    if (!$result) {
        error_log("Email send failed to: {$to}");
    }

    return $result;
}
