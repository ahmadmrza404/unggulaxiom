<!-- COOKIES CONSENT -->
<div id="cookies-consent" class="fixed bottom-6 right-6 max-w-md bg-obsidian-900 border border-champagne-500/20 p-6 shadow-2xl z-50 hidden">
    <div class="space-y-4">
        <div>
            <h3 class="text-sm font-medium text-platinum-50 mb-2">Cookie Notice</h3>
            <p class="text-xs text-platinum-300 leading-relaxed">
                We use cookies to enhance your browsing experience and analyze site traffic. By continuing to use this site, you consent to our use of cookies.
            </p>
        </div>
        <div class="flex gap-3">
            <button onclick="acceptCookies()" class="flex-1 px-4 py-2 bg-champagne-500 text-obsidian-950 text-xs font-medium hover:bg-champagne-400 transition-colors">
                Accept
            </button>
            <button onclick="declineCookies()" class="px-4 py-2 border border-champagne-500/30 text-platinum-300 text-xs font-medium hover:border-champagne-500/60 transition-colors">
                Decline
            </button>
        </div>
    </div>
</div>

<script>
function checkCookieConsent() {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
        document.getElementById('cookies-consent').classList.remove('hidden');
    }
}

function acceptCookies() {
    localStorage.setItem('cookieConsent', 'accepted');
    document.getElementById('cookies-consent').classList.add('hidden');
}

function declineCookies() {
    localStorage.setItem('cookieConsent', 'declined');
    document.getElementById('cookies-consent').classList.add('hidden');
}

// Check on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', checkCookieConsent);
} else {
    checkCookieConsent();
}
</script>
