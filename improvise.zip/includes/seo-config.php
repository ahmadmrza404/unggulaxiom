<?php
/**
 * ============================================
 * SEO METADATA ENGINE
 * ============================================
 * Phase 17: Dynamic page-specific metadata
 *
 * Usage: Set $seo_page variable before including header.php
 * Example: $seo_page = 'home'; or $seo_page = 'cipu';
 * ============================================
 */

// SEO Configuration Array
$seo_config = [
    'home' => [
        'title' => 'Sovereign Halal Infrastructure Platform | Unggul Axiom Group',
        'description' => 'Unggul Axiom Group: Integrated halal infrastructure platform connecting production, certification, logistics, and global market access. Built for institutional investors and sovereign wealth funds.',
        'keywords' => 'sovereign halal infrastructure, integrated halal ecosystem, halal economy architecture, institutional halal investment, ASEAN halal infrastructure, halal supply chain integration',
        'og_image' => '/assets/images/og-home.jpg',
    ],
    'ecosystem' => [
        'title' => 'Integrated Halal Ecosystem | Unggul Axiom Group',
        'description' => 'Five vertically integrated entities: Axiom Agro, HalalTech, Logistics, Global Trade, and Capital. Sovereign-level halal infrastructure for institutional partners.',
        'keywords' => 'halal ecosystem integration, axiom agro, halal certification systems, halal logistics infrastructure, halal trade facilitation',
        'og_image' => '/assets/images/og-ecosystem.jpg',
    ],
    'cipu' => [
        'title' => 'Central Integrated Poultry Unggul (CIPU) | Unggul Axiom Group',
        'description' => 'CIPU: High-efficiency vertically integrated poultry infrastructure. National food security asset designed for scalable halal protein production and export readiness.',
        'keywords' => 'integrated poultry infrastructure, halal poultry production, food security Malaysia, CIPU project, halal protein supply chain',
        'og_image' => '/assets/images/og-cipu.jpg',
    ],
    'investor' => [
        'title' => 'Strategic Partnerships & Investment | Unggul Axiom Group',
        'description' => 'Institutional investment opportunities in sovereign halal infrastructure. Structured entry into the USD 10 trillion global halal economy for accredited investors.',
        'keywords' => 'halal infrastructure investment, institutional halal investment, sovereign wealth fund opportunities, ASEAN infrastructure investment, halal economy investment',
        'og_image' => '/assets/images/og-investor.jpg',
    ],
    'about' => [
        'title' => 'About Unggul Axiom Group | Sovereign Halal Infrastructure',
        'description' => 'Strategic infrastructure organization focused on integrated halal ecosystems. System builder for the global halal economy, not a conventional agricultural operator.',
        'keywords' => 'unggul axiom group, halal infrastructure platform, integrated halal systems, halal economy architecture',
        'og_image' => '/assets/images/og-about.jpg',
    ],
    'contact' => [
        'title' => 'Contact | Unggul Axiom Group',
        'description' => 'Strategic Infrastructure Division, Kuala Lumpur, Malaysia. Contact Unggul Axiom Group for partnerships, investment, and institutional collaboration.',
        'keywords' => 'contact unggul axiom, halal infrastructure partnerships, institutional collaboration Malaysia',
        'og_image' => '/assets/images/og-contact.jpg',
    ],
];

// Determine current page
if (!isset($seo_page)) {
    $current_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $seo_page = match(true) {
        $current_path === '/' || $current_path === '/index.php' => 'home',
        str_contains($current_path, 'ecosystem') => 'ecosystem',
        str_contains($current_path, 'cipu') => 'cipu',
        str_contains($current_path, 'investor') => 'investor',
        str_contains($current_path, 'about') => 'about',
        str_contains($current_path, 'contact') => 'contact',
        default => 'home'
    };
}

// Get SEO data for current page
$seo = $seo_config[$seo_page] ?? $seo_config['home'];

// Set page title
$page_title = $seo['title'];
$meta_description = $seo['description'];
$meta_keywords = $seo['keywords'];
$og_image = url($seo['og_image']);
?>
