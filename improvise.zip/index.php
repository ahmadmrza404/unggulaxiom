<?php
/**
 * ============================================
 * HOMEPAGE CONTROLLER - UNGGUL AXIOM GROUP
 * ============================================
 * Purpose: Modular homepage routing
 * Architecture: Includes sequential section partials
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Home';

require_once INCLUDES_PATH . '/header.php';

// Homepage Sections (Sequential Order)
include __DIR__ . '/partials/home/hero.php';
include __DIR__ . '/partials/home/positioning.php';
include __DIR__ . '/partials/home/market.php';
include __DIR__ . '/partials/home/framework.php';
include __DIR__ . '/partials/home/systems-sectors.php';
include __DIR__ . '/partials/home/ecosystem.php';
include __DIR__ . '/partials/home/uhic.php';
include __DIR__ . '/partials/home/cipu-pilot.php';
include __DIR__ . '/partials/home/cipu-financial.php';
// include __DIR__ . '/partials/home/system-status.php';
include __DIR__ . '/partials/home/capital-structure.php';
include __DIR__ . '/partials/home/replication.php';
include __DIR__ . '/partials/home/governance.php';

require_once INCLUDES_PATH . '/footer.php';
?>
