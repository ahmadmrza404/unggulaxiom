<?php
/**
 * ============================================
 * INVESTOR LANDING PAGE - HIGH CONVERSION VERSION
 * ============================================
 * Purpose: Strategic institutional investment page
 * Architecture: Data room aesthetic with conversion focus
 * ============================================
 */

require_once __DIR__ . '/config.php';

$page_title = 'Investor Landing';

require_once INCLUDES_PATH . '/header.php';
?>

<!-- ============================================ -->
<!-- HERO SECTION -->
<!-- ============================================ -->
<section class="min-h-[70vh] flex items-center justify-center bg-obsidian-950 py-24">
    <div class="container-sovereign">
        <div class="max-w-5xl">
            <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
                INSTITUTIONAL INVESTMENT OPPORTUNITY
            </span>
            <h1 class="font-serif text-6xl md:text-7xl lg:text-8xl text-platinum-50 tracking-editorial leading-none mb-8" data-gsap-fade-up data-gsap-delay="0.2">
                Unggul Axiom Group
            </h1>
            <div class="w-32 h-px bg-champagne-500 mb-8" data-gsap-line-draw data-gsap-delay="0.4"></div>
            <p class="text-xl md:text-2xl text-platinum-200 leading-institutional max-w-4xl mb-8" data-gsap-fade-up data-gsap-delay="0.5">
                Emerging Halal Infrastructure Platform
            </p>
            <p class="text-xl md:text-2xl text-platinum-200 leading-institutional max-w-4xl" data-gsap-fade-up data-gsap-delay="0.6">
                Backed by South Korean Government Technology Transfer
            </p>
        </div>
    </div>
</section>

<!-- ============================================ -->
<!-- SOUTH KOREA BACKING SECTION -->
<!-- ============================================ -->
<section class="py-20 bg-obsidian-900 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
            GOVERNMENT BACKING
        </span>

        <div class="max-w-4xl mb-10" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight">
                South Korean Government Support
            </h2>
            <p class="text-xl text-platinum-200 leading-institutional mb-6">
                Unggul Bronto project is heavily backed by the South Korean government through comprehensive technology transfer agreements, institutional support frameworks, and direct financial commitment.
            </p>
            <div class="border-l-4 border-champagne-600 pl-8 py-6 bg-champagne-50">
                <p class="text-2xl font-serif text-platinum-50 mb-2">
                    USD 10 Million Government Grant
                </p>
                <p class="text-lg text-platinum-200 leading-institutional">
                    South Korean government committed to providing USD 10 million grant upon successful completion and validation of the first farm deployment in Malaysia.
                </p>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div class="border-l-2 border-champagne-600 pl-8" data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-platinum-50 mb-4">AI and IoT Technology Transfer</h3>
                <p class="text-lg text-platinum-200 leading-institutional mb-4">
                    Complete transfer of South Korean advanced poultry production technology powered by artificial intelligence and Internet of Things systems. This technology represents the most sophisticated chicken farming infrastructure currently deployed globally.
                </p>
                <p class="text-base text-sovereign-400 leading-institutional">
                    South Korean AI and IoT integrated systems significantly outperform all existing chicken farming technology in Malaysia across every operational metric including feed conversion efficiency, disease prevention, growth optimization, and production yield.
                </p>
            </div>

            <div class="border-l-2 border-champagne-600 pl-8" data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-platinum-50 mb-4">Institutional Framework</h3>
                <p class="text-lg text-platinum-200 leading-institutional">
                    Government supported infrastructure development with bilateral cooperation agreements ensuring long term operational stability.
                </p>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- TECHNOLOGY TRANSFER DETAILS -->
<!-- ============================================ -->
<section class="py-20 bg-obsidian-900 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
            TECHNOLOGY TRANSFER
        </span>

        <div class="max-w-4xl mb-10" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight">
                Complete Operational Independence
            </h2>
            <p class="text-xl text-platinum-200 leading-institutional">
                Full technology transfer from South Korea enables complete operational autonomy. From parent stock to feed formulation, every component is transferred with 100% rights and zero ongoing dependencies.
            </p>
        </div>

        <div class="space-y-6 max-w-4xl">
            <div class="border-l-2 border-champagne-500 pl-8" data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-platinum-50 mb-4">Parent Stock Technology</h3>
                <p class="text-lg text-platinum-200 leading-institutional">
                    Complete breeding technology transfer including genetic lines, breeding protocols, and hatchery systems. Full operational control without external dependencies.
                </p>
            </div>

            <div class="border-l-2 border-champagne-500 pl-8" data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-platinum-50 mb-4">Exclusive Feed Formula</h3>
                <p class="text-lg text-platinum-200 leading-institutional">
                    Patented feed formulation developed by South Korean research institutions, granted with 100% usage rights. Proprietary nutritional specifications optimized for halal production standards.
                </p>
            </div>

            <div class="border-l-2 border-champagne-500 pl-8" data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-platinum-50 mb-4">End to End Systems</h3>
                <p class="text-lg text-platinum-200 leading-institutional">
                    Complete operational systems covering production, processing, quality control, and distribution. No reliance on external companies for any operational component.
                </p>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- CORE SECTION -->
<!-- ============================================ -->
<section class="py-20 bg-obsidian-900 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
            CORE INFRASTRUCTURE
        </span>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-12 mb-10">
            <div data-gsap-fade-up>
                <h2 class="text-3xl font-serif text-platinum-50 mb-4">Platform: UHIC</h2>
                <p class="text-lg text-platinum-200 leading-institutional">
                    Unggul Halal Integrated Centre serves as the coordinating platform for multi sector halal infrastructure deployment.
                </p>
            </div>
            <div data-gsap-fade-up>
                <h2 class="text-3xl font-serif text-platinum-50 mb-4">Pilot: CIPU</h2>
                <p class="text-lg text-platinum-200 leading-institutional">
                    Central Integrated Poultry Unggul demonstrates the operational model with South Korean technology integration.
                </p>
            </div>
        </div>

        <div class="max-w-4xl" data-gsap-fade-up>
            <p class="text-2xl text-platinum-200 leading-institutional mb-8">
                Expansion: Malaysia to Regional
            </p>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- FINANCIAL SNAPSHOT -->
<!-- ============================================ -->
<section class="py-24 bg-obsidian-950 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
            FINANCIAL SNAPSHOT
        </span>

        <div class="max-w-6xl">
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-12 leading-tight" data-gsap-fade-up>
                Per-Node Economics
            </h2>

            <!-- Key Metrics Grid -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
                <div class="border border-champagne-500/20 bg-obsidian-900/50 p-6" data-gsap-fade-up>
                    <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">ANNUAL CAPACITY</p>
                    <p class="text-4xl font-serif text-platinum-50 mb-2">3.6M</p>
                    <p class="text-sm text-sovereign-400">Chickens per node</p>
                </div>

                <div class="border border-champagne-500/20 bg-obsidian-900/50 p-6" data-gsap-fade-up>
                    <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">BASE NET PROFIT</p>
                    <p class="text-4xl font-serif text-platinum-50 mb-2">RM19.8M</p>
                    <p class="text-sm text-sovereign-400">Annual per node</p>
                </div>

                <div class="border border-champagne-500/20 bg-obsidian-900/50 p-6" data-gsap-fade-up>
                    <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">TARGET IRR</p>
                    <p class="text-4xl font-serif text-platinum-50 mb-2">25-35%</p>
                    <p class="text-sm text-sovereign-400">Institutional returns</p>
                </div>

                <div class="border border-champagne-500/20 bg-obsidian-900/50 p-6" data-gsap-fade-up>
                    <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">PAYBACK PERIOD</p>
                    <p class="text-4xl font-serif text-platinum-50 mb-2">3-4 Yrs</p>
                    <p class="text-sm text-sovereign-400">Capital recovery</p>
                </div>
            </div>

            <!-- Revenue Projection Chart -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
                <div class="border border-champagne-500/20 bg-obsidian-900/50 p-8" data-gsap-fade-up>
                    <h3 class="text-xl font-serif text-platinum-50 mb-6">5-Year Revenue Projection</h3>
                    <canvas id="revenueChart" class="w-full" style="max-height: 300px;"></canvas>
                    <p class="text-xs text-sovereign-400 mt-4">Based on 5-node deployment by Year 3</p>
                </div>

                <div class="border border-champagne-500/20 bg-obsidian-900/50 p-8" data-gsap-fade-up>
                    <h3 class="text-xl font-serif text-platinum-50 mb-6">Profit Margin Analysis</h3>
                    <canvas id="marginChart" class="w-full" style="max-height: 300px;"></canvas>
                    <p class="text-xs text-sovereign-400 mt-4">Operational efficiency vs. industry benchmark</p>
                </div>
            </div>

            <!-- Cost Structure Breakdown -->
            <div class="border border-champagne-500/20 bg-obsidian-900/50 p-8 mb-16" data-gsap-fade-up>
                <h3 class="text-xl font-serif text-platinum-50 mb-8">Cost Structure per Node</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div>
                        <canvas id="costChart" style="max-height: 280px;"></canvas>
                    </div>
                    <div class="space-y-6">
                        <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                            <div class="flex items-center gap-3">
                                <span class="w-4 h-4 bg-champagne-500"></span>
                                <span class="text-platinum-200">Feed & Inputs</span>
                            </div>
                            <span class="text-platinum-100 font-medium">42%</span>
                        </div>
                        <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                            <div class="flex items-center gap-3">
                                <span class="w-4 h-4 bg-champagne-400"></span>
                                <span class="text-platinum-200">Labor & Operations</span>
                            </div>
                            <span class="text-platinum-100 font-medium">18%</span>
                        </div>
                        <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                            <div class="flex items-center gap-3">
                                <span class="w-4 h-4 bg-champagne-300"></span>
                                <span class="text-platinum-200">Utilities & Maintenance</span>
                            </div>
                            <span class="text-platinum-100 font-medium">12%</span>
                        </div>
                        <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                            <div class="flex items-center gap-3">
                                <span class="w-4 h-4 bg-champagne-200"></span>
                                <span class="text-platinum-200">Logistics & Distribution</span>
                            </div>
                            <span class="text-platinum-100 font-medium">8%</span>
                        </div>
                        <div class="flex justify-between items-center pb-3 border-b border-champagne-500/10">
                            <div class="flex items-center gap-3">
                                <span class="w-4 h-4 bg-sovereign-500"></span>
                                <span class="text-platinum-200">Net Profit Margin</span>
                            </div>
                            <span class="text-champagne-500 font-semibold text-lg">20%</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Scalability Model -->
            <div class="border-l-2 border-champagne-500 pl-8" data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-platinum-50 mb-6">Scalability Framework</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div>
                        <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">MODULAR DEPLOYMENT</p>
                        <p class="text-base text-platinum-200 leading-institutional">
                            Each node operates independently with standardized infrastructure enabling rapid replication across markets.
                        </p>
                    </div>
                    <div>
                        <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">ZERO DEPENDENCIES</p>
                        <p class="text-base text-platinum-200 leading-institutional">
                            Complete operational autonomy from breeding to distribution eliminates supply chain vulnerabilities.
                        </p>
                    </div>
                    <div>
                        <p class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-3">TECHNOLOGY ADVANTAGE</p>
                        <p class="text-base text-platinum-200 leading-institutional">
                            AI-powered systems deliver 30% cost advantage versus conventional operations.
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- Chart.js Integration -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const chartColors = {
        champagne: '#C9A961',
        champagneLight: '#D4B876',
        champagneLighter: '#E0C89B',
        champagneLightest: '#EBD8B0',
        sovereign: '#607A92',
        obsidian: '#0F1E33',
        platinum: '#F5F7F9'
    };

    // Revenue Projection Chart
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5'],
                datasets: [{
                    label: 'Projected Revenue (RM Million)',
                    data: [19.8, 39.6, 99.0, 158.4, 198.0],
                    borderColor: chartColors.champagne,
                    backgroundColor: chartColors.champagne + '20',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 6,
                    pointBackgroundColor: chartColors.champagne,
                    pointBorderColor: chartColors.obsidian,
                    pointBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: chartColors.obsidian,
                        titleColor: chartColors.platinum,
                        bodyColor: chartColors.platinum,
                        borderColor: chartColors.champagne,
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return 'RM ' + context.parsed.y.toFixed(1) + 'M';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: chartColors.champagne + '10' },
                        ticks: {
                            color: chartColors.sovereign,
                            callback: function(value) {
                                return 'RM ' + value + 'M';
                            }
                        }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: chartColors.sovereign }
                    }
                }
            }
        });
    }

    // Profit Margin Chart
    const marginCtx = document.getElementById('marginChart');
    if (marginCtx) {
        new Chart(marginCtx, {
            type: 'bar',
            data: {
                labels: ['Unggul Axiom\n(AI-Powered)', 'Industry\nAverage', 'Traditional\nFarms'],
                datasets: [{
                    label: 'Net Profit Margin (%)',
                    data: [20, 12, 8],
                    backgroundColor: [
                        chartColors.champagne,
                        chartColors.champagneLight,
                        chartColors.sovereign
                    ],
                    borderWidth: 0,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: chartColors.obsidian,
                        titleColor: chartColors.platinum,
                        bodyColor: chartColors.platinum,
                        borderColor: chartColors.champagne,
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return context.parsed.y + '% Net Margin';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 25,
                        grid: { color: chartColors.champagne + '10' },
                        ticks: {
                            color: chartColors.sovereign,
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    },
                    x: {
                        grid: { display: false },
                        ticks: {
                            color: chartColors.sovereign,
                            font: { size: 11 }
                        }
                    }
                }
            }
        });
    }

    // Cost Structure Doughnut Chart
    const costCtx = document.getElementById('costChart');
    if (costCtx) {
        new Chart(costCtx, {
            type: 'doughnut',
            data: {
                labels: ['Feed & Inputs', 'Labor & Operations', 'Utilities & Maintenance', 'Logistics & Distribution', 'Net Profit'],
                datasets: [{
                    data: [42, 18, 12, 8, 20],
                    backgroundColor: [
                        chartColors.champagne,
                        chartColors.champagneLight,
                        chartColors.champagneLighter,
                        chartColors.champagneLightest,
                        chartColors.sovereign
                    ],
                    borderWidth: 0,
                    hoverOffset: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: chartColors.obsidian,
                        titleColor: chartColors.platinum,
                        bodyColor: chartColors.platinum,
                        borderColor: chartColors.champagne,
                        borderWidth: 1,
                        padding: 12,
                        displayColors: true,
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed + '%';
                            }
                        }
                    }
                },
                cutout: '65%'
            }
        });
    }
});
</script>

<!-- ============================================ -->
<!-- CAPITAL ENTRY -->
<!-- ============================================ -->
<section class="py-20 bg-obsidian-900 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
            CAPITAL ENTRY
        </span>

        <div class="max-w-4xl mb-10" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight">
                Investment Structure
            </h2>
            <p class="text-xl text-platinum-200 leading-institutional">
                Flexible participation frameworks designed for institutional investors seeking exposure to halal infrastructure development.
            </p>
        </div>

        <div class="space-y-10 max-w-4xl">
            <div class="border border-champagne-500/20 p-8" data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-platinum-50 mb-4">Equity Participation</h3>
                <p class="text-lg text-platinum-200 leading-institutional mb-4">
                    Direct equity investment in Unggul Bronto Sdn. Bhd. with participation in pilot phase development and regional expansion.
                </p>
                <p class="text-base text-sovereign-400 leading-institutional">
                    Minimum investment: RM5M | Target IRR: 25% to 35% | Exit timeline: 1 years
                </p>
            </div>

            <div class="border border-champagne-500/20 p-8" data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-platinum-50 mb-4">Joint Venture Systems</h3>
                <p class="text-lg text-platinum-200 leading-institutional mb-4">
                    Co development partnerships for regional node deployment. Shared investment in infrastructure development with technology transfer rights.
                </p>
                <p class="text-base text-sovereign-400 leading-institutional">
                    Structure: 51% Unggul / 49% Partner | Node investment: RM12M to RM18M | Revenue sharing based on equity stake
                </p>
            </div>

            <div class="border border-champagne-500/20 p-8" data-gsap-fade-up>
                <h3 class="text-2xl font-serif text-platinum-50 mb-4">Infrastructure Financing</h3>
                <p class="text-lg text-platinum-200 leading-institutional mb-4">
                    Project based financing for specific infrastructure components. Shariah compliant financing structures available.
                </p>
                <p class="text-base text-sovereign-400 leading-institutional">
                    Facility size: RM10M to RM50M | Tenor: 5 to 10 years | Security: First charge on project assets
                </p>
            </div>
        </div>

    </div>
</section>


<!-- ============================================ -->
<!-- INVESTMENT THESIS -->
<!-- ============================================ -->
<section class="py-20 bg-obsidian-900 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
            INVESTMENT THESIS
        </span>

        <div class="max-w-4xl" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight">
                Why Invest Now
            </h2>

            <div class="space-y-6">
                <div class="border-l-4 border-champagne-600 pl-8 py-4">
                    <p class="text-2xl font-serif text-platinum-50 leading-tight mb-4">
                        Rare combination of government backing, proven technology, and first mover advantage in high growth market.
                    </p>
                    <p class="text-lg text-platinum-200 leading-institutional">
                        South Korean government support provides technology access typically unavailable to private enterprises. Complete operational independence eliminates ongoing dependencies. Pilot phase demonstrates model viability before regional scaling.
                    </p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-4">Market Opportunity</h3>
                        <ul class="space-y-3 text-base text-platinum-200">
                            <li>• USD 3 trillion global halal food market</li>
                            <li>• 8% annual growth in Malaysia market</li>
                            <li>• Increasing export demand to Middle East</li>
                            <li>• Government food security priorities</li>
                        </ul>
                    </div>

                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-4">Execution Readiness</h3>
                        <ul class="space-y-3 text-base text-platinum-200">
                            <li>• Technology transfer agreements finalized</li>
                            <li>• Pilot site identified and secured</li>
                            <li>• Management team assembled</li>
                            <li>• Regulatory approvals in progress</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- ASIA EXPANSION STRATEGY -->
<!-- ============================================ -->
<section class="py-20 bg-obsidian-900 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-500 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
            ASIA EXPANSION STRATEGY
        </span>

        <div class="max-w-4xl mb-10" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight">
                Regional Dominance Framework
            </h2>
            <p class="text-xl text-platinum-200 leading-institutional mb-6">
                Unggul Bronto is positioned to establish market leadership across the Asian continent through systematic deployment of South Korean AI and IoT powered infrastructure.
            </p>
            <div class="border-l-4 border-champagne-500 pl-8 py-6">
                <p class="text-2xl font-serif text-platinum-50 mb-4">
                    Asia Continental Expansion: 2026 to 2030
                </p>
                <p class="text-lg text-platinum-200 leading-institutional">
                    Strategic rollout across 12 Asian markets with technology superiority providing insurmountable competitive advantage. First mover advantage combined with government backed AI systems creates defensible market position.
                </p>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
            <div class="border border-champagne-500/20 p-8" data-gsap-fade-up>
                <h3 class="text-xl font-serif text-platinum-50 mb-4">Phase 1: Malaysia Dominance</h3>
                <p class="text-base text-platinum-200 leading-institutional mb-4">
                    2026 to 2027: Establish market leadership in Malaysia through rapid node deployment across Peninsular Malaysia, Sabah, and Sarawak.
                </p>
                <ul class="space-y-2 text-sm text-sovereign-400">
                    <li>• 5 operational nodes by end 2026</li>
                    <li>• 15% market share by 2027</li>
                    <li>• Export certification secured</li>
                </ul>
            </div>

            <div class="border border-champagne-500/20 p-8" data-gsap-fade-up>
                <h3 class="text-xl font-serif text-platinum-50 mb-4">Phase 2: Southeast Asia</h3>
                <p class="text-base text-platinum-200 leading-institutional mb-4">
                    2027 to 2028: Regional expansion into Indonesia, Thailand, Singapore, and Brunei with technology licensing partnerships.
                </p>
                <ul class="space-y-2 text-sm text-sovereign-400">
                    <li>• 20 nodes across 4 countries</li>
                    <li>• Joint venture partnerships</li>
                    <li>• Regional supply chain control</li>
                </ul>
            </div>

            <div class="border border-champagne-500/20 p-8" data-gsap-fade-up>
                <h3 class="text-xl font-serif text-platinum-50 mb-4">Phase 3: Pan Asia</h3>
                <p class="text-base text-platinum-200 leading-institutional mb-4">
                    2028 to 2030: Continental expansion into Middle East, South Asia, and East Asia markets with established infrastructure model.
                </p>
                <ul class="space-y-2 text-sm text-sovereign-400">
                    <li>• 50+ nodes across 12 countries</li>
                    <li>• Market leadership position</li>
                    <li>• Technology licensing revenue</li>
                </ul>
            </div>
        </div>

        <div class="max-w-4xl" data-gsap-fade-up>
            <h3 class="text-2xl font-serif text-platinum-50 mb-6">Competitive Moat</h3>
            <p class="text-lg text-platinum-200 leading-institutional mb-6">
                South Korean AI and IoT technology creates insurmountable barrier to entry. Competitors using conventional farming methods cannot match production efficiency, cost structure, or quality consistency. Technology gap estimated at 1 years for nearest competitors to develop equivalent systems.
            </p>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="flex items-start gap-4">
                    <span class="text-champagne-500 text-2xl">→</span>
                    <p class="text-base text-platinum-200 leading-institutional">
                        <strong>Feed Conversion Ratio:</strong> 30% better than Malaysia industry average through AI optimized nutrition management
                    </p>
                </div>
                <div class="flex items-start gap-4">
                    <span class="text-champagne-500 text-2xl">→</span>
                    <p class="text-base text-platinum-200 leading-institutional">
                        <strong>Disease Prevention:</strong> IoT monitoring reduces mortality rates by 40% versus conventional systems
                    </p>
                </div>
                <div class="flex items-start gap-4">
                    <span class="text-champagne-500 text-2xl">→</span>
                    <p class="text-base text-platinum-200 leading-institutional">
                        <strong>Growth Optimization:</strong> AI controlled environment reduces time to market by 15% with superior meat quality
                    </p>
                </div>
                <div class="flex items-start gap-4">
                    <span class="text-champagne-500 text-2xl">→</span>
                    <p class="text-base text-platinum-200 leading-institutional">
                        <strong>Labor Efficiency:</strong> Automated systems reduce labor costs by 50% while improving operational consistency
                    </p>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- ============================================ -->
<!-- NEXT STEPS -->
<!-- ============================================ -->
<section class="py-20 bg-obsidian-900 text-platinum-50">
    <div class="container-sovereign">

        <span class="text-sovereign-xs text-champagne-600 tracking-ultra-wide mb-8 block" data-gsap-fade-up>
            NEXT STEPS
        </span>

        <div class="max-w-4xl" data-gsap-fade-up>
            <h2 class="text-4xl md:text-5xl font-serif text-platinum-50 mb-8 leading-tight">
                Investment Process
            </h2>

            <div class="space-y-6">
                <div class="flex items-start gap-6 border-l-2 border-champagne-500 pl-8 py-4">
                    <span class="text-champagne-500 font-mono text-sm">01</span>
                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-2">Initial Discussion</h3>
                        <p class="text-base text-platinum-200 leading-institutional">
                            Confidential discussion of investment parameters, timeline expectations, and preliminary due diligence requirements.
                        </p>
                    </div>
                </div>

                <div class="flex items-start gap-6 border-l-2 border-champagne-500 pl-8 py-4">
                    <span class="text-champagne-500 font-mono text-sm">02</span>
                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-2">Data Room Access</h3>
                        <p class="text-base text-platinum-200 leading-institutional">
                            Comprehensive documentation including financial models, technology transfer agreements, operational plans, and regulatory compliance materials.
                        </p>
                    </div>
                </div>

                <div class="flex items-start gap-6 border-l-2 border-champagne-500 pl-8 py-4">
                    <span class="text-champagne-500 font-mono text-sm">03</span>
                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-2">Due Diligence</h3>
                        <p class="text-base text-platinum-200 leading-institutional">
                            Technical, financial, and legal due diligence with site visits and management presentations. Typical timeline: 4 to 6 weeks.
                        </p>
                    </div>
                </div>

                <div class="flex items-start gap-6 border-l-2 border-champagne-500 pl-8 py-4">
                    <span class="text-champagne-500 font-mono text-sm">04</span>
                    <div>
                        <h3 class="text-xl font-serif text-platinum-50 mb-2">Term Sheet & Closing</h3>
                        <p class="text-base text-platinum-200 leading-institutional">
                            Negotiation of investment terms, shareholder agreements, and closing documentation. Target closing: 8 to 12 weeks from initial discussion.
                        </p>
                    </div>
                </div>
            </div>

            <div class="mt-16 pt-12 border-t border-champagne-500/20">
                <p class="text-xl text-platinum-200 leading-institutional mb-8">
                    For institutional investment inquiries:
                </p>
                <a href="<?php echo url('/partnerships'); ?>" 
                   class="inline-block px-12 py-5 bg-champagne-500 text-platinum-50 text-sm font-semibold hover:bg-champagne-400 transition-all duration-300 rounded">
                    Submit Investment Inquiry
                </a>
            </div>
        </div>

    </div>
</section>

<?php
require_once INCLUDES_PATH . '/footer.php';
?>
