<?php
/**
 * Personal Bill Splitter - Lightweight Rate Limiter
 * Uses file-based storage in storage/rate_limits to track requests.
 */

if (!defined('STORAGE_DIR')) {
    define('STORAGE_DIR', dirname(__DIR__) . '/storage');
}

/**
 * Retrieve the client IP address securely, considering proxies and Cloudflare.
 */
function getClientIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
}

/**
 * Check if the client has exceeded the rate limit.
 *
 * @param string $action Unique identifier for the action (e.g., 'login', 'register')
 * @param int $limit Max number of allowed requests in the time window
 * @param int $window Time window in seconds
 * @return bool True if request is allowed, False if rate-limited
 */
function checkRateLimit($action, $limit = 20, $window = 60) {
    $dir = STORAGE_DIR . '/rate_limits';
    
    // Ensure directory exists
    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0755, true)) {
            // Fallback: If cannot create directory, do not block the user
            return true;
        }
    }

    $ip = getClientIP();
    $key = md5($ip . '_' . $action);
    $file = $dir . '/' . $key . '.json';

    $now = time();
    $requests = [];

    if (file_exists($file)) {
        $content = @file_get_contents($file);
        if ($content) {
            $data = json_decode($content, true);
            if (is_array($data)) {
                $requests = $data;
            }
        }
    }

    // Filter out timestamps outside the active window
    $requests = array_filter($requests, function($timestamp) use ($now, $window) {
        return $timestamp > ($now - $window);
    });

    // Check if limit exceeded
    if (count($requests) >= $limit) {
        return false;
    }

    // Record the current request timestamp
    $requests[] = $now;
    @file_put_contents($file, json_encode(array_values($requests)));
    return true;
}
