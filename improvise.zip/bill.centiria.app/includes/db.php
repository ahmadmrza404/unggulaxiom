<?php
/**
 * Personal Bill Splitter - Database Connection Helper
 */

require_once __DIR__ . '/config.php';

// Force deletion of install.php after installation
if (file_exists(ROOT_DIR . '/storage/install.lock') && file_exists(ROOT_DIR . '/install.php')) {
    http_response_code(403);
    
    // Detect language
    $lang = 'en';
    if (isset($_COOKIE['lang'])) {
        $lang = $_COOKIE['lang'] === 'bm' ? 'bm' : 'en';
    } elseif (isset($_SESSION['lang'])) {
        $lang = $_SESSION['lang'] === 'bm' ? 'bm' : 'en';
    }
    
    $title = $lang === 'en' ? 'Security Warning' : 'Amaran Keselamatan';
    $heading = $lang === 'en' ? 'Delete install.php File' : 'Padam Fail install.php';
    $message = $lang === 'en' 
        ? 'For your security, the installation file <code>install.php</code> must be deleted from the root directory before you can begin using BillSplitter.' 
        : 'Demi keselamatan anda, fail pemasangan <code>install.php</code> mesti dipadamkan daripada direktori utama sebelum anda boleh mula menggunakan BillSplitter.';
    $refreshBtn = $lang === 'en' ? 'I have deleted it, refresh page' : 'Saya telah memadamkannya, muat semula halaman';
    
    echo "<!DOCTYPE html>
    <html lang='{$lang}'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>{$title} - BillSplitter</title>
        <link rel='preconnect' href='https://fonts.googleapis.com'>
        <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>
        <link href='https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&family=Inter:wght@400;500;600&display=swap' rel='stylesheet'>
        <style>
            body { 
                font-family: 'Inter', sans-serif; 
                background-color: #0b0f19; 
                color: #f8fafc; 
                display: flex; 
                align-items: center; 
                justify-content: center; 
                height: 100vh; 
                margin: 0; 
                padding: 1.5rem; 
            }
            .card { 
                background: rgba(19, 25, 38, 0.75); 
                backdrop-filter: blur(16px); 
                -webkit-backdrop-filter: blur(16px); 
                border: 1px solid rgba(239, 68, 68, 0.2); 
                border-radius: 4px; 
                padding: 2.5rem 2rem; 
                max-width: 440px; 
                width: 100%; 
                text-align: center; 
                box-shadow: 0 15px 40px rgba(0,0,0,0.6); 
            }
            .warning-icon {
                width: 54px;
                height: 54px;
                background: rgba(239, 68, 68, 0.1);
                border: 1px solid #ef4444;
                color: #ef4444;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                font-size: 1.75rem;
                margin-bottom: 1.5rem;
                border-radius: 4px;
            }
            h1 { 
                font-family: 'Outfit', sans-serif; 
                color: #f8fafc; 
                font-size: 1.35rem; 
                margin: 0 0 0.75rem 0; 
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 0.05em;
            }
            p { 
                color: #94a3b8; 
                font-size: 0.9rem; 
                line-height: 1.6; 
                margin: 0 0 2rem 0; 
            }
            code {
                background: rgba(239, 68, 68, 0.15);
                color: #f87171;
                padding: 0.2rem 0.4rem;
                font-family: monospace;
                border-radius: 2px;
            }
            .btn { 
                display: inline-flex; 
                align-items: center; 
                justify-content: center; 
                background: #ef4444; 
                color: #fff; 
                border: none;
                width: 100%;
                height: 2.75rem;
                border-radius: 4px; 
                text-decoration: none; 
                font-weight: 600; 
                font-size: 0.9rem; 
                cursor: pointer;
                transition: all 0.2s; 
            }
            .btn:hover { 
                background: #dc2626; 
                box-shadow: 0 0 15px rgba(239, 68, 68, 0.45); 
            }
        </style>
    </head>
    <body>
        <div class='card'>
            <div class='warning-icon'>⚠️</div>
            <h1>{$heading}</h1>
            <p>{$message}</p>
            <button onclick='window.location.reload();' class='btn'>{$refreshBtn}</button>
        </div>
    </body>
    </html>";
    exit;
}

$db = null;
$dbError = null;

if (isDbConfigured()) {
    try {
        if ($config['db_connection'] === 'sqlite') {
            $dsn = "sqlite:" . $config['db_sqlite_path'];
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ];
            // Ensure storage dir exists
            if (!is_dir(dirname($config['db_sqlite_path']))) {
                mkdir(dirname($config['db_sqlite_path']), 0755, true);
            }
            $db = new PDO($dsn, null, null, $options);
            $db->exec("PRAGMA foreign_keys = ON;");

            // Auto-create tables for SQLite if missing
            $db->exec("CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username VARCHAR(50) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                role VARCHAR(20) DEFAULT 'user',
                display_name VARCHAR(100) NULL,
                qr_type VARCHAR(30) DEFAULT 'none',
                qr_value VARCHAR(255) DEFAULT '',
                qr_image VARCHAR(255) DEFAULT '',
                email VARCHAR(255) NULL,
                profile_pic VARCHAR(255) NULL,
                last_active TIMESTAMP NULL,
                bio TEXT NULL,
                telegram VARCHAR(100) NULL,
                phone VARCHAR(50) NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );");

            $db->exec("CREATE TABLE IF NOT EXISTS user_banks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                bank_name VARCHAR(50) NOT NULL,
                account_name VARCHAR(100) NOT NULL,
                account_number VARCHAR(50) NOT NULL,
                is_preferred TINYINT(1) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            );");

            $db->exec("CREATE TABLE IF NOT EXISTS bills (
                id VARCHAR(50) PRIMARY KEY,
                user_id INTEGER NOT NULL,
                merchant VARCHAR(100) NOT NULL,
                bill_date DATE NOT NULL,
                currency VARCHAR(10) DEFAULT 'MYR',
                exchange_rate DECIMAL(15, 6) DEFAULT 1.000000,
                discount DECIMAL(10, 2) DEFAULT 0.00,
                service_charge DECIMAL(10, 2) DEFAULT 0.00,
                tax DECIMAL(10, 2) DEFAULT 0.00,
                rounding DECIMAL(10, 2) DEFAULT 0.00,
                grand_total DECIMAL(10, 2) NOT NULL,
                tax_distribution VARCHAR(30) DEFAULT 'proportional',
                discount_distribution VARCHAR(30) DEFAULT 'proportional',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            );");

            $db->exec("CREATE TABLE IF NOT EXISTS bill_people (
                id VARCHAR(50) PRIMARY KEY,
                bill_id VARCHAR(50) NOT NULL,
                name VARCHAR(50) NOT NULL,
                user_id INTEGER NULL,
                total_owed DECIMAL(10, 2) DEFAULT 0.00,
                settlement_status INTEGER DEFAULT 0,
                FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
            );");

            $db->exec("CREATE TABLE IF NOT EXISTS bill_items (
                id VARCHAR(50) PRIMARY KEY,
                bill_id VARCHAR(50) NOT NULL,
                name VARCHAR(100) NOT NULL,
                qty INT DEFAULT 1,
                price DECIMAL(10, 2) NOT NULL,
                split_mode VARCHAR(20) DEFAULT 'equal',
                category VARCHAR(30) DEFAULT 'food',
                FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE
            );");

            $db->exec("CREATE TABLE IF NOT EXISTS bill_item_splits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id VARCHAR(50) NOT NULL,
                person_id VARCHAR(50) NOT NULL,
                split_value DECIMAL(10, 4) NOT NULL,
                FOREIGN KEY (item_id) REFERENCES bill_items(id) ON DELETE CASCADE
            );");

            $db->exec("CREATE TABLE IF NOT EXISTS bill_item_assignments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id VARCHAR(50) NOT NULL,
                person_id VARCHAR(50) NOT NULL,
                FOREIGN KEY (item_id) REFERENCES bill_items(id) ON DELETE CASCADE,
                FOREIGN KEY (person_id) REFERENCES bill_people(id) ON DELETE CASCADE
            );");

            $db->exec("CREATE TABLE IF NOT EXISTS activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NULL,
                username VARCHAR(50) NULL,
                action VARCHAR(100) NOT NULL,
                details TEXT NOT NULL,
                ip_address VARCHAR(45) NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
            );");

            $db->exec("CREATE TABLE IF NOT EXISTS system_settings (
                setting_key VARCHAR(50) PRIMARY KEY,
                setting_value TEXT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );");

            // Seed default settings if empty
            $settingsCount = $db->query("SELECT COUNT(*) FROM system_settings")->fetchColumn();
            if (intval($settingsCount) === 0) {
                $db->exec("INSERT INTO system_settings (setting_key, setting_value) VALUES 
                    ('allow_registration', '1'),
                    ('maintenance_mode', '0'),
                    ('default_currency', 'MYR')
                ");
            }

            // Seed default admin if empty
            $usersCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
            if (intval($usersCount) === 0) {
                $defaultPassHash = password_hash('admin123', PASSWORD_DEFAULT);
                $db->prepare("INSERT INTO users (username, password_hash, role, display_name) VALUES (?, ?, 'admin', 'Administrator')")
                   ->execute(['admin', $defaultPassHash]);
            }

            // Auto-migration: Check and add 'settlement_status' column to SQLite 'bill_people' table if missing
            try {
                $stmt = $db->query("PRAGMA table_info(bill_people)");
                $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $hasSettlement = false;
                foreach ($columns as $col) {
                    if ($col['name'] === 'settlement_status') {
                        $hasSettlement = true;
                        break;
                    }
                }
                if (!$hasSettlement) {
                    $db->exec("ALTER TABLE bill_people ADD COLUMN settlement_status INTEGER DEFAULT 0");
                }
            } catch (PDOException $ex) {}
        } else {
            $dbHost = $config['db_host'];
            $dbPort = $config['db_port'];
            $dbName = $config['db_name'];
            $dbUser = $config['db_user'];
            $dbPass = $config['db_pass'];

            $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $db = new PDO($dsn, $dbUser, $dbPass, $options);

            // Auto-migration: Check and add 'category' column to 'bill_items' table if missing
            try {
                $tableExists = $db->query("SHOW TABLES LIKE 'bill_items'")->fetch();
                if ($tableExists) {
                    $stmt = $db->query("SHOW COLUMNS FROM bill_items LIKE 'category'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE bill_items ADD COLUMN category VARCHAR(30) DEFAULT 'food'");
                    }
                }

                // Check if users table needs display_name and QR fields
                $usersTable = $db->query("SHOW TABLES LIKE 'users'")->fetch();
                if ($usersTable) {
                    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'display_name'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE users ADD COLUMN display_name VARCHAR(100) NULL");
                        $db->exec("ALTER TABLE users ADD COLUMN qr_type VARCHAR(30) DEFAULT 'none'");
                        $db->exec("ALTER TABLE users ADD COLUMN qr_value VARCHAR(255) DEFAULT ''");
                        $db->exec("ALTER TABLE users ADD COLUMN qr_image VARCHAR(255) DEFAULT ''");
                    }
                    
                    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'email'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE users ADD COLUMN email VARCHAR(255) NULL");
                    }

                    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'profile_pic'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE users ADD COLUMN profile_pic VARCHAR(255) NULL");
                    }

                    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'last_active'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE users ADD COLUMN last_active TIMESTAMP NULL");
                    }

                    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'bio'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE users ADD COLUMN bio TEXT NULL");
                    }

                    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'telegram'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE users ADD COLUMN telegram VARCHAR(100) NULL");
                    }

                    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'phone'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE users ADD COLUMN phone VARCHAR(50) NULL");
                    }
                }

                // Create user_banks table
                $db->exec("CREATE TABLE IF NOT EXISTS user_banks (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    bank_name VARCHAR(50) NOT NULL,
                    account_name VARCHAR(100) NOT NULL,
                    account_number VARCHAR(50) NOT NULL,
                    is_preferred TINYINT(1) DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

                // Create activity_logs table
                $db->exec("CREATE TABLE IF NOT EXISTS activity_logs (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NULL,
                    username VARCHAR(50) NULL,
                    action VARCHAR(100) NOT NULL,
                    details TEXT NOT NULL,
                    ip_address VARCHAR(45) NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

                // Check if bill_people needs user_id and total_owed columns
                $peopleTable = $db->query("SHOW TABLES LIKE 'bill_people'")->fetch();
                if ($peopleTable) {
                    $stmt = $db->query("SHOW COLUMNS FROM bill_people LIKE 'user_id'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE bill_people ADD COLUMN user_id INT NULL");
                        $db->exec("ALTER TABLE bill_people ADD CONSTRAINT fk_bill_people_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL");
                    }

                    $stmt = $db->query("SHOW COLUMNS FROM bill_people LIKE 'total_owed'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE bill_people ADD COLUMN total_owed DECIMAL(10, 2) DEFAULT 0.00");
                    }

                    $stmt = $db->query("SHOW COLUMNS FROM bill_people LIKE 'settlement_status'");
                    if (!$stmt->fetch()) {
                        $db->exec("ALTER TABLE bill_people ADD COLUMN settlement_status INT DEFAULT 0");
                    }
                }

                // Create system_settings table if missing and seed default values
                $db->exec("CREATE TABLE IF NOT EXISTS system_settings (
                    setting_key VARCHAR(50) PRIMARY KEY,
                    setting_value TEXT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

                $settingsCount = $db->query("SELECT COUNT(*) FROM system_settings")->fetchColumn();
                if (intval($settingsCount) === 0) {
                    $db->exec("INSERT INTO system_settings (setting_key, setting_value) VALUES 
                        ('allow_registration', '1'),
                        ('maintenance_mode', '0'),
                        ('default_currency', 'MYR')
                    ");
                }
            } catch (PDOException $ex) {
                // Silently ignore to avoid breaking initialization before tables are fully installed
            }
        }
    } catch (PDOException $e) {
        $db = null;
        $dbError = $e->getMessage();
    }
}

function isDbConfigured() {
    global $config;
    return ($config['db_connection'] === 'sqlite') || (!empty($config['db_name']) && !empty($config['db_user']));
}

function isDbConnected() {
    global $db;
    return $db !== null;
}
