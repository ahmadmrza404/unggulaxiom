<?php
/**
 * Personal Bill Splitter Common Helpers
 */

require_once __DIR__ . '/rate_limiter.php';
require_once __DIR__ . '/lang.php';

/**
 * Send JSON response and exit.
 *
 * @param mixed $data
 * @param int $statusCode
 * @return void
 */
function sendJSONResponse($data, $statusCode = 200) {
    global $config;
    
    // Set headers
    $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '*';
    $allowed = isset($config['allowed_origins']) ? $config['allowed_origins'] : '*';
    
    if ($allowed === '*') {
        header("Access-Control-Allow-Origin: *");
    } else {
        $allowedOrigins = array_map('trim', explode(',', $allowed));
        if (in_array($origin, $allowedOrigins)) {
            header("Access-Control-Allow-Origin: $origin");
        }
    }
    
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With, X-CSRF-Token");
    
    // Handle preflight OPTIONS request
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
    
    http_response_code($statusCode);
    echo json_encode($data);
    exit;
}

/**
 * Recursively sanitizes data to prevent XSS.
 *
 * @param mixed $data
 * @return mixed
 */
function sanitizeInput($data) {
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            $data[$key] = sanitizeInput($value);
        }
    } else {
        $data = htmlspecialchars(trim((string)$data), ENT_QUOTES, 'UTF-8');
    }
    return $data;
}

/**
 * Validates uploaded receipt files.
 *
 * @param array $file $_FILES['image'] structure
 * @param int $maxSize Max size in bytes (default 5MB)
 * @return array Array with ['success' => bool, 'error' => string|null]
 */
function validateUploadedFile($file, $maxSize = 5242880) {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE   => 'The uploaded file exceeds the upload_max_filesize directive in php.ini.',
            UPLOAD_ERR_FORM_SIZE  => 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.',
            UPLOAD_ERR_PARTIAL    => 'The uploaded file was only partially uploaded.',
            UPLOAD_ERR_NO_FILE     => 'No file was uploaded.',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder.',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
            UPLOAD_ERR_EXTENSION  => 'A PHP extension stopped the file upload.',
        ];
        $code = isset($file['error']) ? $file['error'] : UPLOAD_ERR_NO_FILE;
        return [
            'success' => false,
            'error' => isset($errors[$code]) ? $errors[$code] : 'Unknown upload error.'
        ];
    }

    // Check file size
    if ($file['size'] > $maxSize) {
        $sizeMb = round($maxSize / (1024 * 1024), 2);
        return [
            'success' => false,
            'error' => "File size exceeds the limit of {$sizeMb}MB."
        ];
    }

    // Validate MIME type safely supporting restricted cPanel configurations
    $mimeType = '';
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($file['tmp_name']);
    } elseif (function_exists('mime_content_type')) {
        $mimeType = mime_content_type($file['tmp_name']);
    } else {
        $mimeType = $file['type'];
    }
    
    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        'application/pdf' => 'pdf'
    ];

    if (!array_key_exists($mimeType, $allowedMimeTypes)) {
        return [
            'success' => false,
            'error' => 'Unsupported file format. Only JPG, PNG, WEBP, GIF, and PDF are supported.'
        ];
    }

    return [
        'success' => true,
        'extension' => $allowedMimeTypes[$mimeType],
        'mime' => $mimeType,
        'error' => null
    ];
}

/**
 * Log a user or administrative activity to the database.
 *
 * @param string $action
 * @param string $details
 * @return void
 */
function logActivity($action, $details) {
    global $db;
    if (!$db) return;
    
    try {
        $userId = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;
        $username = null;
        
        if ($userId) {
            $username = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : null;
            if (!$username) {
                $stmt = $db->prepare("SELECT username FROM users WHERE id = ?");
                $stmt->execute([$userId]);
                $username = $stmt->fetchColumn() ?: null;
            }
        }
        
        $ipAddress = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : null;
        
        $stmt = $db->prepare("INSERT INTO activity_logs (user_id, username, action, details, ip_address) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $username, $action, $details, $ipAddress]);
    } catch (PDOException $e) {
        // Silently catch to avoid blocking the main execution path if logging table is locked/fails
    }
}

/**
 * Safely retrieves a global system setting.
 *
 * @param string $key
 * @param mixed $default
 * @return mixed
 */
function getSystemSetting($key, $default = null) {
    global $db;
    if (!$db) return $default;
    try {
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $val = $stmt->fetchColumn();
        return $val !== false ? $val : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

/**
 * Safely inserts or updates a global system setting.
 *
 * @param string $key
 * @param string $value
 * @return bool
 */
function setSystemSetting($key, $value) {
    global $db;
    if (!$db) return false;
    try {
        $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        return $stmt->execute([$key, $value]);
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Renders the global broadcast announcement banner if active.
 *
 * @return void
 */
function renderGlobalAnnouncement() {
    $active = getSystemSetting('announcement_active', '0');
    $text = getSystemSetting('announcement_text', '');
    $type = getSystemSetting('announcement_type', 'info');
    
    if ($active !== '1' || empty($text)) {
        return;
    }
    
    $hash = md5($text);
    
    // Select appropriate Lucide icon and color styles matching modern theme variables
    $icon = 'info';
    $bgColorVar = 'var(--color-primary-light)';
    $borderColorVar = 'var(--color-primary)';
    $textColorVar = 'var(--text-primary)';
    
    if ($type === 'warning') {
        $icon = 'alert-triangle';
        $bgColorVar = 'var(--color-warning-light)';
        $borderColorVar = 'var(--color-warning)';
    } elseif ($type === 'success') {
        $icon = 'check-circle';
        $bgColorVar = 'var(--color-success-light)';
        $borderColorVar = 'var(--color-success)';
    } elseif ($type === 'danger') {
        $icon = 'alert-octagon';
        $bgColorVar = 'var(--color-danger-light)';
        $borderColorVar = 'var(--color-danger)';
    }
    
    echo '
    <div id="announcement-' . $hash . '" class="announcement-banner" style="
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.85rem 1rem;
        background: ' . $bgColorVar . ';
        border: 1px solid ' . $borderColorVar . ';
        border-radius: var(--border-radius-md);
        margin-bottom: 1.25rem;
        gap: 0.75rem;
        box-shadow: var(--shadow-sm);
        transition: opacity var(--transition-normal), transform var(--transition-normal);
        position: relative;
    ">
        <div style="display: flex; align-items: center; gap: 0.6rem; flex: 1;">
            <i class="announcement-icon" data-lucide="' . $icon . '" style="width: 18px; height: 18px; color: ' . $borderColorVar . '; flex-shrink: 0; display: inline-block; vertical-align: middle;"></i>
            <span style="font-size: 0.85rem; line-height: 1.4; color: ' . $textColorVar . '; font-weight: 500;">' . htmlspecialchars($text) . '</span>
        </div>
        <button class="announcement-close-btn" onclick="dismissAnnouncement(\'' . $hash . '\')" aria-label="Dismiss Announcement" style="
            background: none;
            border: none;
            cursor: pointer;
            padding: 0.25rem;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--border-radius-sm);
            transition: all var(--transition-fast);
        ">
            <i data-lucide="x" style="width: 16px; height: 16px;"></i>
        </button>
    </div>
    <script>
        (function() {
            var hash = \'' . $hash . '\';
            if (localStorage.getItem(\'ann_dismissed_\' + hash) === \'1\') {
                var el = document.getElementById(\'announcement-\' + hash);
                if (el) el.style.display = \'none\';
            }
        })();
        function dismissAnnouncement(hash) {
            localStorage.setItem(\'ann_dismissed_\' + hash, \'1\');
            var el = document.getElementById(\'announcement-\' + hash);
            if (el) {
                el.style.opacity = \'0\';
                el.style.transform = \'translateY(-8px)\';
                setTimeout(function() { el.style.display = \'none\'; }, 250);
            }
        }
    </script>
    ';
}

