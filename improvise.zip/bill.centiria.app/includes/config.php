<?php
/**
 * Personal Bill Splitter Configuration Loader
 * Handles loading environment variables from .env and exposes them.
 */

// Define directory constants
define('ROOT_DIR', dirname(__DIR__));
define('STORAGE_DIR', ROOT_DIR . '/storage');
define('TEMP_DIR', STORAGE_DIR . '/temp');

// Load environment variables from .env if it exists
function loadEnv() {
    $envPath = ROOT_DIR . '/.env';
    if (!file_exists($envPath)) {
        return;
    }

    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        // Skip comments
        if (strpos(trim($line), '#') === 0) {
            continue;
        }

        // Split by the first '=' character
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) {
            $key = trim($parts[0]);
            $val = trim($parts[1]);
            
            // Remove quotes if present
            if ((strpos($val, '"') === 0 && substr($val, -1) === '"') ||
                (strpos($val, "'") === 0 && substr($val, -1) === "'")) {
                $val = substr($val, 1, -1);
            }
            
            if (!array_key_exists($key, $_ENV)) {
                $_ENV[$key] = $val;
                putenv("$key=$val");
            }
        }
    }
}

// Initialize environment variables
loadEnv();

// Fetch environment variable with fallback
function env($key, $default = null) {
    $value = getenv($key);
    if ($value === false) {
        return isset($_ENV[$key]) ? $_ENV[$key] : $default;
    }
    return $value;
}

// Generate config array
$config = [
    'env' => env('APP_ENV', 'production'),
    'allowed_origins' => env('ALLOWED_ORIGINS', '*'),
    
    // OCR Configuration
    'ocr_provider' => env('OCR_PROVIDER', 'gemini'), // 'gemini' or 'local'
    'gemini_api_key' => env('GEMINI_API_KEY', ''),
    
    // Currency Exchange API Configuration
    'currency_provider' => env('CURRENCY_PROVIDER', 'frankfurter'), // 'frankfurter' or 'exchangerate_api'
    'exchangerate_api_key' => env('EXCHANGERATE_API_KEY', ''),
    
    // Database Configuration
    'db_connection' => env('DB_CONNECTION', 'sqlite'),
    'db_sqlite_path' => env('DB_SQLITE_PATH', STORAGE_DIR . '/database.sqlite'),
    'db_host' => env('DB_HOST', 'localhost'),
    'db_port' => env('DB_PORT', '3306'),
    'db_user' => env('DB_USER', ''),
    'db_pass' => env('DB_PASS', ''),
    'db_name' => env('DB_NAME', ''),
    
    // Temp storage path
    'temp_dir' => TEMP_DIR,
];

// Ensure temp directory exists
if (!is_dir($config['temp_dir'])) {
    mkdir($config['temp_dir'], 0755, true);
}

// Global Security Headers to protect against clickjacking, MIME sniffing, and referrer leaks
if (!headers_sent()) {
    header("X-Frame-Options: SAMEORIGIN");
    header("X-Content-Type-Options: nosniff");
    header("Referrer-Policy: strict-origin-when-cross-origin");
}

