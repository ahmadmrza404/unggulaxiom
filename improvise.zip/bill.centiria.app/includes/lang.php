<?php
/**
 * Personal Bill Splitter - Translation/Localization Manager
 * Supports English (en) and Bahasa Melayu (bm)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Detect language from Cookie, Session, or default to English
$lang = 'en';
if (isset($_GET['lang'])) {
    $lang = $_GET['lang'] === 'bm' ? 'bm' : 'en';
    $_SESSION['lang'] = $lang;
    setcookie('lang', $lang, time() + (86400 * 30), "/"); // 30 days
} elseif (isset($_COOKIE['lang'])) {
    $lang = $_COOKIE['lang'] === 'bm' ? 'bm' : 'en';
    $_SESSION['lang'] = $lang;
} elseif (isset($_SESSION['lang'])) {
    $lang = $_SESSION['lang'] === 'bm' ? 'bm' : 'en';
}

// Define translations
$translations = [
    'en' => [
        // Navbar & Auth
        'dashboard' => 'Dashboard',
        'profile' => 'Profile',
        'admin_panel' => 'Admin Panel',
        'logout' => 'Logout',
        'login' => 'Login',
        'register' => 'Register',
        'welcome_back' => 'Welcome Back',
        'create_account' => 'Create Account',
        
        // Buttons / Actions
        'save' => 'Save',
        'cancel' => 'Cancel',
        'delete' => 'Delete',
        'edit' => 'Edit',
        'copy' => 'Copy',
        'add' => 'Add',
        'preferred' => 'Preferred',
        'set_preferred' => 'Set Preferred',
        
        // Fields
        'username' => 'Username',
        'password' => 'Password',
        'display_name' => 'Display Name',
        'email_address' => 'Email Address',
        'email_placeholder' => 'Enter email address...',
        'profile_picture' => 'Profile Picture',
        'upload_picture' => 'Upload Picture',
        'change_password' => 'Change Password',
        'current_password' => 'Current Password',
        'new_password' => 'New Password',
        'confirm_new_password' => 'Confirm New Password',
        'recreated_qr' => 'Recreated QR (Scanned from Image)',
        'upload_qr_scan' => 'Upload QR Image to Scan',
        'scan_qr_desc' => 'Upload a DuitNow, TnG, or bank transfer QR. The system will read it and recreate a clean scannable vector QR.',
        'qr_scan_success' => 'QR code scanned and decoded successfully!',
        'qr_scan_failed' => 'Could not detect a scannable QR code. Please make sure the image is clear.',
        
        // Login / Register Extra
        'dont_have_account' => "Don't have an account?",
        'already_have_account' => 'Already have an account?',
        'wrong_credentials' => 'Invalid username or password.',
        'username_taken' => 'Username is already taken.',
        'register_success' => 'Registration successful! Please login.',
        
        // Dashboard
        'splits_created' => 'Splits Created',
        'splits_you_owe' => 'Splits You Owe',
        'create_new_split' => 'Create New Split',
        'no_splits_created' => 'You haven\'t created any bill splits yet.',
        'no_splits_owed' => 'Excellent! You don\'t owe anyone money right now.',
        'total_bill' => 'Total Bill',
        'your_share' => 'Your Share',
        'created_by' => 'Created by',
        'view_details' => 'View Details',
        
        // Profile
        'profile_details' => 'Profile Details',
        'payment_qr_settings' => 'Payment QR Settings',
        'no_qr' => 'No QR Code (Manual Bank Transfer Only)',
        'duitnow_phone' => 'DuitNow ID (Phone Number)',
        'tng_transfer' => 'Touch \'n Go Transfer Link',
        'custom_qr_image' => 'Custom QR Code Image',
        'qr_value_placeholder' => 'Enter Phone Number or TNG URL...',
        'current_qr_file' => 'Current QR Image',
        'upload_new_qr' => 'Upload New QR Image',
        'bank_accounts' => 'Bank Accounts',
        'add_bank_account' => 'Add Bank Account',
        'bank_name' => 'Bank Name',
        'account_name' => 'Account Holder Name',
        'account_number' => 'Account Number',
        'no_bank_accounts' => 'No bank accounts added yet. Please add at least one.',
        
        // Public View
        'payable_to' => 'Payable to',
        'scan_to_pay' => 'Scan or click to pay',
        'bank_transfer_details' => 'Bank Transfer Details',
        'alternate_payment' => 'Alternate Payment Options',
        'click_to_copy' => 'Click to copy account number',
        'copied' => 'Copied!',
    ],
    'bm' => [
        // Navbar & Auth
        'dashboard' => 'Papan Pemuka',
        'profile' => 'Profil',
        'admin_panel' => 'Panel Admin',
        'logout' => 'Log Keluar',
        'login' => 'Log Masuk',
        'register' => 'Daftar',
        'welcome_back' => 'Selamat Kembali',
        'create_account' => 'Daftar Akaun',
        
        // Buttons / Actions
        'save' => 'Simpan',
        'cancel' => 'Batal',
        'delete' => 'Padam',
        'edit' => 'Edit',
        'copy' => 'Salin',
        'add' => 'Tambah',
        'preferred' => 'Utama',
        'set_preferred' => 'Set Utama',
        
        // Fields
        'username' => 'Nama Pengguna',
        'password' => 'Kata Laluan',
        'display_name' => 'Nama Paparan',
        'email_address' => 'Alamat E-mel',
        'email_placeholder' => 'Masukkan alamat e-mel...',
        'profile_picture' => 'Gambar Profil',
        'upload_picture' => 'Muat Naik Gambar',
        'change_password' => 'Tukar Kata Laluan',
        'current_password' => 'Kata Laluan Semasa',
        'new_password' => 'Kata Laluan Baru',
        'confirm_new_password' => 'Sahkan Kata Laluan Baru',
        'recreated_qr' => 'QR Dicipta Semula (Diimbas dari Imej)',
        'upload_qr_scan' => 'Muat Naik Imej QR untuk Imbasan',
        'scan_qr_desc' => 'Muat naik DuitNow, TnG, atau QR pindahan bank. Sistem akan membaca dan mencipta semula QR vektor scannable yang bersih.',
        'qr_scan_success' => 'Kod QR berjaya diimbas dan dinyahkod!',
        'qr_scan_failed' => 'Tidak dapat mengesan kod QR yang boleh diimbas. Sila pastikan imej jelas.',
        
        // Login / Register Extra
        'dont_have_account' => "Belum mempunyai akaun?",
        'already_have_account' => 'Sudah mempunyai akaun?',
        'wrong_credentials' => 'Nama pengguna atau kata laluan salah.',
        'username_taken' => 'Nama pengguna telah digunakan.',
        'register_success' => 'Pendaftaran berjaya! Sila log masuk.',
        
        // Dashboard
        'splits_created' => 'Bil yang Dibuat',
        'splits_you_owe' => 'Bil yang Dihutang',
        'create_new_split' => 'Buat Pembahagian Bil Baru',
        'no_splits_created' => 'Anda belum membuat sebarang pembahagian bil lagi.',
        'no_splits_owed' => 'Cemerlang! Anda tidak berhutang dengan sesiapa buat masa ini.',
        'total_bill' => 'Jumlah Bil',
        'your_share' => 'Bahagian Anda',
        'created_by' => 'Dibuat oleh',
        'view_details' => 'Lihat Perincian',
        
        // Profile
        'profile_details' => 'Maklumat Profil',
        'payment_qr_settings' => 'Tetapan QR Pembayaran',
        'no_qr' => 'Tiada Kod QR (Pindahan Bank Manual Sahaja)',
        'duitnow_phone' => 'DuitNow ID (Nombor Telefon)',
        'tng_transfer' => 'Pautan Pindahan Touch \'n Go',
        'custom_qr_image' => 'Imej Kod QR Kustom',
        'qr_value_placeholder' => 'Masukkan Nombor Telefon atau URL TNG...',
        'current_qr_file' => 'Imej QR Semasa',
        'upload_new_qr' => 'Muat Naik Imej QR Baru',
        'bank_accounts' => 'Akaun Bank',
        'add_bank_account' => 'Tambah Akaun Bank',
        'bank_name' => 'Nama Bank',
        'account_name' => 'Nama Pemegang Akaun',
        'account_number' => 'Nombor Akaun',
        'no_bank_accounts' => 'Tiada akaun bank ditambah lagi. Sila tambah sekurang-kurangnya satu.',
        
        // Public View
        'payable_to' => 'Bayar kepada',
        'scan_to_pay' => 'Imbas atau klik untuk bayar',
        'bank_transfer_details' => 'Butiran Pindahan Bank',
        'alternate_payment' => 'Pilihan Pembayaran Alternatif',
        'click_to_copy' => 'Klik untuk salin nombor akaun',
        'copied' => 'Disalin!',
    ]
];

/**
 * Translation helper function
 */
function __($key) {
    global $translations, $lang;
    if (isset($translations[$lang][$key])) {
        return $translations[$lang][$key];
    }
    return $key;
}

/**
 * Get current language code
 */
function getLang() {
    global $lang;
    return $lang;
}
