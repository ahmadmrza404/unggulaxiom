<?php
/**
 * Personal Bill Splitter - Auth & RBAC Manager
 */

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        ini_set('session.cookie_secure', 1);
    }
    session_start();
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/**
 * Validate CSRF token using timing-safe comparison.
 */
function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}


require_once __DIR__ . '/db.php';

/**
 * Check if the user is authenticated.
 */
function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

/**
 * Get current logged in user details.
 */
function getCurrentUser() {
    global $db;
    if (!isAuthenticated() || !$db) return null;

    try {
        $stmt = $db->prepare("SELECT id, username, role, display_name, email, profile_pic, qr_type, qr_value, qr_image, bio, telegram, phone FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        return null;
    }
}

/**
 * Require authentication, redirect to login if not logged in.
 */
function requireAuth() {
    if (!isAuthenticated()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header('Location: login.php');
        exit;
    }
    
    // Enforce Maintenance Mode
    global $db;
    if ($db) {
        try {
            $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'maintenance_mode'");
            $stmt->execute();
            $maintenanceMode = $stmt->fetchColumn();
            
            if ($maintenanceMode === '1' && !isAdmin()) {
                http_response_code(503);
                include __DIR__ . '/../maintenance.php';
                exit;
            }
        } catch (PDOException $e) {
            // Table might not be created yet during installation
        }
    }
}

/**
 * Check if current user is Admin.
 */
function isAdmin() {
    return isAuthenticated() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Require Admin role, block if not.
 */
function requireAdmin() {
    requireAuth();
    if (!isAdmin()) {
        http_response_code(403);
        echo "<h1>403 Forbidden</h1><p>You do not have administrative privileges to access this page.</p>";
        exit;
    }
}

// Automatically update user last_active timestamp on page load if logged in
if (isAuthenticated() && isDbConnected()) {
    try {
        global $db;
        $stmtActive = $db->prepare("UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE id = ?");
        $stmtActive->execute([$_SESSION['user_id']]);
    } catch (PDOException $e) {
        // Ignore if database is locked or table is missing
    }
}
