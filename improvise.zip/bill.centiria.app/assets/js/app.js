/**
 * Personal Bill Splitter Main Coordinator (Controller)
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize Views and Model
    AppUI.init();
    
    // Translate all static HTML elements with data-i18n attribute
    document.querySelectorAll('[data-i18n]').forEach(elem => {
        const key = elem.getAttribute('data-i18n');
        if (elem.tagName === 'INPUT' || elem.tagName === 'TEXTAREA') {
            elem.placeholder = __(key);
        } else {
            elem.textContent = __(key);
        }
    });

    AppState.reset();

    // Pre-warm Tesseract in background
    OCR.preloadWorker();

    // Stepper routing wrapper
    const showStep = (stepNumber) => {
        AppState.state.step = stepNumber;
        AppUI.showStep(stepNumber);

        // Run step initializers
        if (stepNumber === 1) initStep1();
        if (stepNumber === 2) initStep2();
        if (stepNumber === 3) initStep3();
        if (stepNumber === 4) initStep4();
        if (stepNumber === 5) initStep5();
        if (stepNumber === 6) initStep6();
    };

    // ----------------------------------------------------
    // STEP INITIALIZERS
    // ----------------------------------------------------
    const initStep1 = () => {
        renderRecentBillsList();
    };

    const initStep2 = () => {
        AppUI.elements.billMerchant.value = AppState.state.merchant;
        AppUI.elements.billDate.value = AppState.state.date;
        AppUI.elements.billCurrency.value = AppState.state.currency;

        if (AppState.state.originalImgSrc) {
            AppUI.elements.toggleInspectorBtn.style.display = 'inline-flex';
        } else {
            AppUI.elements.toggleInspectorBtn.style.display = 'none';
            AppUI.elements.receiptInspector.classList.remove('active');
        }

        if (AppState.state.items.length === 0) {
            addItemRow();
        } else {
            AppUI.renderBillItemsTable(AppState.state);
        }
    };

    const initStep3 = () => {
        if (AppState.state.people.length === 0) {
            AppState.state.people = [
                { id: `p_${Date.now()}_1`, name: 'Person 1' },
                { id: `p_${Date.now()}_2`, name: 'Person 2' }
            ];
        }
        AppUI.renderPeopleList(AppState.state);

        // Profile sync logic
        if (window.USER_PROFILE) {
            const up = window.USER_PROFILE;
            const normalizedProfileQrType = up.qrType === 'scanned' ? 'tng' : up.qrType;
            if (!AppState.state.paymentMethod || AppState.state.paymentMethod === 'none') {
                if (normalizedProfileQrType && normalizedProfileQrType !== 'none') {
                    AppState.state.paymentMethod = normalizedProfileQrType;
                    AppState.state.paymentDetails = up.qrValue;
                } else if (up.bankName && up.accountNumber) {
                    AppState.state.paymentMethod = 'bank';
                    AppState.state.bankName = up.bankName;
                    AppState.state.bankAccount = up.accountNumber;
                }
            } else {
                if (AppState.state.paymentMethod === 'duitnow' && !AppState.state.paymentDetails && normalizedProfileQrType === 'duitnow') {
                    AppState.state.paymentDetails = up.qrValue;
                } else if (AppState.state.paymentMethod === 'tng' && !AppState.state.paymentDetails && normalizedProfileQrType === 'tng') {
                    AppState.state.paymentDetails = up.qrValue;
                } else if (AppState.state.paymentMethod === 'bank' && (!AppState.state.bankName || !AppState.state.bankAccount) && up.bankName) {
                    AppState.state.bankName = up.bankName;
                    AppState.state.bankAccount = up.accountNumber;
                } else if (AppState.state.paymentMethod === 'custom' && up.qrType === 'custom') {
                    AppState.state.paymentDetails = 'Custom QR Settings';
                }
            }

        }

        AppState.state.paymentMethod = AppState.state.paymentMethod !== 'none' ? AppState.state.paymentMethod : Utils.storageGet('default_payment_method', 'none');
        if (AppState.state.paymentMethod === 'scanned') {
            AppState.state.paymentMethod = 'tng';
        }
        AppState.state.paymentDetails = AppState.state.paymentDetails || Utils.storageGet('default_payment_details', '');
        AppState.state.bankName = AppState.state.bankName || Utils.storageGet('default_bank_name', '');
        AppState.state.bankAccount = AppState.state.bankAccount || Utils.storageGet('default_bank_account', '');

        AppUI.disableUnconfiguredPaymentOptions();
        
        // Fallback if selected default method is disabled
        const selectedOption = AppUI.elements.paymentMethod.querySelector(`option[value="${AppState.state.paymentMethod}"]`);
        if (selectedOption && selectedOption.disabled) {
            AppState.state.paymentMethod = 'none';
        }

        AppUI.elements.paymentMethod.value = AppState.state.paymentMethod;
        AppUI.elements.paymentDetails.value = AppState.state.paymentDetails;
        AppUI.elements.bankName.value = AppState.state.bankName;
        AppUI.elements.bankAccount.value = AppState.state.bankAccount;
        AppUI.updatePaymentFieldsVisibility();
    };

    const initStep4 = () => {
        AppUI.renderAssignmentUI(AppState.state);
    };

    const initStep5 = () => {
        AppUI.elements.taxDistribution.value = AppState.state.taxDistribution;
        AppUI.elements.discountDistribution.value = AppState.state.discountDistribution;
        triggerCalculations();
    };

    const initStep6 = () => {
        AppState.calculationResults = Calculator.calculateSplit(AppState.state);
        AppState.saveToHistory();
        AppUI.renderFinalSummary(AppState.state, AppState.calculationResults);
        setTimeout(() => {
            window.BillSplitterInstallPrompt?.show();
        }, 1200);
    };

    // ----------------------------------------------------
    // CORE WORKFLOW LOGIC
    // ----------------------------------------------------
    const addItemRow = () => {
        AppState.state.items.push({
            id: `item_${Date.now()}_${AppState.state.items.length}`,
            name: '',
            qty: 1,
            price: 0.00,
            assignedPeople: [],
            splitMode: 'equal',
            splits: {},
            category: 'food'
        });
        AppUI.renderBillItemsTable(AppState.state);
    };

    const recalculateBillTotals = () => {
        let subtotal = 0;
        AppState.state.items.forEach(item => {
            subtotal += item.qty * item.price;
        });
        
        const disc = parseFloat(AppUI.elements.billDiscount.value) || 0;
        const svc = parseFloat(AppUI.elements.billServiceCharge.value) || 0;
        const tax = parseFloat(AppUI.elements.billTax.value) || 0;
        const rnd = parseFloat(AppUI.elements.billRounding.value) || 0;
        
        const total = subtotal - disc + svc + tax + rnd;
        
        AppState.state.discount = disc;
        AppState.state.serviceCharge = svc;
        AppState.state.tax = tax;
        AppState.state.rounding = rnd;
        AppState.state.grandTotal = total;

        AppUI.updateBillTotalsDisplay(subtotal, AppState.state);
    };

    const triggerCalculations = () => {
        AppState.calculationResults = Calculator.calculateSplit(AppState.state);
        AppUI.renderRunningTotals(AppState.state, AppState.calculationResults);
    };

    const renderRecentBillsList = () => {
        const history = Utils.storageGet('bill_history', []);
        AppUI.renderRecentBills(history, (bill) => {
            AppState.hydrateFromData(bill);
            AppState.calculationResults = Calculator.calculateSplit(AppState.state);
            Utils.showToast("Bill loaded from history!", "success");
            showStep(6);
        });
    };

    // ----------------------------------------------------
    // STEP 1: EVENT BINDINGS
    // ----------------------------------------------------
    AppUI.elements.themeToggle.addEventListener('click', () => AppUI.toggleTheme());

    document.getElementById('langToggle')?.addEventListener('click', () => {
        const currentLang = document.cookie.split('; ').find(row => row.startsWith('lang='))?.split('=')[1] || 'en';
        const nextLang = currentLang === 'en' ? 'bm' : 'en';
        document.cookie = `lang=${nextLang}; path=/; max-age=${30 * 86400}`;
        const url = new URL(window.location.href);
        url.searchParams.set('lang', nextLang);
        window.location.href = url.toString();
    });

    AppUI.elements.uploadDropzone.addEventListener('click', () => AppUI.elements.receiptFileInput.click());

    AppUI.elements.loadSampleMYRBtn.addEventListener('click', () => {
        AppState.loadSample('MYR');
        Utils.showToast("Local Cafe MYR Sample Loaded!", "success");
        showStep(2);
    });

    AppUI.elements.loadSampleSGDBtn.addEventListener('click', () => {
        AppState.loadSample('SGD');
        Utils.showToast("Weekend Trip SGD Sample Loaded!", "success");
        showStep(2);
    });

    let selectedReceiptFile = null;

    const applyParsedReceiptToState = (parsedBill) => {
        const safeItems = Array.isArray(parsedBill.items) ? parsedBill.items : [];
        const normalizedItems = safeItems
            .map((item, idx) => {
                const qty = Math.max(1, parseInt(item.qty, 10) || 1);
                const total = parseFloat(item.total);
                const unitPrice = parseFloat(item.price);
                const resolvedPrice = Number.isFinite(unitPrice) && unitPrice > 0
                    ? unitPrice
                    : (Number.isFinite(total) && total > 0 ? total / qty : 0);

                return {
                    id: `item_${Date.now()}_${idx}`,
                    name: (item.name || `Item ${idx + 1}`).toString().trim() || `Item ${idx + 1}`,
                    qty,
                    price: parseFloat(resolvedPrice.toFixed(2)),
                    assignedPeople: [],
                    splitMode: 'equal',
                    splits: {},
                    category: 'food'
                };
            })
            .filter(item => item.price > 0);

        const computedSubtotal = normalizedItems.reduce((sum, item) => sum + (item.qty * item.price), 0);
        const discount = Math.abs(parseFloat(parsedBill.discount) || 0);
        const serviceCharge = parseFloat(parsedBill.service_charge) || 0;
        const tax = parseFloat(parsedBill.tax) || 0;
        const rounding = parseFloat(parsedBill.rounding) || 0;
        const parsedTotal = parseFloat(parsedBill.total);

        AppState.state.merchant = (parsedBill.merchant || '').toString().trim();
        AppState.state.date = (parsedBill.date || '').toString().trim();
        AppState.state.currency = (parsedBill.currency || 'MYR').toString().toUpperCase();
        AppState.state.discount = discount;
        AppState.state.serviceCharge = serviceCharge;
        AppState.state.tax = tax;
        AppState.state.rounding = rounding;
        AppState.state.grandTotal = Number.isFinite(parsedTotal) && parsedTotal > 0
            ? parsedTotal
            : parseFloat((computedSubtotal - discount + serviceCharge + tax + rounding).toFixed(2));
        AppState.state.items = normalizedItems;
    };

    AppUI.elements.receiptFileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        selectedReceiptFile = file;

        if (OCR.cropper) {
            OCR.cropper.destroy();
            OCR.cropper = null;
        }

        AppUI.showLoader('Loading file...');
        try {
            let imgSrc;
            if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
                AppUI.showLoader('Rendering PDF...');
                const pdfCanvas = await OCR.renderPDFToCanvas(file);
                imgSrc = pdfCanvas.toDataURL('image/jpeg');
            } else {
                imgSrc = await new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = (event) => resolve(event.target.result);
                    reader.onerror = (err) => reject(err);
                    reader.readAsDataURL(file);
                });
            }

            AppState.state.originalImgSrc = imgSrc;
            AppUI.elements.preprocessImage.src = imgSrc;
            
            AppUI.elements.preprocessImage.onload = () => {
                AppUI.hideLoader();
                AppUI.elements.uploadDropzone.style.display = 'none';
                AppUI.elements.preprocessCard.style.display = 'block';
                OCR.initCropper(AppUI.elements.preprocessImage);
            };
        } catch (err) {
            Utils.showToast("Failed to load file: " + err.message, "error");
            AppUI.hideLoader();
        }
    });

    AppUI.elements.rotateLeftBtn.addEventListener('click', () => OCR.rotate(-90));
    AppUI.elements.rotateRightBtn.addEventListener('click', () => OCR.rotate(90));

    AppUI.elements.brightnessSlider.addEventListener('input', (e) => {
        AppState.state.brightness = parseInt(e.target.value);
    });
    AppUI.elements.contrastSlider.addEventListener('input', (e) => {
        AppState.state.contrast = parseInt(e.target.value);
    });

    AppUI.elements.ocrProcessBtn.addEventListener('click', async () => {
        AppUI.showLoader('Processing receipt...');
        setTimeout(async () => {
            try {
                let parsedBill = null;
                const csrfMeta = document.querySelector('meta[name="csrf-token"]');
                const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

                if (selectedReceiptFile) {
                    AppUI.elements.loadingText.textContent = 'Trying enhanced receipt OCR...';
                    parsedBill = await OCR.runServerOCR(selectedReceiptFile, csrfToken);
                }

                if (!parsedBill) {
                    const canvas = OCR.getProcessedCanvas(AppState.state.brightness, AppState.state.contrast);
                    if (!canvas) throw new Error("Could not preprocess image.");

                    const rawText = await OCR.runTesseract(canvas, (progressData) => {
                        if (progressData.status === 'recognizing') {
                            const pct = Math.round(progressData.progress * 100);
                            AppUI.elements.loadingText.textContent = `Local OCR Text Extraction: ${pct}%`;
                        } else if (progressData.status === 'initializing') {
                            AppUI.elements.loadingText.textContent = 'Initializing local OCR...';
                        }
                    });

                    parsedBill = OCR.parseReceiptText(rawText);
                }

                applyParsedReceiptToState(parsedBill);

                if (AppState.state.items.length === 0) {
                    addItemRow();
                    Utils.showToast("OCR finished, but no line items were detected. Please enter items manually.", "warning");
                } else {
                    Utils.showToast(`OCR imported ${AppState.state.items.length} item(s). Please review before splitting.`, "success");
                }

                AppUI.hideLoader();
                showStep(2);
            } catch (err) {
                console.warn("OCR extraction failed:", err);
                AppState.state.items = [];
                addItemRow();
                Utils.showToast("OCR extraction failed. Please enter items manually.", "warning");
                AppUI.hideLoader();
                showStep(2);
            }
        }, 100);
    });

    AppUI.elements.skipOcrBtn.addEventListener('click', () => {
        AppState.reset();
        showStep(2);
    });

    // ----------------------------------------------------
    // STEP 2: EVENT BINDINGS (WITH EVENT DELEGATION)
    // ----------------------------------------------------
    AppUI.elements.addItemRowBtn.addEventListener('click', addItemRow);

    AppUI.elements.billItemsBody.addEventListener('change', (e) => {
        const idx = parseInt(e.target.dataset.index);
        if (e.target.classList.contains('item-qty-input')) {
            AppState.state.items[idx].qty = parseInt(e.target.value) || 1;
            recalculateBillTotals();
        } else if (e.target.classList.contains('item-category-select')) {
            AppState.state.items[idx].category = e.target.value;
        } else if (e.target.classList.contains('item-price-input')) {
            AppState.state.items[idx].price = parseFloat(e.target.value) || 0.00;
            recalculateBillTotals();
        }
    });

    AppUI.elements.billItemsBody.addEventListener('input', (e) => {
        if (e.target.classList.contains('item-name-input')) {
            const idx = parseInt(e.target.dataset.index);
            AppState.state.items[idx].name = e.target.value;
        }
    });

    AppUI.elements.billItemsBody.addEventListener('click', (e) => {
        const deleteBtn = e.target.closest('.delete-row-btn');
        if (deleteBtn) {
            const idx = parseInt(deleteBtn.dataset.index);
            AppState.state.items.splice(idx, 1);
            AppUI.renderBillItemsTable(AppState.state);
        }
    });

    AppUI.elements.billItemsBody.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            const idx = parseInt(e.target.dataset.index);
            if (e.target.classList.contains('item-name-input')) {
                e.preventDefault();
                const prices = AppUI.elements.billItemsBody.querySelectorAll('.item-price-input');
                if (prices[idx]) {
                    prices[idx].focus();
                    prices[idx].select();
                }
            } else if (e.target.classList.contains('item-price-input')) {
                e.preventDefault();
                if (idx === AppState.state.items.length - 1) {
                    addItemRow();
                    setTimeout(() => {
                        const names = AppUI.elements.billItemsBody.querySelectorAll('.item-name-input');
                        if (names.length > 0) {
                            names[names.length - 1].focus();
                            names[names.length - 1].select();
                        }
                    }, 50);
                } else {
                    const names = AppUI.elements.billItemsBody.querySelectorAll('.item-name-input');
                    if (names[idx + 1]) {
                        names[idx + 1].focus();
                        names[idx + 1].select();
                    }
                }
            }
        }
    });

    [AppUI.elements.billDiscount, AppUI.elements.billServiceCharge, AppUI.elements.billTax, AppUI.elements.billRounding, AppUI.elements.billGrandTotal].forEach(elem => {
        elem.addEventListener('change', (e) => {
            const val = parseFloat(e.target.value) || 0;
            e.target.value = val.toFixed(2);
            
            if (e.target === AppUI.elements.billGrandTotal) {
                const computedTotal = (parseFloat(AppUI.elements.billSubtotal.textContent) || 0) - AppState.state.discount + AppState.state.serviceCharge + AppState.state.tax;
                AppState.state.rounding = val - computedTotal;
                AppUI.elements.billRounding.value = AppState.state.rounding.toFixed(2);
                AppState.state.grandTotal = val;
            } else {
                recalculateBillTotals();
            }
        });
    });

    AppUI.elements.billMerchant.addEventListener('input', (e) => { AppState.state.merchant = e.target.value; });
    AppUI.elements.billDate.addEventListener('change', (e) => { AppState.state.date = e.target.value; });
    AppUI.elements.billCurrency.addEventListener('change', (e) => {
        AppState.state.currency = e.target.value;
        AppState.state.isForeign = AppState.state.currency.toUpperCase() !== 'MYR';
    });

    // Travel preset modal triggers
    let activeTravelTab = 'gas';
    const updateGasEstimate = () => {
        const dist = parseFloat(AppUI.elements.gasDistance.value) || 0;
        const cons = parseFloat(AppUI.elements.gasConsumption.value) || 0;
        const price = parseFloat(AppUI.elements.gasFuelPrice.value) || 0;
        const total = (dist / 100) * cons * price;
        const currencySym = AppState.state.currency === 'MYR' ? 'RM' : AppState.state.currency;
        AppUI.elements.gasEstimateText.textContent = `${currencySym} ${total.toFixed(2)}`;
    };

    [AppUI.elements.gasDistance, AppUI.elements.gasConsumption, AppUI.elements.gasFuelPrice].forEach(input => {
        if (input) input.addEventListener('input', updateGasEstimate);
    });

    AppUI.elements.addTravelExpenseBtn.addEventListener('click', () => {
        AppUI.elements.hotelRate.value = '';
        AppUI.elements.hotelNights.value = '1';
        AppUI.elements.hotelRooms.value = '1';
        AppUI.elements.hotelName.value = 'Hotel Stay';
        AppUI.elements.activityName.value = '';
        AppUI.elements.activityPrice.value = '';
        AppUI.elements.activityQty.value = '1';
        updateGasEstimate();
        AppUI.elements.travelExpenseModal.classList.add('active');
    });

    AppUI.elements.closeTravelModalBtn.addEventListener('click', () => {
        AppUI.elements.travelExpenseModal.classList.remove('active');
    });

    AppUI.elements.travelExpenseModal.querySelectorAll('.modal-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.dataset.tab;
            activeTravelTab = targetTab;
            AppUI.elements.travelExpenseModal.querySelectorAll('.modal-tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            AppUI.elements.travelExpenseModal.querySelectorAll('.tab-content').forEach(content => {
                content.style.display = (content.id === `tab-${targetTab}`) ? 'block' : 'none';
            });
        });
    });

    AppUI.elements.addTravelExpenseSubmitBtn.addEventListener('click', () => {
        let itemName = '';
        let itemQty = 1;
        let itemPrice = 0;
        let itemCategory = 'food';

        if (activeTravelTab === 'gas') {
            const dist = parseFloat(AppUI.elements.gasDistance.value) || 0;
            const cons = parseFloat(AppUI.elements.gasConsumption.value) || 0;
            const price = parseFloat(AppUI.elements.gasFuelPrice.value) || 0;
            itemPrice = (dist / 100) * cons * price;
            itemName = `Car Gas (${dist} km @ ${cons}L/100km)`;
            itemQty = 1;
            itemCategory = 'transport';

            if (itemPrice <= 0) {
                Utils.showToast("Please enter valid distance, consumption, and price.", "warning");
                return;
            }
        } else if (activeTravelTab === 'hotel') {
            const rate = parseFloat(AppUI.elements.hotelRate.value) || 0;
            const nights = parseInt(AppUI.elements.hotelNights.value) || 1;
            const rooms = parseInt(AppUI.elements.hotelRooms.value) || 1;
            
            itemPrice = rate;
            itemQty = nights * rooms;
            itemName = AppUI.elements.hotelName.value.trim() || 'Hotel Stay';
            itemName += rooms > 1 ? ` (${rooms} Rooms x ${nights} Nights)` : ` (${nights} Night${nights > 1 ? 's' : ''})`;
            itemCategory = 'lodging';

            if (itemPrice <= 0) {
                Utils.showToast("Please enter a valid room price.", "warning");
                return;
            }
        } else if (activeTravelTab === 'activity') {
            const name = AppUI.elements.activityName.value.trim() || 'Sightseeing Activity';
            const price = parseFloat(AppUI.elements.activityPrice.value) || 0;
            const qty = parseInt(AppUI.elements.activityQty.value) || 1;

            itemPrice = price;
            itemQty = qty;
            itemName = name;
            itemCategory = 'activity';

            if (itemPrice <= 0) {
                Utils.showToast("Please enter a valid price.", "warning");
                return;
            }
        }

        AppState.state.items.push({
            id: `item_travel_${Date.now()}`,
            name: itemName,
            qty: itemQty,
            price: itemPrice,
            assignedPeople: [],
            splitMode: 'equal',
            splits: {},
            category: itemCategory
        });

        AppUI.elements.travelExpenseModal.classList.remove('active');
        AppUI.renderBillItemsTable(AppState.state);
        Utils.showToast("Travel expense added successfully!", "success");
    });

    // Inspector image panel
    AppUI.elements.toggleInspectorBtn.addEventListener('click', () => {
        const isActive = AppUI.elements.receiptInspector.classList.toggle('active');
        if (isActive) {
            if (OCR.cropper) {
                const canvas = OCR.getProcessedCanvas(AppState.state.brightness, AppState.state.contrast);
                if (canvas) {
                    AppUI.elements.inspectorImageContainer.innerHTML = '';
                    AppUI.elements.inspectorImageContainer.appendChild(canvas);
                }
            } else if (AppState.state.originalImgSrc) {
                AppUI.elements.inspectorImageContainer.innerHTML = `<img src="${AppState.state.originalImgSrc}" alt="Receipt Source" style="max-width:100%; max-height:100%; object-fit:contain;">`;
            } else {
                AppUI.elements.inspectorImageContainer.innerHTML = `<div class="inspector-placeholder">No receipt image uploaded.</div>`;
            }
        }
    });

    AppUI.elements.closeInspectorBtn.addEventListener('click', () => AppUI.elements.receiptInspector.classList.remove('active'));
    AppUI.elements.backToStep1.addEventListener('click', () => {
        if (OCR.cropper) {
            OCR.cropper.destroy();
            OCR.cropper = null;
        }
        AppUI.elements.receiptInspector.classList.remove('active');
        AppUI.elements.preprocessCard.style.display = 'none';
        AppUI.elements.uploadDropzone.style.display = 'flex';
        showStep(1);
    });

    AppUI.elements.nextToStep3.addEventListener('click', () => {
        if (AppState.state.items.length === 0 || (AppState.state.items.length === 1 && !AppState.state.items[0].name && AppState.state.items[0].price === 0)) {
            Utils.showToast("Please add at least one valid item.", "warning");
            return;
        }
        AppUI.elements.receiptInspector.classList.remove('active');
        showStep(3);
    });

    // ----------------------------------------------------
    // STEP 3: EVENT BINDINGS (WITH EVENT DELEGATION)
    // ----------------------------------------------------
    AppUI.elements.paymentMethod.addEventListener('change', () => {
        const selectedMethod = AppUI.elements.paymentMethod.value;
        const up = window.USER_PROFILE || null;
        const normalizedProfileQrType = up && up.qrType === 'scanned' ? 'tng' : (up ? up.qrType : null);

        AppState.state.paymentMethod = selectedMethod;

        if (selectedMethod === 'duitnow' || selectedMethod === 'tng') {
            AppState.state.paymentDetails = (up && normalizedProfileQrType === selectedMethod && up.qrValue) ? up.qrValue : '';
        } else if (selectedMethod === 'custom') {
            AppState.state.paymentDetails = 'Pay via uploaded custom QR code';
        } else if (selectedMethod === 'bank') {
            AppState.state.paymentDetails = '';
            if (up && up.bankName && up.accountNumber) {
                AppState.state.bankName = up.bankName;
                AppState.state.bankAccount = up.accountNumber;
            }
        } else {
            AppState.state.paymentDetails = '';
        }

        Utils.storageSet('default_payment_method', AppState.state.paymentMethod);
        Utils.storageSet('default_payment_details', AppState.state.paymentDetails);
        Utils.storageSet('default_bank_name', AppState.state.bankName);
        Utils.storageSet('default_bank_account', AppState.state.bankAccount);

        AppUI.elements.paymentDetails.value = AppState.state.paymentDetails;
        AppUI.elements.bankName.value = AppState.state.bankName;
        AppUI.elements.bankAccount.value = AppState.state.bankAccount;
        AppUI.updatePaymentFieldsVisibility();
    });

    AppUI.elements.paymentDetails.addEventListener('input', () => {
        AppState.state.paymentDetails = AppUI.elements.paymentDetails.value.trim();
        Utils.storageSet('default_payment_details', AppState.state.paymentDetails);
    });

    AppUI.elements.bankName.addEventListener('input', () => {
        AppState.state.bankName = AppUI.elements.bankName.value.trim();
        Utils.storageSet('default_bank_name', AppState.state.bankName);
    });

    AppUI.elements.bankAccount.addEventListener('input', () => {
        AppState.state.bankAccount = AppUI.elements.bankAccount.value.trim();
        Utils.storageSet('default_bank_account', AppState.state.bankAccount);
    });

    AppUI.elements.addPersonBtn.addEventListener('click', () => {
        const nextNum = AppState.state.people.length + 1;
        AppState.state.people.push({
            id: `p_${Date.now()}_${nextNum}`,
            name: `Person ${nextNum}`
        });
        AppUI.renderPeopleList(AppState.state);
    });

    // Autocomplete Lookup & Input Handling
    const searchUsers = async (query, pid) => {
        const suggestionsDiv = document.getElementById(`suggestions_${pid}`);
        if (!suggestionsDiv) return;
        
        if (!query || query.length < 1) {
            suggestionsDiv.innerHTML = '';
            suggestionsDiv.style.display = 'none';
            return;
        }

        try {
            const res = await fetch(`api/search_users.php?q=${encodeURIComponent(query)}`);
            const results = await res.json();
            
            if (results && results.length > 0) {
                suggestionsDiv.innerHTML = results.map(u => `
                    <div class="autocomplete-suggestion-item" data-user-id="${u.id}" data-username="${Utils.escapeHtml(u.username)}" data-display-name="${Utils.escapeHtml(u.display_name)}">
                        <div class="autocomplete-avatar">${Utils.escapeHtml(u.display_name.substring(0, 1).toUpperCase())}</div>
                        <div class="autocomplete-info">
                            <span class="autocomplete-display-name">${Utils.escapeHtml(u.display_name)}</span>
                            <span class="autocomplete-username">@${Utils.escapeHtml(u.username)}</span>
                        </div>
                    </div>
                `).join('');
                suggestionsDiv.style.display = 'block';
            } else {
                suggestionsDiv.innerHTML = '';
                suggestionsDiv.style.display = 'none';
            }
        } catch (err) {
            console.error("Autocomplete search error:", err);
        }
    };

    const debounce = (func, delay) => {
        let timeout;
        return (...args) => {
            clearTimeout(timeout);
            timeout = setTimeout(() => func(...args), delay);
        };
    };
    const debouncedSearch = debounce(searchUsers, 250);

    AppUI.elements.peopleList.addEventListener('input', (e) => {
        if (e.target.classList.contains('person-name-input')) {
            const pid = e.target.dataset.id;
            const targetVal = e.target.value;
            const person = AppState.state.people.find(p => p.id === pid);
            if (person) {
                person.name = targetVal;
                if (person.userId) {
                    person.userId = null;
                    person.username = null;
                    e.target.classList.remove('has-badge');
                    const badge = e.target.parentElement.querySelector('.user-badge');
                    if (badge) badge.remove();
                }
            }
            debouncedSearch(targetVal.trim(), pid);
        }
    });

    AppUI.elements.peopleList.addEventListener('click', (e) => {
        const deleteBtn = e.target.closest('.delete-person-btn');
        if (deleteBtn) {
            const pid = deleteBtn.dataset.id;
            if (AppState.state.people.length <= 1) {
                Utils.showToast("At least one person is required to split the bill.", "warning");
                return;
            }

            AppState.state.people = AppState.state.people.filter(p => p.id !== pid);
            AppState.state.items.forEach(item => {
                item.assignedPeople = item.assignedPeople.filter(id => id !== pid);
                if (item.splits?.[pid]) delete item.splits[pid];
            });
            AppUI.renderPeopleList(AppState.state);
            return;
        }

        const suggestionItem = e.target.closest('.autocomplete-suggestion-item');
        if (suggestionItem) {
            const suggestionsDiv = suggestionItem.parentElement;
            const pid = suggestionsDiv.id.replace('suggestions_', '');
            const userId = suggestionItem.dataset.user-id || suggestionItem.getAttribute('data-user-id');
            const username = suggestionItem.dataset.username || suggestionItem.getAttribute('data-username');
            const displayName = suggestionItem.dataset.displayName || suggestionItem.getAttribute('data-display-name');

            const person = AppState.state.people.find(p => p.id === pid);
            if (person) {
                person.name = displayName;
                person.userId = parseInt(userId);
                person.username = username;
            }
            AppUI.renderPeopleList(AppState.state);
        }
    });

    // Default Group operations
    const saveDefaultGroupBtn = document.getElementById('saveDefaultGroupBtn');
    const loadDefaultGroupBtn = document.getElementById('loadDefaultGroupBtn');

    if (saveDefaultGroupBtn) {
        saveDefaultGroupBtn.addEventListener('click', () => {
            const peopleData = AppState.state.people.map(p => ({
                name: p.name,
                userId: p.userId || null,
                username: p.username || null
            }));
            Utils.storageSet('default_people_data', peopleData);
            Utils.showToast(`Saved ${peopleData.length} people as default group!`, "success");
        });
    }

    if (loadDefaultGroupBtn) {
        loadDefaultGroupBtn.addEventListener('click', () => {
            let cachedPeople = Utils.storageGet('default_people_data');
            if (!cachedPeople || cachedPeople.length === 0) {
                const cachedNames = Utils.storageGet('default_people_names');
                if (cachedNames && cachedNames.length > 0) {
                    cachedPeople = cachedNames.map(name => ({ name, userId: null, username: null }));
                }
            }

            if (!cachedPeople || cachedPeople.length === 0) {
                Utils.showToast("No saved group found. Save a group first!", "warning");
                return;
            }
            
            AppState.state.people = cachedPeople.map((p, idx) => ({
                id: `p_${Date.now()}_${idx}`,
                name: p.name,
                userId: p.userId || null,
                username: p.username || null
            }));

            // Reset assignment pointers
            AppState.state.items.forEach(item => {
                item.assignedPeople = [];
                item.splits = {};
            });

            AppUI.renderPeopleList(AppState.state);
            Utils.showToast(`Loaded default group with ${cachedPeople.length} people!`, "success");
        });
    }

    AppUI.elements.backToStep2.addEventListener('click', () => showStep(2));
    AppUI.elements.nextToStep4.addEventListener('click', () => showStep(3)); // Wait! step 3 navigates to step 4
    // Make sure click to step 4 triggers correctly
    AppUI.elements.nextToStep4.addEventListener('click', () => showStep(4));

    // Hide suggestions dropdown clicking offscreen
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.autocomplete-container')) {
            document.querySelectorAll('.autocomplete-suggestions').forEach(el => {
                el.innerHTML = '';
                el.style.display = 'none';
            });
        }
    });

    // ----------------------------------------------------
    // STEP 4: EVENT BINDINGS (WITH EVENT DELEGATION)
    // ----------------------------------------------------
    AppUI.elements.assignItemScroller.addEventListener('click', (e) => {
        const allBtn = e.target.closest('.assign-all-btn');
        if (allBtn) {
            const itemId = allBtn.dataset.id;
            const item = AppState.state.items.find(i => i.id === itemId);
            if (!item) return;

            const allSelected = AppState.state.people.length > 0 && item.assignedPeople.length === AppState.state.people.length;
            if (allSelected) {
                item.assignedPeople = [];
                item.splits = {};
            } else {
                item.assignedPeople = AppState.state.people.map(p => p.id);
                if (!item.splits) item.splits = {};
                AppState.state.people.forEach(p => {
                    if (item.splitMode === 'percent') {
                        item.splits[p.id] = (100 / AppState.state.people.length).toFixed(1);
                    } else if (item.splitMode === 'share') {
                        item.splits[p.id] = 1;
                    }
                });
            }
            AppUI.renderAssignmentUI(AppState.state);
            return;
        }

        const chip = e.target.closest('.person-chip');
        if (chip) {
            const itemId = chip.dataset.itemId;
            const personId = chip.dataset.personId;
            const item = AppState.state.items.find(i => i.id === itemId);
            if (!item) return;

            const index = item.assignedPeople.indexOf(personId);
            if (index > -1) {
                item.assignedPeople.splice(index, 1);
                if (item.splits?.[personId]) delete item.splits[personId];
            } else {
                item.assignedPeople.push(personId);
                if (!item.splits) item.splits = {};
                if (item.splitMode === 'percent') {
                    item.splits[personId] = 0;
                } else if (item.splitMode === 'share') {
                    item.splits[personId] = 1;
                }
            }

            if (item.splitMode === 'percent' && item.assignedPeople.length > 0) {
                const equalPct = (100 / item.assignedPeople.length).toFixed(1);
                item.assignedPeople.forEach(pid => {
                    item.splits[pid] = equalPct;
                });
            }
            AppUI.renderAssignmentUI(AppState.state);
            return;
        }

        const modeBtn = e.target.closest('.split-mode-btn');
        if (modeBtn) {
            const itemId = modeBtn.dataset.id;
            const mode = modeBtn.dataset.mode;
            const item = AppState.state.items.find(i => i.id === itemId);
            if (!item) return;

            item.splitMode = mode;
            item.splits = {};
            if (mode === 'percent' && item.assignedPeople.length > 0) {
                const equalPct = (100 / item.assignedPeople.length).toFixed(1);
                item.assignedPeople.forEach(pid => {
                    item.splits[pid] = equalPct;
                });
            } else if (mode === 'share') {
                item.assignedPeople.forEach(pid => {
                    item.splits[pid] = 1;
                });
            }
            AppUI.renderAssignmentUI(AppState.state);
        }
    });

    AppUI.elements.assignItemScroller.addEventListener('change', (e) => {
        const input = e.target.closest('.custom-split-input');
        if (input) {
            const itemId = input.dataset.itemId;
            const personId = input.dataset.personId;
            const val = parseFloat(e.target.value) || 0;
            const item = AppState.state.items.find(i => i.id === itemId);
            if (item && item.splits) {
                item.splits[personId] = val;
            }
            AppUI.renderAssignmentUI(AppState.state);
        }
    });

    AppUI.elements.backToStep3.addEventListener('click', () => showStep(3));
    AppUI.elements.nextToStep5.addEventListener('click', () => {
        const unassigned = AppState.state.items.filter(i => i.assignedPeople.length === 0);
        if (unassigned.length > 0) {
            const proceed = confirm(`You have ${unassigned.length} unassigned item(s). They will not be counted in anyone's share. Do you want to proceed?`);
            if (!proceed) return;
        }
        showStep(5);
    });

    // ----------------------------------------------------
    // STEP 5: EVENT BINDINGS
    // ----------------------------------------------------
    [AppUI.elements.taxDistribution, AppUI.elements.discountDistribution].forEach(select => {
        select.addEventListener('change', () => {
            AppState.state.taxDistribution = AppUI.elements.taxDistribution.value;
            AppState.state.discountDistribution = AppUI.elements.discountDistribution.value;
            triggerCalculations();
        });
    });

    AppUI.elements.backToStep4.addEventListener('click', () => showStep(4));
    AppUI.elements.nextToStep6.addEventListener('click', () => {
        if (AppState.state.isForeign) {
            fetchExchangeRate();
        } else {
            showStep(6);
        }
    });

    // ----------------------------------------------------
    // CURRENCY CONVERSION API
    // ----------------------------------------------------
    const fetchExchangeRate = async () => {
        AppUI.showLoader(`Fetching exchange rates...`);
        const cachedRates = Utils.storageGet('currency_rates_cache');
        const now = Date.now();
        
        if (cachedRates && cachedRates.rates && (now - cachedRates.timestamp < 24 * 60 * 60 * 1000)) {
            applyFetchedRates(cachedRates.rates);
            AppUI.hideLoader();
            showStep(6);
            return;
        }

        try {
            const res = await fetch(`api/currency.php?base=MYR`);
            const data = await res.json();
            
            if (data.success && data.rates) {
                Utils.storageSet('currency_rates_cache', {
                    timestamp: now,
                    rates: data.rates
                });
                applyFetchedRates(data.rates);
                AppUI.elements.rateLastUpdated.textContent = `Rates: ${data.provider.toUpperCase()} (${new Date().toLocaleDateString()})`;
            } else {
                throw new Error(data.error || "Failed to parse API rates.");
            }
        } catch (e) {
            console.error("Exchange API failed, using static fallbacks", e);
            const staticRates = {
                'MYR': 1.00, 'USD': 0.21, 'SGD': 0.28, 'EUR': 0.19,
                'GBP': 0.165, 'JPY': 33.50, 'THB': 7.70, 'IDR': 3450.00, 'AUD': 0.32
            };
            applyFetchedRates(staticRates);
            AppUI.elements.rateLastUpdated.textContent = `Rates: Offline Static Fallback`;
        }

        AppUI.hideLoader();
        showStep(6);
    };

    const applyFetchedRates = (rates) => {
        const curCode = AppState.state.currency.toUpperCase();
        if (curCode === 'MYR') {
            AppState.state.exchangeRate = 1.000000;
        } else if (rates[curCode]) {
            AppState.state.exchangeRate = 1 / rates[curCode];
        } else {
            const defaults = { 'USD': 4.70, 'SGD': 3.50, 'EUR': 5.10, 'GBP': 6.00, 'JPY': 0.03, 'AUD': 3.10, 'THB': 0.13, 'IDR': 0.0003 };
            AppState.state.exchangeRate = defaults[curCode] || 1.00;
        }

        AppUI.elements.myrConversionWidget.style.display = 'block';
        document.querySelectorAll('.lbl-original-cur').forEach(lbl => {
            lbl.textContent = curCode;
        });
        AppUI.elements.manualExchangeRate.value = AppState.state.exchangeRate.toFixed(6);
        updateMyrTotalOutputs();
    };

    let isUpdatingMyrTotal = false;
    const updateMyrTotalOutputs = () => {
        if (isUpdatingMyrTotal) return;
        isUpdatingMyrTotal = true;
        try {
            if (AppUI.elements.manualExchangeRate) {
                AppState.state.exchangeRate = parseFloat(AppUI.elements.manualExchangeRate.value) || 1.00;
            }
            AppState.calculationResults = Calculator.calculateSplit(AppState.state);
            AppUI.elements.myrGrandTotal.textContent = `RM ${AppState.calculationResults.myrGrandTotal.toFixed(2)}`;
            AppUI.renderFinalSummary(AppState.state, AppState.calculationResults);
        } finally {
            isUpdatingMyrTotal = false;
        }
    };

    AppUI.elements.manualExchangeRate.addEventListener('input', updateMyrTotalOutputs);

    // ----------------------------------------------------
    // STEP 6: EVENT BINDINGS (WITH EVENT DELEGATION)
    // ----------------------------------------------------
    AppUI.elements.peopleSummaryContainer.addEventListener('click', (e) => {
        const qrBtn = e.target.closest('.show-qr-btn');
        if (qrBtn) {
            const pid = qrBtn.dataset.personId;
            AppUI.openQrModal(pid, AppState.state, AppState.calculationResults);
            return;
        }

        const downloadBtn = e.target.closest('.download-card-btn');
        if (downloadBtn) {
            const pid = downloadBtn.dataset.personId;
            AppUI.downloadBillCard(pid, AppState.state, AppState.calculationResults);
        }
    });

    // Creator payment action delegation
    AppUI.elements.creatorPaymentInfoContainer.addEventListener('click', (e) => {
        const copyBtn = e.target.closest('#copyCreatorBankBtn');
        if (copyBtn) {
            const val = document.getElementById('creatorBankAccNo');
            if (val) {
                navigator.clipboard.writeText(val.textContent.trim()).then(() => {
                    Utils.showToast("Bank account number copied!", "success");
                }).catch(() => {
                    Utils.showToast("Failed to copy.", "error");
                });
            }
            return;
        }

        const payQrBtn = e.target.closest('#payCreatorQrBtn');
        if (payQrBtn) {
            const pid = payQrBtn.dataset.personId;
            AppUI.openQrModal(pid, AppState.state, AppState.calculationResults);
        }
    });

    AppUI.elements.closeQrModalBtn.addEventListener('click', () => {
        AppUI.elements.qrModal.classList.remove('active');
    });

    AppUI.elements.qrModal.addEventListener('click', (e) => {
        if (e.target === AppUI.elements.qrModal) {
            AppUI.elements.qrModal.classList.remove('active');
        }
    });

    AppUI.elements.copySummaryBtn.addEventListener('click', async () => {
        const text = Utils.generateSummaryText(AppState.state, AppState.calculationResults);
        const success = await Utils.copyToClipboard(text);
        if (success) {
            Utils.showToast("Summary copied to clipboard!", "success");
        } else {
            Utils.showToast("Failed to copy. Please manually copy.", "error");
        }
    });

    AppUI.elements.whatsappShareBtn.addEventListener('click', () => {
        const text = Utils.generateSummaryText(AppState.state, AppState.calculationResults);
        Utils.shareToWhatsApp(text);
    });

    AppUI.elements.downloadCsvBtn.addEventListener('click', () => {
        const rows = [
            ['Personal Bill Splitter Summary'],
            [`Store: ${AppState.state.merchant || 'N/A'}`],
            [`Date: ${AppState.state.date || 'N/A'}`],
            [`Currency: ${AppState.state.currency}`],
            [],
            ['Person', 'Item / Breakdown', 'Share Amount (Original)', 'MYR Equivalent']
        ];

        const unscaleShare = (v) => v / 10000;
        AppState.calculationResults.people.forEach(person => {
            rows.push([person.name, 'Total Payable', person.total.toFixed(2), person.totalMYR.toFixed(2)]);
            person.items.forEach(item => {
                rows.push(['', `${item.name} (x${item.qty})`, item.shareTotal.toFixed(2), '']);
            });

            if (person.taxShare > 0) rows.push(['', 'Tax portion', unscaleShare(person.taxShare).toFixed(2), '']);
            if (person.serviceShare > 0) rows.push(['', 'Service charge portion', unscaleShare(person.serviceShare).toFixed(2), '']);
            if (person.discountShare > 0) rows.push(['', 'Discount portion', `-${unscaleShare(person.discountShare).toFixed(2)}`, '']);
            if (person.roundingShare !== 0) rows.push(['', 'Rounding portion', unscaleShare(person.roundingShare).toFixed(2), '']);
            if (person.roundingAdjustment !== 0) rows.push(['', 'Rounding Correction', unscaleShare(person.roundingAdjustment).toFixed(2), '']);
            rows.push([]);
        });

        rows.push(['Bill Grand Total', '', AppState.state.grandTotal.toFixed(2), AppState.calculationResults.myrGrandTotal.toFixed(2)]);

        const cleanMerchant = (AppState.state.merchant || 'bill').toLowerCase().replace(/[^a-z0-9]/g, '_');
        Utils.downloadCSV(`split_summary_${cleanMerchant}.csv`, rows);
    });

    AppUI.elements.printBillBtn.addEventListener('click', () => window.print());

    AppUI.elements.restartBtn.addEventListener('click', () => {
        if (confirm("Are you sure you want to discard this bill and start a new one?")) {
            AppState.reset();
            AppUI.elements.receiptFileInput.value = '';
            AppUI.elements.brightnessSlider.value = 100;
            AppUI.elements.contrastSlider.value = 100;
            AppUI.elements.preprocessCard.style.display = 'none';
            AppUI.elements.myrConversionWidget.style.display = 'none';
            AppUI.elements.uploadDropzone.style.display = 'flex';
            showStep(1);
        }
    });

    if (AppUI.elements.clearHistoryBtn) {
        AppUI.elements.clearHistoryBtn.addEventListener('click', () => {
            if (confirm("Are you sure you want to clear all bill history?")) {
                Utils.storageRemove('bill_history');
                renderRecentBillsList();
                Utils.showToast("History cleared!", "success");
            }
        });
    }

    // ----------------------------------------------------
    // INITIAL LOAD INTEGRATION (DB BILL LOAD)
    // ----------------------------------------------------
    const urlParams = new URLSearchParams(window.location.search);
    const billIdParam = urlParams.get('bill_id') || urlParams.get('id');
    const addPartParam = urlParams.get('add_participant');
    
    if (billIdParam) {
        AppUI.showLoader('Loading bill split from database...');
        fetch(`api/fetch_bill.php?id=${encodeURIComponent(billIdParam)}`)
            .then(res => res.json())
            .then(data => {
                AppUI.hideLoader();
                if (data.success && data.bill) {
                    AppState.hydrateFromData(data.bill, data.creatorProfile || null);
                    showStep(6);
                    Utils.showToast("Bill loaded from database!", "success");
                } else {
                    Utils.showToast("Failed to load bill: " + (data.error || 'Unknown error'), "error");
                    showStep(1);
                }
            })
            .catch(err => {
                AppUI.hideLoader();
                console.error("Error loading bill:", err);
                Utils.showToast("Failed to connect to server.", "error");
                showStep(1);
            });
    } else {
        showStep(1);
        if (addPartParam) {
            fetch(`api/search_users.php?exact=1&q=${encodeURIComponent(addPartParam)}`)
                .then(res => res.json())
                .then(data => {
                    if (data && data.length > 0) {
                        const u = data[0];
                        if (!AppState.state.people.some(p => p.username === u.username)) {
                            AppState.state.people.push({
                                id: `p_${Date.now()}_1`,
                                name: u.display_name || u.username,
                                userId: u.id,
                                username: u.username
                            });
                            AppUI.renderPeopleList(AppState.state);
                            Utils.showToast(`Pre-added @${u.username} to your split!`, "success");
                        }
                    }
                })
                .catch(err => console.warn("Failed to pre-add participant:", err));
        }
    }
});
