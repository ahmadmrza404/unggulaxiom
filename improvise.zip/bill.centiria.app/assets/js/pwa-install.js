(() => {
    const STORAGE_KEY = 'pwa_install_prompt_dismissed_until';
    const ONE_WEEK_MS = 7 * 24 * 60 * 60 * 1000;
    let deferredInstallPrompt = null;
    let promptRendered = false;

    const isStandalone = () => {
        return window.matchMedia('(display-mode: standalone)').matches ||
            window.navigator.standalone === true ||
            document.referrer.startsWith('android-app://');
    };

    const isIos = () => /iphone|ipad|ipod/i.test(window.navigator.userAgent);
    const isAndroid = () => /android/i.test(window.navigator.userAgent);
    const isMobile = () => isIos() || isAndroid();

    const shouldSuppressPrompt = () => {
        if (isStandalone() || !isMobile()) return true;

        const dismissedUntil = parseInt(localStorage.getItem(STORAGE_KEY) || '0', 10);
        return Number.isFinite(dismissedUntil) && Date.now() < dismissedUntil;
    };

    const dismissPrompt = (overlay) => {
        localStorage.setItem(STORAGE_KEY, String(Date.now() + ONE_WEEK_MS));
        overlay.classList.remove('active');
        setTimeout(() => overlay.remove(), 200);
    };

    const buildPrompt = (options = {}) => {
        const force = options.force === true;
        if (promptRendered || (!force && shouldSuppressPrompt())) return;
        if (isStandalone() || !isMobile()) return;
        promptRendered = true;

        const overlay = document.createElement('div');
        overlay.className = 'pwa-install-overlay';
        overlay.innerHTML = `
            <div class="pwa-install-card" role="dialog" aria-modal="true" aria-labelledby="pwaInstallTitle">
                <button type="button" class="pwa-install-close" aria-label="Close install prompt">&times;</button>
                <div class="pwa-install-icon">📲</div>
                <h3 id="pwaInstallTitle">Install BillSplitter</h3>
                <p class="pwa-install-copy">Add this app to your home screen for faster access when splitting bills later.</p>
                <div class="pwa-install-ios-steps" style="display:none;">
                    <div>1. Tap the <strong>Share</strong> button in Safari.</div>
                    <div>2. Choose <strong>Add to Home Screen</strong>.</div>
                    <div>3. Tap <strong>Add</strong>.</div>
                </div>
                <button type="button" class="btn btn-primary pwa-install-action">Add to Home Screen</button>
                <button type="button" class="btn btn-secondary pwa-install-later">Maybe Later</button>
            </div>
        `;

        document.body.appendChild(overlay);

        const closeBtn = overlay.querySelector('.pwa-install-close');
        const laterBtn = overlay.querySelector('.pwa-install-later');
        const actionBtn = overlay.querySelector('.pwa-install-action');
        const iosSteps = overlay.querySelector('.pwa-install-ios-steps');

        if (isIos()) {
            iosSteps.style.display = 'flex';
            actionBtn.textContent = 'Show iPhone/iPad Steps';
        } else if (!deferredInstallPrompt) {
            actionBtn.textContent = 'Install Instructions';
        }

        closeBtn.addEventListener('click', () => dismissPrompt(overlay));
        laterBtn.addEventListener('click', () => dismissPrompt(overlay));
        overlay.addEventListener('click', (event) => {
            if (event.target === overlay) dismissPrompt(overlay);
        });

        actionBtn.addEventListener('click', async () => {
            if (deferredInstallPrompt) {
                deferredInstallPrompt.prompt();
                await deferredInstallPrompt.userChoice.catch(() => null);
                deferredInstallPrompt = null;
                dismissPrompt(overlay);
                return;
            }

            if (isIos()) {
                iosSteps.style.display = 'flex';
                return;
            }

            actionBtn.textContent = 'Use browser menu → Add to Home screen';
        });

        requestAnimationFrame(() => overlay.classList.add('active'));
    };

    window.addEventListener('beforeinstallprompt', (event) => {
        event.preventDefault();
        deferredInstallPrompt = event;
        setTimeout(buildPrompt, 800);
    });

    window.addEventListener('appinstalled', () => {
        localStorage.setItem(STORAGE_KEY, String(Date.now() + 365 * 24 * 60 * 60 * 1000));
        document.querySelector('.pwa-install-overlay')?.remove();
    });

    window.BillSplitterInstallPrompt = {
        show: () => {
            localStorage.removeItem(STORAGE_KEY);
            buildPrompt({ force: true });
        }
    };
})();
