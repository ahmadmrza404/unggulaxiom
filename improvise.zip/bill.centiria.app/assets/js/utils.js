/**
 * Personal Bill Splitter Utilities
 */

const Utils = {
    /**
     * Format an amount according to currency code rules.
     * Handles zero-decimal currencies (like JPY) and defaults to 2 decimals.
     *
     * @param {number} amount
     * @param {string} currencyCode
     * @returns {string}
     */
    formatCurrency(amount, currencyCode = 'MYR') {
        const code = currencyCode.toUpperCase();
        
        // Zero-decimal currencies
        const zeroDecimalCurrencies = ['JPY', 'KRW', 'CLP', 'VND', 'PYG'];
        const decimalPlaces = zeroDecimalCurrencies.includes(code) ? 0 : 2;
        
        // Define currency symbols for clean display
        const symbols = {
            'MYR': 'RM',
            'USD': '$',
            'SGD': 'S$',
            'EUR': '€',
            'GBP': '£',
            'JPY': '¥',
            'AUD': 'A$',
            'THB': '฿',
            'IDR': 'Rp'
        };
        
        const symbol = symbols[code] || code;
        
        // Round to correct decimals to avoid presentation floating errors
        const roundedAmount = Number(amount).toFixed(decimalPlaces);
        
        // Format with commas
        const parts = roundedAmount.split('.');
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        
        return `${symbol} ${parts.join('.')}`;
    },

    /**
     * Format a date string into readable format.
     */
    formatDate(dateStr) {
        if (!dateStr) return '';
        try {
            const date = new Date(dateStr);
            if (isNaN(date.getTime())) return dateStr;
            return date.toLocaleDateString('en-MY', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        } catch (e) {
            return dateStr;
        }
    },

    /**
     * Write text to clipboard.
     *
     * @param {string} text
     * @returns {Promise<boolean>}
     */
    async copyToClipboard(text) {
        if (navigator.clipboard && window.isSecureContext) {
            try {
                await navigator.clipboard.writeText(text);
                return true;
            } catch (e) {
                console.error("Clipboard copy failed: ", e);
            }
        }
        
        // Fallback for non-secure contexts or older browsers
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";  // Avoid scrolling to bottom
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            const successful = document.execCommand('copy');
            document.body.removeChild(textArea);
            return successful;
        } catch (err) {
            document.body.removeChild(textArea);
            console.error("Fallback clipboard copy failed: ", err);
            return false;
        }
    },

    /**
     * Safe localStorage wrapper.
     */
    storageSet(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            console.error("Error writing to localStorage: ", e);
        }
    },

    storageGet(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (e) {
            console.error("Error reading from localStorage: ", e);
            return defaultValue;
        }
    },

    storageRemove(key) {
        try {
            localStorage.removeItem(key);
        } catch (e) {
            console.error("Error removing from localStorage: ", e);
        }
    },

    /**
     * Trigger client-side CSV download.
     *
     * @param {string} filename
     * @param {Array<Array<string>>} rows
     */
    downloadCSV(filename, rows) {
        const csvContent = "data:text/csv;charset=utf-8," 
            + rows.map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(",")).join("\n");
            
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    },

    /**
     * Generates a clean text summary.
     */
    generateSummaryText(state, results) {
        const { merchant, date, currency, exchangeRate, isForeign, convertedGrandTotal } = state;
        const currencyCode = currency.toUpperCase();
        
        let text = `🧾 *BILL SPLIT SUMMARY*\n`;
        if (merchant) text += `📍 *Store:* ${merchant}\n`;
        if (date) text += `📅 *Date:* ${this.formatDate(date)}\n`;
        text += `-----------------------------------------\n\n`;
        
        results.people.forEach(person => {
            text += `👤 *${person.name}* pays:\n`;
            
            // List individual items
            person.items.forEach(item => {
                const qtyText = item.qty > 1 ? `x${item.qty} ` : '';
                text += `  • ${qtyText}${item.name} (${this.formatCurrency(item.shareTotal, currencyCode)})\n`;
            });
            
            // Extras Breakdown
            if (person.taxShare > 0 || person.serviceShare > 0 || person.discountShare > 0 || person.roundingShare !== 0) {
                const breakdowns = [];
                if (person.discountShare > 0) breakdowns.push(`Disc: -${this.formatCurrency(person.discountShare / 10000, currencyCode)}`);
                if (person.serviceShare > 0) breakdowns.push(`Svc: +${this.formatCurrency(person.serviceShare / 10000, currencyCode)}`);
                if (person.taxShare > 0) breakdowns.push(`Tax: +${this.formatCurrency(person.taxShare / 10000, currencyCode)}`);
                if (person.roundingShare !== 0) {
                    const roundedDir = person.roundingShare > 0 ? '+' : '';
                    breakdowns.push(`Rnd: ${roundedDir}${this.formatCurrency(person.roundingShare / 10000, currencyCode)}`);
                }
                text += `    [${breakdowns.join(' | ')}]\n`;
            }
            
            // Total
            text += `  *Subtotal:* ${this.formatCurrency(person.total, currencyCode)}`;
            if (isForeign) {
                text += ` / *RM ${person.totalMYR.toFixed(2)}*`;
            }
            text += `\n\n`;
        });
        
        text += `-----------------------------------------\n`;
        text += `💰 *Grand Total:* ${this.formatCurrency(state.grandTotal, currencyCode)}\n`;
        if (isForeign) {
            text += `💱 *Exchange Rate:* 1 ${currencyCode} = ${exchangeRate.toFixed(6)} MYR\n`;
            text += `🇲🇾 *Converted Total:* RM ${convertedGrandTotal.toFixed(2)}\n`;
        }
        
        return text;
    },

    /**
     * Open WhatsApp with a prefilled message.
     */
    shareToWhatsApp(text) {
        const encodedText = encodeURIComponent(text);
        const url = `https://api.whatsapp.com/send?text=${encodedText}`;
        window.open(url, '_blank');
    },

    /**
     * Show a custom animated toast notification.
     *
     * @param {string} message
     * @param {string} type - 'success', 'error', 'warning', 'info'
     */
    showToast(message, type = 'info') {
        let container = document.getElementById('toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container';
            container.className = 'toast-container';
            document.body.appendChild(container);
        }
        
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        let iconHtml = '';
        if (type === 'success') {
            iconHtml = '<span class="toast-icon">✓</span>';
        } else if (type === 'error') {
            iconHtml = '<span class="toast-icon">✗</span>';
        } else if (type === 'warning') {
            iconHtml = '<span class="toast-icon">⚠</span>';
        } else {
            iconHtml = '<span class="toast-icon">ℹ</span>';
        }
        
        toast.innerHTML = `
            ${iconHtml}
            <span class="toast-message">${message}</span>
        `;
        
        container.appendChild(toast);
        
        // Trigger animation
        requestAnimationFrame(() => {
            toast.classList.add('show');
        });
        
        // Remove after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            // Wait for transition to complete before removing from DOM
            const removeToast = () => {
                toast.remove();
                if (container.children.length === 0) {
                    container.remove();
                }
            };
            toast.addEventListener('transitionend', removeToast, { once: true });
            // Fallback safety if transitionend is not fired
            setTimeout(removeToast, 400);
        }, 3000);
    },

    /**
     * Generate a unique ID for bills
     */
    generateId() {
        return 'bill_' + Math.random().toString(36).substring(2, 9) + '_' + Date.now();
    },

    /**
     * Escape HTML special characters to prevent XSS.
     *
     * @param {string} str
     * @returns {string}
     */
    escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }
};
