/**
 * Personal Bill Splitter - App UI (View)
 */

const AppUI = {
    elements: {},

    init() {
        // Cache all DOM element selectors
        this.elements = {
            loadingOverlay: document.getElementById('loadingOverlay'),
            loadingText: document.getElementById('loadingText'),
            themeToggle: document.getElementById('themeToggle'),
            themeSunIcon: document.getElementById('themeSunIcon'),
            themeMoonIcon: document.getElementById('themeMoonIcon'),
            stepperProgressFill: document.getElementById('stepperProgressFill'),

            // Step 1
            uploadDropzone: document.getElementById('uploadDropzone'),
            receiptFileInput: document.getElementById('receiptFileInput'),
            preprocessCard: document.getElementById('preprocessCard'),
            preprocessImage: document.getElementById('preprocessImage'),
            rotateLeftBtn: document.getElementById('rotateLeftBtn'),
            rotateRightBtn: document.getElementById('rotateRightBtn'),
            brightnessSlider: document.getElementById('brightnessSlider'),
            contrastSlider: document.getElementById('contrastSlider'),
            ocrProcessBtn: document.getElementById('ocrProcessBtn'),
            skipOcrBtn: document.getElementById('skipOcrBtn'),
            loadSampleMYRBtn: document.getElementById('loadSampleMYRBtn'),
            loadSampleSGDBtn: document.getElementById('loadSampleSGDBtn'),

            // Step 2
            billMerchant: document.getElementById('billMerchant'),
            billDate: document.getElementById('billDate'),
            billCurrency: document.getElementById('billCurrency'),
            billItemsBody: document.getElementById('billItemsBody'),
            addItemRowBtn: document.getElementById('addItemRowBtn'),
            billSubtotal: document.getElementById('billSubtotal'),
            billDiscount: document.getElementById('billDiscount'),
            billServiceCharge: document.getElementById('billServiceCharge'),
            billTax: document.getElementById('billTax'),
            billRounding: document.getElementById('billRounding'),
            billGrandTotal: document.getElementById('billGrandTotal'),
            backToStep1: document.getElementById('backToStep1'),
            nextToStep3: document.getElementById('nextToStep3'),
            toggleInspectorBtn: document.getElementById('toggleInspectorBtn'),
            receiptInspector: document.getElementById('receiptInspector'),
            closeInspectorBtn: document.getElementById('closeInspectorBtn'),
            inspectorImageContainer: document.getElementById('inspectorImageContainer'),

            // Step 3
            peopleList: document.getElementById('peopleList'),
            addPersonBtn: document.getElementById('addPersonBtn'),
            backToStep2: document.getElementById('backToStep2'),
            nextToStep4: document.getElementById('nextToStep4'),
            paymentMethod: document.getElementById('paymentMethod'),
            paymentDetailGroup: document.getElementById('paymentDetailGroup'),
            paymentDetailLabel: document.getElementById('paymentDetailLabel'),
            paymentDetails: document.getElementById('paymentDetails'),
            bankDetailsGroup: document.getElementById('bankDetailsGroup'),
            bankName: document.getElementById('bankName'),
            bankAccount: document.getElementById('bankAccount'),

            // QR Modal
            qrModal: document.getElementById('qrModal'),
            qrModalTitle: document.getElementById('qrModalTitle'),
            qrModalSubtitle: document.getElementById('qrModalSubtitle'),
            qrCodeContainer: document.getElementById('qrCodeContainer'),
            qrModalDetails: document.getElementById('qrModalDetails'),
            closeQrModalBtn: document.getElementById('closeQrModalBtn'),

            // Travel Modal
            addTravelExpenseBtn: document.getElementById('addTravelExpenseBtn'),
            travelExpenseModal: document.getElementById('travelExpenseModal'),
            closeTravelModalBtn: document.getElementById('closeTravelModalBtn'),
            addTravelExpenseSubmitBtn: document.getElementById('addTravelExpenseSubmitBtn'),
            gasDistance: document.getElementById('gasDistance'),
            gasConsumption: document.getElementById('gasConsumption'),
            gasFuelPrice: document.getElementById('gasFuelPrice'),
            gasEstimateText: document.getElementById('gasEstimateText'),
            hotelRate: document.getElementById('hotelRate'),
            hotelNights: document.getElementById('hotelNights'),
            hotelRooms: document.getElementById('hotelRooms'),
            hotelName: document.getElementById('hotelName'),
            activityName: document.getElementById('activityName'),
            activityPrice: document.getElementById('activityPrice'),
            activityQty: document.getElementById('activityQty'),

            // Step 4
            assignItemScroller: document.getElementById('assignItemScroller'),
            backToStep3: document.getElementById('backToStep3'),
            nextToStep5: document.getElementById('nextToStep5'),

            // Step 5
            taxDistribution: document.getElementById('taxDistribution'),
            discountDistribution: document.getElementById('discountDistribution'),
            validationWarnings: document.getElementById('validationWarnings'),
            runningTotalsList: document.getElementById('runningTotalsList'),
            backToStep4: document.getElementById('backToStep4'),
            nextToStep6: document.getElementById('nextToStep6'),

            // Step 6
            summaryMerchant: document.getElementById('summaryMerchant'),
            summaryDate: document.getElementById('summaryDate'),
            summaryExchangeRateInfo: document.getElementById('summaryExchangeRateInfo'),
            peopleSummaryContainer: document.getElementById('peopleSummaryContainer'),
            billSummaryTotals: document.getElementById('billSummaryTotals'),
            myrConversionWidget: document.getElementById('myrConversionWidget'),
            rateLastUpdated: document.getElementById('rateLastUpdated'),
            manualExchangeRate: document.getElementById('manualExchangeRate'),
            myrGrandTotal: document.getElementById('myrGrandTotal'),
            copySummaryBtn: document.getElementById('copySummaryBtn'),
            whatsappShareBtn: document.getElementById('whatsappShareBtn'),
            downloadCsvBtn: document.getElementById('downloadCsvBtn'),
            printBillBtn: document.getElementById('printBillBtn'),
            restartBtn: document.getElementById('restartBtn'),
            creatorPaymentInfoContainer: document.getElementById('creatorPaymentInfoContainer'),
            recentBillsContainer: document.getElementById('recentBillsContainer'),
            recentBillsList: document.getElementById('recentBillsList'),
            clearHistoryBtn: document.getElementById('clearHistoryBtn')
        };
        this.initTheme();
    },

    // Loader utilities
    showLoader(text) {
        if (this.elements.loadingText && this.elements.loadingOverlay) {
            this.elements.loadingText.textContent = text || 'Loading...';
            this.elements.loadingOverlay.classList.add('active');
        }
    },

    hideLoader() {
        if (this.elements.loadingOverlay) {
            this.elements.loadingOverlay.classList.remove('active');
        }
    },

    // Theme Management
    initTheme() {
        const savedTheme = Utils.storageGet('theme', 'dark');
        document.documentElement.setAttribute('data-theme', savedTheme);
        this.updateThemeIcons(savedTheme);
    },

    updateThemeIcons(theme) {
        if (!this.elements.themeSunIcon || !this.elements.themeMoonIcon) return;
        if (theme === 'light') {
            this.elements.themeSunIcon.style.display = 'none';
            this.elements.themeMoonIcon.style.display = 'block';
        } else {
            this.elements.themeSunIcon.style.display = 'block';
            this.elements.themeMoonIcon.style.display = 'none';
        }
    },

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        Utils.storageSet('theme', newTheme);
        this.updateThemeIcons(newTheme);
    },

    // Stepper router
    showStep(stepNumber) {
        // Hide all wizard panels, show current
        document.querySelectorAll('.wizard-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        const activePanel = document.getElementById(`step${stepNumber}`);
        if (activePanel) activePanel.classList.add('active');

        // Update stepper step styles
        document.querySelectorAll('.step-item').forEach(item => {
            const stepVal = parseInt(item.getAttribute('data-step'));
            item.classList.remove('active', 'completed');
            if (stepVal === stepNumber) {
                item.classList.add('active');
            } else if (stepVal < stepNumber) {
                item.classList.add('completed');
            }
        });

        // Update progress bar width
        if (this.elements.stepperProgressFill) {
            const progressPct = ((stepNumber - 1) / 5) * 100;
            this.elements.stepperProgressFill.style.width = `${progressPct}%`;
        }

        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    },

    // Step 2: Items Table Rendering
    renderBillItemsTable(state) {
        const body = this.elements.billItemsBody;
        if (!body) return;

        body.innerHTML = '';
        if (state.items.length === 0) {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td colspan="4" style="text-align: center; color: var(--text-muted); padding: 2.5rem 0;">
                    <i data-lucide="receipt" style="width: 32px; height: 32px; margin: 0 auto 0.5rem; display: block; stroke-width: 1.5; color: var(--color-primary);"></i>
                    ${__('no_items')}
                </td>
            `;
            body.appendChild(tr);
            lucide.createIcons();
            this.updateBillTotalsDisplay(0, state);
            return;
        }

        let subtotal = 0;
        state.items.forEach((item, index) => {
            const tr = document.createElement('tr');
            const cat = item.category || 'food';
            tr.innerHTML = `
                <td class="col-qty">
                    <input type="number" value="${item.qty}" min="1" class="item-qty-input" data-index="${index}">
                </td>
                <td class="col-name">
                    <div style="display: flex; align-items: center; gap: 0.35rem; width: 100%;">
                        <select class="item-category-select" data-index="${index}" title="Category" style="padding: 0.15rem 0.25rem; font-size: 0.85rem; border-radius: 0.35rem; border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; flex-shrink: 0;">
                            <option value="food" ${cat === 'food' ? 'selected' : ''}>🍔</option>
                            <option value="lodging" ${cat === 'lodging' ? 'selected' : ''}>🏨</option>
                            <option value="transport" ${cat === 'transport' ? 'selected' : ''}>🚗</option>
                            <option value="activity" ${cat === 'activity' ? 'selected' : ''}>🎟️</option>
                            <option value="others" ${cat === 'others' ? 'selected' : ''}>📦</option>
                        </select>
                        <input type="text" value="${Utils.escapeHtml(item.name)}" placeholder="Item Description" class="item-name-input" data-index="${index}">
                    </div>
                </td>
                <td class="col-price">
                    <input type="number" value="${item.price.toFixed(2)}" step="0.01" class="item-price-input" data-index="${index}">
                </td>
                <td class="col-action">
                    <button class="btn btn-secondary btn-sm btn-icon delete-row-btn" data-index="${index}" style="color: var(--color-danger); border: none; background: none;">
                        <i data-lucide="trash-2" style="width: 16px; height: 16px;"></i>
                    </button>
                </td>
            `;
            body.appendChild(tr);
            subtotal += item.qty * item.price;
        });

        lucide.createIcons();
        this.updateBillTotalsDisplay(subtotal, state);
    },

    updateBillTotalsDisplay(subtotal, state) {
        if (this.elements.billSubtotal) this.elements.billSubtotal.textContent = subtotal.toFixed(2);
        if (this.elements.billDiscount) this.elements.billDiscount.value = state.discount.toFixed(2);
        if (this.elements.billServiceCharge) this.elements.billServiceCharge.value = state.serviceCharge.toFixed(2);
        if (this.elements.billTax) this.elements.billTax.value = state.tax.toFixed(2);
        if (this.elements.billRounding) this.elements.billRounding.value = state.rounding.toFixed(2);
        if (this.elements.billGrandTotal) this.elements.billGrandTotal.value = state.grandTotal.toFixed(2);
    },

    // Step 3: Render People list
    renderPeopleList(state) {
        const list = this.elements.peopleList;
        if (!list) return;

        list.innerHTML = '';
        state.people.forEach((person) => {
            const div = document.createElement('div');
            div.className = 'person-row';
            
            const isRegistered = !!person.userId;
            const badgeHtml = isRegistered ? `
                <span class="user-badge" title="Registered User (@${Utils.escapeHtml(person.username)})">
                    <i data-lucide="shield-check" style="width: 14px; height: 14px; color: var(--color-success);"></i>
                    @${Utils.escapeHtml(person.username)}
                </span>
            ` : '';
            
            div.innerHTML = `
                <div class="autocomplete-container">
                    <input type="text" value="${Utils.escapeHtml(person.name)}" class="input-field person-name-input ${isRegistered ? 'has-badge' : ''}" data-id="${person.id}" placeholder="Type name or username..." autocomplete="off">
                    ${badgeHtml ? `<div style="position: absolute; right: 0.75rem; top: 50%; transform: translateY(-50%); display: flex; align-items: center; gap: 0.25rem; pointer-events: none;">${badgeHtml}</div>` : ''}
                    <div class="autocomplete-suggestions" id="suggestions_${person.id}" style="display:none;"></div>
                </div>
                <button class="btn btn-secondary btn-icon delete-person-btn" data-id="${person.id}" style="color: var(--color-danger); border: none; background: none; flex-shrink: 0;">
                    <i data-lucide="x" style="width: 20px; height: 20px;"></i>
                </button>
            `;
            list.appendChild(div);
        });

        lucide.createIcons();
    },

    updatePaymentFieldsVisibility() {
        const val = this.elements.paymentMethod.value;
        const paymentDetailGroup = this.elements.paymentDetailGroup;
        const bankDetailsGroup = this.elements.bankDetailsGroup;
        const paymentDetailLabel = this.elements.paymentDetailLabel;
        const paymentDetails = this.elements.paymentDetails;

        if (!paymentDetailGroup || !bankDetailsGroup) return;

        if (val === 'none') {
            paymentDetailGroup.style.display = 'none';
            bankDetailsGroup.style.display = 'none';
        } else if (val === 'duitnow') {
            paymentDetailGroup.style.display = 'block';
            paymentDetailLabel.textContent = 'Phone Number / DuitNow ID';
            paymentDetails.placeholder = 'e.g. 60123456789';
            bankDetailsGroup.style.display = 'none';
        } else if (val === 'tng') {
            paymentDetailGroup.style.display = 'block';
            paymentDetailLabel.textContent = 'Touch \'n Go Transfer Link';
            paymentDetails.placeholder = 'e.g. https://payment.tngdigital.com.my/...';
            bankDetailsGroup.style.display = 'none';
        } else if (val === 'bank') {
            paymentDetailGroup.style.display = 'none';
            bankDetailsGroup.style.display = 'block';
        } else if (val === 'custom') {
            paymentDetailGroup.style.display = 'block';
            paymentDetailLabel.textContent = 'Custom QR Information';
            paymentDetails.placeholder = 'Custom QR configured in profile';
            if (!paymentDetails.value) {
                paymentDetails.value = 'Pay via uploaded custom QR code';
            }
            bankDetailsGroup.style.display = 'none';
        }
    },

    // Step 4: Item Assignment Rendering
    renderAssignmentUI(state) {
        const container = this.elements.assignItemScroller;
        if (!container) return;

        container.innerHTML = '';
        state.items.forEach((item, itemIdx) => {
            const card = document.createElement('div');
            const isAssigned = item.assignedPeople.length > 0;
            card.className = `assign-card ${isAssigned ? 'assigned' : 'unassigned'}`;
            card.dataset.itemId = item.id;
            
            const qtyText = item.qty > 1 ? `${item.qty}x ` : '';
            const totalVal = item.qty * item.price;

            // Generate split mode options
            const splitModeHtml = `
                <div class="split-mode-selector">
                    <button class="split-mode-btn ${item.splitMode === 'equal' ? 'active' : ''}" data-mode="equal" data-id="${item.id}">Equal</button>
                    <button class="split-mode-btn ${item.splitMode === 'percent' ? 'active' : ''}" data-mode="percent" data-id="${item.id}">%</button>
                    <button class="split-mode-btn ${item.splitMode === 'share' ? 'active' : ''}" data-mode="share" data-id="${item.id}">Shares</button>
                </div>
            `;

            // People Selector Chips
            let chipsHtml = '<div class="people-chips-container">';
            state.people.forEach(person => {
                const isSelected = item.assignedPeople.includes(person.id);
                let shareText = '';
                
                if (isSelected) {
                    let shareAmount = 0;
                    if (item.splitMode === 'percent') {
                        let totalPct = 0;
                        item.assignedPeople.forEach(pid => {
                            totalPct += parseFloat(item.splits?.[pid]) || 0;
                        });
                        const pct = parseFloat(item.splits?.[person.id]) || 0;
                        shareAmount = totalPct > 0 ? (pct / totalPct) * totalVal : 0;
                    } else if (item.splitMode === 'share') {
                        let totalShares = 0;
                        item.assignedPeople.forEach(pid => {
                            totalShares += parseFloat(item.splits?.[pid]) || 0;
                        });
                        const sh = parseFloat(item.splits?.[person.id]) || 0;
                        shareAmount = totalShares > 0 ? (sh / totalShares) * totalVal : 0;
                    } else {
                        shareAmount = totalVal / item.assignedPeople.length;
                    }
                    shareText = ` • ${Utils.formatCurrency(shareAmount, state.currency)}`;
                }

                chipsHtml += `
                    <div class="person-chip ${isSelected ? 'selected' : ''}" data-person-id="${person.id}" data-item-id="${item.id}">
                        <i class="lucide-icon" data-lucide="${isSelected ? 'check-circle-2' : 'circle'}" style="width: 14px; height: 14px;"></i>
                        <span>${Utils.escapeHtml(person.name)}${shareText}</span>
                    </div>
                `;
            });
            chipsHtml += '</div>';

            // Custom inputs for Percent and Share splits
            let customInputsHtml = '';
            if (item.splitMode !== 'equal' && isAssigned) {
                customInputsHtml = `<div class="custom-split-ui">`;
                item.assignedPeople.forEach(pid => {
                    const person = state.people.find(p => p.id === pid);
                    if (!person) return;
                    const val = item.splits?.[pid] || (item.splitMode === 'percent' ? (100 / item.assignedPeople.length).toFixed(1) : '1');
                    const suffix = item.splitMode === 'percent' ? '%' : ' share(s)';
                    
                    customInputsHtml += `
                        <div class="custom-split-row">
                            <span>${Utils.escapeHtml(person.name)}</span>
                            <div class="custom-split-input-wrap">
                                <input type="number" step="any" min="0" class="input-field custom-split-input" 
                                    data-item-id="${item.id}" data-person-id="${pid}" value="${val}">
                                <span style="font-size: 0.75rem; color: var(--text-muted);">${suffix}</span>
                            </div>
                        </div>
                    `;
                });
                customInputsHtml += `</div>`;
            }

            const allSelected = state.people.length > 0 && item.assignedPeople.length === state.people.length;
            const selectAllText = allSelected ? __('clear_all') : __('assign_all');

            card.innerHTML = `
                <div class="assign-card-header">
                    <div>
                        <div class="assign-item-title">${qtyText}${Utils.escapeHtml(item.name || 'Untitled Item')}</div>
                        <div class="assign-item-meta">
                            <span>${Utils.formatCurrency(item.price, state.currency)} ${__('each')}</span>
                            <span> • </span>
                            <button class="assign-all-btn" data-id="${item.id}" style="background: none; border: none; color: var(--color-primary); font-size: 0.75rem; font-weight: 600; padding: 0; cursor: pointer; text-decoration: underline; -webkit-tap-highlight-color: transparent;">${selectAllText}</button>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div class="assign-item-total">${Utils.formatCurrency(totalVal, state.currency)}</div>
                        <div style="margin-top: 0.35rem;">${splitModeHtml}</div>
                    </div>
                </div>
                ${chipsHtml}
                ${customInputsHtml}
            `;
            
            container.appendChild(card);
        });

        lucide.createIcons();
    },

    // Step 5: Render Running Totals & Warnings
    renderRunningTotals(state, calculationResults) {
        const warnings = this.elements.validationWarnings;
        const runningList = this.elements.runningTotalsList;

        if (warnings) {
            warnings.innerHTML = '';
            if (calculationResults.warnings && calculationResults.warnings.length > 0) {
                calculationResults.warnings.forEach(warn => {
                    const alertDiv = document.createElement('div');
                    alertDiv.className = 'alert alert-warning';
                    alertDiv.innerHTML = `
                        <i data-lucide="alert-triangle" style="width: 18px; height: 18px; flex-shrink:0;"></i>
                        <span>${warn}</span>
                    `;
                    warnings.appendChild(alertDiv);
                });
                lucide.createIcons();
            }
        }

        if (runningList) {
            runningList.innerHTML = '';
            calculationResults.people.forEach(person => {
                const div = document.createElement('div');
                div.className = 'running-total-item';
                
                let valText = Utils.formatCurrency(person.total, state.currency);
                if (state.isForeign) {
                    valText += ` / RM ${person.totalMYR.toFixed(2)}`;
                }

                div.innerHTML = `
                    <span class="running-total-name">${Utils.escapeHtml(person.name)}</span>
                    <span class="running-total-val">${valText}</span>
                `;
                runningList.appendChild(div);
            });
        }
    },

    // Step 6: Render Summary screen
    renderFinalSummary(state, calculationResults) {
        if (this.elements.summaryMerchant) this.elements.summaryMerchant.textContent = state.merchant || 'Restaurant Receipt';
        if (this.elements.summaryDate) this.elements.summaryDate.textContent = `Date: ${state.date ? Utils.formatDate(state.date) : 'N/A'}`;

        // Foreign Exchange Rate Header Display
        if (this.elements.summaryExchangeRateInfo) {
            if (state.isForeign) {
                this.elements.summaryExchangeRateInfo.style.display = 'block';
                this.elements.summaryExchangeRateInfo.textContent = `Exchange Rate: 1 ${state.currency} = ${state.exchangeRate.toFixed(6)} MYR`;
            } else {
                this.elements.summaryExchangeRateInfo.style.display = 'none';
            }
        }

        // Creator Payment Info Card
        const creatorContainer = this.elements.creatorPaymentInfoContainer;
        if (creatorContainer) {
            creatorContainer.innerHTML = '';
            const isOwnBill = !state.creatorProfile || (window.USER_PROFILE && window.USER_PROFILE.username === state.creatorProfile.username);
            const hasPaymentDetails = state.creatorProfile && (state.creatorProfile.bankName || (state.creatorProfile.qrType && state.creatorProfile.qrType !== 'none'));
            
            if (!isOwnBill && hasPaymentDetails) {
                const cp = state.creatorProfile;
                const devCard = document.createElement('div');
                devCard.className = 'card';
                devCard.style.borderLeft = '4px solid var(--color-primary)';
                devCard.style.background = 'rgba(129, 140, 248, 0.04)';
                devCard.style.padding = '1.25rem';
                devCard.style.borderRadius = '1rem';
                devCard.style.marginBottom = '1.25rem';
                devCard.style.display = 'flex';
                devCard.style.flexDirection = 'column';
                devCard.style.gap = '0.75rem';
                
                let bankHtml = '';
                if (cp.bankName && cp.accountNumber) {
                    bankHtml = `
                        <div style="background: var(--bg-secondary); padding: 0.85rem 1rem; border-radius: 0.75rem; border: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                            <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                                <span style="font-size: 0.7rem; text-transform: uppercase; font-weight: 700; color: var(--color-primary); letter-spacing: 0.05em;">Preferred Bank Account</span>
                                <span style="font-weight: 700; font-size: 1.15rem; letter-spacing: 0.02em; color: var(--text-primary);" id="creatorBankAccNo">${Utils.escapeHtml(cp.accountNumber)}</span>
                                <span style="font-size: 0.75rem; color: var(--text-muted);">🏦 ${Utils.escapeHtml(cp.bankName)} • Name: ${Utils.escapeHtml(cp.accountName)}</span>
                            </div>
                            <button class="btn btn-secondary btn-sm" id="copyCreatorBankBtn" style="min-height: unset; height: 2.25rem; font-size: 0.75rem; padding: 0 0.75rem; gap: 0.25rem; flex-shrink: 0;">
                                <i data-lucide="copy" style="width: 14px; height: 14px;"></i> Copy Account
                            </button>
                        </div>
                    `;
                }

                let currentUserPid = null;
                if (window.USER_PROFILE && calculationResults && calculationResults.people) {
                    const currentUserPerson = calculationResults.people.find(p => p.username === window.USER_PROFILE.username || p.name.toLowerCase() === window.USER_PROFILE.displayName.toLowerCase());
                    if (currentUserPerson) currentUserPid = currentUserPerson.id;
                }

                let qrHtml = '';
                if (cp.qrType && cp.qrType !== 'none') {
                    let qrTypeName = cp.qrType.toUpperCase();
                    if (cp.qrType === 'tng' || cp.qrType === 'scanned') qrTypeName = "Imported Payment QR";
                    if (cp.qrType === 'duitnow') qrTypeName = "DuitNow ID";
                    if (cp.qrType === 'custom') qrTypeName = "Custom QR Code";

                    let buttonHtml = '';
                    if (currentUserPid) {
                        buttonHtml = `
                            <button class="btn btn-primary btn-sm" id="payCreatorQrBtn" data-person-id="${currentUserPid}" style="min-height: unset; height: 2.25rem; font-size: 0.75rem; padding: 0 0.75rem; gap: 0.35rem; flex-shrink: 0;">
                                <i data-lucide="qr-code" style="width: 14px; height: 14px;"></i> Scan & Pay QR
                            </button>
                        `;
                    }

                    qrHtml = `
                        <div style="background: var(--bg-secondary); padding: 0.85rem 1rem; border-radius: 0.75rem; border: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                            <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                                <span style="font-size: 0.7rem; text-transform: uppercase; font-weight: 700; color: var(--color-success); letter-spacing: 0.05em;">Preferred Payment QR</span>
                                <span style="font-weight: 700; font-size: 1.15rem; color: var(--text-primary);">${qrTypeName}</span>
                                ${cp.qrValue ? `<span style="font-size: 0.75rem; color: var(--text-muted);">${cp.qrValue}</span>` : ''}
                            </div>
                            ${buttonHtml}
                        </div>
                    `;
                }

                devCard.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <i data-lucide="info" style="color: var(--color-primary); width: 20px; height: 20px; flex-shrink:0;"></i>
                        <h3 style="font-size: 1.05rem; font-weight: 700; color: var(--text-primary); margin:0;">Payable to ${Utils.escapeHtml(cp.displayName)}</h3>
                    </div>
                    <p style="font-size: 0.825rem; color: var(--text-muted); line-height: 1.45; margin:0;">
                        This bill split was created by <strong>@${Utils.escapeHtml(cp.username)}</strong>. You can transfer your share directly using their preferred payment options below.
                    </p>
                    ${bankHtml}
                    ${qrHtml}
                `;
                creatorContainer.appendChild(devCard);
            }
        }

        // People individual breakdown cards
        const peopleSummaryContainer = this.elements.peopleSummaryContainer;
        if (peopleSummaryContainer) {
            peopleSummaryContainer.innerHTML = '';
            
            const unscaleShare = (v) => v / 10000;

            calculationResults.people.forEach(person => {
                const card = document.createElement('div');
                card.className = 'person-bill-summary';
                const isCreatorSelf = !!(window.USER_PROFILE && person.userId && window.USER_PROFILE.username && state.creatorProfile && window.USER_PROFILE.username === state.creatorProfile.username && person.userId === window.USER_PROFILE.userId);
                
                let itemsRowsHtml = '';
                person.items.forEach(item => {
                    const qtyText = item.qty > 1 ? `x${item.qty} ` : '';
                    itemsRowsHtml += `
                        <div class="person-summary-item-row">
                            <span>${qtyText}${Utils.escapeHtml(item.name)}</span>
                            <span>${Utils.formatCurrency(item.shareTotal, state.currency)}</span>
                        </div>
                    `;
                });

                let extraBreakdownHtml = '';
                if (person.taxShare > 0 || person.serviceShare > 0 || person.discountShare > 0 || person.roundingShare !== 0) {
                    const list = [];
                    if (person.discountShare > 0) list.push(`Discount: -${Utils.formatCurrency(unscaleShare(person.discountShare), state.currency)}`);
                    if (person.serviceShare > 0) list.push(`Svc Charge: +${Utils.formatCurrency(unscaleShare(person.serviceShare), state.currency)}`);
                    if (person.taxShare > 0) list.push(`Tax: +${Utils.formatCurrency(unscaleShare(person.taxShare), state.currency)}`);
                    if (person.roundingShare !== 0) {
                        const rDir = person.roundingShare > 0 ? '+' : '';
                        list.push(`Rounding: ${rDir}${Utils.formatCurrency(unscaleShare(person.roundingShare), state.currency)}`);
                    }
                    extraBreakdownHtml = `
                        <div class="person-summary-breakdown">
                            ${list.map(l => `<div>${l}</div>`).join('')}
                        </div>
                    `;
                }

                let totalDisplay = Utils.formatCurrency(person.total, state.currency);
                if (state.isForeign) {
                    totalDisplay += ` / RM ${person.totalMYR.toFixed(2)}`;
                }

                const paymentBtnHtml = (!isCreatorSelf && state.paymentMethod !== 'none') ? `
                    <button class="btn btn-secondary btn-sm show-qr-btn" data-person-id="${person.id}" style="font-size:0.75rem; height:2rem; min-height:0; padding:0 0.6rem; gap:0.25rem;">
                        <i data-lucide="qr-code" style="width:13px; height:13px;"></i> Pay QR
                    </button>
                ` : '';

                const actionRowHtml = `
                    <div style="display:flex; justify-content:flex-end; gap:0.5rem; margin-top:0.75rem; border-top: 1px dashed var(--border-color); padding-top: 0.6rem;">
                        ${paymentBtnHtml}
                        <button class="btn btn-secondary btn-sm download-card-btn" data-person-id="${person.id}" style="font-size:0.75rem; height:2rem; min-height:0; padding:0 0.6rem; gap:0.25rem;">
                            <i data-lucide="download" style="width:13px; height:13px;"></i> Card PNG
                        </button>
                    </div>
                `;

                card.innerHTML = `
                    <div class="person-summary-header">
                        <span>${Utils.escapeHtml(person.name)}${isCreatorSelf ? ' <span style="font-size:0.7rem; color:var(--color-success); font-weight:600;">• Already Paid by Creator</span>' : ''}</span>
                        <span>${totalDisplay}</span>
                    </div>
                    <div class="person-summary-items">
                        ${itemsRowsHtml || '<div style="color:var(--text-muted);">No items assigned.</div>'}
                    </div>
                    ${extraBreakdownHtml}
                    ${actionRowHtml}
                `;
                peopleSummaryContainer.appendChild(card);
            });
        }

        // Bill totals panel
        if (this.elements.billSummaryTotals) {
            this.elements.billSummaryTotals.innerHTML = `
                <div class="totals-row">
                    <span>Items Subtotal</span>
                    <span>${Utils.formatCurrency(calculationResults.originalSubtotal, state.currency)}</span>
                </div>
                ${state.discount > 0 ? `
                <div class="totals-row">
                    <span>Discount</span>
                    <span>-${Utils.formatCurrency(state.discount, state.currency)}</span>
                </div>` : ''}
                ${state.serviceCharge > 0 ? `
                <div class="totals-row">
                    <span>Service Charge</span>
                    <span>+${Utils.formatCurrency(state.serviceCharge, state.currency)}</span>
                </div>` : ''}
                ${state.tax > 0 ? `
                <div class="totals-row">
                    <span>Tax</span>
                    <span>+${Utils.formatCurrency(state.tax, state.currency)}</span>
                </div>` : ''}
                ${state.rounding !== 0 ? `
                <div class="totals-row">
                    <span>Rounding Difference</span>
                    <span>${state.rounding > 0 ? '+' : ''}${Utils.formatCurrency(state.rounding, state.currency)}</span>
                </div>` : ''}
                <div class="totals-row grand-total">
                    <span>Grand Total</span>
                    <span>${Utils.formatCurrency(state.grandTotal, state.currency)}</span>
                </div>
            `;
        }

        // Trip cost breakdown chart progress-bars
        const tripBreakdownContainer = document.getElementById('tripBreakdownContainer');
        const tripBreakdownList = document.getElementById('tripBreakdownList');
        if (tripBreakdownContainer && tripBreakdownList) {
            const categoryTotals = { food: 0, lodging: 0, transport: 0, activity: 0, others: 0 };
            let subtotal = 0;
            
            state.items.forEach(item => {
                const itemPrice = parseFloat(item.price) || 0;
                const itemQty = parseInt(item.qty) || 1;
                const itemTotal = itemPrice * itemQty;
                const cat = item.category || 'food';
                
                if (categoryTotals[cat] !== undefined) {
                    categoryTotals[cat] += itemTotal;
                } else {
                    categoryTotals.others += itemTotal;
                }
                subtotal += itemTotal;
            });

            const hasTravelItems = Object.keys(categoryTotals).some(key => key !== 'food' && categoryTotals[key] > 0);
            if (subtotal > 0 && hasTravelItems) {
                tripBreakdownContainer.style.display = 'block';
                tripBreakdownList.innerHTML = '';
                
                const categoriesMeta = [
                    { key: 'food', name: 'Food & Drinks', emoji: '🍔', color: '#f87171' },
                    { key: 'lodging', name: 'Lodging/Hotel', emoji: '🏨', color: '#60a5fa' },
                    { key: 'transport', name: 'Gas & Transport', emoji: '🚗', color: '#34d399' },
                    { key: 'activity', name: 'Activities', emoji: '🎟️', color: '#fbbf24' },
                    { key: 'others', name: 'Others', emoji: '📦', color: '#a78bfa' }
                ];
                
                categoriesMeta.forEach(cat => {
                    const total = categoryTotals[cat.key];
                    if (total > 0) {
                        const pct = ((total / subtotal) * 100).toFixed(1);
                        const formattedAmount = Utils.formatCurrency(total, state.currency);
                        
                        const itemDiv = document.createElement('div');
                        itemDiv.className = 'trip-progress-item';
                        itemDiv.innerHTML = `
                            <div class="trip-progress-label-row">
                                <span style="display: flex; align-items: center; gap: 0.35rem;">
                                    <span>${cat.emoji}</span>
                                    <span>${cat.name}</span>
                                </span>
                                <span>${formattedAmount} (${pct}%)</span>
                            </div>
                            <div class="trip-progress-bar-bg">
                                <div class="trip-progress-bar-fill" style="width: ${pct}%; background-color: ${cat.color};"></div>
                            </div>
                        `;
                        tripBreakdownList.appendChild(itemDiv);
                    }
                });
            } else {
                tripBreakdownContainer.style.display = 'none';
            }
        }

        lucide.createIcons();
    },

    // QR Modal Show
    openQrModal(pid, state, calculationResults) {
        const person = calculationResults.people.find(p => p.id === pid);
        if (!person) return;

        const amount = state.isForeign ? person.totalMYR : person.total;
        const displayAmount = `RM ${amount.toFixed(2)}`;

        let qrText = '';
        let subtitle = '';
        let detailsHtml = '';

        if (state.paymentMethod === 'duitnow') {
            qrText = `DuitNow Transfer\nTo: ${state.paymentDetails}\nAmount: ${displayAmount}\nRef: ${state.merchant || 'BillSplit'}`;
            subtitle = `DuitNow ID: ${Utils.escapeHtml(state.paymentDetails)}`;
            detailsHtml = `
                <div style="margin-bottom:0.25rem;"><strong>Payee Method:</strong> DuitNow ID</div>
                <div style="margin-bottom:0.25rem;"><strong>ID:</strong> ${Utils.escapeHtml(state.paymentDetails)}</div>
                <div><strong>Amount:</strong> ${displayAmount}</div>
                <div style="font-size: 0.7rem; color: var(--text-muted); margin-top: 0.6rem; border-top:1px dashed var(--border-color); padding-top:0.4rem;">Scan QR to see transaction info.</div>
            `;
        } else if (state.paymentMethod === 'bank') {
            qrText = `Bank Transfer\nBank: ${state.bankName}\nAccount: ${state.bankAccount}\nAmount: ${displayAmount}\nRef: ${state.merchant || 'BillSplit'}`;
            subtitle = `${Utils.escapeHtml(state.bankName)} Account`;
            detailsHtml = `
                <div style="margin-bottom:0.25rem;"><strong>Bank:</strong> ${Utils.escapeHtml(state.bankName)}</div>
                <div style="margin-bottom:0.25rem;"><strong>Account:</strong> ${Utils.escapeHtml(state.bankAccount)}</div>
                <div><strong>Amount:</strong> ${displayAmount}</div>
                <div style="font-size: 0.7rem; color: var(--text-muted); margin-top: 0.6rem; border-top:1px dashed var(--border-color); padding-top:0.4rem;">Transfer manually using these details.</div>
            `;
        } else if (state.paymentMethod === 'tng') {
            qrText = state.paymentDetails;
            subtitle = `Touch 'n Go E-Wallet Link`;
            detailsHtml = `
                <div style="margin-bottom:0.25rem;"><strong>Wallet:</strong> Touch 'n Go</div>
                <div><strong>Amount:</strong> ${displayAmount}</div>
                <div style="font-size: 0.7rem; color: var(--text-muted); margin-top: 0.6rem; border-top:1px dashed var(--border-color); padding-top:0.4rem;">Scan to open e-wallet and pay.</div>
            `;
        } else if (state.paymentMethod === 'custom') {
            subtitle = `Custom Merchant QR`;
            const qrImageSrc = (state.creatorProfile && state.creatorProfile.qrImage) 
                ? `storage/qrs/${state.creatorProfile.qrImage}` 
                : ((window.USER_PROFILE && window.USER_PROFILE.qrImage) ? `storage/qrs/${window.USER_PROFILE.qrImage}` : '');
            
            if (qrImageSrc) {
                detailsHtml = `
                    <div style="margin-bottom:0.25rem;"><strong>Payee:</strong> Custom Merchant QR</div>
                    <div><strong>Amount:</strong> ${displayAmount}</div>
                    <div style="font-size: 0.7rem; color: var(--text-muted); margin-top: 0.6rem; border-top:1px dashed var(--border-color); padding-top:0.4rem;">Scan the uploaded QR code to pay.</div>
                `;
            } else {
                detailsHtml = `
                    <div style="margin-bottom:0.25rem; color: var(--color-danger);"><strong>No QR Image Uploaded</strong></div>
                    <div><strong>Amount:</strong> ${displayAmount}</div>
                `;
            }
        }

        this.elements.qrModalTitle.textContent = `Pay ${person.name}`;
        this.elements.qrModalSubtitle.textContent = subtitle;
        this.elements.qrModalDetails.innerHTML = detailsHtml;

        this.elements.qrCodeContainer.innerHTML = '';
        if (state.paymentMethod === 'custom') {
            const qrImageSrc = (state.creatorProfile && state.creatorProfile.qrImage)
                ? `storage/qrs/${state.creatorProfile.qrImage}`
                : ((window.USER_PROFILE && window.USER_PROFILE.qrImage) ? `storage/qrs/${window.USER_PROFILE.qrImage}` : '');
            if (qrImageSrc) {
                this.elements.qrCodeContainer.innerHTML = `<img src="${qrImageSrc}" alt="Payment QR" style="max-width:100%; max-height:100%; object-fit:contain; display:block; margin:0 auto; border-radius: 8px;">`;
            } else {
                this.elements.qrCodeContainer.innerHTML = `<div style="font-size:0.75rem; color:var(--text-muted); text-align:center;">No QR image uploaded in profile.</div>`;
            }
        } else if (qrText) {
            try {
                new QRCode(this.elements.qrCodeContainer, {
                    text: qrText,
                    width: 110,
                    height: 110,
                    colorDark : "#0b0f19",
                    colorLight : "#ffffff",
                    correctLevel : QRCode.CorrectLevel.M
                });
            } catch (e) {
                console.error("QR Code generator crash: ", e);
                this.elements.qrCodeContainer.innerHTML = `<div style="font-size:0.7rem; color:var(--color-danger); text-align:center;">Failed to render QR.</div>`;
            }
        } else {
            this.elements.qrCodeContainer.innerHTML = `<div style="font-size:0.75rem; color:var(--text-muted); text-align:center;">Details Only (No QR)</div>`;
        }

        this.elements.qrModal.classList.add('active');
    },

    // PNG Downloader
    downloadBillCard(pid, state, calculationResults) {
        const person = calculationResults.people.find(p => p.id === pid);
        if (!person) return;

        this.showLoader(`Generating Payer Bill Card...`);

        const captureContainer = document.createElement('div');
        captureContainer.style.position = 'fixed';
        captureContainer.style.top = '-9999px';
        captureContainer.style.left = '-9999px';
        document.body.appendChild(captureContainer);

        const originalCurrency = state.currency.toUpperCase();
        let itemsHtml = '';
        person.items.forEach(item => {
            const qtyText = item.qty > 1 ? `x${item.qty} ` : '';
            itemsHtml += `
                <div class="visual-bill-card-item">
                    <span>${qtyText}${item.name}</span>
                    <span>${Utils.formatCurrency(item.shareTotal, originalCurrency)}</span>
                </div>
            `;
        });

        const unscaleShare = (v) => v / 10000;
        let extraBreakdownHtml = '';
        if (person.taxShare > 0 || person.serviceShare > 0 || person.discountShare > 0 || person.roundingShare !== 0) {
            const list = [];
            if (person.discountShare > 0) list.push(`Discount: -${Utils.formatCurrency(unscaleShare(person.discountShare), originalCurrency)}`);
            if (person.serviceShare > 0) list.push(`Service Charge: +${Utils.formatCurrency(unscaleShare(person.serviceShare), originalCurrency)}`);
            if (person.taxShare > 0) list.push(`Tax: +${Utils.formatCurrency(unscaleShare(person.taxShare), originalCurrency)}`);
            if (person.roundingShare !== 0) {
                const rDir = person.roundingShare > 0 ? '+' : '';
                list.push(`Rounding: ${rDir}${Utils.formatCurrency(unscaleShare(person.roundingShare), originalCurrency)}`);
            }
            extraBreakdownHtml = list.map(l => `
                <div class="visual-bill-card-item" style="opacity: 0.75; font-size: 0.8rem; margin-top:0.15rem;">
                    <span>${l.split(':')[0]}</span>
                    <span>${l.split(':')[1]}</span>
                </div>
            `).join('');
        }

        let totalDisplay = Utils.formatCurrency(person.total, originalCurrency);
        if (state.isForeign) {
            totalDisplay += ` / RM ${person.totalMYR.toFixed(2)}`;
        }

        captureContainer.innerHTML = `
            <div class="visual-bill-card-container" style="display:flex; flex-direction:column; gap:1rem;">
                <div class="visual-bill-card-header" style="text-align:center;">
                    <div style="font-size:0.75rem; text-transform:uppercase; letter-spacing:0.1em; opacity:0.6;">Bill Details for</div>
                    <div style="font-size:1.45rem; font-weight:800; margin-top:0.15rem;">${person.name}</div>
                    <div style="font-size:0.8rem; opacity:0.6; margin-top:0.4rem; line-height:1.35;">
                        📍 ${state.merchant || 'Restaurant Receipt'}<br>
                        📅 ${state.date ? Utils.formatDate(state.date) : new Date().toLocaleDateString()}
                    </div>
                </div>
                <div class="visual-bill-card-body" style="display:flex; flex-direction:column; gap:0.4rem;">
                    <div style="font-weight:600; font-size:0.8rem; text-transform:uppercase; letter-spacing:0.05em; opacity:0.6; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:0.25rem; margin-bottom:0.4rem;">Items Consumed</div>
                    ${itemsHtml || '<div style="opacity:0.5; font-size:0.8rem;">No items assigned.</div>'}
                    ${extraBreakdownHtml ? `
                        <div style="font-weight:600; font-size:0.8rem; text-transform:uppercase; letter-spacing:0.05em; opacity:0.6; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:0.25rem; margin-top:0.6rem; margin-bottom:0.4rem;">Taxes & Adjustments</div>
                        ${extraBreakdownHtml}
                    ` : ''}
                </div>
                <div class="visual-bill-card-total-row" style="display:flex; justify-content:space-between; font-weight:700; font-size:1.1rem; border-top:1px solid rgba(255,255,255,0.1); padding-top:0.6rem; margin-top:0.4rem;">
                    <span>Total Owed</span>
                    <span>${totalDisplay}</span>
                </div>
                ${state.paymentMethod !== 'none' ? `
                    <div style="font-size:0.75rem; text-align:center; border-top:1px dashed rgba(255,255,255,0.15); padding-top:0.6rem; opacity:0.8; line-height:1.3;">
                        💳 <strong>Pay To:</strong> ${state.paymentMethod === 'bank' ? `${state.bankName} (${state.bankAccount})` : `${state.paymentDetails}`}
                    </div>
                ` : ''}
                <div style="font-size:0.6rem; opacity:0.4; text-align:center; margin-top:0.25rem;">Generated via Personal Bill Splitter</div>
            </div>
        `;

        setTimeout(() => {
            html2canvas(captureContainer.querySelector('.visual-bill-card-container'), {
                useCORS: true,
                backgroundColor: null,
                scale: 2
            }).then(canvas => {
                const link = document.createElement('a');
                link.download = `bill_${person.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}.png`;
                link.href = canvas.toDataURL('image/png');
                link.click();
                
                document.body.removeChild(captureContainer);
                this.hideLoader();
                Utils.showToast("Bill Card Image Downloaded!", "success");
            }).catch(err => {
                console.error("Html2canvas error: ", err);
                document.body.removeChild(captureContainer);
                this.hideLoader();
                Utils.showToast("Image generation failed.", "error");
            });
        }, 400);
    },

    // Recent History bills rendering
    renderRecentBills(history, onSelectBillCallback) {
        const recentBillsContainer = this.elements.recentBillsContainer;
        const recentBillsList = this.elements.recentBillsList;
        
        if (!recentBillsList || !recentBillsContainer) return;
        
        if (history.length === 0) {
            recentBillsContainer.style.display = 'block';
            recentBillsList.innerHTML = `
                <div class="empty-dashboard" style="padding: 1.5rem 1rem; border: none; background: none; box-shadow: none; display: flex; flex-direction: column; align-items: center;">
                    <i data-lucide="history" style="width: 32px; height: 32px; stroke-width: 1.5; color: var(--text-muted); margin-bottom: 0.5rem; display: inline-block;"></i>
                    <p style="font-size: 0.8rem; color: var(--text-muted); margin: 0; text-align: center;">No recent splits yet. Your local history will appear here once you save or finish a split.</p>
                </div>
            `;
            if (this.elements.clearHistoryBtn) {
                this.elements.clearHistoryBtn.style.display = 'none';
            }
            lucide.createIcons({
                attrs: {
                    class: 'lucide'
                },
                nameAttr: 'data-lucide',
                nodeList: recentBillsList.querySelectorAll('[data-lucide]')
            });
            return;
        }
        
        recentBillsContainer.style.display = 'block';
        if (this.elements.clearHistoryBtn) {
            this.elements.clearHistoryBtn.style.display = 'block';
        }
        recentBillsList.innerHTML = '';
        
        history.slice(0, 5).forEach(bill => {
            const item = document.createElement('div');
            item.className = 'recent-bill-item';
            item.dataset.billId = bill.id;
            
            const dateText = bill.date ? Utils.formatDate(bill.date) : 'No Date';
            let amountText = Utils.formatCurrency(bill.grandTotal, bill.currency);
            let myrTextHtml = '';
            
            if (bill.isForeign && bill.convertedGrandTotal) {
                myrTextHtml = `<div class="recent-bill-myr">RM ${bill.convertedGrandTotal.toFixed(2)}</div>`;
            }
            
            item.innerHTML = `
                <div class="recent-bill-info">
                    <span class="recent-bill-merchant">${Utils.escapeHtml(bill.merchant || 'Restaurant Receipt')}</span>
                    <span class="recent-bill-meta">${dateText} • ${bill.people.length} people</span>
                </div>
                <div class="recent-bill-amount-wrap">
                    <span class="recent-bill-amount">${amountText}</span>
                    ${myrTextHtml}
                </div>
            `;
            
            item.addEventListener('click', () => {
                onSelectBillCallback(bill);
            });
            
            recentBillsList.appendChild(item);
        });
    },

    disableUnconfiguredPaymentOptions() {
        const up = window.USER_PROFILE;
        const select = this.elements.paymentMethod;
        if (!select) return;

        const normalizedProfileQrType = up && up.qrType === 'scanned' ? 'tng' : (up ? up.qrType : null);
        const options = select.options;
        for (let i = 0; i < options.length; i++) {
            const val = options[i].value;
            if (val === 'none' || val === 'bank') continue; // Always allowed

            let hasQr = false;
            if (up) {
                if (val === 'custom' && up.qrImage) {
                    hasQr = true;
                } else if (val === 'duitnow' && normalizedProfileQrType === 'duitnow' && up.qrValue) {
                    hasQr = true;
                } else if (val === 'tng' && normalizedProfileQrType === 'tng' && up.qrValue) {
                    hasQr = true;
                }
            }

            options[i].disabled = false;
            options[i].textContent = options[i].textContent.replace(' (Upload QR in Profile first)', '');

            if (!hasQr) {
                options[i].disabled = true;
                options[i].textContent += " (Upload QR in Profile first)";
            }
        }
    }
};
