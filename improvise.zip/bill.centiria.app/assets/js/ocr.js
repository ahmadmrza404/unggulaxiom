/**
 * Personal Bill Splitter - OCR and Image Processing Module
 * 
 * High-accuracy Tesseract.js OCR engine with:
 * - Multi-pass recognition (auto-selects best result)
 * - Advanced canvas preprocessing: grayscale → sharpen → adaptive threshold
 * - Smart receipt text parser with line classification
 */

const OCR = {
    cropper: null,

    /**
     * Warm up Tesseract by pre-loading the LSTM model into browser cache.
     */
    preloadWorker() {
        setTimeout(async () => {
            if (typeof Tesseract !== 'undefined') {
                try {
                    const worker = await Tesseract.createWorker('eng', 1);
                    await worker.terminate();
                    console.log('🤖 Tesseract OCR worker warmed up.');
                } catch (e) {
                    console.warn('Background OCR warm-up failed:', e);
                }
            }
        }, 2000);
    },

    // ------------------------------------------------------------------
    // IMAGE PREPROCESSING
    // ------------------------------------------------------------------

    /**
     * Convert canvas to grayscale in place.
     */
    _toGrayscale(ctx, w, h) {
        const imgData = ctx.getImageData(0, 0, w, h);
        const d = imgData.data;
        for (let i = 0; i < d.length; i += 4) {
            const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
            d[i] = d[i + 1] = d[i + 2] = gray;
        }
        ctx.putImageData(imgData, 0, 0);
    },

    /**
     * Apply a 3x3 unsharp-mask sharpening kernel to improve edge contrast for OCR.
     */
    _sharpen(ctx, w, h) {
        const imgData = ctx.getImageData(0, 0, w, h);
        const d = imgData.data;
        const out = new Uint8ClampedArray(d);

        // Sharpen kernel: center=5, edge=-1
        const kernel = [
            0, -1,  0,
           -1,  5, -1,
            0, -1,  0
        ];

        for (let y = 1; y < h - 1; y++) {
            for (let x = 1; x < w - 1; x++) {
                for (let c = 0; c < 3; c++) {
                    let val = 0;
                    for (let ky = -1; ky <= 1; ky++) {
                        for (let kx = -1; kx <= 1; kx++) {
                            const idx = ((y + ky) * w + (x + kx)) * 4 + c;
                            val += d[idx] * kernel[(ky + 1) * 3 + (kx + 1)];
                        }
                    }
                    out[(y * w + x) * 4 + c] = Math.max(0, Math.min(255, val));
                }
            }
        }
        ctx.putImageData(new ImageData(out, w, h), 0, 0);
    },

    /**
     * Adaptive threshold: converts grayscale image to clean black/white.
     * Computes local mean over a window and thresholds relative to local contrast.
     * Much better than global thresholding for uneven lighting in receipt photos.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} w
     * @param {number} h
     * @param {number} [windowSize=21] - local neighborhood size (odd number)
     * @param {number} [C=12] - constant subtracted from mean
     */
    _adaptiveThreshold(ctx, w, h, windowSize = 21, C = 12) {
        const imgData = ctx.getImageData(0, 0, w, h);
        const d = imgData.data;
        const gray = new Float32Array(w * h);

        // Extract single-channel gray values
        for (let i = 0; i < w * h; i++) {
            gray[i] = d[i * 4]; // already grayscale so R=G=B
        }

        // Compute integral image for fast box-filter mean
        const integral = new Float32Array((w + 1) * (h + 1));
        for (let y = 0; y < h; y++) {
            let rowSum = 0;
            for (let x = 0; x < w; x++) {
                rowSum += gray[y * w + x];
                integral[(y + 1) * (w + 1) + (x + 1)] = integral[y * (w + 1) + (x + 1)] + rowSum;
            }
        }

        const half = Math.floor(windowSize / 2);
        const out = new Uint8ClampedArray(d.length);

        for (let y = 0; y < h; y++) {
            for (let x = 0; x < w; x++) {
                const x1 = Math.max(0, x - half);
                const y1 = Math.max(0, y - half);
                const x2 = Math.min(w - 1, x + half);
                const y2 = Math.min(h - 1, y + half);

                const count = (x2 - x1 + 1) * (y2 - y1 + 1);
                const sum = integral[(y2 + 1) * (w + 1) + (x2 + 1)]
                          - integral[y1 * (w + 1) + (x2 + 1)]
                          - integral[(y2 + 1) * (w + 1) + x1]
                          + integral[y1 * (w + 1) + x1];

                const mean = sum / count;
                const pixel = gray[y * w + x];
                const val = pixel < mean - C ? 0 : 255;

                const idx = (y * w + x) * 4;
                out[idx] = out[idx + 1] = out[idx + 2] = val;
                out[idx + 3] = 255;
            }
        }

        ctx.putImageData(new ImageData(out, w, h), 0, 0);
    },

    /**
     * Apply brightness/contrast adjustments (user-controlled sliders).
     */
    applyFilters(canvas, brightness, contrast) {
        const ctx = canvas.getContext('2d');
        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const d = imgData.data;
        const bVal = (brightness - 100) / 100 * 255;
        const cFactor = contrast / 100;

        for (let i = 0; i < d.length; i += 4) {
            for (let j = 0; j < 3; j++) {
                let p = d[i + j];
                p = (p - 128) * cFactor + 128 + bVal;
                d[i + j] = Math.max(0, Math.min(255, p));
            }
        }
        ctx.putImageData(imgData, 0, 0);
    },

    /**
     * Build a preprocessed (grayscale → sharpen → adaptive threshold) canvas
     * from the Cropper.js selection, scaled up to a minimum of 2000px on the
     * longest side for maximum OCR accuracy.
     */
    getProcessedCanvas(brightness, contrast) {
        if (!this.cropper) return null;

        // Determine an upscaled output size (min 2000px longest side)
        const data = this.cropper.getData(true);
        const aspect = data.width / data.height;
        let outW, outH;
        if (aspect >= 1) {
            outW = Math.max(2000, data.width);
            outH = Math.round(outW / aspect);
        } else {
            outH = Math.max(2000, data.height);
            outW = Math.round(outH * aspect);
        }

        const canvas = this.cropper.getCroppedCanvas({
            width: outW,
            height: outH,
            imageSmoothingEnabled: true,
            imageSmoothingQuality: 'high',
            fillColor: '#ffffff'
        });

        if (!canvas) return null;

        const ctx = canvas.getContext('2d');

        // Apply user sliders first (before binarisation)
        if (brightness !== 100 || contrast !== 100) {
            this.applyFilters(canvas, brightness, contrast);
        }

        // Preprocessing pipeline
        this._toGrayscale(ctx, canvas.width, canvas.height);
        this._sharpen(ctx, canvas.width, canvas.height);
        this._adaptiveThreshold(ctx, canvas.width, canvas.height);

        return canvas;
    },

    // ------------------------------------------------------------------
    // CROPPER
    // ------------------------------------------------------------------

    initCropper(imgElement) {
        if (this.cropper) {
            this.cropper.destroy();
        }
        this.cropper = new Cropper(imgElement, {
            viewMode: 1,
            dragMode: 'move',
            autoCropArea: 0.92,
            restore: false,
            modal: true,
            guides: true,
            highlight: false,
            cropBoxMovable: true,
            cropBoxResizable: true,
            toggleDragModeOnDblclick: false,
        });
    },

    rotate(degree) {
        if (this.cropper) this.cropper.rotate(degree);
    },

    // ------------------------------------------------------------------
    // TESSERACT RUNNER
    // ------------------------------------------------------------------

    /**
     * Run Tesseract.js recognition. Configures the engine with receipt-optimised
     * parameters (single-block page layout, LSTM-only engine, conservative DPI).
     *
     * @param {HTMLCanvasElement|string} imageSource
     * @param {Function} onProgress
     * @returns {Promise<string>}
     */
    async runTesseract(imageSource, onProgress) {
        if (typeof Tesseract === 'undefined') {
            throw new Error('Tesseract.js is not loaded.');
        }

        onProgress({ status: 'initializing', progress: 0 });

        // Tesseract Page Segmentation Mode 6 = single uniform block of text,
        // which is optimal for receipts where all text is left-to-right columns.
        const worker = await Tesseract.createWorker('eng', 1, {
            logger: m => {
                if (m.status === 'recognizing text') {
                    onProgress({ status: 'recognizing', progress: m.progress });
                } else if (m.status === 'loading tesseract core') {
                    onProgress({ status: 'initializing', progress: m.progress * 0.3 });
                } else if (m.status === 'loading language traineddata') {
                    onProgress({ status: 'initializing', progress: 0.3 + m.progress * 0.4 });
                }
            }
        });

        try {
            // Configure Tesseract parameters for receipt recognition
            await worker.setParameters({
                tessedit_pageseg_mode: Tesseract.PSM.SINGLE_BLOCK, // PSM 6
                tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,/ ():;$%@&*#!-+\'\"',
                preserve_interword_spaces: '1',
            });

            const { data } = await worker.recognize(imageSource);
            await worker.terminate();
            return data.text;
        } catch (e) {
            await worker.terminate();
            throw e;
        }
    },

    // ------------------------------------------------------------------
    // PDF RENDERER
    // ------------------------------------------------------------------

    async renderPDFToCanvas(file) {
        if (typeof pdfjsLib === 'undefined') {
            throw new Error('PDF.js library is not loaded.');
        }
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = async (e) => {
                try {
                    const pdf = await pdfjsLib.getDocument({ data: e.target.result }).promise;
                    const page = await pdf.getPage(1);
                    const viewport = page.getViewport({ scale: 2.5 }); // higher scale = better OCR
                    const canvas = document.createElement('canvas');
                    canvas.width = viewport.width;
                    canvas.height = viewport.height;
                    await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
                    resolve(canvas);
                } catch (err) {
                    reject(err);
                }
            };
            reader.onerror = reject;
            reader.readAsArrayBuffer(file);
        });
    },

    // ------------------------------------------------------------------
    // SERVER OCR
    // ------------------------------------------------------------------

    async runServerOCR(file, csrfToken) {
        if (!file) return null;
        const formData = new FormData();
        formData.append('receipt', file);
        const response = await fetch('api/ocr.php', {
            method: 'POST',
            headers: { 'X-CSRF-Token': csrfToken || '' },
            body: formData
        });
        let data = null;
        try { data = await response.json(); } catch (e) { throw new Error('Server OCR returned invalid response.'); }

        if (data?.success && data.provider === 'gemini' && data.data) return data.data;
        if (data?.success && data.provider === 'local') return null;
        if (data?.fallback === 'local') return null;
        throw new Error(data?.error || 'Server OCR failed.');
    },

    // ------------------------------------------------------------------
    // RECEIPT TEXT PARSER
    // ------------------------------------------------------------------

    /**
     * Parse raw OCR text into a structured bill object.
     * Handles Malaysian, Singaporean, and general receipt formats.
     *
     * @param {string} text
     * @returns {Object}
     */
    parseReceiptText(text) {
        // Normalise common OCR substitutions before parsing
        text = text
            .replace(/[|l](?=\d)/g, '1')        // | or l before digit → 1
            .replace(/(?<=\d)[|l]/g, '1')         // | or l after digit → 1
            .replace(/O(?=\d)/g, '0')              // O before digit → 0
            .replace(/(?<=\d)O/g, '0')             // O after digit → 0
            .replace(/\r\n/g, '\n')
            .replace(/\r/g, '\n');

        const lines = text
            .split('\n')
            .map(l => l.trim())
            .filter(l => l.length > 0);

        const result = {
            merchant: '',
            date: '',
            currency: 'MYR',
            items: [],
            subtotal: 0,
            tax: 0,
            service_charge: 0,
            discount: 0,
            rounding: 0,
            total: 0
        };

        if (lines.length === 0) return result;

        // ---- Helpers ----

        const toMoney = (str) => {
            if (!str) return 0;
            let s = String(str)
                .replace(/(?:RM|MYR|S\$|SGD|USD|EUR|GBP|JPY|AUD|THB|IDR)/gi, '')
                .replace(/\s/g, '')
                .trim();

            // Handle European / ambiguous comma-dot
            const lc = s.lastIndexOf(',');
            const ld = s.lastIndexOf('.');
            if (lc > -1 && ld > -1) {
                s = lc > ld ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
            } else if (lc > -1) {
                const dec = s.length - lc - 1;
                s = dec === 2 ? s.replace(',', '.') : s.replace(/,/g, '');
            }

            const v = parseFloat(s);
            return Number.isFinite(v) && v >= 0 ? v : 0;
        };

        // Regex that captures a price token at end of line: e.g. 12.50, RM12.50, 1,234.00
        const PRICE_RE = /(?:RM|MYR|S\$|SGD|USD|EUR|GBP|JPY|AUD|THB|IDR)?\s*-?\d{1,3}(?:[,\s]\d{3})*(?:[.,]\d{1,2})\b/gi;

        // ---- Currency Detection ----
        const currencyPatterns = [
            [/\bRM\b|MYR/i, 'MYR'],
            [/\bS\$|SGD\b/i, 'SGD'],
            [/\bUSD\b|\bUS\$/i, 'USD'],
            [/\bEUR\b|€/i, 'EUR'],
            [/\bGBP\b|£/i, 'GBP'],
            [/\bJPY\b|¥/i, 'JPY'],
            [/\bAUD\b|A\$/i, 'AUD'],
            [/\bTHB\b|฿/i, 'THB'],
            [/\bIDR\b|Rp/i, 'IDR'],
        ];
        for (const [re, code] of currencyPatterns) {
            if (re.test(text)) { result.currency = code; break; }
        }

        // ---- Date Detection ----
        // Supports: DD/MM/YYYY, YYYY-MM-DD, DD-MM-YY, DD MMM YYYY
        const datePatterns = [
            /\b(\d{4})[/-](\d{2})[/-](\d{2})\b/,          // YYYY-MM-DD
            /\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b/,      // DD/MM/YYYY
            /\b(\d{1,2})[/-](\d{1,2})[/-](\d{2})\b/,      // DD/MM/YY
            /\b(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+(\d{4})\b/i,
        ];
        for (const re of datePatterns) {
            const m = text.match(re);
            if (m) {
                try {
                    const raw = m[0];
                    const parts = raw.split(/[\s\-/]/);
                    if (parts[0].length === 4) {
                        result.date = `${parts[0]}-${parts[1].padStart(2,'0')}-${parts[2].padStart(2,'0')}`;
                    } else if (parts[2] && parts[2].length === 4) {
                        result.date = `${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}`;
                    } else if (parts[2] && parts[2].length === 2) {
                        result.date = `20${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}`;
                    }
                } catch (_) { /* ignore date parse errors */ }
                if (result.date) break;
            }
        }

        // ---- Merchant Detection ----
        // Skip header noise, take first substantive text line
        const skipWords = /receipt|invoice|tax invoice|official receipt|cashier|welcome|thank you|w i r e l e s s|wifi|password|reprint|copy/i;
        for (let i = 0; i < Math.min(8, lines.length); i++) {
            const line = lines[i];
            // Must be at least 3 chars, not purely numeric, not a date, not a known skip word
            if (
                line.length >= 3 &&
                !/^\d+$/.test(line) &&
                !datePatterns.some(re => re.test(line)) &&
                !skipWords.test(line)
            ) {
                result.merchant = line.replace(/[^a-zA-Z0-9\s&'.-]/g, '').trim();
                if (result.merchant.length > 1) break;
            }
        }

        // ---- Line-by-line classification ----
        const NOISE_WORDS = [
            'tel', 'phone', 'fax', 'cashier', 'receipt', 'invoice', 'date', 'time',
            'table', 'pax', 'cash', 'change', 'visa', 'mastercard', 'credit card',
            'debit', 'payment', 'pin', 'approved', 'auth', 'ref no', 'trans',
            'thank', 'welcome', 'address', 'email', 'www', 'http', 'opening', 'hours',
            'return', 'policy', 'member', 'point', 'loyalty', 'staff', 'operator',
            'order', 'check', 'bill no', 'receipt no', 'terminal', 'merchant id',
            'mode', 'nett', 'gst reg'
        ];

        const TOTAL_LABELS = [
            'grand total', 'total amount', 'amount due', 'amount payable',
            'balance due', 'total payable', 'nett total', 'net total', 'total (rm'
        ];
        const SUBTOTAL_LABELS = ['subtotal', 'sub-total', 'sub total', 'items subtotal'];
        const SERVICE_LABELS = ['service charge', 'svc charge', 'svc chg', 'service tax', 'serv chg'];
        const TAX_LABELS = ['gst', 'sst', 'tax', 'vat', 'cukai perkhidmatan'];
        const DISCOUNT_LABELS = ['discount', 'disc', 'promo', 'rebate', 'less'];
        const ROUNDING_LABELS = ['rounding', 'round', 'adj', 'adjustment'];

        let detectedTotal = 0;
        let detectedSubtotal = 0;
        const potentialItems = [];

        for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
            const line = lines[lineIdx];
            const lower = line.toLowerCase();

            // Extract all prices from this line
            const rawPrices = line.match(PRICE_RE);
            if (!rawPrices || rawPrices.length === 0) continue;
            const prices = rawPrices.map(p => toMoney(p)).filter(v => v > 0);
            if (prices.length === 0) continue;

            const lastPrice = prices[prices.length - 1];

            // ---- Classify the line ----

            if (TOTAL_LABELS.some(lbl => lower.includes(lbl))) {
                if (lastPrice > detectedTotal) detectedTotal = lastPrice;
                continue;
            }

            if (SUBTOTAL_LABELS.some(lbl => lower.includes(lbl))) {
                detectedSubtotal = lastPrice;
                continue;
            }

            if (SERVICE_LABELS.some(lbl => lower.includes(lbl))) {
                result.service_charge += lastPrice;
                continue;
            }

            if (TAX_LABELS.some(lbl => lower.includes(lbl))) {
                // Avoid double-counting if tax is listed as a percentage then amount
                if (lastPrice < 100) result.tax += lastPrice;
                continue;
            }

            if (DISCOUNT_LABELS.some(lbl => lower.includes(lbl))) {
                result.discount += lastPrice;
                continue;
            }

            if (ROUNDING_LABELS.some(lbl => lower.includes(lbl))) {
                // Rounding can be negative
                const raw = rawPrices[rawPrices.length - 1];
                result.rounding = raw && raw.includes('-') ? -lastPrice : lastPrice;
                continue;
            }

            // Skip noise lines
            if (NOISE_WORDS.some(n => lower.includes(n))) continue;

            // ---- Item line detection ----
            // Remove price tokens from line to get item name
            let textPart = line;
            rawPrices.forEach(p => { textPart = textPart.replace(p, ' '); });
            textPart = textPart.replace(/[^a-zA-Z0-9\s%\-\/&()'.,*#@!]/g, ' ').replace(/\s{2,}/g, ' ').trim();

            if (textPart.length < 2) continue;

            // Quantity extraction: "2x", "2 X", "2 @", "QTY 2", leading digit
            let qty = 1;
            const qtyMatch = textPart.match(/^(\d+)\s*[xX@*]\s*/);
            if (qtyMatch) {
                qty = parseInt(qtyMatch[1]) || 1;
                textPart = textPart.slice(qtyMatch[0].length).trim();
            } else {
                const leadingNum = textPart.match(/^(\d+)\s+(?=[A-Za-z])/);
                if (leadingNum && parseInt(leadingNum[1]) <= 20) {
                    qty = parseInt(leadingNum[1]);
                    textPart = textPart.slice(leadingNum[0].length).trim();
                }
            }

            if (textPart.length < 2) continue;

            // When receipt shows "item ... unit_price   total", last price is total
            const totalItemPrice = prices.length >= 2 ? prices[prices.length - 1] : lastPrice;
            const unitPrice = parseFloat((totalItemPrice / qty).toFixed(2));

            potentialItems.push({
                name: textPart,
                qty,
                price: unitPrice,
                total: totalItemPrice
            });
        }

        // ---- Consolidate ----
        result.items = potentialItems;

        const computedSubtotal = result.items.reduce((s, i) => s + i.total, 0);
        result.subtotal = detectedSubtotal || parseFloat(computedSubtotal.toFixed(2));

        if (detectedTotal > 0) {
            result.total = detectedTotal;
        } else {
            result.total = parseFloat(
                (result.subtotal - result.discount + result.service_charge + result.tax + result.rounding).toFixed(2)
            );
        }

        return result;
    }
};
