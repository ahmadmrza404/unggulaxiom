/**
 * Personal Bill Splitter - Frontend Localization Dictionary
 * Supports English (en) and Bahasa Melayu (bm)
 */

const AppTranslations = {
    en: {
        // Stepper
        step_upload: 'Upload',
        step_edit: 'Edit',
        step_people: 'People',
        step_assign: 'Assign',
        step_review: 'Review',
        step_share: 'Share',

        // Buttons / Globals
        back: 'Back',
        next: 'Next',
        save: 'Save',
        cancel: 'Cancel',
        delete: 'Delete',
        loading: 'Loading...',

        // Step 1: Upload
        step1_title: 'Scan or Upload Receipt',
        step1_subtitle: 'Upload an image of your receipt. We will process it locally on your device to extract items.',
        dropzone_title: 'Tap to scan or select file',
        dropzone_subtitle: 'Supports JPG, PNG, WEBP, and PDF',
        recent_bills: 'Recent Bills',
        clear_history: 'Clear History',
        demo_title: 'Quick Test / Demo Bills',
        demo_subtitle: "Don't have a receipt on hand? Click a sample to test the calculator instantly.",
        demo_myr: 'Local Cafe (MYR)',
        demo_myr_desc: 'Nasi Lemak, Kopi O, Kaya Toast • RM 27.85',
        demo_sgd: 'Weekend Trip (SGD)',
        demo_sgd_desc: 'Hotel Stay, Car Gas, Attraction Tickets • SGD 220.00',
        skip_ocr: 'Skip OCR / Manual Bill',
        preprocess_title: 'Preprocess Receipt',
        preprocess_subtitle: 'Rotate, crop, and adjust brightness to make the receipt text clearer for OCR.',
        rotate_left: 'Rotate Left',
        rotate_right: 'Rotate Right',
        brightness: 'Brightness',
        contrast: 'Contrast',
        extract_ocr: 'Extract Items (OCR)',

        // Step 2: Edit
        step2_title: 'Review Extracted Bill',
        step2_subtitle: 'Verify and correct the store, currency, items, and taxes. Double click or tap fields to edit.',
        view_receipt: 'View Receipt',
        merchant_store: 'Merchant / Store',
        date: 'Date',
        currency: 'Currency',
        col_qty: 'Qty',
        col_name: 'Item Name',
        col_price: 'Price',
        add_item: 'Add Item',
        travel_expense: 'Travel Expense',
        subtotal: 'Items Subtotal',
        discount: 'Discount',
        service_charge: 'Service Charge',
        tax: 'Tax',
        rounding: 'Rounding Difference',
        grand_total: 'Grand Total',
        no_items: 'No items added yet. Click "+ Add Item" to start.',

        // Step 3: People
        step3_title: 'Add People',
        step3_subtitle: 'Enter the names of everyone sharing the bill. Type their username to link their profile details.',
        add_person: 'Add Person',
        payment_method: 'Preferred Payment Method (For receiving money)',
        payment_details: 'Payment Details / Phone Number',
        bank_name: 'Bank Name',
        bank_account: 'Account Number',

        // Step 4: Assign
        step4_title: 'Assign Items',
        step4_subtitle: 'Tap people to assign items. Change split mode (Equal, %, or Shares) for uneven divisions.',
        assign_all: 'Assign All',
        clear_all: 'Clear All',
        each: 'each',

        // Step 5: Review
        step5_title: 'Review Split Shares',
        step5_subtitle: 'Verify each person\'s final calculated share, and choose how taxes/discounts are distributed.',
        tax_svc_dist: 'Tax & Service Distribution',
        disc_dist: 'Discount Distribution',
        proportional: 'Proportional',
        equally: 'Equally',
        running_totals: 'Running Totals',

        // Step 6: Share
        step6_title: 'Share Split Summary',
        step6_subtitle: 'Perfect! The bill has been split successfully. You can copy the text summary or share it directly.',
        copy_summary: 'Copy Summary Text',
        share_whatsapp: 'Share to WhatsApp',
        download_csv: 'Download CSV',
        print_bill: 'Print Bill',
        restart: 'Restart Wizard',
        trip_breakdown: 'Trip Cost Breakdown',

        // Toast messages
        toast_ocr_success: 'Receipt parsed successfully!',
        toast_ocr_failed: 'OCR failed. Please enter items manually.',
        toast_copied: 'Summary copied to clipboard!',
        toast_history_cleared: 'History cleared.',
        toast_sample_myr: 'Local Cafe MYR Sample Loaded!',
        toast_sample_sgd: 'Weekend Trip SGD Sample Loaded!',
        toast_validation_unassigned: 'Warning: Some items have no people assigned.',
        toast_validation_total_mismatch: 'Warning: Sum of splits does not match grand total.'
    },
    bm: {
        // Stepper
        step_upload: 'Muat Naik',
        step_edit: 'Edit',
        step_people: 'Ahli',
        step_assign: 'Agih',
        step_review: 'Semak',
        step_share: 'Kongsi',

        // Buttons / Globals
        back: 'Kembali',
        next: 'Seterusnya',
        save: 'Simpan',
        cancel: 'Batal',
        delete: 'Padam',
        loading: 'Memuatkan...',

        // Step 1: Upload
        step1_title: 'Imbas atau Muat Naik Resit',
        step1_subtitle: 'Muat naik imej resit anda. Kami akan memprosesnya secara lokal pada peranti anda untuk mengekstrak barang.',
        dropzone_title: 'Ketik untuk imbas atau pilih fail',
        dropzone_subtitle: 'Menyokong JPG, PNG, WEBP, dan PDF',
        recent_bills: 'Resit Semasa',
        clear_history: 'Padam Sejarah',
        demo_title: 'Ujian Pantas / Resit Demo',
        demo_subtitle: 'Tiada resit di tangan? Klik contoh untuk menguji kalkulator serta-merta.',
        demo_myr: 'Kafe Tempatan (MYR)',
        demo_myr_desc: 'Nasi Lemak, Kopi O, Kaya Toast • RM 27.85',
        demo_sgd: 'Percutian Hujung Minggu (SGD)',
        demo_sgd_desc: 'Penginapan Hotel, Gas Kenderaan, Tiket Tarikan • SGD 220.00',
        skip_ocr: 'Langkau OCR / Bil Manual',
        preprocess_title: 'Pra-proses Resit',
        preprocess_subtitle: 'Putar, potong, dan laraskan kecerahan untuk menjadikan teks resit lebih jelas untuk OCR.',
        rotate_left: 'Putar Kiri',
        rotate_right: 'Putar Kanan',
        brightness: 'Kecerahan',
        contrast: 'Kontras',
        extract_ocr: 'Ekstrak Barang (OCR)',

        // Step 2: Edit
        step2_title: 'Semak Bil yang Diekstrak',
        step2_subtitle: 'Sahkan dan betulkan nama kedai, mata wang, barang, dan cukai. Ketik dua kali pada ruangan untuk edit.',
        view_receipt: 'Lihat Resit',
        merchant_store: 'Kedai / Peniaga',
        date: 'Tarikh',
        currency: 'Mata Wang',
        col_qty: 'Kuantiti',
        col_name: 'Nama Barang',
        col_price: 'Harga',
        add_item: 'Tambah Barang',
        travel_expense: 'Belanja Perjalanan',
        subtotal: 'Jumlah Kecil Barang',
        discount: 'Diskaun',
        service_charge: 'Caj Perkhidmatan',
        tax: 'Cukai',
        rounding: 'Perbezaan Penggenapan',
        grand_total: 'Jumlah Keseluruhan',
        no_items: 'Tiada barang ditambah lagi. Klik "+ Tambah Barang" untuk mulakan.',

        // Step 3: People
        step3_title: 'Tambah Ahli',
        step3_subtitle: 'Masukkan nama setiap orang yang berkongsi bil. Taip nama pengguna mereka untuk menghubungkan butiran profil.',
        add_person: 'Tambah Ahli',
        payment_method: 'Kaedah Pembayaran Pilihan (Untuk menerima wang)',
        payment_details: 'Butiran Pembayaran / Nombor Telefon',
        bank_name: 'Nama Bank',
        bank_account: 'Nombor Akaun',

        // Step 4: Assign
        step4_title: 'Agihkan Barang',
        step4_subtitle: 'Ketik pada nama ahli untuk mengagihkan barang. Tukar mod pembahagian (Sama Rata, %, atau Syer) untuk pembahagian tidak sama rata.',
        assign_all: 'Agih Semua',
        clear_all: 'Kosongkan Semua',
        each: 'setiap satu',

        // Step 5: Review
        step5_title: 'Semak Syer Pembahagian',
        step5_subtitle: 'Sahkan syer akhir yang dikira untuk setiap orang, dan pilih bagaimana cukai/diskaun diagihkan.',
        tax_svc_dist: 'Pengagihan Cukai & Perkhidmatan',
        disc_dist: 'Pengagihan Diskaun',
        proportional: 'Berkadar (Proportional)',
        equally: 'Sama Rata (Equally)',
        running_totals: 'Jumlah Berjalan',

        // Step 6: Share
        step6_title: 'Kongsi Ringkasan Bil',
        step6_subtitle: 'Hebat! Bil telah berjaya dibahagikan. Anda boleh menyalin ringkasan teks atau berkongsi secara terus.',
        copy_summary: 'Salin Teks Ringkasan',
        share_whatsapp: 'Kongsi ke WhatsApp',
        download_csv: 'Muat Turun CSV',
        print_bill: 'Cetak Bil',
        restart: 'Mula Semula',
        trip_breakdown: 'Pecahan Kos Percutian',

        // Toast messages
        toast_ocr_success: 'Resit berjaya diproses!',
        toast_ocr_failed: 'OCR gagal. Sila masukkan butiran secara manual.',
        toast_copied: 'Ringkasan telah disalin ke papan klip!',
        toast_history_cleared: 'Sejarah dipadam.',
        toast_sample_myr: 'Contoh MYR Kafe Tempatan Dimuatkan!',
        toast_sample_sgd: 'Contoh SGD Percutian Dimuatkan!',
        toast_validation_unassigned: 'Amaran: Beberapa barang belum diagihkan kepada sesiapa.',
        toast_validation_total_mismatch: 'Amaran: Jumlah syer tidak sepadan dengan jumlah keseluruhan.'
    }
};

/**
 * Client-side translation helper
 */
const __ = (key) => {
    // Read active language from cookie
    const getCookie = (name) => {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return 'en';
    };
    const lang = getCookie('lang') || 'en';
    return AppTranslations[lang]?.[key] || AppTranslations['en']?.[key] || key;
};
window.__ = __;
