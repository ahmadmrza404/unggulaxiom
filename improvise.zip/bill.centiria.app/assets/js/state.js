/**
 * Personal Bill Splitter - App State (Model)
 */

const AppState = {
    state: {
        id: null,
        step: 1,
        merchant: '',
        date: '',
        currency: 'MYR',
        exchangeRate: 1.000000,
        isForeign: false,
        items: [],          // Array of { id, name, qty, price, assignedPeople: [], splitMode: 'equal', splits: {} }
        people: [],         // Array of { id, name }
        discount: 0.00,
        serviceCharge: 0.00,
        tax: 0.00,
        rounding: 0.00,
        grandTotal: 0.00,
        taxDistribution: 'proportional',
        discountDistribution: 'proportional',
        
        paymentMethod: 'none',
        paymentDetails: '',
        bankName: '',
        bankAccount: '',
        
        // Image Processing State
        originalImgSrc: null,
        brightness: 100,
        contrast: 100,
        rotation: 0,
        creatorProfile: null
    },

    calculationResults: null,

    reset() {
        this.state.id = null;
        this.state.step = 1;
        this.state.merchant = '';
        this.state.date = '';
        this.state.currency = 'MYR';
        this.state.exchangeRate = 1.000000;
        this.state.isForeign = false;
        this.state.items = [];
        this.state.people = [];
        this.state.discount = 0.00;
        this.state.serviceCharge = 0.00;
        this.state.tax = 0.00;
        this.state.rounding = 0.00;
        this.state.grandTotal = 0.00;
        this.state.taxDistribution = 'proportional';
        this.state.discountDistribution = 'proportional';
        this.state.paymentMethod = 'none';
        this.state.paymentDetails = '';
        this.state.bankName = '';
        this.state.bankAccount = '';
        this.state.originalImgSrc = null;
        this.state.brightness = 100;
        this.state.contrast = 100;
        this.state.rotation = 0;
        this.state.creatorProfile = null;
        this.calculationResults = null;
    },

    loadSample(type) {
        this.reset();
        this.state.date = new Date().toISOString().split('T')[0];
        
        if (type === 'MYR') {
            this.state.merchant = 'Kopitiam Corner';
            this.state.currency = 'MYR';
            this.state.isForeign = false;
            this.state.items = [
                { id: `item_myr_${Date.now()}_1`, name: 'Nasi Lemak', qty: 1, price: 12.50, assignedPeople: [], splitMode: 'equal', splits: {}, category: 'food' },
                { id: `item_myr_${Date.now()}_2`, name: 'Kopi O', qty: 2, price: 3.50, assignedPeople: [], splitMode: 'equal', splits: {}, category: 'food' },
                { id: `item_myr_${Date.now()}_3`, name: 'Kaya Toast', qty: 1, price: 4.50, assignedPeople: [], splitMode: 'equal', splits: {}, category: 'food' }
            ];
            this.state.serviceCharge = 2.40;
            this.state.tax = 1.44;
            this.state.rounding = 0.01;
            this.state.grandTotal = 27.85;
        } else if (type === 'SGD') {
            this.state.merchant = 'Singapore Weekend Getaway';
            this.state.currency = 'SGD';
            this.state.isForeign = true;
            this.state.items = [
                { id: `item_sgd_${Date.now()}_1`, name: 'Hotel Stay (Hilton)', qty: 1, price: 120.00, assignedPeople: [], splitMode: 'equal', splits: {}, category: 'lodging' },
                { id: `item_sgd_${Date.now()}_2`, name: 'Fuel & Highway Toll', qty: 1, price: 50.00, assignedPeople: [], splitMode: 'equal', splits: {}, category: 'transport' },
                { id: `item_sgd_${Date.now()}_3`, name: 'Theme Park Tickets', qty: 1, price: 50.00, assignedPeople: [], splitMode: 'equal', splits: {}, category: 'activity' }
            ];
            this.state.grandTotal = 220.00;
        }
    },

    async saveToDatabase() {
        try {
            const results = Calculator.calculateSplit(this.state);
            const payload = {
                ...this.state,
                people: this.state.people.map(p => {
                    const calcPerson = results.people.find(cp => cp.id === p.id);
                    return {
                        id: p.id,
                        name: p.name,
                        userId: p.userId || null,
                        username: p.username || null,
                        total_owed: calcPerson ? calcPerson.total : 0.00
                    };
                })
            };

            const csrfMeta = document.querySelector('meta[name="csrf-token"]');
            const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
            const res = await fetch('api/save_bill.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken
                },
                body: JSON.stringify(payload)
            });
            const data = await res.json();
            if (!data.success) {
                console.warn("DB save failed: ", data.error);
            } else {
                console.log("📂 Bill split saved to database successfully.");
            }
        } catch (e) {
            console.warn("Could not save split to database: ", e);
        }
    },

    saveToHistory() {
        if (!this.state.id) {
            this.state.id = Utils.generateId();
        }
        
        const historyItem = {
            id: this.state.id,
            timestamp: Date.now(),
            merchant: this.state.merchant,
            date: this.state.date,
            currency: this.state.currency,
            exchangeRate: this.state.exchangeRate,
            isForeign: this.state.isForeign,
            items: this.state.items.map(i => ({
                id: i.id,
                name: i.name,
                qty: i.qty,
                price: i.price,
                assignedPeople: [...i.assignedPeople],
                splitMode: i.splitMode,
                splits: i.splits ? {...i.splits} : {},
                category: i.category || 'food'
            })),
            people: this.state.people.map(p => ({ id: p.id, name: p.name, userId: p.userId || null, username: p.username || null })),
            discount: this.state.discount,
            serviceCharge: this.state.serviceCharge,
            tax: this.state.tax,
            rounding: this.state.rounding,
            grandTotal: this.state.grandTotal,
            taxDistribution: this.state.taxDistribution,
            discountDistribution: this.state.discountDistribution,
            convertedGrandTotal: this.calculationResults ? this.calculationResults.myrGrandTotal : this.state.grandTotal
        };
        
        let history = Utils.storageGet('bill_history', []);
        history = history.filter(item => item.id !== this.state.id);
        history.unshift(historyItem);
        history = history.slice(0, 10);
        
        Utils.storageSet('bill_history', history);
        this.saveToDatabase();
    },

    hydrateFromData(bill, creatorProfile = null) {
        this.state.id = bill.id;
        this.state.merchant = bill.merchant || '';
        this.state.date = bill.date || '';
        this.state.currency = bill.currency || 'MYR';
        this.state.exchangeRate = parseFloat(bill.exchangeRate) || 1.00;
        this.state.isForeign = (this.state.currency !== 'MYR');
        
        this.state.items = (bill.items || []).map(i => ({
            id: i.id,
            name: i.name,
            qty: parseInt(i.qty) || 1,
            price: parseFloat(i.price) || 0,
            assignedPeople: [...i.assignedPeople],
            splitMode: i.splitMode,
            splits: i.splits ? {...i.splits} : {},
            category: i.category || 'food'
        }));
        
        this.state.people = (bill.people || []).map(p => ({
            id: p.id,
            name: p.name,
            userId: p.userId ? parseInt(p.userId) : null,
            username: p.username || null
        }));
        
        this.state.discount = parseFloat(bill.discount) || 0;
        this.state.serviceCharge = parseFloat(bill.serviceCharge) || 0;
        this.state.tax = parseFloat(bill.tax) || 0;
        this.state.rounding = parseFloat(bill.rounding) || 0;
        this.state.grandTotal = parseFloat(bill.grandTotal) || 0;
        this.state.taxDistribution = bill.taxDistribution || 'proportional';
        this.state.discountDistribution = bill.discountDistribution || 'proportional';
        
        if (creatorProfile) {
            this.state.creatorProfile = creatorProfile;
            const cp = creatorProfile;
            const normalizedQrType = cp.qrType === 'scanned' ? 'tng' : cp.qrType;
            if (normalizedQrType && normalizedQrType !== 'none') {
                this.state.paymentMethod = normalizedQrType;
                this.state.paymentDetails = cp.qrValue;
            } else if (cp.bankName && cp.accountNumber) {
                this.state.paymentMethod = 'bank';
                this.state.bankName = cp.bankName;
                this.state.bankAccount = cp.accountNumber;
            }
        }
    }
};
