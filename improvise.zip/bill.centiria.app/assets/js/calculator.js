/**
 * Personal Bill Splitter Calculations Engine
 * Uses decimal-safe scaling (4 decimal places internally) to avoid float issues.
 */

const Calculator = {
    /**
     * Get display decimal places for a currency code.
     */
    getDecimalPlaces(currency) {
        const zeroDecimalCurrencies = ['JPY', 'KRW', 'CLP', 'VND', 'PYG'];
        return zeroDecimalCurrencies.includes(currency.toUpperCase()) ? 0 : 2;
    },

    /**
     * Scale a float value to high-precision integer (4 decimal places).
     */
    scale(val) {
        if (typeof val !== 'number' || isNaN(val)) val = 0;
        return Math.round(val * 10000);
    },

    /**
     * Unscale a high-precision integer back to float.
     */
    unscale(val) {
        return val / 10000;
    },

    /**
     * Round a scaled value to the currency's decimal places, returning a scaled value.
     */
    roundToCurrencyScale(scaledVal, decimals) {
        const factor = Math.pow(10, 4 - decimals);
        return Math.round(scaledVal / factor) * factor;
    },

    /**
     * Performs complete bill split calculation.
     *
     * @param {Object} billState
     * @returns {Object} Calculated results
     */
    calculateSplit(billState) {
        const {
            currency = 'MYR',
            items = [],
            people = [],
            discount = 0,
            serviceCharge = 0,
            tax = 0,
            rounding = 0,
            grandTotal = 0,
            taxDistribution = 'proportional',
            discountDistribution = 'proportional',
            exchangeRate = 1.0
        } = billState;

        const decimals = this.getDecimalPlaces(currency);
        const hasPeople = people.length > 0;

        // 1. Scale input numbers to avoid floating point issues
        const scaledDiscount = this.scale(discount);
        const scaledServiceCharge = this.scale(serviceCharge);
        const scaledTax = this.scale(tax);
        const scaledRounding = this.scale(rounding);
        const scaledGrandTotal = this.scale(grandTotal);
        const scaledExchangeRate = this.scale(exchangeRate); // 1.0000 -> 10000

        // Initialize results structure
        const resultPeople = people.map(p => ({
            id: p.id,
            name: p.name,
            items: [],          // items assigned to them
            itemSubtotal: 0,    // scaled sum of item shares
            discountShare: 0,   // scaled discount portion
            serviceShare: 0,    // scaled service charge portion
            taxShare: 0,        // scaled tax portion
            roundingShare: 0,   // scaled receipt rounding portion
            roundingAdjustment: 0, // scaled final adjustment
            total: 0,           // final unscaled currency amount
            totalMYR: 0         // final unscaled MYR amount
        }));

        const peopleMap = {};
        resultPeople.forEach(p => { peopleMap[p.id] = p; });

        let scaledCalculatedSubtotal = 0;
        const unassignedItems = [];

        // 2. Distribute each item
        items.forEach(item => {
            const itemPrice = parseFloat(item.price) || 0;
            const itemQty = parseInt(item.qty) || 1;
            const itemTotal = itemPrice * itemQty;
            const scaledItemTotal = this.scale(itemTotal);

            const assigned = item.assignedPeople || [];
            
            if (assigned.length === 0 || !hasPeople) {
                unassignedItems.push(item);
                return;
            }

            // Calculate shares
            const shares = {}; // maps personId to scaled portion of this item
            
            if (item.splitMode === 'percent') {
                let totalPct = 0;
                assigned.forEach(pid => {
                    const pct = parseFloat(item.splits?.[pid]) || 0;
                    totalPct += pct;
                });
                
                assigned.forEach(pid => {
                    const pct = parseFloat(item.splits?.[pid]) || 0;
                    const portion = totalPct > 0 ? pct / totalPct : 0;
                    shares[pid] = Math.round(scaledItemTotal * portion);
                });
            } else if (item.splitMode === 'share') {
                let totalShares = 0;
                assigned.forEach(pid => {
                    const sh = parseFloat(item.splits?.[pid]) || 0;
                    totalShares += sh;
                });
                
                assigned.forEach(pid => {
                    const sh = parseFloat(item.splits?.[pid]) || 0;
                    const portion = totalShares > 0 ? sh / totalShares : 0;
                    shares[pid] = Math.round(scaledItemTotal * portion);
                });
            } else {
                // Default: Equal Split
                const portion = 1 / assigned.length;
                assigned.forEach(pid => {
                    shares[pid] = Math.round(scaledItemTotal * portion);
                });
            }

            // Correct item rounding (sum of shares must equal item total)
            let sharesSum = 0;
            Object.values(shares).forEach(s => { sharesSum += s; });
            const itemDiff = scaledItemTotal - sharesSum;
            if (itemDiff !== 0 && assigned.length > 0) {
                // Adjust first person's share
                shares[assigned[0]] += itemDiff;
            }

            // Add shares to people
            assigned.forEach(pid => {
                const person = peopleMap[pid];
                if (person) {
                    const shareVal = this.unscale(shares[pid]);
                    person.items.push({
                        id: item.id,
                        name: item.name,
                        qty: itemQty,
                        shareTotal: shareVal
                    });
                    person.itemSubtotal += shares[pid];
                    scaledCalculatedSubtotal += shares[pid];
                }
            });
        });

        // Identify active people (people who have at least one item assigned)
        const activePeople = resultPeople.filter(p => p.itemSubtotal > 0);

        // 3. Distribute extra charges
        resultPeople.forEach(person => {
            let taxRatio = 0;
            let discountRatio = 0;

            // Service + Tax distribution
            if (taxDistribution === 'proportional') {
                taxRatio = scaledCalculatedSubtotal > 0 ? person.itemSubtotal / scaledCalculatedSubtotal : 0;
            } else if (taxDistribution === 'equal' && hasPeople) {
                taxRatio = 1 / people.length;
            } else if (taxDistribution === 'equal_assigned' && activePeople.length > 0) {
                taxRatio = person.itemSubtotal > 0 ? 1 / activePeople.length : 0;
            }

            // Discount distribution
            if (discountDistribution === 'proportional') {
                discountRatio = scaledCalculatedSubtotal > 0 ? person.itemSubtotal / scaledCalculatedSubtotal : 0;
            } else if (discountDistribution === 'equal' && hasPeople) {
                discountRatio = 1 / people.length;
            } else if (discountDistribution === 'equal_assigned' && activePeople.length > 0) {
                discountRatio = person.itemSubtotal > 0 ? 1 / activePeople.length : 0;
            }

            person.serviceShare = Math.round(scaledServiceCharge * taxRatio);
            person.taxShare = Math.round(scaledTax * taxRatio);
            person.discountShare = Math.round(scaledDiscount * discountRatio);
            person.roundingShare = Math.round(scaledRounding * taxRatio); // distribute receipt rounding proportionally/equally
        });

        // Correct extra charges sums
        const adjustExtraCharge = (field, targetScaledVal) => {
            let sum = 0;
            resultPeople.forEach(p => { sum += p[field]; });
            const diff = targetScaledVal - sum;
            if (diff !== 0 && activePeople.length > 0) {
                activePeople[0][field] += diff;
            } else if (diff !== 0 && resultPeople.length > 0) {
                resultPeople[0][field] += diff;
            }
        };

        adjustExtraCharge('serviceShare', scaledServiceCharge);
        adjustExtraCharge('taxShare', scaledTax);
        adjustExtraCharge('discountShare', scaledDiscount);
        adjustExtraCharge('roundingShare', scaledRounding);

        // 4. Calculate raw person totals and round to currency decimals
        let roundedSum = 0;
        resultPeople.forEach(person => {
            const rawTotal = person.itemSubtotal - person.discountShare + person.serviceShare + person.taxShare + person.roundingShare;
            // Round in scaled units
            const roundedScaled = this.roundToCurrencyScale(rawTotal, decimals);
            person.total = this.unscale(roundedScaled);
            roundedSum += roundedScaled;
        });

        // 5. Apply final rounding correction so sum of individuals equals receipt grand total exactly
        const finalDiff = scaledGrandTotal - roundedSum;
        if (finalDiff !== 0) {
            // Find person to apply adjustment: highest share, or first active, or first person
            const targetPerson = activePeople.length > 0 ? activePeople[0] : (resultPeople.length > 0 ? resultPeople[0] : null);
            if (targetPerson) {
                targetPerson.roundingAdjustment = finalDiff;
                const newScaledTotal = this.scale(targetPerson.total) + finalDiff;
                targetPerson.total = this.unscale(newScaledTotal);
            }
        }

        // 6. Currency Conversion to MYR if applicable
        const isForeign = currency.toUpperCase() !== 'MYR';
        let myrGrandTotal = 0;
        
        if (isForeign) {
            // Unscaled exchange rate float
            const rate = exchangeRate;
            
            // Expected grand total in MYR
            const targetMyrGrandTotal = Math.round(grandTotal * rate * 100) / 100; // MYR is 2 decimals
            myrGrandTotal = targetMyrGrandTotal;

            let myrSum = 0;
            resultPeople.forEach(person => {
                // Direct multiply and round to 2 decimals
                const personMyrTotal = Math.round(person.total * rate * 100) / 100;
                person.totalMYR = personMyrTotal;
                myrSum += Math.round(personMyrTotal * 100);
            });

            // Adjust converted MYR differences
            const targetMyrGrandTotalScaled = Math.round(targetMyrGrandTotal * 100);
            const myrDiffScaled = targetMyrGrandTotalScaled - myrSum;
            
            if (myrDiffScaled !== 0) {
                const targetPerson = activePeople.length > 0 ? activePeople[0] : (resultPeople.length > 0 ? resultPeople[0] : null);
                if (targetPerson) {
                    const adjustment = myrDiffScaled / 100;
                    targetPerson.totalMYR = Math.round((targetPerson.totalMYR + adjustment) * 100) / 100;
                }
            }
        } else {
            resultPeople.forEach(person => {
                person.totalMYR = person.total;
            });
            myrGrandTotal = grandTotal;
        }

        // 7. Validation and warnings
        const warnings = [];
        if (unassignedItems.length > 0) {
            warnings.push(`${unassignedItems.length} item(s) are not assigned to anyone.`);
        }
        
        // Check if item totals match grand total
        let itemsSum = 0;
        items.forEach(item => {
            itemsSum += (parseFloat(item.price) || 0) * (parseInt(item.qty) || 1);
        });
        const expectedTotal = itemsSum - discount + serviceCharge + tax + rounding;
        if (Math.abs(expectedTotal - grandTotal) > 0.02) {
            warnings.push(`The sum of items + taxes - discount (${expectedTotal.toFixed(2)}) does not match the entered Grand Total (${grandTotal.toFixed(2)}).`);
        }

        return {
            people: resultPeople,
            unassignedItems,
            warnings,
            originalSubtotal: this.unscale(scaledCalculatedSubtotal),
            myrGrandTotal
        };
    }
};
