<?php
/**
 * Personal Bill Splitter - Advanced Admin Panel Dashboard
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
requireAdmin();

// Handle GET Admin Actions (Downloads and Details)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
    $action = $_GET['action'];
    if ($action === 'get_user_details') {
        $token = isset($_GET['csrf_token']) ? $_GET['csrf_token'] : '';
        if (!validateCSRFToken($token)) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Invalid CSRF token']);
            exit;
        }
        
        $targetId = intval($_GET['id']);
        try {
            header('Content-Type: application/json');
            $stmt = $db->prepare("SELECT id, username, display_name, email, qr_type, qr_value, bio, telegram, phone, created_at FROM users WHERE id = ?");
            $stmt->execute([$targetId]);
            $userData = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($userData) {
                $stmtBank = $db->prepare("SELECT bank_name, account_name, account_number, is_preferred FROM user_banks WHERE user_id = ?");
                $stmtBank->execute([$targetId]);
                $banks = $stmtBank->fetchAll(PDO::FETCH_ASSOC);
                
                $stmtBills = $db->prepare("SELECT id, merchant, grand_total, currency, created_at FROM bills WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
                $stmtBills->execute([$targetId]);
                $bills = $stmtBills->fetchAll(PDO::FETCH_ASSOC);
                
                echo json_encode([
                    'success' => true,
                    'user' => $userData,
                    'banks' => $banks,
                    'bills' => $bills
                ]);
                exit;
            } else {
                echo json_encode(['success' => false, 'error' => 'User not found']);
                exit;
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            exit;
        }
    }
    
    if (in_array($action, ['export_users', 'export_bills', 'export_logs', 'download_db_backup'])) {
        $token = isset($_GET['csrf_token']) ? $_GET['csrf_token'] : '';
        if (!validateCSRFToken($token)) {
            http_response_code(403);
            echo "<h1>403 Forbidden</h1><p>Invalid or missing CSRF token.</p>";
            exit;
        }
        
        // Handle GET Admin Actions
        if ($action === 'export_users') {
            try {
                header('Content-Type: text/csv; charset=utf-8');
                header('Content-Disposition: attachment; filename="users_report_' . date('Ymd') . '.csv"');
                $output = fopen('php://output', 'w');
                fputcsv($output, ['ID', 'Username', 'Display Name', 'Email', 'Role', 'Last Active', 'Created At']);
                
                $stmt = $db->query("SELECT id, username, display_name, email, role, last_active, created_at FROM users ORDER BY id ASC");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    fputcsv($output, $row);
                }
                fclose($output);
                logActivity('admin_export_users', "Exported user directory report as CSV");
                exit;
            } catch (Exception $e) {
                http_response_code(500);
                echo "Export failed: " . $e->getMessage();
                exit;
            }
        } elseif ($action === 'export_bills') {
            try {
                header('Content-Type: text/csv; charset=utf-8');
                header('Content-Disposition: attachment; filename="splits_report_' . date('Ymd') . '.csv"');
                $output = fopen('php://output', 'w');
                fputcsv($output, ['Bill ID', 'Creator Username', 'Merchant / Store', 'Bill Date', 'Currency', 'Grand Total', 'Created At']);
                
                $stmt = $db->query("
                    SELECT b.id, u.username, b.merchant, b.bill_date, b.currency, b.grand_total, b.created_at 
                    FROM bills b
                    JOIN users u ON b.user_id = u.id
                    ORDER BY b.id ASC
                ");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    fputcsv($output, $row);
                }
                fclose($output);
                logActivity('admin_export_bills', "Exported global bill splits report as CSV");
                exit;
            } catch (Exception $e) {
                http_response_code(500);
                echo "Export failed: " . $e->getMessage();
                exit;
            }
        } elseif ($action === 'export_logs') {
            try {
                header('Content-Type: text/csv; charset=utf-8');
                header('Content-Disposition: attachment; filename="activity_audit_logs_' . date('Ymd') . '.csv"');
                $output = fopen('php://output', 'w');
                fputcsv($output, ['Log ID', 'User ID', 'Username', 'Action', 'Details', 'IP Address', 'Timestamp']);
                
                $stmt = $db->query("SELECT id, user_id, username, action, details, ip_address, created_at FROM activity_logs ORDER BY created_at DESC");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    fputcsv($output, $row);
                }
                fclose($output);
                logActivity('admin_export_logs', "Exported system activity audit trail logs as CSV");
                exit;
            } catch (Exception $e) {
                http_response_code(500);
                echo "Export failed: " . $e->getMessage();
                exit;
            }
        } elseif ($action === 'download_db_backup') {
            try {
                $sql = "-- BillSplitter Database Backup\n";
                $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
                $sql .= "-- Database: " . $config['db_name'] . "\n\n";
                
                $sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
                
                $tables = [];
                $stmt = $db->query("SHOW TABLES");
                while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
                    $tables[] = $row[0];
                }
                
                foreach ($tables as $table) {
                    $stmtCreate = $db->query("SHOW CREATE TABLE `" . $table . "`");
                    $createRow = $stmtCreate->fetch(PDO::FETCH_NUM);
                    $sql .= "\n\n-- Table structure for table `" . $table . "`\n";
                    $sql .= "DROP TABLE IF EXISTS `" . $table . "`;\n";
                    $sql .= $createRow[1] . ";\n\n";
                    
                    $stmtData = $db->query("SELECT * FROM `" . $table . "`");
                    $sql .= "-- Dumping data for table `" . $table . "`\n";
                    $rowCount = 0;
                    while ($dataRow = $stmtData->fetch(PDO::FETCH_ASSOC)) {
                        if ($rowCount === 0) {
                            $sql .= "INSERT INTO `" . $table . "` (";
                            $cols = array_keys($dataRow);
                            $sql .= implode(", ", array_map(function($c) { return "`" . $c . "`"; }, $cols));
                            $sql .= ") VALUES\n";
                        } else {
                            $sql .= ",\n";
                        }
                        
                        $vals = [];
                        foreach ($dataRow as $val) {
                            if ($val === null) {
                                $vals[] = "NULL";
                            } else {
                                $vals[] = $db->quote($val);
                            }
                        }
                        $sql .= "(" . implode(", ", $vals) . ")";
                        $rowCount++;
                    }
                    if ($rowCount > 0) {
                        $sql .= ";\n";
                    }
                }
                
                $sql .= "\nSET FOREIGN_KEY_CHECKS=1;\n";
                
                header('Content-Type: application/sql; charset=utf-8');
                header('Content-Disposition: attachment; filename="billsplitter_db_backup_' . date('Ymd_His') . '.sql');
                header('Pragma: no-cache');
                header('Expires: 0');
                echo $sql;
                logActivity('admin_db_backup', "Created and downloaded a full SQL database backup");
                exit;
            } catch (Exception $e) {
                http_response_code(500);
                echo "Database backup failed: " . $e->getMessage();
                exit;
            }
        }
    }
}

// Validate CSRF for admin POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
    if (!validateCSRFToken($token)) {
        http_response_code(403);
        echo "<h1>403 Forbidden</h1><p>Invalid or missing CSRF token.</p>";
        exit;
    }
}

$dbError = null;
$successMessage = null;
$stats = ['users' => 0, 'bills' => 0, 'storage_qrs' => 0, 'storage_profiles' => 0, 'db_size' => 'Unknown'];
$usersList = [];
$billsList = [];
$logsList = [];
$settings = [];

// Handle Admin Operations
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'toggle_role') {
        $targetId = intval($_POST['target_id']);
        $newRole = $_POST['role'] === 'admin' ? 'user' : 'admin';
        
        // Prevent changing own role
        if ($targetId !== $_SESSION['user_id']) {
            try {
                $stmt = $db->prepare("UPDATE users SET role = ? WHERE id = ?");
                $stmt->execute([$newRole, $targetId]);
                
                logActivity('admin_toggle_role', "Updated user ID {$targetId} privilege to {$newRole}");
                $successMessage = "User role updated successfully.";
            } catch (PDOException $e) {
                $dbError = "Failed to update role: " . $e->getMessage();
            }
        }
    } elseif ($action === 'delete_user') {
        $targetId = intval($_POST['target_id']);
        
        // Prevent deleting self
        if ($targetId !== $_SESSION['user_id']) {
            try {
                // Fetch user info first for logging
                $stmtInfo = $db->prepare("SELECT username, profile_pic, qr_image FROM users WHERE id = ?");
                $stmtInfo->execute([$targetId]);
                $targetUser = $stmtInfo->fetch();
                
                if ($targetUser) {
                    if (!empty($targetUser['profile_pic'])) {
                        @unlink(STORAGE_DIR . '/profiles/' . $targetUser['profile_pic']);
                    }
                    if (!empty($targetUser['qr_image'])) {
                        @unlink(STORAGE_DIR . '/qrs/' . $targetUser['qr_image']);
                    }
                    
                    $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
                    $stmt->execute([$targetId]);
                    
                    logActivity('admin_delete_user', "Deleted user account @{$targetUser['username']} (ID {$targetId})");
                    $successMessage = "User and all their associated splits/files deleted successfully.";
                }
            } catch (PDOException $e) {
                $dbError = "Failed to delete user: " . $e->getMessage();
            }
        }
    } elseif ($action === 'create_user') {
        $newUsername = trim($_POST['new_username']);
        $newPassword = trim($_POST['new_password']);
        $newRole = $_POST['new_role'] === 'admin' ? 'admin' : 'user';

        if (!empty($newUsername) && !empty($newPassword)) {
            try {
                $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
                $stmt->execute([$newUsername]);
                if ($stmt->fetch()) {
                    $dbError = "Username is already taken.";
                } else {
                    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                    $stmt = $db->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
                    $stmt->execute([$newUsername, $hash, $newRole]);
                    
                    logActivity('admin_create_user', "Created manual user account: @{$newUsername} as {$newRole}");
                    $successMessage = "User account @{$newUsername} created successfully.";
                }
            } catch (PDOException $e) {
                $dbError = "Failed to create user: " . $e->getMessage();
            }
        }
    } elseif ($action === 'reset_password') {
        $targetId = intval($_POST['target_id']);
        $newPassword = trim($_POST['new_password']);
        
        if (strlen($newPassword) >= 6) {
            try {
                // Fetch target username for logging
                $stmtName = $db->prepare("SELECT username FROM users WHERE id = ?");
                $stmtName->execute([$targetId]);
                $targetUsername = $stmtName->fetchColumn();
                
                $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                $stmt->execute([$hash, $targetId]);
                
                logActivity('admin_reset_password', "Reset account password for user @{$targetUsername}");
                $successMessage = "Password reset successfully.";
            } catch (PDOException $e) {
                $dbError = "Failed to reset password: " . $e->getMessage();
            }
        } else {
            $dbError = "Password must be at least 6 characters.";
        }
    } elseif ($action === 'edit_user') {
        $targetId = intval($_POST['target_id']);
        $displayName = trim($_POST['display_name']);
        $email = trim($_POST['email']);
        
        try {
            $stmt = $db->prepare("UPDATE users SET display_name = ?, email = ? WHERE id = ?");
            $stmt->execute([$displayName ?: null, $email ?: null, $targetId]);
            
            $stmtName = $db->prepare("SELECT username FROM users WHERE id = ?");
            $stmtName->execute([$targetId]);
            $targetUsername = $stmtName->fetchColumn();
            
            logActivity('admin_edit_user', "Updated profile details for user @{$targetUsername} (ID {$targetId})");
            $successMessage = "User profile updated successfully.";
        } catch (PDOException $e) {
            $dbError = "Failed to update profile: " . $e->getMessage();
        }
    } elseif ($action === 'update_settings') {
        $allowReg = isset($_POST['allow_registration']) ? '1' : '0';
        $mMode = isset($_POST['maintenance_mode']) ? '1' : '0';
        $defCurr = trim($_POST['default_currency']);
        
        try {
            $stmt = $db->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = ?");
            $stmt->execute([$allowReg, 'allow_registration']);
            $stmt->execute([$mMode, 'maintenance_mode']);
            $stmt->execute([$defCurr, 'default_currency']);
            
            logActivity('admin_update_settings', "Updated global platform settings: Maintenance Mode={$mMode}, Allow Registration={$allowReg}, Default Currency={$defCurr}");
            $successMessage = "Global platform configurations updated successfully.";
        } catch (PDOException $e) {
            $dbError = "Failed to save settings: " . $e->getMessage();
        }
    } elseif ($action === 'delete_bill') {
        $targetId = intval($_POST['target_id']);
        try {
            // Fetch bill info for logging
            $stmtInfo = $db->prepare("SELECT merchant, grand_total, currency FROM bills WHERE id = ?");
            $stmtInfo->execute([$targetId]);
            $bill = $stmtInfo->fetch();
            
            if ($bill) {
                $stmt = $db->prepare("DELETE FROM bills WHERE id = ?");
                $stmt->execute([$targetId]);
                
                logActivity('admin_delete_bill', "Moderated and deleted bill split split: '{$bill['merchant']}' - {$bill['currency']} {$bill['grand_total']} (ID {$targetId})");
                $successMessage = "Bill split deleted successfully from the platform.";
            }
        } catch (PDOException $e) {
            $dbError = "Failed to delete bill: " . $e->getMessage();
        }
    } elseif ($action === 'reset_demo_data') {
        try {
            $db->beginTransaction();
            // Truncate tables securely
            $db->exec("DELETE FROM bill_items");
            $db->exec("DELETE FROM bill_people");
            $db->exec("DELETE FROM bills");
            $db->exec("DELETE FROM user_banks");
            
            // Wipe scanned QRs from storage
            $qrDir = STORAGE_DIR . '/qrs';
            if (is_dir($qrDir)) {
                $files = scandir($qrDir);
                foreach ($files as $file) {
                    if ($file !== '.' && $file !== '..' && $file !== '.gitkeep') {
                        @unlink($qrDir . '/' . $file);
                    }
                }
            }
            
            // Reset active users' payment profiles
            $db->exec("UPDATE users SET qr_type = 'none', qr_value = '', qr_image = ''");
            
            logActivity('admin_reset_database', "Cleared all database bills, bank accounts, custom QRs, and reset active payment profiles to default");
            $db->commit();
            
            $successMessage = "Demo database reset completed. All bills, splits, bank accounts, and custom QRs have been cleared.";
        } catch (Exception $e) {
            $db->rollBack();
            $dbError = "Failed to reset database: " . $e->getMessage();
        }
    } elseif ($action === 'disk_cleanup') {
        try {
            // Fetch referenced active files from DB
            $referencedQrs = [];
            $referencedAvatars = [];
            
            $stmt = $db->query("SELECT qr_image, profile_pic FROM users");
            while ($row = $stmt->fetch()) {
                if (!empty($row['qr_image'])) {
                    $referencedQrs[] = $row['qr_image'];
                }
                if (!empty($row['profile_pic'])) {
                    $referencedAvatars[] = $row['profile_pic'];
                }
            }
            
            $cleanedQrs = 0;
            $cleanedAvatars = 0;
            
            // Clean QR codes directory
            $qrDir = STORAGE_DIR . '/qrs';
            if (is_dir($qrDir)) {
                $files = scandir($qrDir);
                foreach ($files as $file) {
                    if ($file !== '.' && $file !== '..' && $file !== '.gitkeep') {
                        if (!in_array($file, $referencedQrs)) {
                            @unlink($qrDir . '/' . $file);
                            $cleanedQrs++;
                        }
                    }
                }
            }
            
            // Clean avatars directory
            $profilesDir = STORAGE_DIR . '/profiles';
            if (is_dir($profilesDir)) {
                $files = scandir($profilesDir);
                foreach ($files as $file) {
                    if ($file !== '.' && $file !== '..' && $file !== '.gitkeep') {
                        if (!in_array($file, $referencedAvatars)) {
                            @unlink($profilesDir . '/' . $file);
                            $cleanedAvatars++;
                        }
                    }
                }
            }
            
            logActivity('admin_disk_cleanup', "Ran upload directories disk cleanup. Deleted {$cleanedQrs} orphan QR codes and {$cleanedAvatars} orphan profile pictures");
            $successMessage = "Disk cleanup completed successfully! Deleted {$cleanedQrs} orphan QR codes and {$cleanedAvatars} orphan profile pictures.";
        } catch (Exception $e) {
            $dbError = "Disk cleanup failed: " . $e->getMessage();
        }
    } elseif ($action === 'update_announcement') {
        $annText = trim($_POST['announcement_text']);
        $annType = $_POST['announcement_type'];
        $annActive = isset($_POST['announcement_active']) ? '1' : '0';
        
        try {
            setSystemSetting('announcement_text', $annText);
            setSystemSetting('announcement_type', $annType);
            setSystemSetting('announcement_active', $annActive);
            
            logActivity('admin_update_announcement', "Updated global broadcast announcement: Active={$annActive}, Type={$annType}");
            $successMessage = "Global broadcast announcement updated successfully.";
        } catch (Exception $e) {
            $dbError = "Failed to save announcement: " . $e->getMessage();
        }
    } elseif ($action === 'clear_logs') {
        $clearType = $_POST['clear_type'];
        try {
            if ($clearType === 'all') {
                $db->exec("DELETE FROM activity_logs");
                logActivity('admin_clear_logs', "Cleared all activity audit logs");
                $successMessage = "All activity logs have been cleared.";
            } else {
                $dateLimit = date('Y-m-d H:i:s', strtotime('-30 days'));
                $stmt = $db->prepare("DELETE FROM activity_logs WHERE created_at < ?");
                $stmt->execute([$dateLimit]);
                logActivity('admin_clear_logs', "Cleared activity logs older than 30 days");
                $successMessage = "Activity logs older than 30 days have been cleared.";
            }
        } catch (PDOException $e) {
            $dbError = "Failed to clear logs: " . $e->getMessage();
        }
    }
}

// Fetch Stats, Users, Bills, logs, and settings
try {
    if (isDbConnected()) {
        // Core counts
        $stats['users'] = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $stats['bills'] = $db->query("SELECT COUNT(*) FROM bills")->fetchColumn();
        
        // Settings map
        $stmtSettings = $db->query("SELECT setting_key, setting_value FROM system_settings");
        while ($row = $stmtSettings->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        
        // Paginate users
        $limitUsers = 10;
        $totalUsers = intval($stats['users']);
        $totalPagesUsers = max(1, ceil($totalUsers / $limitUsers));
        $pageUsers = isset($_GET['p_users']) ? max(1, min($totalPagesUsers, intval($_GET['p_users']))) : 1;
        $offsetUsers = ($pageUsers - 1) * $limitUsers;

        $usersList = $db->query("SELECT id, username, display_name, email, profile_pic, role, last_active, created_at FROM users ORDER BY created_at DESC LIMIT $limitUsers OFFSET $offsetUsers")->fetchAll();
        
        // Paginate bills
        $limitBills = 10;
        $totalBills = intval($stats['bills']);
        $totalPagesBills = max(1, ceil($totalBills / $limitBills));
        $pageBills = isset($_GET['p_bills']) ? max(1, min($totalPagesBills, intval($_GET['p_bills']))) : 1;
        $offsetBills = ($pageBills - 1) * $limitBills;

        $billsList = $db->query("
            SELECT b.id, b.merchant, b.bill_date, b.currency, b.grand_total, b.created_at, u.username as owner_username, u.display_name as owner_display_name
            FROM bills b
            JOIN users u ON b.user_id = u.id
            ORDER BY b.created_at DESC
            LIMIT $limitBills OFFSET $offsetBills
        ")->fetchAll();
        
        // Paginate logs
        $limitLogs = 20;
        $totalLogs = intval($db->query("SELECT COUNT(*) FROM activity_logs")->fetchColumn());
        $totalPagesLogs = max(1, ceil($totalLogs / $limitLogs));
        $pageLogs = isset($_GET['p_logs']) ? max(1, min($totalPagesLogs, intval($_GET['p_logs']))) : 1;
        $offsetLogs = ($pageLogs - 1) * $limitLogs;

        $logsList = $db->query("
            SELECT id, user_id, username, action, details, ip_address, created_at 
            FROM activity_logs 
            ORDER BY created_at DESC 
            LIMIT $limitLogs OFFSET $offsetLogs
        ")->fetchAll();
        
        // Storage size analyzer
        $stats['storage_qrs_count'] = 0;
        $stats['storage_qrs_size'] = 0;
        $stats['storage_profiles_count'] = 0;
        $stats['storage_profiles_size'] = 0;
        
        $qrDir = STORAGE_DIR . '/qrs';
        if (is_dir($qrDir)) {
            $files = scandir($qrDir);
            foreach ($files as $file) {
                if ($file !== '.' && $file !== '..' && $file !== '.gitkeep') {
                    $stats['storage_qrs_count']++;
                    $stats['storage_qrs_size'] += filesize($qrDir . '/' . $file);
                }
            }
        }
        
        $profilesDir = STORAGE_DIR . '/profiles';
        if (is_dir($profilesDir)) {
            $files = scandir($profilesDir);
            foreach ($files as $file) {
                if ($file !== '.' && $file !== '..' && $file !== '.gitkeep') {
                    $stats['storage_profiles_count']++;
                    $stats['storage_profiles_size'] += filesize($profilesDir . '/' . $file);
                }
            }
        }
        
        // Database storage size calculation (MySQL dynamic size query)
        $dbSizeBytes = 0;
        try {
            $stmtSize = $db->query("SELECT SUM(data_length + index_length) AS size FROM information_schema.TABLES WHERE table_schema = DATABASE()");
            $dbSizeBytes = $stmtSize->fetchColumn();
        } catch (PDOException $e) {}
        
        if ($dbSizeBytes) {
            if ($dbSizeBytes > 1048576) {
                $stats['db_size'] = round($dbSizeBytes / 1048576, 2) . ' MB';
            } else {
                $stats['db_size'] = round($dbSizeBytes / 1024, 2) . ' KB';
            }
        } else {
            $stats['db_size'] = '0.00 KB';
        }
        
        // 1. Total volume split grouped by currency
        $currencyVolumes = [];
        $stmtVol = $db->query("SELECT currency, SUM(grand_total) as total_val, COUNT(*) as bill_count FROM bills GROUP BY currency ORDER BY total_val DESC");
        if ($stmtVol) {
            $currencyVolumes = $stmtVol->fetchAll();
        }
        
        // 2. Average bill size
        $averageBillSize = 0;
        $stmtAvg = $db->query("SELECT AVG(grand_total) FROM bills");
        if ($stmtAvg) {
            $averageBillSize = floatval($stmtAvg->fetchColumn());
        }
        
        // 3. Weekly Trend (Counts of bill splits created per day for the last 7 days)
        $weeklyTrend = [];
        for ($i = 6; $i >= 0; $i--) {
            $dateStr = date('Y-m-d', strtotime("-$i days"));
            $weeklyTrend[$dateStr] = 0;
        }
        
        $stmtTrend = $db->query("
            SELECT DATE(created_at) as bill_date, COUNT(*) as count 
            FROM bills 
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) 
            GROUP BY DATE(created_at)
        ");
        if ($stmtTrend) {
            while ($row = $stmtTrend->fetch()) {
                $dateKey = $row['bill_date'];
                if (isset($weeklyTrend[$dateKey])) {
                    $weeklyTrend[$dateKey] = intval($row['count']);
                }
            }
        }
        
        // 4. Top 5 Most Active Splitters Leaderboard
        $topSplitters = [];
        $stmtTop = $db->query("
            SELECT u.id, u.username, u.display_name, u.profile_pic, COUNT(b.id) as bills_count, COALESCE(SUM(b.grand_total), 0) as total_amount
            FROM users u
            JOIN bills b ON u.id = b.user_id
            GROUP BY u.id
            ORDER BY bills_count DESC, total_amount DESC
            LIMIT 5
        ");
        if ($stmtTop) {
            $topSplitters = $stmtTop->fetchAll();
        }
    } else {
        $dbError = "Database offline.";
    }
} catch (PDOException $e) {
    $dbError = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BillSplitter - Admin Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://unpkg.com">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }
        @media(max-width: 992px) {
            .stats-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        @media(max-width: 576px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        .stat-card {
            background: var(--bg-glass);
            border: 1px solid var(--border-color);
            border-radius: 4px;
            padding: 1rem;
            text-align: center;
            display: flex;
            flex-direction: column;
            gap: 0.15rem;
            box-shadow: var(--shadow-sm);
        }
        .stat-val {
            font-family: var(--font-heading);
            font-size: 1.65rem;
            font-weight: 800;
            color: var(--color-primary);
        }
        .stat-lbl {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 0.05em;
        }
        .table-wrapper {
            margin-top: 0.5rem;
            overflow-x: auto;
        }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            color: var(--text-primary);
        }
        .admin-table th, .admin-table td {
            padding: 0.65rem 0.85rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        .admin-table th {
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            font-size: 0.65rem;
            letter-spacing: 0.05em;
        }
        .role-badge {
            display: inline-block;
            padding: 0.1rem 0.35rem;
            border-radius: 2px;
            font-size: 0.65rem;
            font-weight: 700;
            text-transform: uppercase;
        }
        .role-admin {
            background-color: var(--color-primary-light);
            color: var(--color-primary);
        }
        .role-user {
            background-color: var(--bg-tertiary);
            color: var(--text-secondary);
        }
        .action-cell {
            display: flex;
            gap: 0.35rem;
            flex-wrap: wrap;
        }
        .action-cell form {
            display: inline;
        }
        .btn-inline {
            background: none;
            border: 1px solid var(--border-color);
            cursor: pointer;
            font-size: 0.7rem;
            font-weight: 700;
            padding: 0.2rem 0.5rem;
            border-radius: 2px;
            color: var(--text-secondary);
            transition: all var(--transition-fast);
        }
        .btn-inline:hover {
            border-color: var(--color-primary);
            color: var(--color-primary);
            background: var(--color-primary-light);
        }
        .btn-toggle {
            color: var(--color-warning);
        }
        .btn-toggle:hover {
            border-color: var(--color-warning);
            color: var(--color-warning);
            background-color: var(--color-warning-light);
        }
        .btn-delete {
            color: var(--color-danger);
        }
        .btn-delete:hover {
            border-color: var(--color-danger);
            color: var(--color-danger);
            background-color: var(--color-danger-light);
        }
        
        /* Tabs styles */
        .admin-tabs {
            display: flex;
            gap: 0.25rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 1.5rem;
            overflow-x: auto;
            padding-bottom: 0.25rem;
        }
        .tab-btn {
            background: none;
            border: none;
            padding: 0.6rem 1.15rem;
            font-family: 'Outfit', sans-serif;
            font-weight: 600;
            font-size: 0.8rem;
            color: var(--text-muted);
            cursor: pointer;
            border-radius: 4px 4px 0 0;
            border-bottom: 2px solid transparent;
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            transition: all 0.2s;
            white-space: nowrap;
        }
        .tab-btn:hover {
            color: var(--text-primary);
            background: rgba(255,255,255,0.02);
        }
        .tab-btn.active {
            color: var(--color-primary);
            border-bottom-color: var(--color-primary);
            background: rgba(99,102,241,0.05);
        }
        .tab-panel {
            display: none;
        }
        .tab-panel.active {
            display: block;
            animation: fadeIn 0.25s ease-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(5px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="logo">
            <i data-lucide="shield-check"></i>
            <span>Admin Center</span>
        </div>
        <div class="header-actions">
            <a href="dashboard.php" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size: 0.8rem;">
                <i data-lucide="layout-dashboard"></i> User Dashboard
            </a>
            <a href="logout.php" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size: 0.8rem; color: var(--color-danger); border-color: rgba(239, 68, 68, 0.2);">
                <i data-lucide="log-out"></i> Logout
            </a>
        </div>
    </header>

    <main class="container">
        <div class="admin-header">
            <div>
                <h1 style="font-family:var(--font-heading); font-size: 1.65rem;">Administrative Console</h1>
                <p style="color:var(--text-muted); font-size:0.8rem; margin-top:0.25rem;">Monitor platform stats, audit user behaviors, track online sessions, and manage global settings.</p>
            </div>
        </div>

        <?php if ($dbError): ?>
            <div class="alert alert-warning" style="margin-bottom: 1.5rem;">
                <i data-lucide="alert-triangle"></i>
                <span><?php echo htmlspecialchars($dbError); ?></span>
            </div>
        <?php endif; ?>

        <?php if ($successMessage): ?>
            <div class="alert alert-success" style="margin-bottom: 1.5rem;">
                <i data-lucide="check-circle"></i>
                <span><?php echo htmlspecialchars($successMessage); ?></span>
            </div>
        <?php endif; ?>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <span class="stat-val"><?php echo $stats['users']; ?></span>
                <span class="stat-lbl">Registered Users</span>
            </div>
            <div class="stat-card">
                <span class="stat-val"><?php echo $stats['bills']; ?></span>
                <span class="stat-lbl">Bills Split</span>
            </div>
            <div class="stat-card">
                <span class="stat-val"><?php echo $stats['storage_profiles_count']; ?></span>
                <span class="stat-lbl">Avatars (<?php echo round($stats['storage_profiles_size'] / 1024, 1); ?> KB)</span>
            </div>
            <div class="stat-card">
                <span class="stat-val"><?php echo $stats['storage_qrs_count']; ?></span>
                <span class="stat-lbl">Custom QRs (<?php echo round($stats['storage_qrs_size'] / 1024, 1); ?> KB)</span>
            </div>
            <div class="stat-card">
                <span class="stat-val" style="color: #10b981;"><?php echo $stats['db_size']; ?></span>
                <span class="stat-lbl">Database Size</span>
            </div>
        </div>

        <!-- Admin Dashboard Tab Selectors -->
        <div class="admin-tabs">
            <button class="tab-btn active" data-tab="overview"><i data-lucide="sliders"></i> Overview & Config</button>
            <button class="tab-btn" data-tab="analytics"><i data-lucide="bar-chart-3"></i> Analytics & Reports</button>
            <button class="tab-btn" data-tab="users"><i data-lucide="users"></i> User Management</button>
            <button class="tab-btn" data-tab="bills"><i data-lucide="receipt"></i> Bills Moderation</button>
            <button class="tab-btn" data-tab="logs"><i data-lucide="clipboard-list"></i> Activity Logs</button>
            <button class="tab-btn" data-tab="system"><i data-lucide="cpu"></i> System Maintenance</button>
        </div>

        <!-- TAB 1: OVERVIEW & CONFIG -->
        <section id="panel-overview" class="tab-panel active">
            <div class="card">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="settings" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> Global Configurations</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1.25rem;">Configure global parameters, block access, and lock registrations.</p>
                
                <form action="admin.php" method="POST" style="display:flex; flex-direction:column; gap:1rem;">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <input type="hidden" name="action" value="update_settings">
                    
                    <div class="input-group" style="flex-direction:row; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.02); padding:0.75rem 1rem; border:1px solid var(--border-color); border-radius:4px;">
                        <div style="display:flex; flex-direction:column; gap:0.15rem;">
                            <label style="margin-bottom:0; font-weight:600; cursor:pointer;" for="maintenance_mode">Global Maintenance Mode</label>
                            <span style="font-size:0.7rem; color:var(--text-muted);">Blocks non-administrator logins and splits using a themed notice screen.</span>
                        </div>
                        <input type="checkbox" id="maintenance_mode" name="maintenance_mode" style="width:20px; height:20px; cursor:pointer;" <?php echo ($settings['maintenance_mode'] ?? '0') === '1' ? 'checked' : ''; ?>>
                    </div>

                    <div class="input-group" style="flex-direction:row; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.02); padding:0.75rem 1rem; border:1px solid var(--border-color); border-radius:4px;">
                        <div style="display:flex; flex-direction:column; gap:0.15rem;">
                            <label style="margin-bottom:0; font-weight:600; cursor:pointer;" for="allow_registration">Allow New Registrations</label>
                            <span style="font-size:0.7rem; color:var(--text-muted);">Enables or disables public registration forms on the welcome screens.</span>
                        </div>
                        <input type="checkbox" id="allow_registration" name="allow_registration" style="width:20px; height:20px; cursor:pointer;" <?php echo ($settings['allow_registration'] ?? '1') === '1' ? 'checked' : ''; ?>>
                    </div>

                    <div class="input-group">
                        <label for="default_currency" style="font-weight:600;">Default Calculator Currency</label>
                        <select id="default_currency" name="default_currency" class="input-field">
                            <option value="MYR" <?php echo ($settings['default_currency'] ?? 'MYR') === 'MYR' ? 'selected' : ''; ?>>MYR (RM)</option>
                            <option value="SGD" <?php echo ($settings['default_currency'] ?? 'MYR') === 'SGD' ? 'selected' : ''; ?>>SGD (S$)</option>
                            <option value="USD" <?php echo ($settings['default_currency'] ?? 'MYR') === 'USD' ? 'selected' : ''; ?>>USD ($)</option>
                            <option value="EUR" <?php echo ($settings['default_currency'] ?? 'MYR') === 'EUR' ? 'selected' : ''; ?>>EUR (€)</option>
                            <option value="GBP" <?php echo ($settings['default_currency'] ?? 'MYR') === 'GBP' ? 'selected' : ''; ?>>GBP (£)</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary" style="height:2.5rem; min-height:0;">Save Platform Configurations</button>
                </form>
            </div>

            <!-- Broadcast Announcement Card -->
            <div class="card mt-4">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="megaphone" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> System Broadcast Announcement</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1.25rem;">Publish a global banner alert across all user dashboards and calculators.</p>
                
                <form action="admin.php" method="POST" style="display:flex; flex-direction:column; gap:1rem;">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <input type="hidden" name="action" value="update_announcement">
                    
                    <div class="input-group" style="flex-direction:row; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.02); padding:0.75rem 1rem; border:1px solid var(--border-color); border-radius:4px;">
                        <div style="display:flex; flex-direction:column; gap:0.15rem;">
                            <label style="margin-bottom:0; font-weight:600; cursor:pointer;" for="announcement_active">Activate Broadcast Banner</label>
                            <span style="font-size:0.7rem; color:var(--text-muted);">Toggles the visibility of the broadcast message for all logged-in users.</span>
                        </div>
                        <input type="checkbox" id="announcement_active" name="announcement_active" style="width:20px; height:20px; cursor:pointer;" <?php echo getSystemSetting('announcement_active', '0') === '1' ? 'checked' : ''; ?>>
                    </div>

                    <div class="input-group">
                        <label for="announcement_text" style="font-weight:600;">Announcement Message</label>
                        <textarea id="announcement_text" name="announcement_text" class="input-field" style="min-height:80px; resize:vertical; padding:0.6rem 0.8rem;" placeholder="Type system notice, downtime schedule, or update announcement here..."><?php echo htmlspecialchars(getSystemSetting('announcement_text', '')); ?></textarea>
                    </div>

                    <div class="input-group">
                        <label for="announcement_type" style="font-weight:600;">Alert Type / Styling Accent</label>
                        <select id="announcement_type" name="announcement_type" class="input-field">
                            <option value="info" <?php echo getSystemSetting('announcement_type', 'info') === 'info' ? 'selected' : ''; ?>>Info Accent (Indigo/Blue)</option>
                            <option value="warning" <?php echo getSystemSetting('announcement_type', 'info') === 'warning' ? 'selected' : ''; ?>>Warning Accent (Orange/Amber)</option>
                            <option value="success" <?php echo getSystemSetting('announcement_type', 'info') === 'success' ? 'selected' : ''; ?>>Success Accent (Emerald/Green)</option>
                            <option value="danger" <?php echo getSystemSetting('announcement_type', 'info') === 'danger' ? 'selected' : ''; ?>>Danger Accent (Red/Rose)</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary" style="height:2.5rem; min-height:0;">Update Global Announcement</button>
                </form>
            </div>
        </section>

        <!-- TAB: ANALYTICS & REPORTS -->
        <section id="panel-analytics" class="tab-panel">
            <!-- Analytics Key Metrics Grid -->
            <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:0.75rem; margin-bottom:1.5rem;">
                <div class="card" style="margin-bottom:0; display:flex; flex-direction:column; gap:0.5rem;">
                    <h4 style="font-size:0.75rem; color:var(--text-muted); text-transform:uppercase; font-weight:700; letter-spacing:0.05em; margin:0;">Average Bill Size</h4>
                    <span class="stat-val" style="font-size:1.85rem; color:var(--color-primary);">
                        RM <?php echo number_format($averageBillSize, 2); ?>
                    </span>
                    <p style="font-size:0.7rem; color:var(--text-muted); margin:0;">Average transaction amount split across all created receipts.</p>
                </div>
                <div class="card" style="margin-bottom:0; display:flex; flex-direction:column; gap:0.5rem; justify-content:center;">
                    <h4 style="font-size:0.75rem; color:var(--text-muted); text-transform:uppercase; font-weight:700; letter-spacing:0.05em; margin:0;">Volume by Currency</h4>
                    <div style="display:flex; flex-direction:column; gap:0.25rem; margin-top:0.25rem;">
                        <?php if (empty($currencyVolumes)): ?>
                            <span style="font-size:0.8rem; color:var(--text-muted); font-style:italic;">No transactions logged.</span>
                        <?php else: ?>
                            <?php foreach (array_slice($currencyVolumes, 0, 3) as $vol): ?>
                                <div style="display:flex; justify-content:space-between; font-size:0.75rem; border-bottom:1px solid rgba(255,255,255,0.02); padding-bottom:2px;">
                                    <span style="font-weight:700; color:var(--text-secondary);"><?php echo htmlspecialchars($vol['currency']); ?></span>
                                    <strong style="color:var(--text-primary);"><?php echo number_format($vol['total_val'], 2); ?> (<?php echo $vol['bill_count']; ?> splits)</strong>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Weekly Trend SVG Chart -->
            <div class="card">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="bar-chart-3" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> Weekly Split Activity</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1.25rem;">Timeline showing count of bill splits created daily for the last 7 days.</p>
                
                <?php
                // Build SVG chart variables dynamically
                $maxCount = max(1, max($weeklyTrend));
                $chartHeight = 160;
                $chartWidth = 460;
                $barSpacing = 55;
                $startX = 50;
                $startY = 130;
                $yScale = 90 / $maxCount; // Leave headroom
                ?>
                <div style="overflow-x:auto; width:100%; text-align:center;">
                    <svg viewBox="0 0 480 180" style="width:100%; max-width:480px; height:auto; font-family:var(--font-body);">
                        <!-- Grid Lines -->
                        <line x1="40" y1="130" x2="460" y2="130" stroke="var(--border-color)" stroke-width="1" />
                        <line x1="40" y1="85" x2="460" y2="85" stroke="var(--border-color)" stroke-dasharray="2,2" stroke-width="0.5" />
                        <line x1="40" y1="40" x2="460" y2="40" stroke="var(--border-color)" stroke-dasharray="2,2" stroke-width="0.5" />
                        
                        <!-- Y Axis labels -->
                        <text x="30" y="134" font-size="8" fill="var(--text-muted)" text-anchor="end">0</text>
                        <text x="30" y="89" font-size="8" fill="var(--text-muted)" text-anchor="end"><?php echo round($maxCount / 2); ?></text>
                        <text x="30" y="44" font-size="8" fill="var(--text-muted)" text-anchor="end"><?php echo $maxCount; ?></text>

                        <!-- Bars & Labels -->
                        <?php
                        $index = 0;
                        foreach ($weeklyTrend as $date => $count) {
                            $x = $startX + ($index * $barSpacing);
                            $h = $count * $yScale;
                            $y = $startY - $h;
                            $formattedDate = date('d M', strtotime($date));
                            $index++;
                            ?>
                            <g class="bar-group" style="cursor:pointer;">
                                <title><?php echo $count; ?> splits on <?php echo date('l, M d', strtotime($date)); ?></title>
                                <rect x="<?php echo $x - 12; ?>" y="15" width="24" height="115" fill="transparent" />
                                
                                <rect x="<?php echo $x - 8; ?>" y="<?php echo $y; ?>" width="16" height="<?php echo $h; ?>" 
                                      fill="var(--color-primary)" 
                                      opacity="0.85" 
                                      style="transition: all var(--transition-fast);"
                                      onmouseover="this.setAttribute('opacity', '1'); this.setAttribute('fill', 'var(--color-primary-hover)');"
                                      onmouseout="this.setAttribute('opacity', '0.85'); this.setAttribute('fill', 'var(--color-primary)');" />
                                
                                <?php if ($count > 0): ?>
                                    <text x="<?php echo $x; ?>" y="<?php echo $y - 4; ?>" font-size="8" font-weight="700" fill="var(--color-primary)" text-anchor="middle"><?php echo $count; ?></text>
                                <?php endif; ?>
                                
                                <text x="<?php echo $x; ?>" y="146" font-size="8" font-weight="600" fill="var(--text-muted)" text-anchor="middle"><?php echo $formattedDate; ?></text>
                            </g>
                            <?php
                        }
                        ?>
                    </svg>
                </div>
            </div>

            <!-- Top Splitters Leaderboard -->
            <div class="card">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="award" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> Top Active Users</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1rem;">Most active participants based on number of bill splits created.</p>
                
                <div class="table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>User</th>
                                <th style="text-align:center;">Splits Created</th>
                                <th style="text-align:right;">Total Splitting Volume</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($topSplitters)): ?>
                                <tr>
                                    <td colspan="4" style="text-align:center; padding:1.5rem; color:var(--text-muted); font-style:italic;">No activity logged yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php 
                                $rank = 1; 
                                foreach ($topSplitters as $tpl): 
                                ?>
                                    <tr>
                                        <td style="font-weight:700; width:40px; color:var(--text-muted); font-size:0.85rem;">#<?php echo $rank++; ?></td>
                                        <td>
                                            <div style="display:flex; align-items:center; gap:0.4rem;">
                                                <div style="width:22px; height:22px; border-radius:2px; overflow:hidden; border:1px solid var(--border-color); background:var(--bg-secondary);">
                                                    <?php if (!empty($tpl['profile_pic']) && file_exists(STORAGE_DIR . '/profiles/' . $tpl['profile_pic'])): ?>
                                                        <img src="storage/profiles/<?php echo htmlspecialchars($tpl['profile_pic']); ?>" style="width:100%; height:100%; object-fit:cover;" alt="Avatar">
                                                    <?php else: ?>
                                                        <div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:var(--color-primary-light); color:var(--color-primary); font-size:0.6rem; font-weight:700;">
                                                            <?php echo strtoupper(substr($tpl['display_name'] ?: $tpl['username'], 0, 1)); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <span style="font-weight:600;"><?php echo htmlspecialchars($tpl['display_name'] ?: $tpl['username']); ?></span>
                                            </div>
                                        </td>
                                        <td style="text-align:center; font-weight:700; color:var(--text-secondary);"><?php echo $tpl['bills_count']; ?></td>
                                        <td style="text-align:right; font-family:var(--font-heading); font-weight:700; color:var(--color-primary);">RM <?php echo number_format($tpl['total_amount'], 2); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- CSV Export Center -->
            <div class="card">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="download" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> Reports Export Center</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1.25rem;">Export system records securely into spreadsheets for audit logs and external analyses.</p>
                
                <div style="display:flex; flex-direction:column; gap:0.75rem;">
                    <a href="admin.php?action=export_users&csrf_token=<?php echo urlencode($_SESSION['csrf_token']); ?>" class="btn btn-secondary" style="height:2.5rem; font-size:0.8rem; justify-content:flex-start; text-align:left; border-radius:var(--border-radius-md); padding:0 1rem; width:100%;">
                        <i data-lucide="users" style="width:16px; height:16px;"></i> Export Registered Users Directory (.CSV)
                    </a>
                    <a href="admin.php?action=export_bills&csrf_token=<?php echo urlencode($_SESSION['csrf_token']); ?>" class="btn btn-secondary" style="height:2.5rem; font-size:0.8rem; justify-content:flex-start; text-align:left; border-radius:var(--border-radius-md); padding:0 1rem; width:100%;">
                        <i data-lucide="receipt" style="width:16px; height:16px;"></i> Export Saved Bill Splits Catalog (.CSV)
                    </a>
                    <a href="admin.php?action=export_logs&csrf_token=<?php echo urlencode($_SESSION['csrf_token']); ?>" class="btn btn-secondary" style="height:2.5rem; font-size:0.8rem; justify-content:flex-start; text-align:left; border-radius:var(--border-radius-md); padding:0 1rem; width:100%;">
                        <i data-lucide="clipboard-list" style="width:16px; height:16px;"></i> Export Security Activity Audit Trails (.CSV)
                    </a>
                </div>
            </div>
        </section>

        <!-- TAB 2: USER MANAGEMENT -->
        <section id="panel-users" class="tab-panel">
            <!-- Create User Card -->
            <div class="card">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="user-plus" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> Create New User</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1rem;">Register a user manually with assigned privileges.</p>
                
                <form action="admin.php" method="POST" style="display:flex; flex-direction:column; gap:0.85rem;">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <input type="hidden" name="action" value="create_user">
                    <div class="row-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                        <div class="input-group">
                            <label for="new_username">Username</label>
                            <input type="text" id="new_username" name="new_username" class="input-field" placeholder="Username" required>
                        </div>
                        <div class="input-group">
                            <label for="new_password">Password</label>
                            <input type="password" id="new_password" name="new_password" class="input-field" placeholder="Password" minlength="6" required>
                        </div>
                    </div>
                    <div class="input-group">
                        <label for="new_role">Privilege Level</label>
                        <select id="new_role" name="new_role" class="input-field">
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary" style="height:2.5rem; min-height:0; padding:0;">Create Account</button>
                </form>
            </div>

            <!-- Users Management Table -->
            <div class="card mt-4">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="users" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> User Management</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:0.75rem;">Modify status, toggle admin access, reset user passwords, or monitor live sessions.</p>
                
                <div class="table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($usersList as $usr): ?>
                                <?php
                                $isOnline = false;
                                if (!empty($usr['last_active'])) {
                                    $lastActiveTime = strtotime($usr['last_active']);
                                    $timeDiff = time() - $lastActiveTime;
                                    if ($timeDiff <= 300) { // active in last 5 minutes
                                        $isOnline = true;
                                    }
                                }
                                ?>
                                <tr>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:0.5rem;">
                                            <div style="width:26px; height:26px; border-radius:2px; border:1px solid var(--border-color); overflow:hidden; flex-shrink:0; background:var(--bg-secondary);">
                                                <?php if (!empty($usr['profile_pic']) && file_exists(STORAGE_DIR . '/profiles/' . $usr['profile_pic'])): ?>
                                                    <img src="storage/profiles/<?php echo htmlspecialchars($usr['profile_pic']); ?>" style="width:100%; height:100%; object-fit:cover;" alt="Avatar">
                                                <?php else: ?>
                                                    <div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:var(--color-primary-light); color:var(--color-primary); font-size:0.7rem; font-weight:700;">
                                                        <?php echo strtoupper(substr($usr['display_name'] ?: $usr['username'], 0, 1)); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <span style="font-weight:600;"><?php echo htmlspecialchars($usr['username']); ?></span>
                                        </div>
                                    </td>
                                    <td style="color:var(--text-secondary);"><?php echo htmlspecialchars($usr['email'] ?: 'No email'); ?></td>
                                    <td>
                                        <span class="role-badge <?php echo $usr['role'] === 'admin' ? 'role-admin' : 'role-user'; ?>">
                                            <?php echo htmlspecialchars($usr['role']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($isOnline): ?>
                                            <span class="role-badge" style="background:rgba(16,185,129,0.08); color:#10b981; font-size:0.6rem; border:1px solid rgba(16,185,129,0.2);"><span style="background:#10b981; width:6px; height:6px; border-radius:50%; display:inline-block; margin-right:0.25rem; vertical-align:middle; box-shadow:0 0 6px #10b981;"></span>Online</span>
                                        <?php else: ?>
                                            <?php if (!empty($usr['last_active'])): ?>
                                                <span style="color:var(--text-muted); font-size:0.75rem;"><?php echo htmlspecialchars(date('M d, H:i', strtotime($usr['last_active']))); ?></span>
                                            <?php else: ?>
                                                <span style="color:var(--text-muted); font-size:0.75rem; font-style:italic;">Never</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars(date('M d, Y', strtotime($usr['created_at']))); ?></td>
                                    <td class="action-cell">
                                        <?php if ($usr['id'] !== $_SESSION['user_id']): ?>
                                            <!-- Role Toggle -->
                                            <form action="admin.php" method="POST">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                <input type="hidden" name="action" value="toggle_role">
                                                <input type="hidden" name="target_id" value="<?php echo $usr['id']; ?>">
                                                <input type="hidden" name="role" value="<?php echo $usr['role']; ?>">
                                                <button type="submit" class="btn-inline btn-toggle">Toggle Role</button>
                                            </form>

                                            <!-- Reset Password -->
                                            <form action="admin.php" method="POST" style="display:inline;" onsubmit="return promptForReset(this, '<?php echo htmlspecialchars($usr['username']); ?>', <?php echo $usr['id']; ?>)">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                <input type="hidden" name="action" value="reset_password">
                                                <input type="hidden" name="target_id" value="<?php echo $usr['id']; ?>">
                                                <input type="hidden" name="new_password" id="new_password_input_<?php echo $usr['id']; ?>" value="">
                                                <button type="submit" class="btn-inline" style="color:var(--color-primary);">Reset Pass</button>
                                            </form>

                                            <!-- Edit Info -->
                                            <button type="button" class="btn-inline" style="color:var(--color-primary);" onclick="openEditUserModal(<?php echo $usr['id']; ?>, '<?php echo htmlspecialchars($usr['username']); ?>', '<?php echo htmlspecialchars($usr['display_name'] ?: ''); ?>', '<?php echo htmlspecialchars($usr['email'] ?: ''); ?>')">Edit Info</button>

                                            <!-- Delete User -->
                                            <form action="admin.php" method="POST" onsubmit="return confirm('Are you sure you want to delete user @<?php echo htmlspecialchars($usr['username']); ?>? This deletes all their splits, bank accounts, and storage files. This action is irreversible.')">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                <input type="hidden" name="action" value="delete_user">
                                                <input type="hidden" name="target_id" value="<?php echo $usr['id']; ?>">
                                                <button type="submit" class="btn-inline btn-delete">Delete</button>
                                            </form>
                                        <?php else: ?>
                                            <span style="font-size:0.75rem; color:var(--text-muted); font-style:italic; padding-left:0.5rem;">Current Account</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination Controls for Users -->
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:1rem; flex-wrap:wrap; gap:0.5rem; font-size:0.8rem;">
                    <span style="color:var(--text-muted);">Showing Page <?php echo $pageUsers; ?> of <?php echo $totalPagesUsers; ?> (Total Users: <?php echo $totalUsers; ?>)</span>
                    <div style="display:flex; gap:0.25rem;">
                        <a href="admin.php?p_users=<?php echo max(1, $pageUsers - 1); ?>" class="btn btn-secondary btn-sm" style="min-height:unset; height:2rem; padding:0 0.5rem; display:inline-flex; align-items:center; <?php echo $pageUsers <= 1 ? 'pointer-events:none; opacity:0.5;' : ''; ?>"><i data-lucide="chevron-left" style="width:14px; height:14px;"></i> Prev</a>
                        <a href="admin.php?p_users=<?php echo min($totalPagesUsers, $pageUsers + 1); ?>" class="btn btn-secondary btn-sm" style="min-height:unset; height:2rem; padding:0 0.5rem; display:inline-flex; align-items:center; <?php echo $pageUsers >= $totalPagesUsers ? 'pointer-events:none; opacity:0.5;' : ''; ?>">Next <i data-lucide="chevron-right" style="width:14px; height:14px;"></i></a>
                    </div>
                </div>
            </div>
        </section>

        <!-- TAB 3: BILLS MODERATION -->
        <section id="panel-bills" class="tab-panel">
            <div class="card">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="receipt" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> Global Bills Moderation</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1rem;">Moderate, inspect, and delete any bill split created on the platform.</p>
                
                <div class="input-group mb-3">
                    <input type="text" id="billSearchInput" class="input-field" placeholder="Search by merchant, creator, or total..." onkeyup="filterBillsTable();" style="height:2.5rem;">
                </div>

                <div class="table-wrapper">
                    <table class="admin-table" id="globalBillsTable">
                        <thead>
                            <tr>
                                <th>Creator</th>
                                <th>Merchant / Store</th>
                                <th>Bill Date</th>
                                <th>Grand Total</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($billsList)): ?>
                                <tr>
                                    <td colspan="6" style="text-align:center; padding:2rem; color:var(--text-muted);">No bills splits have been created yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($billsList as $bill): ?>
                                    <tr>
                                        <td style="font-weight:600;">@<?php echo htmlspecialchars($bill['owner_username']); ?></td>
                                        <td><?php echo htmlspecialchars($bill['merchant']); ?></td>
                                        <td><?php echo htmlspecialchars($bill['bill_date']); ?></td>
                                        <td style="font-family:var(--font-heading); font-weight:700; color:var(--color-primary);">
                                            <?php echo htmlspecialchars($bill['currency']); ?> <?php echo number_format($bill['grand_total'], 2); ?>
                                        </td>
                                        <td style="color:var(--text-muted); font-size:0.75rem;"><?php echo htmlspecialchars(date('M d, Y H:i', strtotime($bill['created_at']))); ?></td>
                                        <td>
                                            <form action="admin.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this bill split? This action cannot be undone.')" style="margin:0;">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                <input type="hidden" name="action" value="delete_bill">
                                                <input type="hidden" name="target_id" value="<?php echo $bill['id']; ?>">
                                                <button type="submit" class="btn-inline btn-delete" style="padding: 0.15rem 0.4rem; font-size: 0.65rem;">Delete Bill</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination Controls for Bills -->
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:1rem; flex-wrap:wrap; gap:0.5rem; font-size:0.8rem;">
                    <span style="color:var(--text-muted);">Showing Page <?php echo $pageBills; ?> of <?php echo $totalPagesBills; ?> (Total Bills: <?php echo $totalBills; ?>)</span>
                    <div style="display:flex; gap:0.25rem;">
                        <a href="admin.php?p_bills=<?php echo max(1, $pageBills - 1); ?>" class="btn btn-secondary btn-sm" style="min-height:unset; height:2rem; padding:0 0.5rem; display:inline-flex; align-items:center; <?php echo $pageBills <= 1 ? 'pointer-events:none; opacity:0.5;' : ''; ?>"><i data-lucide="chevron-left" style="width:14px; height:14px;"></i> Prev</a>
                        <a href="admin.php?p_bills=<?php echo min($totalPagesBills, $pageBills + 1); ?>" class="btn btn-secondary btn-sm" style="min-height:unset; height:2rem; padding:0 0.5rem; display:inline-flex; align-items:center; <?php echo $pageBills >= $totalPagesBills ? 'pointer-events:none; opacity:0.5;' : ''; ?>">Next <i data-lucide="chevron-right" style="width:14px; height:14px;"></i></a>
                    </div>
                </div>
            </div>
        </section>

        <!-- TAB 4: ACTIVITY LOGS -->
        <section id="panel-logs" class="tab-panel">
            <div class="card">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="clipboard-list" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> System Activity Logs</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1rem;">Audit trails of critical events, user actions, logins, and administrative overrides.</p>
                
                <div style="display:flex; justify-content:space-between; align-items:center; gap:0.5rem; flex-wrap:wrap; margin-bottom:1rem;">
                    <input type="text" id="logSearchInput" class="input-field" placeholder="Search logs by action, username, details, or IP..." onkeyup="filterLogsTable();" style="height:2.5rem; flex:1; min-width:200px; margin-bottom:0;">
                    
                    <div style="display:flex; gap:0.5rem; align-items:center; flex-wrap:wrap;">
                        <!-- CSV Export -->
                        <a href="admin.php?action=export_logs&csrf_token=<?php echo urlencode($_SESSION['csrf_token']); ?>" class="btn btn-secondary btn-sm" style="height:2.5rem; font-size:0.8rem; min-height:unset; padding:0 0.75rem; display:inline-flex; align-items:center; justify-content:center;">
                            <i data-lucide="download" style="width:14px; height:14px; margin-right:0.25rem;"></i> Export CSV
                        </a>
                        
                        <!-- Clear Logs Form -->
                        <form action="admin.php" method="POST" onsubmit="return confirm('Are you sure you want to clear system activity logs? This action is final.')" style="margin:0; display:flex; gap:0.25rem;">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <input type="hidden" name="action" value="clear_logs">
                            <select name="clear_type" class="input-field" style="height:2.5rem; padding:0 0.5rem; font-size:0.75rem; width:130px; border-radius:var(--border-radius-sm); margin-bottom:0; background:var(--bg-tertiary);">
                                <option value="30days">Older than 30 Days</option>
                                <option value="all">Wipe All Logs</option>
                            </select>
                            <button type="submit" class="btn btn-secondary btn-sm" style="height:2.5rem; font-size:0.8rem; min-height:unset; padding:0 0.75rem; border-color:rgba(239, 68, 68, 0.2); color:var(--color-danger); display:inline-flex; align-items:center; justify-content:center;">
                                <i data-lucide="trash-2" style="width:14px; height:14px; margin-right:0.25rem;"></i> Clear
                            </button>
                        </form>
                    </div>
                </div>

                <div class="table-wrapper">
                    <table class="admin-table" id="activityLogsTable">
                        <thead>
                            <tr>
                                <th>Timestamp</th>
                                <th>User</th>
                                <th>Action</th>
                                <th>Details / Description</th>
                                <th>IP Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($logsList)): ?>
                                <tr>
                                    <td colspan="5" style="text-align:center; padding:2rem; color:var(--text-muted);">No activity logs captured yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($logsList as $log): ?>
                                    <tr>
                                        <td style="color:var(--text-muted); font-size:0.75rem; white-space:nowrap;"><?php echo htmlspecialchars(date('M d, Y H:i:s', strtotime($log['created_at']))); ?></td>
                                        <td style="font-weight:600; white-space:nowrap;"><?php echo htmlspecialchars($log['username'] ? '@' . $log['username'] : 'System/Guest'); ?></td>
                                        <td>
                                            <span class="role-badge" style="background:rgba(255,255,255,0.03); border:1px solid var(--border-color); font-size:0.65rem; color:var(--text-secondary); text-transform:none; font-family:monospace;"><?php echo htmlspecialchars($log['action']); ?></span>
                                        </td>
                                        <td style="color:var(--text-secondary);"><?php echo htmlspecialchars($log['details']); ?></td>
                                        <td style="font-family:monospace; font-size:0.75rem; color:var(--text-muted);"><?php echo htmlspecialchars($log['ip_address'] ?: 'Unknown'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination Controls for Logs -->
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:1rem; flex-wrap:wrap; gap:0.5rem; font-size:0.8rem;">
                    <span style="color:var(--text-muted);">Showing Page <?php echo $pageLogs; ?> of <?php echo $totalPagesLogs; ?> (Total Logs: <?php echo $totalLogs; ?>)</span>
                    <div style="display:flex; gap:0.25rem;">
                        <a href="admin.php?p_logs=<?php echo max(1, $pageLogs - 1); ?>" class="btn btn-secondary btn-sm" style="min-height:unset; height:2rem; padding:0 0.5rem; display:inline-flex; align-items:center; <?php echo $pageLogs <= 1 ? 'pointer-events:none; opacity:0.5;' : ''; ?>"><i data-lucide="chevron-left" style="width:14px; height:14px;"></i> Prev</a>
                        <a href="admin.php?p_logs=<?php echo min($totalPagesLogs, $pageLogs + 1); ?>" class="btn btn-secondary btn-sm" style="min-height:unset; height:2rem; padding:0 0.5rem; display:inline-flex; align-items:center; <?php echo $pageLogs >= $totalPagesLogs ? 'pointer-events:none; opacity:0.5;' : ''; ?>">Next <i data-lucide="chevron-right" style="width:14px; height:14px;"></i></a>
                    </div>
                </div>
            </div>
        </section>

        <!-- TAB 5: SYSTEM MAINTENANCE -->
        <section id="panel-system" class="tab-panel">
            <div class="card">
                <h3 style="font-size:1.1rem; margin-bottom:0.25rem;"><i data-lucide="cpu" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:0.25rem;"></i> Database & Storage Maintenance</h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1.25rem;">Analyze uploads directory sizes, scan database orphans, and manage server health.</p>

                <!-- System Metadata Table -->
                <div style="background:rgba(255,255,255,0.01); border:1px solid var(--border-color); border-radius:4px; padding:1rem; margin-bottom:1.5rem; display:flex; flex-direction:column; gap:0.75rem;">
                    <h5 style="font-size:0.85rem; font-weight:700; color:var(--color-primary); text-transform:uppercase; margin:0;">Environment Diagnostics</h5>
                    <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:1rem; font-size:0.8rem;">
                        <div>
                            <span style="color:var(--text-muted);">PHP Version:</span>
                            <strong style="color:var(--text-primary); margin-left:0.25rem;"><?php echo PHP_VERSION; ?></strong>
                        </div>
                        <div>
                            <span style="color:var(--text-muted);">Database Status:</span>
                            <strong style="color:#10b981; margin-left:0.25rem;"><i data-lucide="check" style="width:14px; height:14px; display:inline-block; vertical-align:middle;"></i> Online (PDO)</strong>
                        </div>
                        <div>
                            <span style="color:var(--text-muted);">Avatars Directory Size:</span>
                            <strong style="color:var(--text-primary); margin-left:0.25rem;"><?php echo round($stats['storage_profiles_size'] / 1024, 2); ?> KB (<?php echo $stats['storage_profiles_count']; ?> files)</strong>
                        </div>
                        <div>
                            <span style="color:var(--text-muted);">QR Codes Directory Size:</span>
                            <strong style="color:var(--text-primary); margin-left:0.25rem;"><?php echo round($stats['storage_qrs_size'] / 1024, 2); ?> KB (<?php echo $stats['storage_qrs_count']; ?> files)</strong>
                        </div>
                        <div>
                            <span style="color:var(--text-muted);">Storage Permissions:</span>
                            <strong style="color:<?php echo (is_writable(STORAGE_DIR) && is_writable(STORAGE_DIR . '/profiles') && is_writable(STORAGE_DIR . '/qrs')) ? '#10b981' : '#f87171'; ?>; margin-left:0.25rem;">
                                <?php echo (is_writable(STORAGE_DIR) && is_writable(STORAGE_DIR . '/profiles') && is_writable(STORAGE_DIR . '/qrs')) ? 'Writable' : 'Read-only'; ?>
                            </strong>
                        </div>
                        <div>
                            <span style="color:var(--text-muted);">SQLite Extension:</span>
                            <strong style="color:<?php echo extension_loaded('pdo_sqlite') ? '#10b981' : '#f87171'; ?>; margin-left:0.25rem;">
                                <?php echo extension_loaded('pdo_sqlite') ? 'Loaded' : 'Missing'; ?>
                            </strong>
                        </div>
                        <div>
                            <span style="color:var(--text-muted);">GD Image Extension:</span>
                            <strong style="color:<?php echo extension_loaded('gd') ? '#10b981' : '#f87171'; ?>; margin-left:0.25rem;">
                                <?php echo extension_loaded('gd') ? 'Loaded' : 'Missing'; ?>
                            </strong>
                        </div>
                        <div>
                            <span style="color:var(--text-muted);">Mbstring Extension:</span>
                            <strong style="color:<?php echo extension_loaded('mbstring') ? '#10b981' : '#f87171'; ?>; margin-left:0.25rem;">
                                <?php echo extension_loaded('mbstring') ? 'Loaded' : 'Missing'; ?>
                            </strong>
                        </div>
                    </div>
                </div>

                <!-- Action Blocks -->
                <div style="display:flex; flex-direction:column; gap:1rem;">
                    <!-- Disk Cleanup -->
                    <div style="padding:1rem; border:1px solid var(--border-color); background:rgba(255,255,255,0.01); border-radius:4px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
                        <div style="max-width:450px;">
                            <strong style="font-size:0.9rem; color:var(--text-primary); display:block; margin-bottom:0.2rem;">Analyze & Clean Upload Orphans</strong>
                            <span style="font-size:0.75rem; color:var(--text-muted);">Scans storage upload directories and deletes files that are no longer referenced in the database (deleted avatars or obsolete QR images). Keeps disk usage clean.</span>
                        </div>
                        <form action="admin.php" method="POST" style="margin:0;">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <input type="hidden" name="action" value="disk_cleanup">
                            <button type="submit" class="btn btn-secondary btn-sm" style="min-height:unset; height:2.5rem; padding:0 1rem;"><i data-lucide="trash-2" style="width:16px; height:16px; margin-right:0.25rem;"></i> Run Disk Cleanup</button>
                        </form>
                    </div>

                    <!-- Database Backup -->
                    <div style="padding:1rem; border:1px solid var(--border-color); background:rgba(255,255,255,0.01); border-radius:4px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
                        <div style="max-width:450px;">
                            <strong style="font-size:0.9rem; color:var(--text-primary); display:block; margin-bottom:0.2rem;">Generate SQL Database Backup</strong>
                            <span style="font-size:0.75rem; color:var(--text-muted);">Generates and downloads a complete SQL database backup containing schema definitions (CREATE TABLE) and row insert statements for all tables. Recommended before performing database resets.</span>
                        </div>
                        <a href="admin.php?action=download_db_backup&csrf_token=<?php echo urlencode($_SESSION['csrf_token']); ?>" class="btn btn-secondary btn-sm" style="min-height:unset; height:2.5rem; padding:0 1rem; display:inline-flex; align-items:center; justify-content:center;">
                            <i data-lucide="download" style="width:16px; height:16px; margin-right:0.25rem;"></i> Download SQL Backup
                        </a>
                    </div>

                    <!-- Database Wipe -->
                    <div style="padding:1rem; border:1px solid rgba(239, 68, 68, 0.2); background:rgba(239, 68, 68, 0.02); border-radius:4px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
                        <div style="max-width:450px;">
                            <strong style="font-size:0.9rem; color:#f87171; display:block; margin-bottom:0.2rem;">Reset Demonstration Data</strong>
                            <span style="font-size:0.75rem; color:var(--text-muted);">Wipes all bills, items, split relationships, bank accounts, and custom QRs on disk to return the app to a pristine testing state. Admins and user profiles remain intact.</span>
                        </div>
                        <form action="admin.php" method="POST" onsubmit="return confirm('WARNING: You are about to wipe all split data, bill splits, and bank accounts from the database. This action is final. Proceed?')" style="margin:0;">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <input type="hidden" name="action" value="reset_demo_data">
                            <button type="submit" class="btn btn-secondary btn-sm" style="min-height:unset; height:2.5rem; padding:0 1rem; border-color:rgba(239, 68, 68, 0.3); color:#f87171;"><i data-lucide="database" style="width:16px; height:16px; margin-right:0.25rem;"></i> Reset Demo Database</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- Admin Edit User Modal -->
        <div id="adminEditUserModal" class="qr-modal-overlay" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(11,15,25,0.85); backdrop-filter: blur(8px); align-items: center; justify-content: center; z-index: 1000;">
            <div class="qr-modal-card" style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: 1.25rem; padding: 1.75rem; max-width: 500px; width: 90%; text-align: left; box-shadow: var(--shadow-lg); max-height: 90vh; overflow-y: auto;">
                <h3 style="font-size: 1.25rem; margin-bottom: 0.25rem; color: var(--text-primary); display: flex; align-items: center; gap: 0.35rem;">
                    <i data-lucide="user-cog" style="color: var(--color-primary);"></i> User Inspection & Profile Edit
                </h3>
                <p id="editUserSubtitle" style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;"></p>
                
                <!-- Quick Tabs inside detail modal -->
                <div style="display:flex; border-bottom:1px solid var(--border-color); margin-bottom:1rem; gap:0.5rem;">
                    <button type="button" id="modalTabEdit" class="btn btn-secondary btn-sm" style="flex:1; border-radius:0; border:none; background:none; border-bottom:2px solid var(--color-primary); color:var(--color-primary); font-weight:600; min-height:unset; height:2rem; font-size:0.8rem;">Profile Info</button>
                    <button type="button" id="modalTabBills" class="btn btn-secondary btn-sm" style="flex:1; border-radius:0; border:none; background:none; border-bottom:2px solid transparent; color:var(--text-muted); min-height:unset; height:2rem; font-size:0.8rem;">Active Bills</button>
                    <button type="button" id="modalTabBanks" class="btn btn-secondary btn-sm" style="flex:1; border-radius:0; border:none; background:none; border-bottom:2px solid transparent; color:var(--text-muted); min-height:unset; height:2rem; font-size:0.8rem;">Bank Profiles</button>
                </div>

                <!-- Tab content: Info edit -->
                <div id="modalPanelEdit">
                    <form action="admin.php" method="POST" style="display:flex; flex-direction:column; gap:1rem;">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <input type="hidden" name="action" value="edit_user">
                        <input type="hidden" id="edit_target_id" name="target_id" value="">
                        
                        <div class="input-group">
                            <label for="edit_display_name" style="font-weight:600; font-size:0.75rem; text-transform:uppercase; color:var(--text-muted);">Display Name</label>
                            <input type="text" id="edit_display_name" name="edit_display_name" class="input-field" required placeholder="e.g. John Doe">
                        </div>
                        
                        <div class="input-group">
                            <label for="edit_email" style="font-weight:600; font-size:0.75rem; text-transform:uppercase; color:var(--text-muted);">Email Address</label>
                            <input type="email" id="edit_email" name="edit_email" class="input-field" placeholder="e.g. john@example.com">
                        </div>

                        <!-- Payment configurations lookup -->
                        <div style="background:rgba(255,255,255,0.02); border:1px solid var(--border-color); border-radius:0.5rem; padding:0.75rem 1rem; margin-top:0.5rem;">
                            <strong style="font-size:0.8rem; color:var(--text-primary); display:block; margin-bottom:0.25rem;">QR Payment Config</strong>
                            <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:0.5rem; font-size:0.75rem;">
                                <div>
                                    <span style="color:var(--text-muted);">QR Type:</span>
                                    <strong id="detail_qr_type" style="color:var(--color-primary); margin-left:0.25rem;">-</strong>
                                </div>
                                <div>
                                    <span style="color:var(--text-muted);">QR Value:</span>
                                    <strong id="detail_qr_value" style="color:var(--color-primary); margin-left:0.25rem; word-break:break-all;">-</strong>
                                </div>
                            </div>
                        </div>
                        
                        <div style="display: flex; gap: 0.75rem; margin-top: 1rem;">
                            <button type="button" class="btn btn-secondary w-full close-edit-modal-btn" style="min-height: 2.75rem; padding: 0.5rem 1rem;">Cancel</button>
                            <button type="submit" class="btn btn-primary w-full" style="min-height: 2.75rem; padding: 0.5rem 1rem;">Save Changes</button>
                        </div>
                    </form>
                </div>

                <!-- Tab content: Bills list -->
                <div id="modalPanelBills" style="display:none;">
                    <div id="modalBillsLoading" style="text-align:center; padding:1.5rem; color:var(--text-muted); font-size:0.85rem;"><i data-lucide="loader" class="animate-spin" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:4px;"></i> Loading bills...</div>
                    <div id="modalBillsContainer" style="display:none; max-height:220px; overflow-y:auto; display:flex; flex-direction:column; gap:0.5rem;"></div>
                    <button type="button" class="btn btn-secondary w-full close-edit-modal-btn" style="min-height: 2.75rem; padding: 0.5rem 1rem; margin-top:1rem;">Close Details</button>
                </div>

                <!-- Tab content: Bank profiles -->
                <div id="modalPanelBanks" style="display:none;">
                    <div id="modalBanksLoading" style="text-align:center; padding:1.5rem; color:var(--text-muted); font-size:0.85rem;"><i data-lucide="loader" class="animate-spin" style="width:18px; height:18px; display:inline-block; vertical-align:middle; margin-right:4px;"></i> Loading banks...</div>
                    <div id="modalBanksContainer" style="display:none; max-height:220px; overflow-y:auto; display:flex; flex-direction:column; gap:0.5rem;"></div>
                    <button type="button" class="btn btn-secondary w-full close-edit-modal-btn" style="min-height: 2.75rem; padding: 0.5rem 1rem; margin-top:1rem;">Close Details</button>
                </div>
            </div>
        </div>
    </main>

    <!-- Library scripts -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        lucide.createIcons();

        // 1. Interactive Tab Switcher
        const tabs = document.querySelectorAll('.tab-btn');
        const panels = document.querySelectorAll('.tab-panel');
        
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const target = tab.dataset.tab;
                
                // Set active tab
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                
                // Show target panel
                panels.forEach(p => {
                    p.classList.remove('active');
                    if (p.id === `panel-${target}`) {
                        p.classList.add('active');
                    }
                });
            });
        });

        // 2. Prompt for Password Reset
        function promptForReset(form, username, userId) {
            const newPass = prompt(`Enter new password for @${username}:`);
            if (newPass === null) return false; // Cancelled
            const trimmed = newPass.trim();
            if (trimmed.length < 6) {
                alert("Password must be at least 6 characters.");
                return false;
            }
            document.getElementById(`new_password_input_${userId}`).value = trimmed;
            return true;
        }

        // 3. Global Bills Filter
        function filterBillsTable() {
            const input = document.getElementById("billSearchInput");
            const filter = input.value.toUpperCase();
            const table = document.getElementById("globalBillsTable");
            const tr = table.getElementsByTagName("tr");

            for (let i = 1; i < tr.length; i++) {
                let show = false;
                const tds = tr[i].getElementsByTagName("td");
                for (let j = 0; j < tds.length - 1; j++) { // Skip the actions cell
                    if (tds[j]) {
                        const txtValue = tds[j].textContent || tds[j].innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            show = true;
                            break;
                        }
                    }
                }
                tr[i].style.display = show ? "" : "none";
            }
        }

        // 4. Global Activity Logs Filter
        function filterLogsTable() {
            const input = document.getElementById("logSearchInput");
            const filter = input.value.toUpperCase();
            const table = document.getElementById("activityLogsTable");
            const tr = table.getElementsByTagName("tr");

            for (let i = 1; i < tr.length; i++) {
                let show = false;
                const tds = tr[i].getElementsByTagName("td");
                for (let j = 0; j < tds.length; j++) {
                    if (tds[j]) {
                        const txtValue = tds[j].textContent || tds[j].innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            show = true;
                            break;
                        }
                    }
                }
                tr[i].style.display = show ? "" : "none";
            }
        }

        // 5. User Inspection Details fetching
        function openEditUserModal(id, username, displayName, email) {
            document.getElementById('edit_target_id').value = id;
            document.getElementById('editUserSubtitle').textContent = `Inspecting & editing profile details for @${username}`;
            document.getElementById('edit_display_name').value = displayName;
            document.getElementById('edit_email').value = email;
            document.getElementById('adminEditUserModal').style.display = 'flex';
            
            // Set first tab as active
            switchModalTab('edit');

            // Trigger details loading
            const csrfToken = "<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>";
            
            // Show loading
            document.getElementById('modalBillsLoading').style.display = 'block';
            document.getElementById('modalBillsContainer').style.display = 'none';
            document.getElementById('modalBanksLoading').style.display = 'block';
            document.getElementById('modalBanksContainer').style.display = 'none';
            
            fetch(`admin.php?action=get_user_details&id=${id}&csrf_token=${encodeURIComponent(csrfToken)}`)
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        // Populate QR payment config details
                        document.getElementById('detail_qr_type').textContent = data.user.qr_type.toUpperCase();
                        document.getElementById('detail_qr_value').textContent = data.user.qr_value || 'None';
                        
                        // Populate bills list
                        const billsContainer = document.getElementById('modalBillsContainer');
                        billsContainer.innerHTML = '';
                        if (data.bills.length === 0) {
                            billsContainer.innerHTML = `<div style="text-align:center; padding:1rem; color:var(--text-muted); font-size:0.8rem; font-style:italic;">No bills created yet by this user.</div>`;
                        } else {
                            data.bills.forEach(bill => {
                                const row = document.createElement('div');
                                row.style = 'background:rgba(255,255,255,0.02); border:1px solid var(--border-color); padding:0.6rem 0.85rem; border-radius:4px; display:flex; justify-content:space-between; align-items:center; font-size:0.75rem;';
                                row.innerHTML = `
                                    <div>
                                        <strong style="color:var(--text-primary);">${bill.merchant || 'Restaurant Split'}</strong>
                                        <div style="color:var(--text-muted); font-size:0.65rem; margin-top:0.15rem;">Date: ${bill.bill_date}</div>
                                    </div>
                                    <strong style="color:var(--color-primary);">${bill.currency} ${parseFloat(bill.grand_total).toFixed(2)}</strong>
                                `;
                                billsContainer.appendChild(row);
                            });
                        }
                        
                        // Populate banks list
                        const banksContainer = document.getElementById('modalBanksContainer');
                        banksContainer.innerHTML = '';
                        if (data.banks.length === 0) {
                            banksContainer.innerHTML = `<div style="text-align:center; padding:1rem; color:var(--text-muted); font-size:0.8rem; font-style:italic;">No bank accounts added yet.</div>`;
                        } else {
                            data.banks.forEach(bank => {
                                const row = document.createElement('div');
                                row.style = `background:rgba(255,255,255,0.02); border:1px solid var(--border-color); padding:0.6rem 0.85rem; border-radius:4px; display:flex; justify-content:space-between; align-items:center; font-size:0.75rem; ${bank.is_preferred ? 'border-color:var(--color-primary); background:rgba(99,102,241,0.03);' : ''}`;
                                row.innerHTML = `
                                    <div>
                                        <strong style="color:var(--text-primary);">${bank.bank_name}</strong>
                                        <div style="color:var(--text-muted); font-size:0.65rem; margin-top:0.15rem;">Acc Name: ${bank.account_name}</div>
                                    </div>
                                    <strong style="color:var(--text-secondary);">${bank.account_number}</strong>
                                `;
                                banksContainer.appendChild(row);
                            });
                        }

                        document.getElementById('modalBillsLoading').style.display = 'none';
                        document.getElementById('modalBillsContainer').style.display = 'flex';
                        document.getElementById('modalBanksLoading').style.display = 'none';
                        document.getElementById('modalBanksContainer').style.display = 'flex';
                        
                        // Recreate icons inside dynamically generated content
                        lucide.createIcons();
                    } else {
                        alert("Failed to load user details: " + (data.error || "Unknown error"));
                    }
                })
                .catch(err => {
                    console.error("Error loading user details:", err);
                });
        }
        
        // Modal tab switching
        function switchModalTab(tabName) {
            const btnEdit = document.getElementById('modalTabEdit');
            const btnBills = document.getElementById('modalTabBills');
            const btnBanks = document.getElementById('modalTabBanks');
            
            const panelEdit = document.getElementById('modalPanelEdit');
            const panelBills = document.getElementById('modalPanelBills');
            const panelBanks = document.getElementById('modalPanelBanks');
            
            // Reset active states
            [btnEdit, btnBills, btnBanks].forEach(b => {
                b.style.color = 'var(--text-muted)';
                b.style.borderBottomColor = 'transparent';
                b.style.fontWeight = '500';
            });
            [panelEdit, panelBills, panelBanks].forEach(p => p.style.display = 'none');
            
            if (tabName === 'edit') {
                btnEdit.style.color = 'var(--color-primary)';
                btnEdit.style.borderBottomColor = 'var(--color-primary)';
                btnEdit.style.fontWeight = '600';
                panelEdit.style.display = 'block';
            } else if (tabName === 'bills') {
                btnBills.style.color = 'var(--color-primary)';
                btnBills.style.borderBottomColor = 'var(--color-primary)';
                btnBills.style.fontWeight = '600';
                panelBills.style.display = 'block';
            } else if (tabName === 'banks') {
                btnBanks.style.color = 'var(--color-primary)';
                btnBanks.style.borderBottomColor = 'var(--color-primary)';
                btnBanks.style.fontWeight = '600';
                panelBanks.style.display = 'block';
            }
        }
        
        document.getElementById('modalTabEdit')?.addEventListener('click', () => switchModalTab('edit'));
        document.getElementById('modalTabBills')?.addEventListener('click', () => switchModalTab('bills'));
        document.getElementById('modalTabBanks')?.addEventListener('click', () => switchModalTab('banks'));
        
        document.querySelectorAll('.close-edit-modal-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('adminEditUserModal').style.display = 'none';
            });
        });
    </script>
</body>
</html>
