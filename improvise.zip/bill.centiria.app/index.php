<?php
/**
 * Personal Bill Splitter - Main Entry Point
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

// Redirect to installer if DB not configured
if (!isDbConfigured() && file_exists('install.php')) {
    header('Location: install.php');
    exit;
}

// Enforce login
requireAuth();

// Load logged-in user profile details for frontend pre-population
$userProfile = null;
$defaultSystemCurrency = 'MYR';
if (isDbConnected()) {
    try {
        // Fetch default currency setting
        $stmtCurr = $db->query("SELECT setting_value FROM system_settings WHERE setting_key = 'default_currency'");
        if ($stmtCurr) {
            $defaultSystemCurrency = $stmtCurr->fetchColumn() ?: 'MYR';
        }

        $stmtProfile = $db->prepare("
            SELECT u.username, u.display_name, u.email, u.profile_pic, u.qr_type, u.qr_value, u.qr_image,
                   ub.bank_name, ub.account_name, ub.account_number
            FROM users u
            LEFT JOIN user_banks ub ON u.id = ub.user_id AND ub.is_preferred = 1
            WHERE u.id = ?
        ");
        $stmtProfile->execute([$_SESSION['user_id']]);
        $profile = $stmtProfile->fetch();
        if ($profile) {
            $userProfile = [
                'username' => $profile['username'],
                'displayName' => $profile['display_name'] ?: $profile['username'],
                'email' => $profile['email'],
                'profilePic' => $profile['profile_pic'],
                'qrType' => $profile['qr_type'],
                'qrValue' => $profile['qr_value'],
                'qrImage' => $profile['qr_image'],
                'bankName' => $profile['bank_name'] ?: null,
                'accountName' => $profile['account_name'] ?: null,
                'accountNumber' => $profile['account_number'] ?: null
            ];
        }
    } catch (PDOException $e) {
        // Silent catch
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <title>Personal Bill Splitter</title>
    
    <!-- Preconnect resource hints for faster loading of CDN libraries -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
    <link rel="preconnect" href="https://unpkg.com">
    
    <!-- Favicon and PWA Meta -->
    <link rel="icon" type="image/svg+xml" href="assets/icons/icon.svg">
    <link rel="apple-touch-icon" href="assets/icons/icon.svg">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#6366f1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="csrf-token" content="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
    
    <!-- CDNs for icons, image cropper, and OCR -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .autocomplete-container {
            position: relative;
            flex: 1;
            display: flex;
            align-items: center;
        }
        .autocomplete-container input {
            width: 100%;
        }
        /* Pad input when badge is visible inside it */
        .autocomplete-container input.has-badge {
            padding-right: 6.85rem !important;
        }
        .autocomplete-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: #1e2638;
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: var(--border-radius-sm);
            z-index: 1000;
            max-height: 200px;
            overflow-y: auto;
            margin-top: 0.25rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        }
        .autocomplete-suggestion-item {
            padding: 0.65rem 1rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.65rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            font-size: 0.85rem;
            transition: background-color 0.15s ease;
            text-align: left;
        }
        .autocomplete-suggestion-item:last-child {
            border-bottom: none;
        }
        .autocomplete-suggestion-item:hover {
            background-color: rgba(129, 140, 248, 0.15);
        }
        .autocomplete-avatar {
            width: 28px;
            height: 28px;
            background: var(--color-primary-light);
            color: var(--color-primary);
            border-radius: var(--border-radius-xs);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: 700;
            flex-shrink: 0;
        }
        .autocomplete-info {
            display: flex;
            flex-direction: column;
            gap: 0.1rem;
        }
        .autocomplete-display-name {
            font-weight: 600;
            color: var(--text-primary);
            font-size: 0.85rem;
        }
        .autocomplete-username {
            font-size: 0.75rem;
            color: var(--text-muted);
        }
        .user-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            padding: 0.15rem 0.4rem;
            border-radius: var(--border-radius-sm);
            font-size: 0.7rem;
            color: #10b981;
            font-weight: 600;
        }
    </style>
</head>
<body>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay">
        <div class="loading-box"></div>
        <div id="loadingText" class="loading-text">Processing receipt...</div>
    </div>

    <!-- Header -->
    <header>
        <div class="logo">
            <i data-lucide="receipt"></i>
            <span>BillSplitter</span>
        </div>
        <div style="display: flex; gap: 0.5rem; align-items: center;">
            <a href="dashboard.php" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size: 0.8rem; padding: 0 0.75rem; display: inline-flex; align-items: center; gap: 0.35rem;">
                <i data-lucide="layout-dashboard" style="width: 14px; height: 14px;"></i> <?php echo __('dashboard'); ?>
            </a>
            <a href="profile.php" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size: 0.8rem; gap: 0.35rem; padding: 0 0.65rem; display: inline-flex; align-items: center;">
                <?php if ($userProfile && !empty($userProfile['profilePic']) && file_exists(STORAGE_DIR . '/profiles/' . $userProfile['profilePic'])): ?>
                    <img src="storage/profiles/<?php echo htmlspecialchars($userProfile['profilePic']); ?>" style="width: 18px; height: 18px; object-fit: cover; border-radius: 2px;" alt="User Avatar">
                <?php else: ?>
                    <i data-lucide="user" style="width: 14px; height: 14px;"></i>
                <?php endif; ?>
                <span><?php echo __('profile'); ?></span>
            </a>
            <!-- Language Toggle Button -->
            <button id="langToggle" class="theme-toggle-btn" style="font-weight: 700; font-size: 0.8rem; font-family: var(--font-heading);" aria-label="Change Language">
                <?php echo getLang() === 'en' ? 'BM' : 'EN'; ?>
            </button>
            <button id="themeToggle" class="theme-toggle-btn" aria-label="Toggle Theme">
                <i data-lucide="sun" id="themeSunIcon" style="display:none;"></i>
                <i data-lucide="moon" id="themeMoonIcon"></i>
            </button>
        </div>
    </header>

    <!-- Main Content Container -->
    <main class="container">
        <?php renderGlobalAnnouncement(); ?>
        
        <!-- Stepper -->
        <div class="stepper">
            <div class="stepper-progress">
                <div id="stepperProgressFill" class="stepper-progress-fill"></div>
            </div>
            <div class="step-item active" data-step="1">
                <div class="step-dot">1</div>
                <span class="step-label" data-i18n="step_upload">Upload</span>
            </div>
            <div class="step-item" data-step="2">
                <div class="step-dot">2</div>
                <span class="step-label" data-i18n="step_edit">Edit</span>
            </div>
            <div class="step-item" data-step="3">
                <div class="step-dot">3</div>
                <span class="step-label" data-i18n="step_people">People</span>
            </div>
            <div class="step-item" data-step="4">
                <div class="step-dot">4</div>
                <span class="step-label" data-i18n="step_assign">Assign</span>
            </div>
            <div class="step-item" data-step="5">
                <div class="step-dot">5</div>
                <span class="step-label" data-i18n="step_review">Review</span>
            </div>
            <div class="step-item" data-step="6">
                <div class="step-dot">6</div>
                <span class="step-label" data-i18n="step_share">Share</span>
            </div>
        </div>

        <!-- STEP 1: UPLOAD / CAMERA SCAN -->
        <section id="step1" class="wizard-panel active">
            <div class="card">
                <h2 data-i18n="step1_title">Scan or Upload Receipt</h2>
                <p class="mb-4" data-i18n="step1_subtitle">Upload an image of your receipt. We will process it locally on your device to extract items.</p>
                
                <div id="uploadDropzone" class="upload-dropzone">
                    <i data-lucide="upload-cloud" class="upload-icon"></i>
                    <h3 data-i18n="dropzone_title">Tap to scan or select file</h3>
                    <p data-i18n="dropzone_subtitle">Supports JPG, PNG, WEBP, and PDF</p>
                    <input type="file" id="receiptFileInput" accept="image/*,application/pdf" capture="environment">
                </div>
            </div>

            <!-- Recent Bills History (Step 1) -->
            <div id="recentBillsContainer" class="card mt-4" style="display: none;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                    <h2 style="margin: 0; font-size: 1.25rem;" data-i18n="recent_bills">Recent Bills</h2>
                    <button id="clearHistoryBtn" class="btn btn-secondary btn-sm" style="min-height: 2rem; padding: 0.2rem 0.6rem; font-size: 0.75rem;" data-i18n="clear_history">Clear History</button>
                </div>
                <div id="recentBillsList" class="recent-bills-list">
                    <!-- History items populated dynamically -->
                </div>
            </div>

            <!-- Demo Bills Card -->
            <div class="card mt-4">
                <h2 style="font-size: 1.25rem; margin-bottom: 0.25rem;" data-i18n="demo_title">Quick Test / Demo Bills</h2>
                <p class="mb-4" style="font-size: 0.85rem; color: var(--text-muted);" data-i18n="demo_subtitle">Don't have a receipt on hand? Click a sample to test the calculator instantly.</p>
                <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                    <button id="loadSampleMYRBtn" class="btn btn-secondary w-full" style="justify-content: flex-start; gap: 0.75rem; padding: 0.6rem 0.85rem; min-height: 3.5rem;">
                        <i data-lucide="coffee" style="width: 20px; height: 20px; color: var(--color-primary); flex-shrink: 0;"></i>
                        <div style="text-align: left;">
                            <div style="font-weight: 600; font-size: 0.85rem; color: var(--text-primary);" data-i18n="demo_myr">Local Cafe (MYR)</div>
                            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.15rem;" data-i18n="demo_myr_desc">Nasi Lemak, Kopi O, Kaya Toast • RM 27.85</div>
                        </div>
                    </button>
                    <button id="loadSampleSGDBtn" class="btn btn-secondary w-full" style="justify-content: flex-start; gap: 0.75rem; padding: 0.6rem 0.85rem; min-height: 3.5rem;">
                        <i data-lucide="compass" style="width: 20px; height: 20px; color: var(--color-primary); flex-shrink: 0;"></i>
                        <div style="text-align: left;">
                            <div style="font-weight: 600; font-size: 0.85rem; color: var(--text-primary);" data-i18n="demo_sgd">Weekend Trip (SGD)</div>
                            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.15rem;" data-i18n="demo_sgd_desc">Hotel Stay, Car Gas, Attraction Tickets • SGD 220.00</div>
                        </div>
                    </button>
                </div>
            </div>

            <div id="preprocessCard" class="card preprocess-wrapper" style="display: none;">
                <h2 data-i18n="preprocess_title">Preprocess Receipt</h2>
                <p class="mb-4" data-i18n="preprocess_subtitle">Rotate, crop, and adjust brightness to make the receipt text clearer for OCR.</p>
                
                <div class="cropper-modal-container">
                    <img id="preprocessImage" class="cropper-img" src="" alt="Receipt Preview">
                </div>
                
                <div class="preprocess-controls">
                    <button id="rotateLeftBtn" class="btn btn-secondary btn-sm">
                        <i data-lucide="rotate-ccw"></i> <span data-i18n="rotate_left">Rotate Left</span>
                    </button>
                    <button id="rotateRightBtn" class="btn btn-secondary btn-sm">
                        <i data-lucide="rotate-cw"></i> <span data-i18n="rotate_right">Rotate Right</span>
                    </button>
                </div>

                <div class="input-group">
                    <label for="brightnessSlider" data-i18n="brightness">Brightness</label>
                    <input type="range" id="brightnessSlider" min="50" max="150" value="100" class="w-full">
                </div>
                <div class="input-group">
                    <label for="contrastSlider" data-i18n="contrast">Contrast</label>
                    <input type="range" id="contrastSlider" min="50" max="150" value="100" class="w-full">
                </div>

                <button id="ocrProcessBtn" class="btn btn-primary w-full">
                    <i data-lucide="scan-line"></i> <span data-i18n="extract_ocr">Extract Items (OCR)</span>
                </button>
            </div>
            
            <div class="wizard-footer-buttons">
                <div></div>
                <button id="skipOcrBtn" class="btn btn-secondary">
                    <span data-i18n="skip_ocr">Skip OCR / Manual Bill</span> <i data-lucide="arrow-right"></i>
                </button>
            </div>
        </section>

        <!-- STEP 2: REVIEW DETECTED BILL ITEMS -->
        <section id="step2" class="wizard-panel">
            <div class="card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; gap: 0.5rem; flex-wrap: wrap;">
                    <h2 style="margin: 0; font-size: 1.35rem;" data-i18n="step2_title">Review Extracted Bill</h2>
                    <button id="toggleInspectorBtn" class="btn btn-secondary btn-sm" style="display: none; height: 2.25rem; font-size: 0.8rem; padding: 0 0.75rem; align-items: center; gap: 0.35rem;">
                        <i data-lucide="eye" style="width: 16px; height: 16px;"></i> <span data-i18n="view_receipt">View Receipt</span>
                    </button>
                </div>
                <p class="mb-4" data-i18n="step2_subtitle">Verify and correct the store, currency, items, and taxes. Double click or tap fields to edit.</p>
                
                <div class="bill-meta-grid">
                    <div class="input-group">
                        <label for="billMerchant" data-i18n="merchant_store">Merchant / Store</label>
                        <input type="text" id="billMerchant" class="input-field" placeholder="Restaurant Name">
                    </div>
                    <div class="input-group">
                        <label for="billDate" data-i18n="date">Date</label>
                        <input type="date" id="billDate" class="input-field">
                    </div>
                    <div class="input-group">
                        <label for="billCurrency" data-i18n="currency">Currency</label>
                        <select id="billCurrency" class="input-field">
                            <option value="MYR" <?php echo $defaultSystemCurrency === 'MYR' ? 'selected' : ''; ?>>MYR (RM)</option>
                            <option value="SGD" <?php echo $defaultSystemCurrency === 'SGD' ? 'selected' : ''; ?>>SGD (S$)</option>
                            <option value="USD" <?php echo $defaultSystemCurrency === 'USD' ? 'selected' : ''; ?>>USD ($)</option>
                            <option value="EUR" <?php echo $defaultSystemCurrency === 'EUR' ? 'selected' : ''; ?>>EUR (€)</option>
                            <option value="GBP" <?php echo $defaultSystemCurrency === 'GBP' ? 'selected' : ''; ?>>GBP (£)</option>
                            <option value="JPY" <?php echo $defaultSystemCurrency === 'JPY' ? 'selected' : ''; ?>>JPY (¥)</option>
                            <option value="AUD" <?php echo $defaultSystemCurrency === 'AUD' ? 'selected' : ''; ?>>AUD (A$)</option>
                            <option value="THB" <?php echo $defaultSystemCurrency === 'THB' ? 'selected' : ''; ?>>THB (฿)</option>
                            <option value="IDR" <?php echo $defaultSystemCurrency === 'IDR' ? 'selected' : ''; ?>>IDR (Rp)</option>
                        </select>
                    </div>
                </div>

                <!-- Items Table -->
                <div class="table-wrapper">
                    <table id="billItemsTable" class="bill-table">
                        <thead>
                            <tr>
                                <th class="col-qty" data-i18n="col_qty">Qty</th>
                                <th class="col-name" data-i18n="col_name">Item Name</th>
                                <th class="col-price" data-i18n="col_price">Price</th>
                                <th class="col-action"></th>
                            </tr>
                        </thead>
                        <tbody id="billItemsBody">
                            <!-- Rows will be injected here -->
                        </tbody>
                    </table>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-top: 1rem;">
                    <button id="addItemRowBtn" class="btn btn-secondary btn-sm" style="min-height: 2.5rem; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                        <i data-lucide="plus"></i> <span data-i18n="add_item">Add Item</span>
                    </button>
                    <button id="addTravelExpenseBtn" class="btn btn-secondary btn-sm" style="min-height: 2.5rem; color: var(--color-primary); border-color: rgba(129, 140, 248, 0.3); display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                        <i data-lucide="compass"></i> <span data-i18n="travel_expense">Travel Expense</span>
                    </button>
                </div>

                <!-- Tax, service, discounts inputs -->
                <div class="bill-table-totals">
                    <div class="totals-row">
                        <span data-i18n="subtotal">Items Subtotal</span>
                        <span id="billSubtotal">0.00</span>
                    </div>
                    <div class="totals-row">
                        <span data-i18n="discount">Discount</span>
                        <input type="number" id="billDiscount" step="0.01" value="0.00">
                    </div>
                    <div class="totals-row">
                        <span data-i18n="service_charge">Service Charge</span>
                        <input type="number" id="billServiceCharge" step="0.01" value="0.00">
                    </div>
                    <div class="totals-row">
                        <span data-i18n="tax">Tax</span>
                        <input type="number" id="billTax" step="0.01" value="0.00">
                    </div>
                    <div class="totals-row">
                        <span data-i18n="rounding">Rounding Difference</span>
                        <input type="number" id="billRounding" step="0.01" value="0.00">
                    </div>
                    <div class="totals-row grand-total">
                        <span data-i18n="grand_total">Grand Total</span>
                        <input type="number" id="billGrandTotal" step="0.01" value="0.00">
                    </div>
                </div>
            </div>

            <!-- Sticky Receipt Inspector Panel -->
            <div id="receiptInspector" class="receipt-inspector">
                <div class="inspector-header">
                    <span>Receipt Preview</span>
                    <button id="closeInspectorBtn" class="inspector-close-btn">&times;</button>
                </div>
                <div class="inspector-body">
                    <div id="inspectorImageContainer" class="inspector-img-container">
                        <div class="inspector-placeholder">No receipt image uploaded.</div>
                    </div>
                </div>
            </div>

            <div class="wizard-footer-buttons">
                <button id="backToStep1" class="btn btn-secondary">
                    <i data-lucide="arrow-left"></i> <span data-i18n="back">Back</span>
                </button>
                <button id="nextToStep3" class="btn btn-primary">
                    <span data-i18n="next">Next</span>: <span data-i18n="step_people">People</span> <i data-lucide="arrow-right"></i>
                </button>
            </div>
        </section>

        <!-- STEP 3: PEOPLE MANAGEMENT -->
        <section id="step3" class="wizard-panel">
            <div class="card people-manager">
                <h2 data-i18n="step3_title">Add People</h2>
                <p data-i18n="step3_subtitle">Enter the names of everyone sharing the bill. Type their username to link their profile details.</p>
                
                <div id="peopleList" class="people-list">
                    <!-- People rows injected here -->
                </div>

                <button id="addPersonBtn" class="btn btn-secondary w-full">
                    <i data-lucide="user-plus"></i> <span data-i18n="add_person">Add Person</span>
                </button>
                <div style="display: flex; gap: 0.5rem; margin-top: 0.75rem;">
                    <button id="saveDefaultGroupBtn" class="btn btn-secondary btn-sm w-full" style="font-size: 0.8rem; height: 2.25rem;">
                        <i data-lucide="save" style="width: 14px; height: 14px;"></i> <span data-i18n="save">Save Group</span>
                    </button>
                    <button id="loadDefaultGroupBtn" class="btn btn-secondary btn-sm w-full" style="font-size: 0.8rem; height: 2.25rem;">
                        <i data-lucide="folder-open" style="width: 14px; height: 14px;"></i> <span data-i18n="load">Load Group</span>
                    </button>
                </div>
            </div>

            <!-- Payment Settings Card -->
            <div class="card payment-settings-card">
                <h3 style="font-size: 1.1rem; margin-bottom: 0.25rem; display: flex; align-items: center; gap: 0.5rem; color: var(--text-primary);">
                    <i data-lucide="qr-code" style="color: var(--color-primary); width: 20px; height: 20px;"></i> <span data-i18n="payment_qr_settings">Payment QR Settings</span>
                </h3>
                <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 0.5rem;"></p>
                
                <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                    <div class="input-group" style="margin-bottom: 0;">
                        <label for="paymentMethod" style="font-size: 0.75rem;" data-i18n="payment_method">Preferred Payment Method</label>
                        <select id="paymentMethod" class="input-field">
                            <option value="none">Disabled (No QR Codes)</option>
                            <option value="duitnow">DuitNow ID (Phone / NRIC)</option>
                            <option value="bank">Bank Transfer (Details Only)</option>
                            <option value="tng">Touch 'n Go E-Wallet Link</option>
                            <option value="custom">Custom QR Image</option>
                        </select>
                    </div>
                    <div id="paymentDetailGroup" class="input-group" style="margin-bottom: 0; display: none;">
                        <label id="paymentDetailLabel" for="paymentDetails" style="font-size: 0.75rem;">Phone Number / DuitNow ID</label>
                        <input type="text" id="paymentDetails" class="input-field" placeholder="e.g. 60123456789">
                    </div>
                    <div id="bankDetailsGroup" class="input-group" style="margin-bottom: 0; display: none;">
                        <label for="bankName" style="font-size: 0.75rem;" data-i18n="bank_name">Bank Name</label>
                        <input type="text" id="bankName" class="input-field" placeholder="e.g. Maybank">
                        <label for="bankAccount" style="font-size: 0.75rem; margin-top: 0.5rem;" data-i18n="bank_account">Account Number</label>
                        <input type="text" id="bankAccount" class="input-field" placeholder="e.g. 164012345678">
                    </div>
                </div>
            </div>

            <div class="wizard-footer-buttons">
                <button id="backToStep2" class="btn btn-secondary">
                    <i data-lucide="arrow-left"></i> <span data-i18n="back">Back</span>
                </button>
                <button id="nextToStep4" class="btn btn-primary">
                    <span data-i18n="next">Next</span>: <span data-i18n="step_assign">Assign</span> <i data-lucide="arrow-right"></i>
                </button>
            </div>
        </section>

        <!-- STEP 4: ITEM ASSIGNMENT -->
        <section id="step4" class="wizard-panel">
            <div class="card">
                <h2 data-i18n="step4_title">Assign Items</h2>
                <p class="mb-4" data-i18n="step4_subtitle">Tap people to assign items. Change split mode (Equal, %, or Shares) for uneven divisions.</p>
                
                <div id="assignItemScroller" class="assign-item-scroller">
                    <!-- Cards representing items and checkboxes/chips for people -->
                </div>
            </div>

            <div class="wizard-footer-buttons">
                <button id="backToStep3" class="btn btn-secondary">
                    <i data-lucide="arrow-left"></i> <span data-i18n="back">Back</span>
                </button>
                <button id="nextToStep5" class="btn btn-primary">
                    <span data-i18n="next">Next</span>: <span data-i18n="step_review">Review</span> <i data-lucide="arrow-right"></i>
                </button>
            </div>
        </section>

        <!-- STEP 5: REVIEW SPLIT RESULT -->
        <section id="step5" class="wizard-panel">
            <div class="card">
                <h2 data-i18n="step5_title">Review Split Shares</h2>
                <p class="mb-4" data-i18n="step5_subtitle">Verify each person's final calculated share, and choose how taxes/discounts are distributed.</p>

                <div class="distribution-settings">
                    <h3 data-i18n="tax_svc_dist">Tax & Service Distribution</h3>
                    
                    <div class="distribution-select-row mt-4">
                        <label for="taxDistribution" data-i18n="tax_svc_dist">Tax & Service Distribution</label>
                        <select id="taxDistribution" class="input-field" style="width: auto;">
                            <option value="proportional" data-i18n="proportional">Proportional</option>
                            <option value="equal" data-i18n="equally">Equally</option>
                            <option value="equal_assigned">Equally among Active</option>
                        </select>
                    </div>

                    <div class="distribution-select-row mt-4">
                        <label for="discountDistribution" data-i18n="disc_dist">Discount Distribution</label>
                        <select id="discountDistribution" class="input-field" style="width: auto;">
                            <option value="proportional" data-i18n="proportional">Proportional</option>
                            <option value="equal" data-i18n="equally">Equally</option>
                            <option value="equal_assigned">Equally among Active</option>
                        </select>
                    </div>
                </div>

                <div id="validationWarnings" class="mb-4">
                    <!-- Validation alerts are dynamically injected here -->
                </div>

                <h3 data-i18n="running_totals">Running Totals</h3>
                <div id="runningTotalsList" class="running-totals-list mt-4">
                    <!-- Running totals per person -->
                </div>
            </div>

            <div class="wizard-footer-buttons">
                <button id="backToStep4" class="btn btn-secondary">
                    <i data-lucide="arrow-left"></i> <span data-i18n="back">Back</span>
                </button>
                <button id="nextToStep6" class="btn btn-primary">
                    <span data-i18n="next">Next</span>: <span data-i18n="step_share">Share</span> <i data-lucide="arrow-right"></i>
                </button>
            </div>
        </section>

        <!-- STEP 6: SUMMARY & EXPORT / SHARE -->
        <section id="step6" class="wizard-panel">
            <div id="creatorPaymentInfoContainer"></div>
            <div class="card">
                <div id="billSummaryPrintArea" class="summary-container">
                    <div class="summary-header">
                        <div id="summaryMerchant" class="summary-store">Merchant Name</div>
                        <div id="summaryDate" class="summary-meta">Date: -</div>
                        <div id="summaryExchangeRateInfo" class="summary-meta" style="display: none;"></div>
                    </div>
                    
                    <div id="peopleSummaryContainer" class="summary-container">
                        <!-- Breakdown of each person's items and final amount -->
                    </div>

                    <!-- Trip Cost Breakdown -->
                    <div id="tripBreakdownContainer" style="display: none; margin-top: 1.5rem; background: var(--bg-glass); border: 1px solid var(--border-color); border-radius: 1rem; padding: 1.25rem;">
                        <h3 style="font-size: 1.05rem; margin-bottom: 0.85rem; color: var(--text-primary); display: flex; align-items: center; gap: 0.35rem; font-family: var(--font-heading);">
                            <i data-lucide="pie-chart" style="width: 16px; height: 16px; color: var(--color-primary);"></i> <span data-i18n="trip_breakdown">Trip Cost Breakdown</span>
                        </h3>
                        <div id="tripBreakdownList" style="display: flex; flex-direction: column; gap: 0.75rem;">
                            <!-- Progress bars will be injected dynamically -->
                        </div>
                    </div>

                    <div id="billSummaryTotals" class="bill-table-totals mt-4" style="border-top: 1px solid var(--border-color); padding-top: 0.5rem;">
                        <!-- Totals will be shown here -->
                    </div>
                </div>
            </div>

            <!-- Currency Conversion to MYR Widget -->
            <div id="myrConversionWidget" class="card exchange-rate-alert" style="display: none;">
                <div class="exchange-rate-row">
                    <strong style="color: var(--text-primary);">Foreign Currency Detected</strong>
                    <span id="rateLastUpdated" style="font-size:0.75rem; color:var(--text-muted);">Rates: Frankfurter</span>
                </div>
                <p>Converted values are calculated using the exchange rate below. You can override it manually.</p>
                <div class="exchange-rate-row mt-4">
                    <span>1 <span class="lbl-original-cur">USD</span> =</span>
                    <div class="exchange-rate-input-wrap">
                        <input type="number" id="manualExchangeRate" step="0.000001" min="0.000001">
                        <strong>MYR</strong>
                    </div>
                </div>
                <div class="exchange-rate-row">
                    <span>Grand Total in MYR:</span>
                    <strong id="myrGrandTotal" style="color: var(--color-success);">RM 0.00</strong>
                </div>
            </div>

            <div class="share-options-grid">
                <button id="copySummaryBtn" class="btn btn-secondary">
                    <i data-lucide="copy"></i> <span data-i18n="copy_summary">Copy Summary Text</span>
                </button>
                <button id="whatsappShareBtn" class="btn btn-primary" style="background-color: #25d366; border-color: #25d366;">
                    <i data-lucide="message-square"></i> <span data-i18n="share_whatsapp">Share to WhatsApp</span>
                </button>
                <button id="downloadCsvBtn" class="btn btn-secondary">
                    <i data-lucide="download"></i> <span data-i18n="download_csv">Download CSV</span>
                </button>
                <button id="printBillBtn" class="btn btn-secondary">
                    <i data-lucide="printer"></i> <span data-i18n="print_bill">Print Bill</span>
                </button>
            </div>

            <button id="restartBtn" class="btn btn-danger w-full mt-4">
                <i data-lucide="refresh-cw"></i> <span data-i18n="restart">Restart Wizard</span>
            </button>
        </section>

    </main>

    <!-- Configuration block to pass configurations from PHP to JS -->
    <script>
        window.APP_CONFIG = {
            ocrProvider: "<?php echo $config['ocr_provider']; ?>",
            currencyProvider: "<?php echo $config['currency_provider']; ?>"
        };
        window.USER_PROFILE = <?php echo json_encode($userProfile); ?>;
    </script>
    
    <!-- QR Code Modal -->
    <div id="qrModal" class="qr-modal-overlay">
        <div class="qr-modal-card">
            <h3 id="qrModalTitle" style="font-size: 1.15rem; margin-bottom: 0.5rem; color: var(--text-primary);">Payer QR Code</h3>
            <p id="qrModalSubtitle" style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;"></p>
            <div id="qrCodeContainer" class="payment-qr-container"></div>
            <p id="qrModalDetails" style="font-size: 0.85rem; font-weight: 500; color: var(--text-primary); margin-top: 1rem; line-height: 1.4; word-break: break-all;"></p>
            <button id="closeQrModalBtn" class="btn btn-secondary w-full mt-4" style="min-height: 2.5rem; padding: 0.5rem 1rem;" data-i18n="cancel">Close</button>
        </div>
    </div>

    <!-- Travel Expense Modal -->
    <div id="travelExpenseModal" class="qr-modal-overlay">
        <div class="qr-modal-card" style="max-width: 480px;">
            <h3 style="font-size: 1.25rem; margin-bottom: 0.75rem; color: var(--text-primary); display: flex; align-items: center; gap: 0.35rem;">
                <i data-lucide="compass" style="color: var(--color-primary);"></i> Travel Expense Calculator
            </h3>
            
            <!-- Modal Tabs -->
            <div class="modal-tabs" style="display: flex; border-bottom: 1px solid var(--border-color); margin-bottom: 1.25rem; gap: 0.5rem;">
                <button type="button" class="modal-tab-btn active" data-tab="gas" style="background: none; border: none; padding: 0.5rem 0.75rem; color: var(--color-primary); border-bottom: 2px solid var(--color-primary); font-weight: 600; cursor: pointer; font-size: 0.85rem;">🚗 Fuel/Gas</button>
                <button type="button" class="modal-tab-btn" data-tab="hotel" style="background: none; border: none; padding: 0.5rem 0.75rem; color: var(--text-muted); font-weight: 500; cursor: pointer; font-size: 0.85rem;">🏨 Lodging</button>
                <button type="button" class="modal-tab-btn" data-tab="activity" style="background: none; border: none; padding: 0.5rem 0.75rem; color: var(--text-muted); font-weight: 500; cursor: pointer; font-size: 0.85rem;">🎟️ Activity</button>
            </div>

            <!-- TAB CONTENT: GAS -->
            <div id="tab-gas" class="tab-content active-content">
                <div class="input-group mb-3" style="margin-bottom: 0.85rem;">
                    <label for="gasDistance" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Distance (km)</label>
                    <input type="number" id="gasDistance" class="input-field" value="100" placeholder="e.g. 150">
                </div>
                <div class="input-group mb-3" style="margin-bottom: 0.85rem;">
                    <label for="gasConsumption" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Fuel Consumption Rate (L/100km)</label>
                    <input type="number" id="gasConsumption" class="input-field" value="8.0" step="0.1" placeholder="e.g. 7.5">
                </div>
                <div class="input-group mb-3" style="margin-bottom: 0.85rem;">
                    <label for="gasFuelPrice" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Fuel Price (per Litre)</label>
                    <input type="number" id="gasFuelPrice" class="input-field" value="2.05" step="0.01" placeholder="e.g. 2.05">
                </div>
                <div style="background: var(--bg-secondary); padding: 0.75rem 1rem; border-radius: 0.75rem; margin-bottom: 1.25rem; border: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-size: 0.85rem; color: var(--text-muted);">Estimated Gas Cost:</span>
                    <strong id="gasEstimateText" style="color: var(--color-primary); font-size: 1.05rem;">RM 16.40</strong>
                </div>
            </div>

            <!-- TAB CONTENT: HOTEL -->
            <div id="tab-hotel" class="tab-content" style="display: none;">
                <div class="input-group mb-3" style="margin-bottom: 0.85rem;">
                    <label for="hotelRate" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Room Price (per night)</label>
                    <input type="number" id="hotelRate" class="input-field" placeholder="e.g. 150.00">
                </div>
                <div class="row-grid mb-3" style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 0.85rem;">
                    <div class="input-group">
                        <label for="hotelNights" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Nights</label>
                        <input type="number" id="hotelNights" class="input-field" value="1" min="1">
                    </div>
                    <div class="input-group">
                        <label for="hotelRooms" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Rooms</label>
                        <input type="number" id="hotelRooms" class="input-field" value="1" min="1">
                    </div>
                </div>
                <div class="input-group mb-3" style="margin-bottom: 0.85rem;">
                    <label for="hotelName" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Hotel / Room Label</label>
                    <input type="text" id="hotelName" class="input-field" value="Hotel Stay" placeholder="e.g. Hilton Room 302">
                </div>
            </div>

            <!-- TAB CONTENT: ACTIVITY -->
            <div id="tab-activity" class="tab-content" style="display: none;">
                <div class="input-group mb-3" style="margin-bottom: 0.85rem;">
                    <label for="activityName" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Activity Description</label>
                    <input type="text" id="activityName" class="input-field" placeholder="e.g. Theme Park Tickets">
                </div>
                <div class="row-grid mb-3" style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 0.85rem;">
                    <div class="input-group">
                        <label for="activityPrice" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Price per Person</label>
                        <input type="number" id="activityPrice" class="input-field" placeholder="e.g. 50.00">
                    </div>
                    <div class="input-group">
                        <label for="activityQty" style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Quantity</label>
                        <input type="number" id="activityQty" class="input-field" value="1" min="1">
                    </div>
                </div>
            </div>

            <div style="display: flex; gap: 0.75rem; margin-top: 1.5rem;">
                <button type="button" id="closeTravelModalBtn" class="btn btn-secondary w-full" style="min-height: 2.75rem; padding: 0.5rem 1rem;">Cancel</button>
                <button type="button" id="addTravelExpenseSubmitBtn" class="btn btn-primary w-full" style="min-height: 2.75rem; padding: 0.5rem 1rem;">Add Expense</button>
            </div>
        </div>
    </div>

    <!-- Library scripts -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    
    <!-- App modules -->
    <script src="assets/js/lang.js"></script>
    <script src="assets/js/utils.js"></script>
    <script src="assets/js/calculator.js"></script>
    <script src="assets/js/ocr.js"></script>
    <script src="assets/js/state.js"></script>
    <script src="assets/js/ui.js"></script>
    <script src="assets/js/app.js"></script>
    <script src="assets/js/pwa-install.js"></script>

    <!-- Run Lucide Icons replace -->
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
