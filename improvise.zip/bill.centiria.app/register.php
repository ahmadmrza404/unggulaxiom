<?php
/**
 * Personal Bill Splitter - User Registration Page
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

// 1. Redirect to installer if DB not configured
if (!isDbConfigured() && file_exists('install.php')) {
    header('Location: install.php');
    exit;
}

// 2. Redirect to dashboard if already logged in
if (isAuthenticated()) {
    header('Location: dashboard.php');
    exit;
}

$error = null;
$success = null;

// Check if registration is allowed in system settings
$registrationAllowed = true;
if (isDbConnected()) {
    try {
        $stmt = $db->query("SELECT setting_value FROM system_settings WHERE setting_key = 'allow_registration'");
        $val = $stmt->fetchColumn();
        if ($val === '0') {
            $registrationAllowed = false;
        }
    } catch (PDOException $e) {
        // Fallback if table not exists
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$registrationAllowed) {
        $error = "Registration is currently disabled by the administrator.";
    } elseif (!checkRateLimit('register', 5, 60)) {
        $error = "Too many registration attempts. Please wait a minute and try again.";
    } else {
        $token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
        if (!validateCSRFToken($token)) {
            $error = "CSRF verification failed. Please refresh the page and try again.";
        } else {
            $username = trim($_POST['username']);
            $password = trim($_POST['password']);
            $confirmPassword = trim($_POST['confirm_password']);

            if (empty($username) || empty($password) || empty($confirmPassword)) {
                $error = "Please fill in all fields.";
            } elseif (strlen($username) < 3) {
                $error = "Username must be at least 3 characters.";
            } elseif (strlen($password) < 6) {
                $error = "Password must be at least 6 characters.";
            } elseif ($password !== $confirmPassword) {
                $error = "Passwords do not match.";
            } else {
                try {
                    if (!isDbConnected()) {
                        throw new Exception("Database is offline.");
                    }

                    // Check if username already exists
                    $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
                    $stmt->execute([$username]);
                    if ($stmt->fetch()) {
                        $error = "Username is already taken.";
                    } else {
                        // Register user
                        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $db->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'user')");
                        $stmt->execute([$username, $passwordHash]);

                        logActivity('user_register', "Registered new user account: @$username");
                        $success = "Registration successful! You can now log in.";
                    }
                } catch (Exception $e) {
                    $error = $e->getMessage();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BillSplitter - Register</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" type="image/svg+xml" href="assets/icons/icon.svg">
    <link rel="apple-touch-icon" href="assets/icons/icon.svg">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#6366f1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        :root {
            --bg-primary: #0b0f19;
            --bg-secondary: #131926;
            --bg-tertiary: #1e2638;
            --border-color: rgba(255, 255, 255, 0.08);
            --color-primary: #818cf8;
            --color-primary-hover: #6366f1;
            --text-primary: #f8fafc;
            --text-muted: #64748b;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: 'Inter', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 1.5rem;
        }
        .container {
            width: 100%;
            max-width: 420px;
        }
        .card {
            background: rgba(19, 25, 38, 0.75);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--border-color);
            border-radius: 4px;
            padding: 2.25rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.5);
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        .header {
            text-align: center;
        }
        .header h1 {
            font-family: 'Outfit', sans-serif;
            font-size: 1.75rem;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
            letter-spacing: -0.02em;
        }
        .header p {
            font-size: 0.85rem;
            color: var(--text-muted);
        }
        .input-group {
            display: flex;
            flex-direction: column;
            gap: 0.4rem;
        }
        .input-group label {
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 0.05em;
        }
        .input-field {
            width: 100%;
            font-family: inherit;
            font-size: 0.95rem;
            padding: 0.75rem 1rem;
            border-radius: 2px;
            border: 1px solid var(--border-color);
            background-color: var(--bg-secondary);
            color: var(--text-primary);
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .input-field:focus {
            border-color: var(--color-primary);
            box-shadow: 0 0 12px rgba(129, 140, 248, 0.4);
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background-color: var(--color-primary);
            color: #ffffff;
            font-size: 0.95rem;
            font-weight: 600;
            padding: 0.8rem 1.5rem;
            border-radius: 2px;
            border: none;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.2s, transform 0.2s, box-shadow 0.2s;
            text-decoration: none;
        }
        .btn:hover {
            background-color: var(--color-primary-hover);
            box-shadow: 0 0 12px rgba(129, 140, 248, 0.4);
        }
        .btn:active {
            transform: scale(0.98);
        }
        .alert {
            padding: 0.85rem 1.25rem;
            border-radius: 2px;
            font-size: 0.875rem;
            line-height: 1.4;
        }
        .alert-error {
            background-color: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: #f87171;
        }
        .alert-success {
            background-color: rgba(52, 211, 153, 0.15);
            border: 1px solid rgba(52, 211, 153, 0.2);
            color: #34d399;
        }
        .footer-text {
            font-size: 0.85rem;
            color: var(--text-muted);
            text-align: center;
            margin-top: 0.5rem;
        }
        .footer-text a {
            color: var(--color-primary);
            text-decoration: none;
            font-weight: 600;
        }
        .footer-text a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Floating Language Switcher -->
    <div style="position: fixed; top: 1.5rem; right: 1.5rem; z-index: 1000;">
        <button id="langToggle" style="background: rgba(19, 25, 38, 0.75); border: 1px solid var(--border-color); color: var(--text-primary); cursor: pointer; border-radius: 4px; padding: 0.5rem 0.75rem; font-weight: 700; font-size: 0.8rem; font-family: 'Outfit', sans-serif; transition: all 0.2s;" onmouseover="this.style.borderColor='var(--color-primary)'" onmouseout="this.style.borderColor='var(--border-color)'" aria-label="Change Language">
            <?php echo getLang() === 'en' ? 'BM' : 'EN'; ?>
        </button>
    </div>

    <div class="container">
        <form action="register.php" method="POST" class="card">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <div class="header">
                <h1><?php echo __('create_account'); ?></h1>
                <p><?php echo getLang() === 'en' ? 'Register to save and track your bill splits' : 'Daftar untuk menyimpan dan mengesan bil anda'; ?></p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!$registrationAllowed): ?>
                <div class="alert alert-error" style="background-color: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.2); color: #fbbf24; display: flex; align-items: center; gap: 0.5rem; justify-content: center; padding: 1.25rem;">
                    <i data-lucide="alert-triangle" style="width: 20px; height: 20px; flex-shrink: 0; color: #fbbf24;"></i>
                    <span style="font-weight: 500; font-size: 0.85rem;"><?php echo getLang() === 'en' ? 'Registration is currently closed by the administrator.' : 'Pendaftaran sedang ditutup oleh pentadbir.'; ?></span>
                </div>
                <div style="margin-top: 1.5rem; text-align: center;">
                    <a href="login.php" class="btn" style="text-decoration: none;"><?php echo getLang() === 'en' ? 'Go to Login' : 'Kembali ke Log Masuk'; ?></a>
                </div>
            <?php else: ?>
                <div class="input-group">
                    <label for="username"><?php echo __('username'); ?></label>
                    <input type="text" id="username" name="username" class="input-field" placeholder="<?php echo getLang() === 'en' ? 'Choose a username' : 'Pilih nama pengguna'; ?>" required autofocus>
                </div>

                <div class="input-group">
                    <label for="password"><?php echo __('password'); ?></label>
                    <input type="password" id="password" name="password" class="input-field" placeholder="<?php echo getLang() === 'en' ? 'At least 6 characters' : 'Sekurang-kurangnya 6 aksara'; ?>" required>
                </div>

                <div class="input-group">
                    <label for="confirm_password"><?php echo getLang() === 'en' ? 'Confirm Password' : 'Sahkan Kata Laluan'; ?></label>
                    <input type="password" id="confirm_password" name="confirm_password" class="input-field" placeholder="<?php echo getLang() === 'en' ? 'Confirm your password' : 'Sahkan kata laluan anda'; ?>" required>
                </div>

                <button type="submit" class="btn"><?php echo __('register'); ?></button>
                
                <div class="footer-text">
                    <?php echo __('already_have_account'); ?> <a href="login.php"><?php echo __('login'); ?></a>
                </div>
            <?php endif; ?>
        </form>
    </div>

    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="assets/js/pwa-install.js"></script>
    <script>
        lucide.createIcons();
        <?php if ($success): ?>
        setTimeout(() => window.BillSplitterInstallPrompt?.show(), 900);
        <?php endif; ?>
        document.getElementById('langToggle')?.addEventListener('click', () => {
            const currentLang = document.cookie.split('; ').find(row => row.startsWith('lang='))?.split('=')[1] || 'en';
            const nextLang = currentLang === 'en' ? 'bm' : 'en';
            document.cookie = `lang=${nextLang}; path=/; max-age=${30 * 86400}`;
            const url = new URL(window.location.href);
            url.searchParams.set('lang', nextLang);
            window.location.href = url.toString();
        });
    </script>
</body>
</html>
