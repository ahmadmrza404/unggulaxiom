<?php
/**
 * Personal Bill Splitter - User Autocomplete Search API
 */

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!isAuthenticated()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$query = isset($_GET['q']) ? trim($_GET['q']) : '';

if (strlen($query) < 1) {
    echo json_encode([]);
    exit;
}

try {
    // Exclude the currently logged-in user from self-searching suggestions to keep the list relevant
    $currentUserId = $_SESSION['user_id'];
    
    if (isset($_GET['exact']) && $_GET['exact'] === '1') {
        $stmt = $db->prepare("
            SELECT id, username, display_name 
            FROM users 
            WHERE username = ? AND id != ?
        ");
        $stmt->execute([$query, $currentUserId]);
    } else {
        $stmt = $db->prepare("
            SELECT id, username, display_name 
            FROM users 
            WHERE (username LIKE ? OR display_name LIKE ?) 
              AND id != ? 
            LIMIT 5
        ");
        $likeQuery = '%' . $query . '%';
        $stmt->execute([$likeQuery, $likeQuery, $currentUserId]);
    }
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Clean and return results
    $results = [];
    foreach ($users as $u) {
        $results[] = [
            'id' => intval($u['id']),
            'username' => $u['username'],
            'display_name' => $u['display_name'] ?: $u['username']
        ];
    }
    
    echo json_encode($results);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
