<?php
/**
 * Personal Bill Splitter — Server-Side OCR Endpoint
 *
 * Uses Google Gemini Vision AI to understand receipt images with human-level accuracy.
 * Falls back to client-side Tesseract.js if Gemini is not configured.
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

// Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    sendJSONResponse(['success' => true], 204);
}

// Require Authentication
if (!isAuthenticated()) {
    sendJSONResponse(['success' => false, 'error' => 'Unauthorized. Please log in.'], 401);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSONResponse(['success' => false, 'error' => 'Method not allowed. Use POST.'], 405);
}

// Validate CSRF token
$csrfToken = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '';
if (!validateCSRFToken($csrfToken)) {
    sendJSONResponse(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
}

// Rate limiting: 15 OCR scans per minute
if (!checkRateLimit('ocr', 15, 60)) {
    sendJSONResponse(['success' => false, 'error' => 'Too many OCR scans. Please wait a minute and try again.'], 429);
}

// ── File Upload Validation ──────────────────────────────────────────────────
if (!isset($_FILES['receipt'])) {
    sendJSONResponse(['success' => false, 'error' => 'No receipt file uploaded.'], 400);
}

$fileValidation = validateUploadedFile($_FILES['receipt']);
if (!$fileValidation['success']) {
    sendJSONResponse(['success' => false, 'error' => $fileValidation['error']], 400);
}

$tempFilename = uniqid('receipt_', true) . '.' . $fileValidation['extension'];
$tempFilePath = $config['temp_dir'] . '/' . $tempFilename;

if (!move_uploaded_file($_FILES['receipt']['tmp_name'], $tempFilePath)) {
    sendJSONResponse(['success' => false, 'error' => 'Failed to store uploaded file temporarily.'], 500);
}

register_shutdown_function(function () use ($tempFilePath) {
    if (file_exists($tempFilePath)) @unlink($tempFilePath);
});

// ── OCR Provider Check ──────────────────────────────────────────────────────
$provider = isset($config['ocr_provider']) ? strtolower(trim($config['ocr_provider'])) : 'gemini';

if ($provider !== 'gemini') {
    sendJSONResponse([
        'success'  => true,
        'provider' => 'local',
        'message'  => 'Server is configured for local OCR. Client will run Tesseract.js.'
    ]);
}

$apiKey = isset($config['gemini_api_key']) ? trim($config['gemini_api_key']) : '';
if (empty($apiKey) || $apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
    sendJSONResponse([
        'success'  => true,
        'provider' => 'local',
        'message'  => 'Gemini API Key not configured. Falling back to local OCR.'
    ]);
}

// ── Gemini Vision OCR ───────────────────────────────────────────────────────
try {
    $mimeType  = $fileValidation['mime'];
    $imageData = base64_encode(file_get_contents($tempFilePath));

    $prompt = <<<PROMPT
You are an expert receipt parser. Analyze the attached receipt image carefully and extract ALL information from it.

Return a single valid JSON object with this exact schema (no markdown, no code fences, just raw JSON):
{
  "merchant": "Full store/restaurant/merchant name as printed on the receipt",
  "date": "Date in YYYY-MM-DD format, or empty string if not found",
  "currency": "ISO 4217 currency code detected from the receipt (e.g. MYR, USD, SGD, EUR, GBP, JPY, THB, IDR, AUD). Default to MYR if unclear.",
  "items": [
    {
      "name": "Clean, human-readable item name (remove item codes, trailing punctuation, leading quantities)",
      "qty": <integer quantity, default 1>,
      "price": <unit price as float, 2 decimal places>,
      "total": <total price for this line as float, 2 decimal places = qty * price>
    }
  ],
  "subtotal": <float - sum of all item totals before tax/service, 0.00 if not found>,
  "tax": <float - GST/SST/VAT/tax amount total, 0.00 if none>,
  "service_charge": <float - service charge amount, 0.00 if none>,
  "discount": <float - discount/promo/rebate total as a positive number, 0.00 if none>,
  "rounding": <float - rounding adjustment (can be negative), 0.00 if none>,
  "total": <float - grand total / amount due / final payable amount>
}

Rules:
- Extract EVERY food/product/service line item visible. Do not skip any.
- For items like "2x Nasi Lemak 12.50", set qty=2, price=6.25, total=12.50.
- Clean item names: remove leading numbers/codes, fix capitalization. "1 NASI LEMAK AYAM" → "Nasi Lemak Ayam".
- Do NOT include subtotal, tax, service charge, discount, or total rows as items.
- Do NOT make up any numbers. If a field is absent from the receipt, use 0 or empty string.
- All monetary values must be positive floats with 2 decimal places, except rounding which can be negative.
- Return ONLY the JSON object. No explanation, no markdown, no code fences.
PROMPT;

    // Use Gemini 2.0 Flash (best vision model, free tier available)
    $models = [
        'gemini-2.0-flash',
        'gemini-1.5-flash',
    ];

    $lastError = null;
    $parsedReceipt = null;

    foreach ($models as $model) {
        $apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . urlencode($apiKey);

        $payload = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt],
                        [
                            'inline_data' => [
                                'mime_type' => $mimeType,
                                'data'      => $imageData
                            ]
                        ]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature'     => 0.1,   // Low temperature = deterministic, factual
                'topP'            => 0.95,
                'maxOutputTokens' => 4096,
                'responseMimeType' => 'application/json'
            ]
        ];

        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => 45,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr) {
            $lastError = "cURL Error: " . $curlErr;
            continue;
        }

        if ($httpCode !== 200) {
            $lastError = "Gemini API HTTP {$httpCode}: " . substr($response, 0, 300);
            continue;
        }

        $resData = json_decode($response, true);

        if (!isset($resData['candidates'][0]['content']['parts'][0]['text'])) {
            $lastError = "Unexpected Gemini response structure.";
            continue;
        }

        $rawText = trim($resData['candidates'][0]['content']['parts'][0]['text']);

        // Strip any accidental markdown fences
        $rawText = preg_replace('/^```(?:json)?\s*/i', '', $rawText);
        $rawText = preg_replace('/\s*```$/', '', $rawText);
        $rawText = trim($rawText);

        $parsed = json_decode($rawText, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            $lastError = "JSON parse error: " . json_last_error_msg() . " — Raw: " . substr($rawText, 0, 200);
            continue;
        }

        // Validate minimum structure
        if (!isset($parsed['items']) || !is_array($parsed['items'])) {
            $lastError = "Response missing 'items' array.";
            continue;
        }

        // Sanitise numeric fields
        $numericFields = ['subtotal', 'tax', 'service_charge', 'discount', 'rounding', 'total'];
        foreach ($numericFields as $field) {
            $parsed[$field] = isset($parsed[$field]) ? round((float)$parsed[$field], 2) : 0.00;
        }

        // Sanitise items
        foreach ($parsed['items'] as &$item) {
            $item['qty']   = isset($item['qty'])   ? max(1, (int)$item['qty'])         : 1;
            $item['price'] = isset($item['price'])  ? round((float)$item['price'], 2)   : 0.00;
            $item['total'] = isset($item['total'])  ? round((float)$item['total'], 2)   : 0.00;
            $item['name']  = isset($item['name'])   ? trim((string)$item['name'])        : 'Unknown Item';
        }
        unset($item);

        $parsedReceipt = $parsed;
        break; // Success — no need to try next model
    }

    if ($parsedReceipt === null) {
        throw new Exception($lastError ?: 'All Gemini models failed.');
    }

    sendJSONResponse([
        'success'  => true,
        'provider' => 'gemini',
        'data'     => $parsedReceipt
    ]);

} catch (Exception $e) {
    error_log('[BillSplitter OCR] ' . $e->getMessage());
    sendJSONResponse([
        'success'  => false,
        'error'    => 'OCR Service Error: ' . $e->getMessage(),
        'fallback' => 'local'
    ], 500);
}
