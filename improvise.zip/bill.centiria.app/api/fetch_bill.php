<?php
/**
 * Personal Bill Splitter - Fetch Bill Split Record
 */

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!isAuthenticated()) {
    sendJSONResponse(['success' => false, 'error' => 'Unauthorized.'], 401);
}

$userId = $_SESSION['user_id'];
$billId = isset($_GET['id']) ? trim($_GET['id']) : '';

if (empty($billId)) {
    sendJSONResponse(['success' => false, 'error' => 'Bill ID is required.'], 400);
}

try {
    // 1. Fetch Bill Header
    $stmt = $db->prepare("SELECT * FROM bills WHERE id = ?");
    $stmt->execute([$billId]);
    $bill = $stmt->fetch();

    if (!$bill) {
        sendJSONResponse(['success' => false, 'error' => 'Bill not found.'], 404);
    }

    $isOwner = (intval($bill['user_id']) === $userId);
    $isParticipant = false;

    $checkPart = $db->prepare("SELECT COUNT(*) FROM bill_people WHERE bill_id = ? AND user_id = ?");
    $checkPart->execute([$billId, $userId]);
    if ($checkPart->fetchColumn() > 0) {
        $isParticipant = true;
    }

    if (!$isOwner && !$isParticipant) {
        sendJSONResponse(['success' => false, 'error' => 'Unauthorized to access this record.'], 403);
    }

    // 2. Fetch People
    $stmt = $db->prepare("SELECT id, name, user_id FROM bill_people WHERE bill_id = ?");
    $stmt->execute([$billId]);
    $dbPeople = $stmt->fetchAll();

    $people = [];
    foreach ($dbPeople as $p) {
        $people[] = [
            'id' => $p['id'],
            'name' => $p['name'],
            'userId' => $p['user_id'] ? intval($p['user_id']) : null
        ];
    }

    // 3. Fetch Items
    $stmt = $db->prepare("SELECT id, name, qty, price, split_mode, category FROM bill_items WHERE bill_id = ?");
    $stmt->execute([$billId]);
    $dbItems = $stmt->fetchAll();

    $items = [];
    foreach ($dbItems as $dbItem) {
        $itemId = $dbItem['id'];

        // Get Assignments
        $assignStmt = $db->prepare("SELECT person_id FROM bill_item_assignments WHERE item_id = ?");
        $assignStmt->execute([$itemId]);
        $assignedPeople = $assignStmt->fetchAll(PDO::FETCH_COLUMN);

        // Get Custom Splits
        $splitsStmt = $db->prepare("SELECT person_id, split_value FROM bill_item_splits WHERE item_id = ?");
        $splitsStmt->execute([$itemId]);
        $splitsRows = $splitsStmt->fetchAll();

        $splits = [];
        foreach ($splitsRows as $row) {
            $splits[$row['person_id']] = floatval($row['split_value']);
        }

        $items[] = [
            'id' => $itemId,
            'name' => $dbItem['name'],
            'qty' => intval($dbItem['qty']),
            'price' => floatval($dbItem['price']),
            'assignedPeople' => $assignedPeople,
            'splitMode' => $dbItem['split_mode'],
            'splits' => $splits,
            'category' => isset($dbItem['category']) ? $dbItem['category'] : 'food'
        ];
    }

    // Format output matching app.js state structure
    $outputState = [
        'id' => $bill['id'],
        'merchant' => $bill['merchant'],
        'date' => $bill['bill_date'],
        'currency' => $bill['currency'],
        'exchangeRate' => floatval($bill['exchange_rate']),
        'discount' => floatval($bill['discount']),
        'serviceCharge' => floatval($bill['service_charge']),
        'tax' => floatval($bill['tax']),
        'rounding' => floatval($bill['rounding']),
        'grandTotal' => floatval($bill['grand_total']),
        'taxDistribution' => $bill['tax_distribution'],
        'discountDistribution' => $bill['discount_distribution'],
        'people' => $people,
        'items' => $items
    ];

    // Fetch creator's payment details
    $creatorProfile = null;
    $stmtCreator = $db->prepare("
        SELECT u.username, u.display_name, u.qr_type, u.qr_value, u.qr_image,
               ub.bank_name, ub.account_name, ub.account_number
        FROM users u
        LEFT JOIN user_banks ub ON u.id = ub.user_id AND ub.is_preferred = 1
        WHERE u.id = ?
    ");
    $stmtCreator->execute([$bill['user_id']]);
    $creator = $stmtCreator->fetch();
    if ($creator) {
        $creatorProfile = [
            'username' => $creator['username'],
            'displayName' => $creator['display_name'] ?: $creator['username'],
            'qrType' => $creator['qr_type'],
            'qrValue' => $creator['qr_value'],
            'qrImage' => $creator['qr_image'],
            'bankName' => $creator['bank_name'] ?: null,
            'accountName' => $creator['account_name'] ?: null,
            'accountNumber' => $creator['account_number'] ?: null
        ];
    }

    sendJSONResponse([
        'success' => true,
        'bill' => $outputState,
        'creatorProfile' => $creatorProfile
    ]);

} catch (Exception $e) {
    sendJSONResponse(['success' => false, 'error' => $e->getMessage()], 500);
}
