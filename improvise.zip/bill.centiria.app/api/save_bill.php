<?php
/**
 * Personal Bill Splitter - Save Bill Split Record
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSONResponse(['success' => false, 'error' => 'Method not allowed. Use POST.'], 405);
}

if (!isAuthenticated()) {
    sendJSONResponse(['success' => false, 'error' => 'Unauthorized. Please log in.'], 401);
}

// Validate CSRF token
$csrfToken = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '';
if (!validateCSRFToken($csrfToken)) {
    sendJSONResponse(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
}

$userId = $_SESSION['user_id'];
$rawInput = file_get_contents('php://input');
$billState = json_decode($rawInput, true);

if (!$billState || empty($billState['grandTotal'])) {
    sendJSONResponse(['success' => false, 'error' => 'Invalid bill data payload.'], 400);
}

try {
    $db->beginTransaction();

    $billId = $billState['id'];
    $merchant = $billState['merchant'] ?: 'Restaurant Split';
    $billDate = $billState['date'] ?: date('Y-m-d');
    $currency = $billState['currency'] ?: 'MYR';
    $exchangeRate = floatval($billState['exchangeRate'] ?: 1.000000);
    $discount = floatval($billState['discount'] ?: 0.00);
    $serviceCharge = floatval($billState['serviceCharge'] ?: 0.00);
    $tax = floatval($billState['tax'] ?: 0.00);
    $rounding = floatval($billState['rounding'] ?: 0.00);
    $grandTotal = floatval($billState['grandTotal']);
    $taxDistribution = $billState['taxDistribution'] ?: 'proportional';
    $discountDistribution = $billState['discountDistribution'] ?: 'proportional';

    // 1. Check if bill exists
    $stmt = $db->prepare("SELECT user_id FROM bills WHERE id = ?");
    $stmt->execute([$billId]);
    $existing = $stmt->fetch();

    if ($existing) {
        // Enforce owner check
        if (intval($existing['user_id']) !== $userId) {
            throw new Exception("You do not have permission to edit this bill.");
        }
        
        // Clean old references (Cascade will delete items, assignments, splits, people)
        $deleteStmt = $db->prepare("DELETE FROM bills WHERE id = ?");
        $deleteStmt->execute([$billId]);
    }

    // 2. Insert Bill Header
    $insertBill = $db->prepare("INSERT INTO bills (id, user_id, merchant, bill_date, currency, exchange_rate, discount, service_charge, tax, rounding, grand_total, tax_distribution, discount_distribution) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $insertBill->execute([
        $billId, $userId, $merchant, $billDate, $currency, $exchangeRate, $discount, $serviceCharge, $tax, $rounding, $grandTotal, $taxDistribution, $discountDistribution
    ]);

    // 3. Insert People
    $insertPerson = $db->prepare("INSERT INTO bill_people (id, bill_id, name, user_id, total_owed) VALUES (?, ?, ?, ?, ?)");
    foreach ($billState['people'] as $person) {
        $personUserId = !empty($person['userId']) ? intval($person['userId']) : null;
        $totalOwed = isset($person['total_owed']) ? floatval($person['total_owed']) : 0.00;

        // If the bill creator includes themself as a participant, that share is already paid upfront
        // and should not become a collectible reimbursement entry.
        if ($personUserId !== null && intval($personUserId) === intval($userId)) {
            $totalOwed = 0.00;
        }

        $insertPerson->execute([$person['id'], $billId, $person['name'], $personUserId, $totalOwed]);
    }

    // 4. Insert Items
    $insertItem = $db->prepare("INSERT INTO bill_items (id, bill_id, name, qty, price, split_mode, category) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $insertAssignment = $db->prepare("INSERT INTO bill_item_assignments (item_id, person_id) VALUES (?, ?)");
    $insertSplitVal = $db->prepare("INSERT INTO bill_item_splits (item_id, person_id, split_value) VALUES (?, ?, ?)");

    foreach ($billState['items'] as $item) {
        $qty = intval($item['qty'] ?: 1);
        $price = floatval($item['price'] ?: 0.00);
        $splitMode = $item['splitMode'] ?: 'equal';
        $category = isset($item['category']) ? trim($item['category']) : 'food';
        
        $insertItem->execute([$item['id'], $billId, $item['name'] ?: 'Item', $qty, $price, $splitMode, $category]);

        // Insert Person Assignments
        if (!empty($item['assignedPeople'])) {
            foreach ($item['assignedPeople'] as $pid) {
                $insertAssignment->execute([$item['id'], $pid]);
                
                // If custom split mode (percent or share), insert custom splits details
                if ($splitMode !== 'equal' && isset($item['splits'][$pid])) {
                    $splitVal = floatval($item['splits'][$pid]);
                    $insertSplitVal->execute([$item['id'], $pid, $splitVal]);
                }
            }
        }
    }

    logActivity('create_bill', "Saved bill split: {$merchant} ({$currency} {$grandTotal})");
    $db->commit();
    sendJSONResponse(['success' => true]);

} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    sendJSONResponse(['success' => false, 'error' => $e->getMessage()], 500);
}
