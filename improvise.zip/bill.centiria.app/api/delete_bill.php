<?php
/**
 * Personal Bill Splitter - Delete Bill Split Record
 */

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSONResponse(['success' => false, 'error' => 'Method not allowed. Use POST.'], 405);
}

if (!isAuthenticated()) {
    sendJSONResponse(['success' => false, 'error' => 'Unauthorized.'], 401);
}

// Validate CSRF token
$csrfToken = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '';
if (!validateCSRFToken($csrfToken)) {
    sendJSONResponse(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
}

$userId = $_SESSION['user_id'];
$billId = isset($_GET['id']) ? trim($_GET['id']) : '';

if (empty($billId)) {
    sendJSONResponse(['success' => false, 'error' => 'Bill ID is required.'], 400);
}

try {
    // 1. Fetch Bill to verify ownership
    $stmt = $db->prepare("SELECT user_id FROM bills WHERE id = ?");
    $stmt->execute([$billId]);
    $bill = $stmt->fetch();

    if (!$bill) {
        sendJSONResponse(['success' => false, 'error' => 'Bill not found.'], 404);
    }

    if (intval($bill['user_id']) !== $userId) {
        sendJSONResponse(['success' => false, 'error' => 'Unauthorized to delete this record.'], 403);
    }

    // 2. Delete Bill
    $deleteStmt = $db->prepare("DELETE FROM bills WHERE id = ?");
    $deleteStmt->execute([$billId]);

    sendJSONResponse(['success' => true]);

} catch (PDOException $e) {
    sendJSONResponse(['success' => false, 'error' => $e->getMessage()], 500);
}
