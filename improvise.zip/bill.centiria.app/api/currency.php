<?php
/**
 * Personal Bill Splitter Currency Exchange Proxy
 * Fetches latest exchange rates from configured provider to convert to MYR.
 * Caches responses on the server briefly or lets client handle caching.
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

// Allow preflight and validate request method
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    sendJSONResponse(['success' => true], 204);
}

// Require Authentication
if (!isAuthenticated()) {
    sendJSONResponse(['success' => false, 'error' => 'Unauthorized. Please log in.'], 401);
}

// Rate limiting: 20 currency checks per minute
if (!checkRateLimit('currency', 20, 60)) {
    sendJSONResponse(['success' => false, 'error' => 'Too many currency requests. Please wait a minute and try again.'], 429);
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendJSONResponse(['success' => false, 'error' => 'Method not allowed. Use GET.'], 405);
}

$base = isset($_GET['base']) ? strtoupper(trim(sanitizeInput($_GET['base']))) : 'MYR';
$provider = isset($config['currency_provider']) ? $config['currency_provider'] : 'frankfurter';

// If base is MYR, we want rates from MYR to other currencies (or vice versa).
// Standardizing base as MYR is easiest to get all conversion rates at once.
try {
    $rates = [];
    $fetchedBase = 'MYR';
    
    if ($provider === 'exchangerate_api') {
        $apiKey = isset($config['exchangerate_api_key']) ? $config['exchangerate_api_key'] : '';
        if (empty($apiKey)) {
            throw new Exception("ExchangeRate-API key is not configured in .env.");
        }
        
        $url = "https://v6.exchangerate-api.com/v6/{$apiKey}/latest/MYR";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            throw new Exception("ExchangeRate-API returned HTTP code " . $httpCode);
        }
        
        $data = json_decode($response, true);
        if (isset($data['result']) && $data['result'] === 'success') {
            $rates = $data['conversion_rates'];
        } else {
            throw new Exception("Failed to fetch rates from ExchangeRate-API: " . ($data['error-type'] ?? 'Unknown error'));
        }
        
    } else {
        // Default to Frankfurter API (Free, no key)
        // Frankfurter base is EUR by default, but supports ?from=MYR
        // Note: Frankfurter does not support MYR as base if it's offline, or sometimes base currency limits apply.
        // But Frankfurter generally supports MYR. Let's write a robust fetch with EUR fallback if MYR base is rejected.
        $url = "https://api.frankfurter.app/latest?from=MYR";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            if (isset($data['rates'])) {
                $rates = $data['rates'];
                $rates['MYR'] = 1.0; // Self rate
            }
        } else {
            // Fallback: Fetch base EUR, then compute relative to MYR
            $urlFallback = "https://api.frankfurter.app/latest";
            $ch = curl_init($urlFallback);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            $response = curl_exec($ch);
            curl_close($ch);
            
            $data = json_decode($response, true);
            if (isset($data['rates']) && isset($data['rates']['MYR'])) {
                $eurToMyr = $data['rates']['MYR'];
                $rates['EUR'] = round(1 / $eurToMyr, 6);
                $rates['MYR'] = 1.0;
                foreach ($data['rates'] as $cur => $val) {
                    if ($cur !== 'MYR') {
                        $rates[$cur] = round($val / $eurToMyr, 6);
                    }
                }
            } else {
                throw new Exception("Frankfurter API returned HTTP code " . $httpCode);
            }
        }
    }
    
    // Send response
    sendJSONResponse([
        'success' => true,
        'base' => 'MYR',
        'provider' => $provider,
        'timestamp' => time(),
        'rates' => $rates
    ]);
    
} catch (Exception $e) {
    // If external APIs fail, send a list of static/mock conversion rates for major currencies as emergency fallback
    // relative to MYR (as of mid 2026 ballpark rates for USD, SGD, EUR, GBP, JPY, THB, IDR)
    $fallbackRates = [
        'MYR' => 1.000000,
        'USD' => 0.210000, // 1 USD = 4.76 MYR
        'SGD' => 0.280000, // 1 SGD = 3.57 MYR
        'EUR' => 0.190000, // 1 EUR = 5.26 MYR
        'GBP' => 0.165000, // 1 GBP = 6.06 MYR
        'JPY' => 33.50000, // 100 JPY = 3.00 MYR -> 1 MYR = 33.5 JPY
        'THB' => 7.700000, // 1 MYR = 7.7 THB
        'IDR' => 3450.000, // 1 MYR = 3450 IDR
        'AUD' => 0.320000, // 1 AUD = 3.12 MYR
    ];
    
    sendJSONResponse([
        'success' => true,
        'base' => 'MYR',
        'provider' => 'fallback_static',
        'error' => $e->getMessage(),
        'timestamp' => time(),
        'rates' => $fallbackRates
    ]);
}
