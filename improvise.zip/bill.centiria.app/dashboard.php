<?php
/**
 * Personal Bill Splitter - User Dashboard
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
requireAuth();

$user = getCurrentUser();
$userId = $_SESSION['user_id'];
$userBills = [];
$owedBills = [];
$dbError = null;
$successMessage = null;

if (isset($_GET['success'])) {
    if ($_GET['success'] === 'payment_marked') {
        $successMessage = "Your payment has been marked as paid and is pending creator verification.";
    } elseif ($_GET['success'] === 'payment_verified') {
        $successMessage = "Payment verified successfully.";
    } elseif ($_GET['success'] === 'payment_rejected') {
        $successMessage = "Payment rejected/unsettled successfully.";
    }
}

// Handle POST actions for dashboard
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
    if (!validateCSRFToken($token)) {
        http_response_code(403);
        echo "<h1>403 Forbidden</h1><p>Invalid or missing CSRF token.</p>";
        exit;
    }
    
    $action = $_POST['action'];
    if ($action === 'mark_paid') {
        $billId = $_POST['bill_id'];
        try {
            $stmt = $db->prepare("UPDATE bill_people SET settlement_status = 1 WHERE bill_id = ? AND user_id = ? AND settlement_status = 0");
            $stmt->execute([$billId, $userId]);
            logActivity('debtor_mark_paid', "Marked bill split ID {$billId} as paid (pending verification)");
            header("Location: dashboard.php?success=payment_marked");
            exit;
        } catch (PDOException $e) {
            $dbError = "Failed to mark paid: " . $e->getMessage();
        }
    } elseif ($action === 'verify_settlement') {
        $billId = $_POST['bill_id'];
        $personId = $_POST['person_id'];
        try {
            $stmtCheck = $db->prepare("SELECT user_id FROM bills WHERE id = ?");
            $stmtCheck->execute([$billId]);
            $owner = $stmtCheck->fetchColumn();
            
            if (intval($owner) === intval($userId)) {
                $stmt = $db->prepare("UPDATE bill_people SET settlement_status = 2 WHERE id = ? AND bill_id = ?");
                $stmt->execute([$personId, $billId]);
                logActivity('creator_verify_payment', "Verified payment from participant ID {$personId} on bill ID {$billId}");
                header("Location: dashboard.php?success=payment_verified");
                exit;
            } else {
                $dbError = "Unauthorized verification attempt.";
            }
        } catch (PDOException $e) {
            $dbError = "Failed to verify payment: " . $e->getMessage();
        }
    } elseif ($action === 'reject_settlement') {
        $billId = $_POST['bill_id'];
        $personId = $_POST['person_id'];
        try {
            $stmtCheck = $db->prepare("SELECT user_id FROM bills WHERE id = ?");
            $stmtCheck->execute([$billId]);
            $owner = $stmtCheck->fetchColumn();
            
            if (intval($owner) === intval($userId)) {
                $stmt = $db->prepare("UPDATE bill_people SET settlement_status = 0 WHERE id = ? AND bill_id = ?");
                $stmt->execute([$personId, $billId]);
                logActivity('creator_reject_payment', "Rejected/unsettled payment from participant ID {$personId} on bill ID {$billId}");
                header("Location: dashboard.php?success=payment_rejected");
                exit;
            } else {
                $dbError = "Unauthorized verification attempt.";
            }
        } catch (PDOException $e) {
            $dbError = "Failed to reject payment: " . $e->getMessage();
        }
    }
}

$totalPaid = 0.00;
$totalOwed = 0.00;
$avgCreated = 0.00;
$settleRate = 100;
$userBillsPeople = [];

try {
    if (isDbConnected()) {
        $stmt = $db->prepare("SELECT id, merchant, bill_date, currency, grand_total FROM bills WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$userId]);
        $userBills = $stmt->fetchAll();

        // Fetch bills split by others where you are listed as a participant
        $stmt = $db->prepare("
            SELECT b.id, b.merchant, b.bill_date, b.currency, bp.total_owed, bp.settlement_status, u.username as owner_username, u.display_name as owner_display_name
            FROM bills b 
            JOIN bill_people bp ON bp.bill_id = b.id 
            JOIN users u ON b.user_id = u.id 
            WHERE bp.user_id = ? AND b.user_id != ?
            ORDER BY b.created_at DESC
        ");
        $stmt->execute([$userId, $userId]);
        $owedBills = $stmt->fetchAll();

        // Aggregate stats
        $stmt = $db->prepare("SELECT SUM(grand_total) FROM bills WHERE user_id = ?");
        $stmt->execute([$userId]);
        $totalPaid = floatval($stmt->fetchColumn());

        $stmt = $db->prepare("SELECT SUM(bp.total_owed) FROM bill_people bp JOIN bills b ON bp.bill_id = b.id WHERE bp.user_id = ? AND b.user_id != ? AND bp.settlement_status != 2");
        $stmt->execute([$userId, $userId]);
        $totalOwed = floatval($stmt->fetchColumn());

        $stmt = $db->prepare("SELECT AVG(grand_total) FROM bills WHERE user_id = ?");
        $stmt->execute([$userId]);
        $avgCreated = floatval($stmt->fetchColumn());

        $stmt = $db->prepare("
            SELECT COUNT(*) 
            FROM bill_people bp 
            JOIN bills b ON bp.bill_id = b.id 
            WHERE b.user_id = ?
        ");
        $stmt->execute([$userId]);
        $totalPeople = intval($stmt->fetchColumn());

        $stmt = $db->prepare("
            SELECT COUNT(*) 
            FROM bill_people bp 
            JOIN bills b ON bp.bill_id = b.id 
            WHERE b.user_id = ? AND bp.settlement_status = 2
        ");
        $stmt->execute([$userId]);
        $settledPeople = intval($stmt->fetchColumn());

        $settleRate = $totalPeople > 0 ? round(($settledPeople / $totalPeople) * 100) : 100;

        // Fetch bill people details for settlement verification (Creator perspective)
        if (!empty($userBills)) {
            $stmt = $db->prepare("
                SELECT id, bill_id, name, user_id, total_owed, settlement_status 
                FROM bill_people 
                WHERE bill_id IN (" . implode(',', array_fill(0, count($userBills), '?')) . ")
            ");
            $stmt->execute(array_column($userBills, 'id'));
            while ($row = $stmt->fetch()) {
                $userBillsPeople[$row['bill_id']][] = $row;
            }
        }
    } else {
        $dbError = "Database offline. Please check connection.";
    }
} catch (PDOException $e) {
    $dbError = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BillSplitter - Dashboard</title>
    
    <!-- Preconnect resource hints for faster loading of CDN libraries -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://unpkg.com">
    
    <meta name="csrf-token" content="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
    <link rel="icon" type="image/svg+xml" href="assets/icons/icon.svg">
    <link rel="apple-touch-icon" href="assets/icons/icon.svg">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#6366f1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .user-welcome h1 {
            font-family: var(--font-heading);
            font-size: 1.75rem;
            color: var(--text-primary);
        }
        .user-welcome p {
            color: var(--text-muted);
            font-size: 0.85rem;
            margin-top: 0.25rem;
        }
        .header-actions {
            display: flex;
            gap: 0.75rem;
            align-items: center;
        }
        .bill-card-grid {
            display: flex;
            flex-direction: column;
            gap: 0.85rem;
        }
        .db-bill-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 1.25rem;
            background: var(--bg-glass);
            border: 1px solid var(--border-color);
            border-radius: 1rem;
            text-decoration: none;
            color: var(--text-primary);
            transition: all var(--transition-fast);
        }
        .db-bill-item:hover {
            transform: translateY(-2px);
            border-color: var(--color-primary);
            background-color: var(--color-primary-light);
        }
        .db-bill-info {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }
        .db-bill-merchant {
            font-weight: 600;
            font-size: 1rem;
        }
        .db-bill-meta {
            font-size: 0.75rem;
            color: var(--text-muted);
        }
        .db-bill-amount-wrap {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .db-bill-amount {
            font-family: var(--font-heading);
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--color-primary);
        }
        .delete-bill-btn {
            background: none;
            border: none;
            color: var(--color-danger);
            cursor: pointer;
            padding: 0.25rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 0.35rem;
            transition: background-color 0.2s;
        }
        .delete-bill-btn:hover {
            background-color: var(--color-danger-light);
        }
        .empty-dashboard {
            text-align: center;
            padding: 3.5rem 1.5rem;
            background: var(--bg-glass);
            border: 1px solid var(--border-color);
            border-radius: 1.25rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1rem;
        }
        .empty-dashboard h3 {
            font-size: 1.2rem;
            color: var(--text-primary);
        }
        .empty-dashboard p {
            max-width: 320px;
            font-size: 0.85rem;
            color: var(--text-muted);
            line-height: 1.4;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }
        @media(max-width: 768px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        .stat-card {
            background: var(--bg-glass);
            border: 1px solid var(--border-color);
            border-radius: 1rem;
            padding: 1rem;
            text-align: center;
            display: flex;
            flex-direction: column;
            gap: 0.15rem;
            box-shadow: var(--shadow-sm);
        }
        .stat-val {
            font-family: var(--font-heading);
            font-size: 1.35rem;
            font-weight: 800;
            color: var(--color-primary);
        }
        .stat-lbl {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 0.05em;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="logo">
            <i data-lucide="receipt"></i>
            <span>BillSplitter</span>
        </div>
        <div class="header-actions">
            <?php if (isAdmin()): ?>
                <a href="admin.php" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size: 0.8rem;">
                    <i data-lucide="shield-check"></i> <?php echo __('admin_panel'); ?>
                </a>
            <?php endif; ?>
            <a href="profile.php" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size: 0.8rem; gap: 0.35rem; padding: 0 0.65rem; display: inline-flex; align-items: center;">
                <?php if (!empty($user['profile_pic']) && file_exists(STORAGE_DIR . '/profiles/' . $user['profile_pic'])): ?>
                    <img src="storage/profiles/<?php echo htmlspecialchars($user['profile_pic']); ?>" style="width: 18px; height: 18px; object-fit: cover; border-radius: 2px;" alt="User Avatar">
                <?php else: ?>
                    <i data-lucide="user" style="width: 14px; height: 14px;"></i>
                <?php endif; ?>
                <span><?php echo __('profile'); ?></span>
            </a>
            <!-- Language Toggle Button -->
            <button id="langToggle" class="theme-toggle-btn" style="font-weight: 700; font-size: 0.8rem; font-family: var(--font-heading);" aria-label="Change Language">
                <?php echo getLang() === 'en' ? 'BM' : 'EN'; ?>
            </button>
            <a href="logout.php" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size: 0.8rem; color: var(--color-danger); border-color: rgba(239, 68, 68, 0.2);">
                <i data-lucide="log-out"></i> <?php echo __('logout'); ?>
            </a>
        </div>
    </header>

    <main class="container">
        <?php renderGlobalAnnouncement(); ?>
        <!-- Welcomer -->
        <div class="dashboard-header">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <?php if (!empty($user['profile_pic']) && file_exists(STORAGE_DIR . '/profiles/' . $user['profile_pic'])): ?>
                    <div style="width: 50px; height: 50px; border: 1px solid var(--border-color); border-radius: 4px; overflow: hidden; flex-shrink: 0;">
                        <img src="storage/profiles/<?php echo htmlspecialchars($user['profile_pic']); ?>" style="width: 100%; height: 100%; object-fit: cover;" alt="Avatar">
                    </div>
                <?php else: ?>
                    <div style="width: 50px; height: 50px; border: 1px solid var(--border-color); border-radius: 4px; background: var(--color-primary-light); color: var(--color-primary); display: flex; align-items: center; justify-content: center; font-family: var(--font-heading); font-size: 1.35rem; font-weight: 700; flex-shrink: 0;">
                        <?php echo strtoupper(substr($user['display_name'] ?: $user['username'], 0, 1)); ?>
                    </div>
                <?php endif; ?>
                <div class="user-welcome">
                    <h1 style="margin: 0; font-size: 1.45rem; line-height: 1.2;"><?php echo getLang() === 'en' ? 'Hello' : 'Helo'; ?>, <?php echo htmlspecialchars($user['display_name'] ?: $user['username']); ?>!</h1>
                    <p style="margin: 0.2rem 0 0 0; font-size: 0.8rem; color: var(--text-muted);"><?php echo getLang() === 'en' ? 'Track your shared bills and currency conversions' : 'Jejak bil kongsi dan pertukaran mata wang anda'; ?></p>
                </div>
            </div>
            <a href="index.php" class="btn btn-primary" style="height: 2.75rem; padding: 0 1.25rem;">
                <i data-lucide="plus-circle"></i> <?php echo __('create_new_split'); ?>
            </a>
        </div>

        <?php if ($dbError): ?>
            <div class="alert alert-warning" style="margin-bottom: 1.5rem;">
                <i data-lucide="alert-triangle"></i>
                <span><?php echo htmlspecialchars($dbError); ?></span>
            </div>
        <?php endif; ?>

        <?php if ($successMessage): ?>
            <div class="alert alert-success" style="margin-bottom: 1.5rem; background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.2); color: #10b981; padding: 0.75rem 1rem; display: flex; align-items: center; gap: 0.5rem; border-radius: 0.5rem;">
                <i data-lucide="check-circle" style="width: 18px; height: 18px;"></i>
                <span><?php echo htmlspecialchars($successMessage); ?></span>
            </div>
        <?php endif; ?>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <span class="stat-val">RM <?php echo number_format($totalPaid, 2); ?></span>
                <span class="stat-lbl"><?php echo getLang() === 'en' ? 'Total Paid/Split' : 'Jumlah Dibayar/Diberi'; ?></span>
            </div>
            <div class="stat-card">
                <span class="stat-val" style="color: var(--color-warning);">RM <?php echo number_format($totalOwed, 2); ?></span>
                <span class="stat-lbl"><?php echo getLang() === 'en' ? 'Total You Owe' : 'Jumlah Anda Hutang'; ?></span>
            </div>
            <div class="stat-card">
                <span class="stat-val">RM <?php echo number_format($avgCreated, 2); ?></span>
                <span class="stat-lbl"><?php echo getLang() === 'en' ? 'Avg Bill Split' : 'Purata Pembahagian'; ?></span>
            </div>
            <div class="stat-card">
                <span class="stat-val" style="color: #10b981;"><?php echo $settleRate; ?>%</span>
                <span class="stat-lbl"><?php echo getLang() === 'en' ? 'Settle Rate' : 'Kadar Selesai'; ?></span>
            </div>
        </div>

        <!-- Quick Profile Actions -->
        <div class="card" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem; padding: 1rem 1.25rem; margin-bottom: 1.5rem; border-radius: 1rem; background: var(--bg-glass);">
            <div style="display:flex; flex-direction:column; gap:0.25rem;">
                <strong style="font-size:0.95rem; color:var(--text-primary);"><?php echo getLang() === 'en' ? 'Quick Share Link' : 'Pautan Kongsi Cepat'; ?></strong>
                <span style="font-size:0.75rem; color:var(--text-muted);"><?php echo getLang() === 'en' ? 'Let others scan your DuitNow / details QR or add you directly as a participant.' : 'Biarkan rakan-rakan imbas QR DuitNow anda atau tambah anda secara terus.'; ?></span>
            </div>
            <div style="display:flex; gap:0.5rem; align-items:center;">
                <input type="text" id="dashboardShareLink" value="<?php echo htmlspecialchars((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/profile_view.php?u=' . $user['username']); ?>" readonly style="position:absolute; left:-9999px;">
                <button id="copyShareBtn" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size:0.8rem; display:inline-flex; align-items:center; gap:0.35rem; padding:0 0.85rem;">
                    <i data-lucide="copy" style="width:14px; height:14px;"></i> <span><?php echo getLang() === 'en' ? 'Copy Link' : 'Salin Pautan'; ?></span>
                </button>
                <button id="showQrBtn" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size:0.8rem; display:inline-flex; align-items:center; gap:0.35rem; padding:0 0.85rem;">
                    <i data-lucide="qr-code" style="width:14px; height:14px;"></i> <span><?php echo getLang() === 'en' ? 'Show Profile QR' : 'Tunjuk QR Profil'; ?></span>
                </button>
            </div>
        </div>

        <!-- Dashboard Tabs -->
        <div class="modal-tabs" style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem; border-bottom: 1px solid var(--border-color);">
            <button class="modal-tab-btn active" id="tabBtnPaid" style="flex:1; text-align:center; padding: 0.75rem; font-size: 0.9rem; font-weight: 600; cursor: pointer; border-bottom: 2px solid var(--color-primary); background:none; border:none; color:var(--color-primary)">
                <i data-lucide="receipt" style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:4px;"></i> <?php echo __('splits_created'); ?>
            </button>
            <button class="modal-tab-btn" id="tabBtnOwe" style="flex:1; text-align:center; padding: 0.75rem; font-size: 0.9rem; font-weight: 500; cursor: pointer; border-bottom: 2px solid transparent; background:none; border:none; color:var(--text-muted)">
                <i data-lucide="circle-dollar-sign" style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:4px;"></i> <?php echo __('splits_you_owe'); ?>
            </button>
        </div>

        <!-- TAB 1: SPLITS YOU PAID -->
        <div id="tabContentPaid">
            <?php if (empty($userBills)): ?>
                <div class="empty-dashboard">
                    <i data-lucide="clipboard-list" style="width: 48px; height: 48px; stroke-width: 1.25; color: var(--color-primary);"></i>
                    <h3><?php echo getLang() === 'en' ? 'No Saved Splits Yet' : 'Tiada Bil Disimpan Lagi'; ?></h3>
                    <p><?php echo getLang() === 'en' ? 'Start a new bill split, scan your receipt, assign food and drinks to friends, and save the totals here.' : 'Mulakan pembahagian bil baru, imbas resit anda, agihkan makanan dan minuman kepada rakan, dan simpan jumlah di sini.'; ?></p>
                    <a href="index.php" class="btn btn-primary btn-sm mt-2"><?php echo getLang() === 'en' ? 'Create First Split' : 'Buat Bil Pertama'; ?></a>
                </div>
            <?php else: ?>
                <!-- Search Filter -->
                <div class="input-group mb-3" style="margin-bottom:1rem;">
                    <input type="text" id="paidSearchInput" class="input-field" placeholder="<?php echo getLang() === 'en' ? 'Search splits created...' : 'Cari bil dicipta...'; ?>" onkeyup="filterBills('paidSearchInput', 'paidBillList')" style="height:2.5rem;">
                </div>

                <div class="bill-card-grid" id="paidBillList">
                    <?php foreach ($userBills as $bill): ?>
                        <div class="db-bill-item" style="flex-direction:column; align-items:stretch; gap:0.5rem;">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <a href="index.php?bill_id=<?php echo urlencode($bill['id']); ?>" style="display:flex; flex:1; text-decoration:none; color:inherit;">
                                    <div class="db-bill-info">
                                        <span class="db-bill-merchant" style="display:flex; align-items:center; gap:0.35rem;"><i data-lucide="utensils" style="width:16px; height:16px; color:var(--color-primary);"></i> <?php echo htmlspecialchars($bill['merchant'] ?: 'Restaurant Split'); ?></span>
                                        <span class="db-bill-meta">
                                            📅 <?php echo htmlspecialchars(date('M d, Y', strtotime($bill['bill_date']))); ?>
                                        </span>
                                    </div>
                                </a>
                                <div class="db-bill-amount-wrap">
                                    <span class="db-bill-amount">
                                        <?php
                                        $symbols = ['MYR' => 'RM', 'SGD' => 'S$', 'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'JPY' => '¥'];
                                        $symbol = isset($symbols[strtoupper($bill['currency'])]) ? $symbols[strtoupper($bill['currency'])] : $bill['currency'];
                                        $decimals = in_array(strtoupper($bill['currency']), ['JPY', 'KRW', 'CLP', 'VND', 'PYG']) ? 0 : 2;
                                        echo $symbol . ' ' . number_format($bill['grand_total'], $decimals);
                                        ?>
                                    </span>
                                    <button class="delete-bill-btn" data-bill-id="<?php echo htmlspecialchars($bill['id']); ?>" title="Delete Record">
                                        <i data-lucide="trash-2" style="width: 18px; height: 18px;"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <?php if (isset($userBillsPeople[$bill['id']])): ?>
                                <div style="margin-top: 0.5rem; border-top: 1px solid var(--border-color); padding-top: 0.5rem; display:flex; flex-direction:column; gap:0.4rem;">
                                    <?php foreach ($userBillsPeople[$bill['id']] as $person): ?>
                                        <?php if (floatval($person['total_owed']) <= 0 && intval($person['user_id']) === intval($userId)) continue; ?>
                                        <div style="display:flex; justify-content:space-between; align-items:center; font-size:0.75rem; padding: 0.15rem 0;">
                                            <span style="color:var(--text-secondary); display:flex; align-items:center; gap:0.25rem;"><i data-lucide="user" style="width:12px; height:12px; color:var(--text-muted);"></i> <?php echo htmlspecialchars($person['name']); ?></span>
                                            <div style="display:flex; align-items:center; gap:0.5rem;">
                                                <span style="font-weight:600; color:var(--text-primary);">
                                                    RM <?php echo number_format($person['total_owed'], 2); ?>
                                                </span>
                                                <?php if ($person['settlement_status'] == 2): ?>
                                                    <span style="background:rgba(16,185,129,0.08); color:#10b981; font-size:0.6rem; font-weight:700; padding:0.1rem 0.35rem; border-radius:2px; border:1px solid rgba(16,185,129,0.15); display:inline-flex; align-items:center; gap:0.15rem;"><i data-lucide="check" style="width:10px; height:10px;"></i> <?php echo getLang() === 'en' ? 'Settled' : 'Selesai'; ?></span>
                                                <?php elseif ($person['settlement_status'] == 1): ?>
                                                    <div style="display:flex; gap:0.25rem;">
                                                        <form action="dashboard.php" method="POST" style="margin:0;">
                                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                            <input type="hidden" name="action" value="verify_settlement">
                                                            <input type="hidden" name="bill_id" value="<?php echo $bill['id']; ?>">
                                                            <input type="hidden" name="person_id" value="<?php echo $person['id']; ?>">
                                                            <button type="submit" class="btn btn-secondary btn-sm" style="font-size:0.65rem; padding:0.1rem 0.4rem; height:1.5rem; background:rgba(16,185,129,0.15); color:#10b981; border-color:rgba(16,185,129,0.25); min-height:unset; display:inline-flex; align-items:center; gap:0.15rem; font-weight:600;"><i data-lucide="check" style="width:10px; height:10px;"></i> <?php echo getLang() === 'en' ? 'Verify' : 'Sahkan'; ?></button>
                                                        </form>
                                                        <form action="dashboard.php" method="POST" style="margin:0;">
                                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                            <input type="hidden" name="action" value="reject_settlement">
                                                            <input type="hidden" name="bill_id" value="<?php echo $bill['id']; ?>">
                                                            <input type="hidden" name="person_id" value="<?php echo $person['id']; ?>">
                                                            <button type="submit" class="btn btn-secondary btn-sm" style="font-size:0.65rem; padding:0.1rem 0.4rem; height:1.5rem; color:var(--color-danger); border-color:rgba(239,68,68,0.2); min-height:unset; display:inline-flex; align-items:center; gap:0.15rem; font-weight:600;"><i data-lucide="x" style="width:10px; height:10px;"></i> <?php echo getLang() === 'en' ? 'Reject' : 'Tolak'; ?></button>
                                                        </form>
                                                    </div>
                                                <?php else: ?>
                                                    <span style="background:rgba(239,68,68,0.06); color:#f87171; font-size:0.6rem; font-weight:700; padding:0.1rem 0.35rem; border-radius:2px; border:1px solid rgba(239,68,68,0.12); display:inline-flex; align-items:center; gap:0.15rem;"><i data-lucide="clock" style="width:10px; height:10px;"></i> <?php echo getLang() === 'en' ? 'Unpaid' : 'Belum Bayar'; ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- TAB 2: SPLITS YOU OWE -->
        <div id="tabContentOwe" style="display: none;">
            <?php if (empty($owedBills)): ?>
                <div class="empty-dashboard">
                    <i data-lucide="smile" style="width: 48px; height: 48px; stroke-width: 1.25; color: var(--color-success);"></i>
                    <h3><?php echo getLang() === 'en' ? 'All Settled Up!' : 'Semua Selesai!'; ?></h3>
                    <p><?php echo getLang() === 'en' ? 'No bills owed to others. When friends add you to their splits by your username, they will appear here.' : 'Tiada bil yang dihutang kepada orang lain. Apabila rakan menambah anda ke bil mereka menggunakan nama pengguna anda, ia akan muncul di sini.'; ?></p>
                </div>
            <?php else: ?>
                <!-- Search Filter -->
                <div class="input-group mb-3" style="margin-bottom:1rem;">
                    <input type="text" id="owedSearchInput" class="input-field" placeholder="<?php echo getLang() === 'en' ? 'Search splits you owe...' : 'Cari bil anda hutang...'; ?>" onkeyup="filterBills('owedSearchInput', 'owedBillList')" style="height:2.5rem;">
                </div>

                <div class="bill-card-grid" id="owedBillList">
                    <?php foreach ($owedBills as $bill): ?>
                        <div class="db-bill-item">
                            <a href="index.php?bill_id=<?php echo urlencode($bill['id']); ?>" style="display:flex; flex:1; text-decoration:none; color:inherit;">
                                <div class="db-bill-info">
                                    <span class="db-bill-merchant" style="display:flex; align-items:center; gap:0.35rem;"><i data-lucide="utensils" style="width:16px; height:16px; color:var(--color-warning);"></i> <?php echo htmlspecialchars($bill['merchant'] ?: 'Restaurant Split'); ?></span>
                                    <span class="db-bill-meta">
                                        👤 <?php echo getLang() === 'en' ? 'Paid by' : 'Dibayar oleh'; ?>: <strong><?php echo htmlspecialchars($bill['owner_display_name'] ?: $bill['owner_username']); ?></strong> • 📅 <?php echo htmlspecialchars(date('M d, Y', strtotime($bill['bill_date']))); ?>
                                    </span>
                                </div>
                            </a>
                            <div class="db-bill-amount-wrap">
                                <span class="db-bill-amount" style="color:var(--color-warning); margin-right: 0.5rem;">
                                    <?php
                                    $symbols = ['MYR' => 'RM', 'SGD' => 'S$', 'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'JPY' => '¥'];
                                    $symbol = isset($symbols[strtoupper($bill['currency'])]) ? $symbols[strtoupper($bill['currency'])] : $bill['currency'];
                                    $decimals = in_array(strtoupper($bill['currency']), ['JPY', 'KRW', 'CLP', 'VND', 'PYG']) ? 0 : 2;
                                    echo $symbol . ' ' . number_format($bill['total_owed'], $decimals);
                                    ?>
                                </span>
                                <?php if ($bill['settlement_status'] == 2): ?>
                                    <span style="background:rgba(16,185,129,0.08); color:#10b981; font-size:0.7rem; font-weight:700; padding:0.2rem 0.5rem; border-radius:4px; border:1px solid rgba(16,185,129,0.15); display:inline-flex; align-items:center; gap:0.2rem;"><i data-lucide="check" style="width:12px; height:12px;"></i> <?php echo getLang() === 'en' ? 'Settled' : 'Selesai'; ?></span>
                                <?php elseif ($bill['settlement_status'] == 1): ?>
                                    <span style="background:rgba(245,158,11,0.08); color:#f59e0b; font-size:0.7rem; font-weight:700; padding:0.2rem 0.5rem; border-radius:4px; border:1px solid rgba(245,158,11,0.15); display:inline-flex; align-items:center; gap:0.2rem;"><i data-lucide="clock" style="width:12px; height:12px;"></i> <?php echo getLang() === 'en' ? 'Pending Verification' : 'Menunggu Pengesahan'; ?></span>
                                <?php else: ?>
                                    <form action="dashboard.php" method="POST" style="margin:0;">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                        <input type="hidden" name="action" value="mark_paid">
                                        <input type="hidden" name="bill_id" value="<?php echo $bill['id']; ?>">
                                        <button type="submit" class="btn btn-secondary btn-sm" style="font-size:0.75rem; height:2.25rem; padding:0 0.75rem; min-height:unset; color:#10b981; border-color:rgba(16,185,129,0.3); font-weight:600; display:inline-flex; align-items:center; gap:0.25rem;"><i data-lucide="credit-card" style="width:14px; height:14px;"></i> <?php echo getLang() === 'en' ? 'Mark as Paid' : 'Tanda Sudah Bayar'; ?></button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Dashboard Profile QR Modal -->
        <div id="profileQrModal" class="qr-modal-overlay" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(11,15,25,0.85); backdrop-filter: blur(8px); align-items: center; justify-content: center; z-index: 1000;">
            <div class="qr-modal-card" style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: 1.25rem; padding: 2rem; max-width: 360px; width: 90%; text-align: center; box-shadow: var(--shadow-lg);">
                <h3 style="font-size: 1.15rem; margin-bottom: 0.5rem; color: var(--text-primary);"><?php echo getLang() === 'en' ? 'My Profile QR Code' : 'Kod QR Profil Saya'; ?></h3>
                <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;"><?php echo getLang() === 'en' ? 'Let friends scan this QR to see your details and split bills instantly.' : 'Biarkan rakan-rakan imbas QR ini untuk melihat butiran anda dan membahagikan bil.'; ?></p>
                <div id="profileQrContainer" style="background: #fff; padding: 0.75rem; border-radius: 0.5rem; display: inline-flex; justify-content: center; margin-bottom: 1rem; border: 1px solid var(--border-color);"></div>
                <button id="closeProfileQrModalBtn" class="btn btn-secondary w-full" style="min-height: 2.5rem; padding: 0.5rem 1rem;"><?php echo getLang() === 'en' ? 'Close' : 'Tutup'; ?></button>
            </div>
        </div>
    </main>

    <!-- Library scripts -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script src="assets/js/utils.js"></script>
    <script>
        lucide.createIcons();

        // 1. Filter lists dynamically
        function filterBills(inputId, listId) {
            const query = document.getElementById(inputId).value.toLowerCase();
            const items = document.querySelectorAll(`#${listId} > .db-bill-item`);
            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.indexOf(query) > -1) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        // 2. Share profile link
        const copyShareBtn = document.getElementById('copyShareBtn');
        if (copyShareBtn) {
            copyShareBtn.addEventListener('click', () => {
                const linkInput = document.getElementById('dashboardShareLink');
                linkInput.select();
                document.execCommand('copy');
                Utils.showToast("<?php echo getLang() === 'en' ? 'Profile link copied!' : 'Pautan profil disalin!'; ?>", "success");
            });
        }

        // 3. Profile QR Code Popup
        const showQrBtn = document.getElementById('showQrBtn');
        const closeProfileQrModalBtn = document.getElementById('closeProfileQrModalBtn');
        const profileQrModal = document.getElementById('profileQrModal');
        const profileQrContainer = document.getElementById('profileQrContainer');
        let profileQrGen = null;

        if (showQrBtn && profileQrModal) {
            showQrBtn.addEventListener('click', () => {
                profileQrModal.style.display = 'flex';
                if (!profileQrGen) {
                    const shareUrl = document.getElementById('dashboardShareLink').value;
                    profileQrContainer.innerHTML = '';
                    profileQrGen = new QRCode(profileQrContainer, {
                        text: shareUrl,
                        width: 160,
                        height: 160,
                        colorDark : "#0b0f19",
                        colorLight : "#ffffff",
                        correctLevel : QRCode.CorrectLevel.M
                    });
                }
            });
        }

        if (closeProfileQrModalBtn && profileQrModal) {
            closeProfileQrModalBtn.addEventListener('click', () => {
                profileQrModal.style.display = 'none';
            });
        }

        // Language Switcher Logic
        document.getElementById('langToggle')?.addEventListener('click', () => {
            const currentLang = document.cookie.split('; ').find(row => row.startsWith('lang='))?.split('=')[1] || 'en';
            const nextLang = currentLang === 'en' ? 'bm' : 'en';
            document.cookie = `lang=${nextLang}; path=/; max-age=${30 * 86400}`;
            const url = new URL(window.location.href);
            url.searchParams.set('lang', nextLang);
            window.location.href = url.toString();
        });

        // Tab Switching logic
        const tabBtnPaid = document.getElementById('tabBtnPaid');
        const tabBtnOwe = document.getElementById('tabBtnOwe');
        const tabContentPaid = document.getElementById('tabContentPaid');
        const tabContentOwe = document.getElementById('tabContentOwe');

        if (tabBtnPaid && tabBtnOwe) {
            tabBtnPaid.addEventListener('click', () => {
                tabBtnPaid.classList.add('active');
                tabBtnPaid.style.color = 'var(--color-primary)';
                tabBtnPaid.style.borderBottomColor = 'var(--color-primary)';
                tabBtnPaid.style.fontWeight = '600';

                tabBtnOwe.classList.remove('active');
                tabBtnOwe.style.color = 'var(--text-muted)';
                tabBtnOwe.style.borderBottomColor = 'transparent';
                tabBtnOwe.style.fontWeight = '500';

                tabContentPaid.style.display = 'block';
                tabContentOwe.style.display = 'none';
            });

            tabBtnOwe.addEventListener('click', () => {
                tabBtnOwe.classList.add('active');
                tabBtnOwe.style.color = 'var(--color-primary)';
                tabBtnOwe.style.borderBottomColor = 'var(--color-primary)';
                tabBtnOwe.style.fontWeight = '600';

                tabBtnPaid.classList.remove('active');
                tabBtnPaid.style.color = 'var(--text-muted)';
                tabBtnPaid.style.borderBottomColor = 'transparent';
                tabBtnPaid.style.fontWeight = '500';

                tabContentPaid.style.display = 'none';
                tabContentOwe.style.display = 'block';
            });
        }

        // Handle delete clicks via fetch
        document.querySelectorAll('.delete-bill-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const billId = btn.dataset.billId;
                const confirmMsg = "<?php echo getLang() === 'en' ? 'Are you sure you want to delete this saved bill? This action cannot be undone.' : 'Adakah anda pasti mahu memadam bil yang disimpan ini? Tindakan ini tidak boleh diundur.'; ?>";
                const successMsg = "<?php echo getLang() === 'en' ? 'Bill deleted successfully' : 'Bil berjaya dipadam'; ?>";
                const failMsg = "<?php echo getLang() === 'en' ? 'Failed to delete bill' : 'Gagal memadam bil'; ?>";
                const connErrorMsg = "<?php echo getLang() === 'en' ? 'Error connecting to server' : 'Ralat menyambung ke pelayan'; ?>";

                if (confirm(confirmMsg)) {
                    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                    fetch(`api/delete_bill.php?id=${encodeURIComponent(billId)}`, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-Token': csrfToken
                        }
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            Utils.showToast(successMsg, "success");
                            setTimeout(() => location.reload(), 1000);
                        } else {
                            Utils.showToast(data.error || failMsg, "error");
                        }
                    })
                    .catch(err => {
                        Utils.showToast(connErrorMsg, "error");
                    });
                }
            });
        });
    </script>
</body>
</html>
