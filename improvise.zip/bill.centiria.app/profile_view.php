<?php
/**
 * Personal Bill Splitter - Public Profile & Payment View
 * Access: PUBLIC (No login required)
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$username = isset($_GET['u']) ? trim($_GET['u']) : '';
$profileUser = null;
$error = null;

if (empty($username)) {
    $error = "No username specified.";
} else {
    try {
        if (isDbConnected()) {
            $stmt = $db->prepare("SELECT id, username, display_name, email, profile_pic, qr_type, qr_value, qr_image, bio, telegram, phone FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $profileUser = $stmt->fetch();
            
            if (!$profileUser) {
                $error = "User @{$username} not found in our system.";
            }
        } else {
            $error = "Database offline. Please try again later.";
        }
    } catch (PDOException $e) {
        $error = "Database Error: " . $e->getMessage();
    }
}

$preferredBank = null;
$otherBanks = [];

if ($profileUser) {
    try {
        // Fetch all bank accounts
        $stmt = $db->prepare("SELECT * FROM user_banks WHERE user_id = ? ORDER BY is_preferred DESC, created_at DESC");
        $stmt->execute([$profileUser['id']]);
        $banks = $stmt->fetchAll();
        
        foreach ($banks as $bank) {
            if ($bank['is_preferred']) {
                $preferredBank = $bank;
            } else {
                $otherBanks[] = $bank;
            }
        }
        
        // Fallback: If no bank is marked as preferred but banks exist, treat the first one as preferred
        if (!$preferredBank && count($banks) > 0) {
            $preferredBank = $banks[0];
            array_shift($otherBanks);
        }
    } catch (PDOException $e) {
        // Silent error
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay <?php echo $profileUser ? htmlspecialchars($profileUser['display_name'] ?: $profileUser['username']) : 'Not Found'; ?> - BillSplitter</title>
    
    <!-- Preconnect resource hints for faster loading of CDN libraries -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://unpkg.com">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
    
    <link rel="icon" type="image/svg+xml" href="assets/icons/icon.svg">
    <link rel="apple-touch-icon" href="assets/icons/icon.svg">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#6366f1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background-color: #0b0f19;
            color: #f8fafc;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 1.5rem 1rem;
        }
        .public-profile-card {
            width: 100%;
            max-width: 440px;
            background: rgba(19, 25, 38, 0.7);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 1.5rem;
            padding: 2rem 1.5rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.5);
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        .profile-header {
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
        }
        .profile-avatar {
            width: 72px;
            height: 72px;
            background: var(--color-primary-light);
            border: 2px solid var(--color-primary);
            color: var(--color-primary);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            font-family: var(--font-heading);
            font-weight: 700;
            margin-bottom: 0.25rem;
        }
        .profile-name {
            font-family: var(--font-heading);
            font-size: 1.35rem;
            font-weight: 700;
            color: var(--text-primary);
        }
        .profile-username {
            font-size: 0.85rem;
            color: var(--text-muted);
        }
        .payment-box {
            background: rgba(255,255,255,0.02);
            border: 1px solid var(--border-color);
            border-radius: 1rem;
            padding: 1.25rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        .bank-details-block {
            display: flex;
            flex-direction: column;
            gap: 0.35rem;
            position: relative;
        }
        .bank-name-label {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            color: var(--color-primary);
            letter-spacing: 0.05em;
        }
        .account-number-large {
            font-family: var(--font-heading);
            font-size: 1.35rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: 0.02em;
            margin: 0.15rem 0;
            word-break: break-all;
        }
        .account-holder-name {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }
        .qr-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
            border-top: 1px dashed var(--border-color);
            padding-top: 1rem;
        }
        .public-qr-card {
            background: #ffffff;
            padding: 0.75rem;
            border-radius: 0.75rem;
            width: 140px;
            height: 140px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--border-color);
        }
        .public-qr-card canvas, .public-qr-card img {
            max-width: 100%;
            max-height: 100%;
        }
        .sec-banks-accordion {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        .sec-bank-item {
            background: rgba(255,255,255,0.01);
            border: 1px solid var(--border-color);
            border-radius: 0.75rem;
            padding: 0.75rem 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .profile-bio-box {
            font-size: 0.85rem;
            color: var(--text-secondary);
            text-align: center;
            font-style: italic;
            border-top: 1px dashed var(--border-color);
            padding-top: 0.85rem;
            margin-top: 0.35rem;
            width: 100%;
            line-height: 1.4;
        }
        .contact-badges {
            display: flex;
            gap: 0.5rem;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 0.25rem;
            width: 100%;
        }
        .contact-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.35rem 0.65rem;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--border-color);
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 600;
            text-decoration: none;
            border-radius: 4px;
            transition: all var(--transition-fast);
        }
        .contact-badge:hover {
            border-color: var(--color-primary);
            color: var(--color-primary);
            background: var(--color-primary-light);
            transform: translateY(-1px);
        }
        .interactive-pay-calc {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--border-color);
            border-radius: 1rem;
            padding: 1.25rem;
            display: flex;
            flex-direction: column;
            gap: 0.85rem;
        }
        .quick-amount-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 0.4rem;
        }
        .quick-amount-btn {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--border-color);
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 700;
            padding: 0.45rem 0;
            cursor: pointer;
            border-radius: 4px;
            text-align: center;
            font-family: var(--font-heading);
            transition: all var(--transition-fast);
        }
        .quick-amount-btn:hover {
            border-color: var(--color-primary);
            color: var(--color-primary);
            background: var(--color-primary-light);
        }
        .quick-amount-btn.active {
            border-color: var(--color-primary);
            color: var(--color-primary);
            background: var(--color-primary-light);
        }
    </style>
</head>
<body>
    <!-- Floating Language Switcher -->
    <div style="position: fixed; top: 1.5rem; right: 1.5rem; z-index: 1000;">
        <button id="langToggle" style="background: rgba(19, 25, 38, 0.75); border: 1px solid var(--border-color); color: var(--text-primary); cursor: pointer; border-radius: 4px; padding: 0.5rem 0.75rem; font-weight: 700; font-size: 0.8rem; font-family: 'Outfit', sans-serif; transition: all 0.2s;" onmouseover="this.style.borderColor='var(--color-primary)'" onmouseout="this.style.borderColor='var(--border-color)'" aria-label="Change Language">
            <?php echo getLang() === 'en' ? 'BM' : 'EN'; ?>
        </button>
    </div>

    <div class="public-profile-card">
        <?php if ($error): ?>
            <div class="profile-header" style="padding:2rem 0;">
                <div class="profile-avatar" style="background:rgba(239,68,68,0.1); border-color:#ef4444; color:#ef4444;">
                    <i data-lucide="alert-octagon" style="width:32px; height:32px;"></i>
                </div>
                <h2 class="profile-name" style="color:#f87171;"><?php echo getLang() === 'en' ? 'Profile Error' : 'Ralat Profil'; ?></h2>
                <p class="profile-username" style="font-size:0.9rem; line-height:1.5; margin-top:0.5rem;"><?php echo htmlspecialchars($error); ?></p>
                <a href="login.php" class="btn btn-secondary mt-4 w-full" style="text-decoration:none;"><?php echo getLang() === 'en' ? 'Go to Homepage' : 'Kembali ke Laman Utama'; ?></a>
            </div>
        <?php else: ?>
            <!-- Header Info -->
            <div class="profile-header">
                <div class="profile-avatar" style="overflow:hidden;">
                    <?php if (!empty($profileUser['profile_pic']) && file_exists(STORAGE_DIR . '/profiles/' . $profileUser['profile_pic'])): ?>
                        <img src="storage/profiles/<?php echo htmlspecialchars($profileUser['profile_pic']); ?>" style="width:100%; height:100%; object-fit:cover;" alt="Avatar">
                    <?php else: ?>
                        <?php 
                        $nameForAvatar = $profileUser['display_name'] ?: $profileUser['username'];
                        echo strtoupper(substr($nameForAvatar, 0, 1)); 
                        ?>
                    <?php endif; ?>
                </div>
                <h2 class="profile-name"><?php echo htmlspecialchars($profileUser['display_name'] ?: $profileUser['username']); ?></h2>
                <span class="profile-username">@<?php echo htmlspecialchars($profileUser['username']); ?></span>
                <?php if (!empty($profileUser['email'])): ?>
                    <span class="profile-email" style="font-size:0.8rem; color:var(--text-muted); display:flex; align-items:center; gap:0.35rem; margin-top:0.25rem;">
                        <i data-lucide="mail" style="width:14px; height:14px;"></i> <span><?php echo htmlspecialchars($profileUser['email']); ?></span>
                    </span>
                <?php endif; ?>

                <?php if (!empty($profileUser['bio'])): ?>
                    <div class="profile-bio-box">
                        "<?php echo htmlspecialchars($profileUser['bio']); ?>"
                    </div>
                <?php endif; ?>

                <?php if (!empty($profileUser['telegram']) || !empty($profileUser['phone'])): ?>
                    <div class="contact-badges">
                        <?php if (!empty($profileUser['telegram'])): ?>
                            <a href="https://t.me/<?php echo urlencode($profileUser['telegram']); ?>" target="_blank" class="contact-badge">
                                <i data-lucide="send" style="width:12px; height:12px; transform: rotate(-30deg);"></i> Telegram
                            </a>
                        <?php endif; ?>
                        <?php if (!empty($profileUser['phone'])): ?>
                            <?php
                            $cleanPhone = preg_replace('/[^0-9]/', '', $profileUser['phone']);
                            ?>
                            <a href="https://wa.me/<?php echo urlencode($cleanPhone); ?>" target="_blank" class="contact-badge">
                                <i data-lucide="message-square" style="width:12px; height:12px;"></i> WhatsApp
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Primary Payment Card -->
            <?php if ($preferredBank || ($profileUser['qr_type'] && $profileUser['qr_type'] !== 'none')): ?>
                <div class="payment-box">
                    <?php if ($preferredBank): ?>
                        <div class="bank-details-block">
                            <span class="bank-name-label"><?php echo getLang() === 'en' ? 'Preferred Bank Account' : 'Akaun Bank Pilihan'; ?></span>
                            <div class="account-number-large" id="primaryAccountNo"><?php echo htmlspecialchars($preferredBank['account_number']); ?></div>
                            <span class="account-holder-name">
                                🏦 <strong><?php echo htmlspecialchars($preferredBank['bank_name']); ?></strong> • <?php echo htmlspecialchars($preferredBank['account_name']); ?>
                            </span>
                            <button id="copyPrimaryBankBtn" class="btn btn-primary btn-sm mt-3 w-full" style="height:2.25rem; min-height:unset; font-size:0.8rem; gap:0.25rem;">
                                <i data-lucide="copy" style="width:14px; height:14px;"></i> <?php echo getLang() === 'en' ? 'Copy Account Number' : 'Salin Nombor Akaun'; ?>
                            </button>
                        </div>
                    <?php endif; ?>

                    <!-- QR Section -->
                    <?php if ($profileUser['qr_type'] && $profileUser['qr_type'] !== 'none'): ?>
                        <div class="qr-section">
                            <span style="font-size: 0.75rem; font-weight:700; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.05em;"><?php echo getLang() === 'en' ? 'Scan QR to Transfer' : 'Imbas QR untuk Pindahan'; ?></span>
                            <div class="public-qr-card">
                                <?php if ($profileUser['qr_type'] === 'custom' && !empty($profileUser['qr_image'])): ?>
                                    <!-- Custom QR code image -->
                                    <img src="storage/qrs/<?php echo htmlspecialchars($profileUser['qr_image']); ?>" alt="Payment QR">
                                <?php else: ?>
                                    <!-- Client-side script generated QR code placeholder -->
                                    <div id="publicQrContainer"></div>
                                <?php endif; ?>
                            </div>
                            <span style="font-size:0.75rem; color:var(--text-muted); text-align:center;">
                                <?php
                                if ($profileUser['qr_type'] === 'duitnow') echo 'DuitNow ID: ' . htmlspecialchars($profileUser['qr_value']);
                                if ($profileUser['qr_type'] === 'tng') echo "Touch 'n Go E-Wallet";
                                if ($profileUser['qr_type'] === 'scanned') echo getLang() === 'en' ? "Recreated Payment QR" : "QR Pembayaran Dicipta Semula";
                                if ($profileUser['qr_type'] === 'custom') echo getLang() === 'en' ? "Custom Merchant QR" : "QR Peniaga Kustom";
                                ?>
                            </span>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Interactive Pay Calculator / Quick Transfer Assistant -->
            <?php if ($preferredBank || ($profileUser['qr_type'] && $profileUser['qr_type'] !== 'none')): ?>
                <div class="interactive-pay-calc">
                    <span class="bank-name-label" style="display:flex; justify-content:space-between; align-items:center;">
                        <span><?php echo getLang() === 'en' ? 'Quick Transfer Assistant' : 'Pembantu Pindahan Segera'; ?></span>
                        <span style="font-size:0.65rem; text-transform:none; color:var(--text-muted); font-weight:400;"><?php echo getLang() === 'en' ? 'Input amount to generate custom QR' : 'Masukkan jumlah untuk jana QR kustom'; ?></span>
                    </span>
                    
                    <div style="position:relative; display:flex; align-items:center;">
                        <span style="position:absolute; left:0.75rem; font-weight:700; color:var(--text-secondary); font-family:var(--font-heading); font-size:1.1rem; pointer-events:none;">RM</span>
                        <input type="number" id="payAmountInput" class="input-field" style="padding-left:2.25rem; font-family:var(--font-heading); font-weight:800; font-size:1.25rem; height:2.75rem; margin-bottom:0; width:100%;" placeholder="0.00" step="0.01" min="0">
                        <button id="clearPayAmountBtn" style="position:absolute; right:0.75rem; background:none; border:none; color:var(--text-muted); cursor:pointer; display:none; padding: 0.25rem;"><i data-lucide="x" style="width:16px; height:16px;"></i></button>
                    </div>

                    <!-- Quick select amount buttons -->
                    <div class="quick-amount-grid">
                        <button type="button" class="quick-amount-btn" data-val="5.00">RM 5</button>
                        <button type="button" class="quick-amount-btn" data-val="10.00">RM 10</button>
                        <button type="button" class="quick-amount-btn" data-val="50.00">RM 50</button>
                        <button type="button" class="quick-amount-btn" data-val="100.00">RM 100</button>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!$preferredBank && (!$profileUser['qr_type'] || $profileUser['qr_type'] === 'none')): ?>
                <div style="text-align:center; padding:1.5rem; border:1px dashed var(--border-color); border-radius:1rem; color:var(--text-muted); font-size:0.85rem;">
                    <?php echo getLang() === 'en' ? 'No preferred payment details configured by' : 'Tiada butiran pembayaran pilihan dikonfigurasikan oleh'; ?> @<?php echo htmlspecialchars($profileUser['username']); ?>.
                </div>
            <?php endif; ?>

            <!-- Secondary Banks List -->
            <?php if (!empty($otherBanks)): ?>
                <div class="sec-banks-accordion">
                    <span style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.25rem;"><?php echo getLang() === 'en' ? 'Other Bank Accounts' : 'Akaun Bank Lain'; ?></span>
                    <?php foreach ($otherBanks as $idx => $bank): ?>
                        <div class="sec-bank-item">
                            <div style="display:flex; flex-direction:column; gap:0.15rem;">
                                <strong style="font-size:0.85rem; color:var(--text-primary);"><?php echo htmlspecialchars($bank['bank_name']); ?></strong>
                                <span style="font-size:0.8rem; color:var(--text-muted);" id="secAccNo_<?php echo $idx; ?>"><?php echo htmlspecialchars($bank['account_number']); ?></span>
                                <span style="font-size:0.7rem; color:var(--text-muted);"><?php echo __('account_name'); ?>: <?php echo htmlspecialchars($bank['account_name']); ?></span>
                            </div>
                            <button class="btn btn-secondary btn-sm copy-sec-bank-btn" data-target="secAccNo_<?php echo $idx; ?>" style="min-height:unset; height:1.85rem; padding:0 0.5rem; font-size:0.75rem;">
                                <i data-lucide="copy" style="width:12px; height:12px;"></i>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- Split Bill CTA & Share Card -->
            <div style="display:flex; flex-direction:column; gap:0.75rem; margin-top:0.5rem; width:100%;">
                <!-- Split Button -->
                <a href="index.php?add_participant=<?php echo urlencode($profileUser['username']); ?>" class="btn btn-secondary w-full" style="height: 2.75rem; border-color: rgba(99, 102, 241, 0.2); gap: 0.5rem; justify-content:center; text-decoration:none; display:flex; align-items:center;">
                    <i data-lucide="plus-circle" style="color: var(--color-primary); width:18px; height:18px;"></i>
                    <span style="font-weight:600; font-size:0.85rem; color:var(--text-primary);"><?php echo getLang() === 'en' ? 'Split a Bill with ' : 'Kongsi Bil dengan '; ?><?php echo htmlspecialchars($profileUser['display_name'] ?: $profileUser['username']); ?></span>
                </a>
                
                <!-- QR Profile Code Share Box -->
                <div style="background:rgba(255,255,255,0.01); border:1px solid var(--border-color); padding:1rem; border-radius:0.75rem; display:flex; flex-direction:column; align-items:center; gap:0.75rem; margin-bottom: 0.5rem;">
                    <span style="font-size:0.75rem; font-weight:700; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.05em;"><?php echo getLang() === 'en' ? 'Share This Profile QR' : 'Kongsi QR Profil Ini'; ?></span>
                    <div id="profileShareQrContainer" style="background:#ffffff; padding:0.5rem; border-radius:0.5rem; width:100px; height:100px; display:flex; align-items:center; justify-content:center;"></div>
                    <p style="font-size:0.7rem; color:var(--text-muted); text-align:center; margin:0;"><?php echo getLang() === 'en' ? 'Let friends scan this to access your payment details instantly.' : 'Biarkan rakan mengimbas ini untuk mengakses butiran pembayaran anda.'; ?></p>
                </div>
            </div>

            <div style="font-size:0.7rem; color:var(--text-muted); text-align:center; border-top:1px solid var(--border-color); padding-top:0.85rem;">
                <?php echo getLang() === 'en' ? 'Powering payment splits via' : 'Dikuasakan untuk pembahagian bayaran melalui'; ?> <strong>BillSplitter</strong>.
            </div>
        <?php endif; ?>
    </div>

    <!-- Library scripts -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script src="assets/js/utils.js"></script>
    <script>
        lucide.createIcons();

        // Language Switcher Logic
        document.getElementById('langToggle')?.addEventListener('click', () => {
            const currentLang = document.cookie.split('; ').find(row => row.startsWith('lang='))?.split('=')[1] || 'en';
            const nextLang = currentLang === 'en' ? 'bm' : 'en';
            document.cookie = `lang=${nextLang}; path=/; max-age=${30 * 86400}`;
            const url = new URL(window.location.href);
            url.searchParams.set('lang', nextLang);
            window.location.href = url.toString();
        });

        // 1. Generate QR Code client-side if DuitNow or TnG Link is selected
        <?php if ($profileUser && $profileUser['qr_type'] !== 'none' && $profileUser['qr_type'] !== 'custom'): ?>
        const qrContainer = document.getElementById('publicQrContainer');
        let qrInstance = null;
        
        function updatePaymentQr(amount = '') {
            if (!qrContainer) return;
            qrContainer.innerHTML = '';
            
            let qrText = '';
            const type = <?php echo json_encode($profileUser['qr_type']); ?>;
            const val = <?php echo json_encode($profileUser['qr_value']); ?>;
            
            if (type === 'duitnow') {
                if (amount) {
                    qrText = `DuitNow Transfer\nTo: ${val}\nAmount: RM ${amount}\nRef: BillSplit`;
                } else {
                    qrText = `DuitNow Transfer\nTo: ${val}\nRef: BillSplit`;
                }
            } else if (type === 'tng' || type === 'scanned') {
                qrText = val;
            }
            
            try {
                qrInstance = new QRCode(qrContainer, {
                    text: qrText,
                    width: 120,
                    height: 120,
                    colorDark : "#0b0f19",
                    colorLight : "#ffffff",
                    correctLevel : QRCode.CorrectLevel.M
                });
            } catch (e) {
                console.error("QR generator failed: ", e);
                qrContainer.innerHTML = `<span style="font-size:0.7rem; color:#ef4444;">Failed to load QR</span>`;
            }
        }
        updatePaymentQr();
        <?php endif; ?>

        // Generate Profile Share Link QR Code
        const shareQrContainer = document.getElementById('profileShareQrContainer');
        if (shareQrContainer) {
            try {
                new QRCode(shareQrContainer, {
                    text: window.location.href,
                    width: 90,
                    height: 90,
                    colorDark : "#0b0f19",
                    colorLight : "#ffffff",
                    correctLevel : QRCode.CorrectLevel.M
                });
            } catch (e) {
                console.error("Profile share QR generator failed: ", e);
            }
        }

        // 2. Primary Account Copy Action
        const copyPrimaryBankBtn = document.getElementById('copyPrimaryBankBtn');
        const primaryAccountNo = document.getElementById('primaryAccountNo');
        const copiedToastMsg = "<?php echo getLang() === 'en' ? 'Account number copied!' : 'Nombor akaun disalin!'; ?>";
        const copyFailedMsg = "<?php echo getLang() === 'en' ? 'Failed to copy.' : 'Gagal menyalin.'; ?>";
        
        if (copyPrimaryBankBtn && primaryAccountNo) {
            copyPrimaryBankBtn.addEventListener('click', () => {
                const text = primaryAccountNo.textContent.trim();
                navigator.clipboard.writeText(text).then(() => {
                    Utils.showToast(copiedToastMsg, "success");
                }).catch(() => {
                    Utils.showToast(copyFailedMsg, "error");
                });
            });
        }

        // 3. Secondary Accounts Copy Actions
        document.querySelectorAll('.copy-sec-bank-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const targetId = btn.dataset.target;
                const elem = document.getElementById(targetId);
                if (elem) {
                    const text = elem.textContent.trim();
                    navigator.clipboard.writeText(text).then(() => {
                        Utils.showToast(copiedToastMsg, "success");
                    }).catch(() => {
                        Utils.showToast(copyFailedMsg, "error");
                    });
                }
            });
        });

        // 4. Quick Transfer Assistant Logic
        const payAmountInput = document.getElementById('payAmountInput');
        const clearPayAmountBtn = document.getElementById('clearPayAmountBtn');
        const quickAmountBtns = document.querySelectorAll('.quick-amount-btn');
        
        function handleAmountChange(amountVal) {
            const amount = parseFloat(amountVal);
            if (isNaN(amount) || amount <= 0) {
                if (clearPayAmountBtn) clearPayAmountBtn.style.display = 'none';
                <?php if ($profileUser && $profileUser['qr_type'] !== 'none' && $profileUser['qr_type'] !== 'custom'): ?>
                updatePaymentQr();
                <?php endif; ?>
                quickAmountBtns.forEach(btn => btn.classList.remove('active'));
            } else {
                if (clearPayAmountBtn) clearPayAmountBtn.style.display = 'block';
                <?php if ($profileUser && $profileUser['qr_type'] !== 'none' && $profileUser['qr_type'] !== 'custom'): ?>
                updatePaymentQr(amount.toFixed(2));
                <?php endif; ?>
                
                // Highlight matching button
                quickAmountBtns.forEach(btn => {
                    if (parseFloat(btn.dataset.val) === amount) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                    }
                });
            }
        }
        
        if (payAmountInput) {
            payAmountInput.addEventListener('input', (e) => {
                handleAmountChange(e.target.value);
            });
        }
        
        if (clearPayAmountBtn) {
            clearPayAmountBtn.addEventListener('click', () => {
                payAmountInput.value = '';
                handleAmountChange('');
            });
        }
        
        quickAmountBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const val = btn.dataset.val;
                payAmountInput.value = val;
                handleAmountChange(val);
            });
        });
    </script>
</body>
</html>
