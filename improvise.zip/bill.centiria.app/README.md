# Personal Bill Splitter

A mobile-first web application designed for quick, offline-ready, and zero-registration receipt scanning and bill splitting. Easily deployable to standard cPanel shared hosting (PHP 8+).

## Features
1. **Zero Registration / Zero API Keys Required**: Runs entirely client-side for OCR and uses open public APIs for currency exchange. No accounts or signup forms needed.
2. **Local Client-Side OCR**: Uses **Tesseract.js** loaded via CDN. Performs image processing, text extraction, and receipt parsing directly in the browser.
3. **Open Exchange Rates**: Converts foreign receipts to MYR using the free, open **Frankfurter API** (no keys required).
4. **Interactive Mobile Interface**: Includes cropping, rotation, and brightness adjustments (using **Cropper.js** via CDN). Easy-to-use tap controls for selecting who pays what.
5. **Exact Decimal-Safe Arithmetic**: All calculations are scaled to prevent JavaScript floating-point bugs. Rounding adjustments are distributed to ensure that individual totals sum up *exactly* to the receipt's grand total.
6. **Summary & Share Options**: Copy text summaries directly, share to WhatsApp, download CSV summaries, or print a receipt layout.

---

## Technical Architecture & Folder Structure

```
/
├── index.php             # Main entry point and wizard UI
├── assets/
│   ├── css/
│   │   └── style.css     # Dark/Light CSS styles & animations
│   └── js/
│       ├── app.js        # Main UI step-router and state controller
│       ├── calculator.js # Decimal-safe split engine
│       ├── ocr.js        # Canvas filters & regex receipt text parser
│       └── utils.js      # CSV, share, clipboard, and cache utilities
├── api/
│   ├── ocr.php           # PHP backend endpoint (provided for future extensions)
│   └── currency.php      # PHP secure proxy for Frankfurter API rates
├── includes/
│   ├── config.php        # Simple .env parser and config loader
│   └── helpers.php       # PHP upload validators & sanitization
├── storage/
│   └── temp/             # Folder for temporary files (.htaccess protected)
├── tests/
│   └── test_calculations.js # Test script for calculation engine
├── .env.example          # Environment template
├── .env                  # Environment configuration
└── README.md             # Setup and deployment manual
```

---

## Installation & Setup Guide

The application comes with a step-by-step graphical database installation script (`install.php`) supporting both **SQLite** (zero-configuration) and **MySQL** database drivers.

### Writable Directories Check
Ensure your PHP webserver has write permissions for the following storage paths:
- `storage/`
- `storage/profiles/`
- `storage/qrs/`
- `storage/rate_limits/`
- `storage/temp/`

### Option 1: Standard Installation Wizard
1. Clone or extract the project to your local server root folder (e.g. `htdocs/bill-splitter` or `public_html/`).
2. Open your browser and navigate to the project directory: `http://localhost/bill-splitter/`
3. You will be automatically redirected to the **Installation Wizard** (`install.php`).
4. Select your preferred database setup:
   - **SQLite**: No configuration required. Creates a new database file inside `storage/database.sqlite`.
   - **MySQL**: Enter your MySQL server host, port, database name, username, and password.
5. Create your **Administrator Profile** (Admin username, password, display name, and email).
6. Click **Install Database**. The installer will configure the `.env` settings and seed the schema.
7. **CRITICAL SECURITY REQUIREMENT**: For security reasons, you **must delete `install.php`** from the root folder before you can access the dashboard. If `install.php` remains, the application blocks access with a `403 Forbidden` warning.

### Option 2: Manual Configuration
1. Rename `.env.example` to `.env`.
2. Configure database credentials manually inside `.env`:
   - Set `DB_DRIVER=sqlite` (default) or `DB_DRIVER=mysql`.
   - Update `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, and `DB_PORT`.
3. Set `INSTALL_LOCK=true` inside `.env` once setup is complete.
4. Delete `install.php`.

### Running Calculations Tests
To verify the math engine, run the automated test suite in your terminal:
```bash
node tests/test_calculations.js
```

---

## cPanel Deployment Instructions

Follow these steps to deploy this application to your standard cPanel shared hosting environment:

1. **Upload the Staged Archive**:
   Upload the pre-packaged `bill-splitter.zip` (fresh, clean package containing directory layouts) to your web root folder (usually `public_html/`).

2. **Extract Files**:
   Extract the archive files into `public_html/` or your desired subdomain path.

3. **Database Configuration**:
   - Access `http://yourdomain.com/` which redirects to the installer.
   - Choose **SQLite** for a fast setup without MySQL configuration, or **MySQL** (configure databases and users in the cPanel MySQL Databases panel first).

4. **Delete Installer**:
   Once setup completes, open cPanel **File Manager**, find `install.php` in the root folder, and click **Delete** (or check "Trash" to permanently delete it). This unlocks full access to the dashboard.

5. **Verify Folder Permissions**:
   Ensure `storage/` directory permissions are set to `0755` (or `0777` if required by hosting providers).
   Notice that `storage/temp/.htaccess` contains `Deny from all` to prevent direct browser access to files inside this directory.

---

## Calculation Rules & Rounding Resolution

1. **High-Precision Scale**: To avoid IEEE 754 floating point issues (such as `0.1 + 0.2 = 0.30000000000000004`), the calculation engine (`Calculator.calculateSplit`) scales all prices by multiplying by `10,000` (4 decimal places) and converts them to integers before applying splits, taxes, discounts, and rounding.
2. **Rounding Correction**: When an item is split (e.g., splitting a $10.00 item equally among 3 people), the engine calculates the rounded shares in currency decimals (e.g., $3.34, $3.33, and $3.33). The sum ($10.00) matches the target.
   - The engine automatically allocates any remainder cents (caused by divisions) to the first active person in the split group so that the sum of parts always equals the grand total exactly.
3. **Extra Charge Allocation**: Service charges, taxes, and discounts can be distributed:
   - **Proportional**: Distributed relative to each person's consumed items subtotal (standard behavior).
   - **Equal**: Shared equally among all people.
   - **Equal (Active)**: Shared equally only among people who have assigned items.
4. **Foreign Currency Conversion**: If the receipt is in a foreign currency (e.g., SGD) and converted to MYR, the individual MYR totals are rounded to 2 decimal places. A final adjustment is automatically applied to ensure the sum of individual converted MYR payments matches the converted MYR grand total.

---

## Sample Receipt Data for Testing

You can use the following mock text or enter these values manually to test the app:

### Sample 1: Local Cafe Receipt (MYR)
- **Store**: Kopitiam Corner
- **Date**: 2026-06-25
- **Currency**: MYR
- **Items**:
  - 1x Nasi Lemak (RM 12.50)
  - 2x Kopi O (RM 3.50 each -> RM 7.00)
  - 1x Kaya Toast (RM 4.50)
- **Subtotal**: RM 24.00
- **Service Charge (10%)**: RM 2.40
- **Service Tax (6%)**: RM 1.44
- **Rounding**: RM 0.01 (adjustment)
- **Grand Total**: RM 27.85

*Test Case:*
- Alice and Bob share the Kopi O.
- Alice eats Nasi Lemak.
- Bob eats Kaya Toast.
- Taxes split proportionally.
- *Verify:* Sum of Alice's and Bob's individual totals equals exactly RM 27.85.

### Sample 2: Singapore Diner (SGD to MYR)
- **Store**: Orchard Bistro
- **Currency**: SGD
- **Items**:
  - 1x Hainanese Chicken Rice (SGD 8.50)
  - 1x Laksa (SGD 9.50)
  - 1x Barley Drink (SGD 2.00)
- **Subtotal**: SGD 20.00
- **GST (9%)**: SGD 1.80
- **Grand Total**: SGD 21.80

*Test Case:*
- Alice eats Chicken Rice and Bob eats Laksa.
- They split the Barley Drink 50/50.
- Convert to MYR using exchange rate (e.g., 1 SGD = 3.50 MYR).
- *Verify:* Subtotals and Grand Total display in both SGD and converted MYR correctly.
