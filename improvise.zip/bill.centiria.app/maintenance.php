<?php
/**
 * Personal Bill Splitter - System Maintenance Block Screen
 */
require_once __DIR__ . '/includes/lang.php';
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getLang() === 'en' ? 'System Maintenance - BillSplitter' : 'Penyelenggaraan Sistem - BillSplitter'; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://unpkg.com">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background-color: #0b0f19;
            color: #f8fafc;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 1.5rem 1rem;
        }
        .maintenance-card {
            width: 100%;
            max-width: 420px;
            background: rgba(19, 25, 38, 0.7);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 4px; /* Sharp angle theme */
            padding: 2.5rem 2rem;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1.5rem;
            position: relative;
            overflow: hidden;
        }
        .maintenance-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--color-primary), var(--color-warning));
        }
        .icon-wrapper {
            width: 64px;
            height: 64px;
            background: rgba(245, 158, 11, 0.1);
            border: 1px solid var(--color-warning);
            color: var(--color-warning);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 0.5rem;
            position: relative;
        }
        .pulsing-glow {
            position: absolute;
            width: 100%;
            height: 100%;
            border: 1px solid var(--color-warning);
            border-radius: 4px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); opacity: 0.8; }
            100% { transform: scale(1.3); opacity: 0; }
        }
        .maintenance-title {
            font-family: var(--font-heading);
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: 0.02em;
        }
        .maintenance-desc {
            font-size: 0.85rem;
            color: var(--text-muted);
            line-height: 1.6;
        }
        .wireframe-box {
            border: 1px dashed rgba(255, 255, 255, 0.08);
            padding: 1rem;
            width: 100%;
            background: rgba(255, 255, 255, 0.01);
            border-radius: 2px;
            font-family: monospace;
            font-size: 0.7rem;
            color: var(--color-primary);
            text-align: left;
            overflow: hidden;
            white-space: nowrap;
        }
    </style>
</head>
<body>
    <!-- Floating Language Switcher -->
    <div style="position: fixed; top: 1.5rem; right: 1.5rem; z-index: 1000;">
        <button id="langToggle" style="background: rgba(19, 25, 38, 0.75); border: 1px solid var(--border-color); color: var(--text-primary); cursor: pointer; border-radius: 4px; padding: 0.5rem 0.75rem; font-weight: 700; font-size: 0.8rem; font-family: 'Outfit', sans-serif; transition: all 0.2s;" onmouseover="this.style.borderColor='var(--color-primary)'" onmouseout="this.style.borderColor='var(--border-color)'" aria-label="Change Language">
            <?php echo getLang() === 'en' ? 'BM' : 'EN'; ?>
        </button>
    </div>

    <div class="maintenance-card">
        <div class="icon-wrapper">
            <div class="pulsing-glow"></div>
            <i data-lucide="construction" style="width: 32px; height: 32px;"></i>
        </div>
        
        <div style="display: flex; flex-direction: column; gap: 0.5rem;">
            <h2 class="maintenance-title">
                <?php echo getLang() === 'en' ? 'UNDER MAINTENANCE' : 'PENYELENGGARAAN SISTEM'; ?>
            </h2>
            <p class="maintenance-desc">
                <?php echo getLang() === 'en' ? 'The system is currently undergoing scheduled upgrades to improve performance and security. We will be back online shortly.' : 'Sistem sedang menjalani naiktaraf berjadual untuk meningkatkan prestasi dan keselamatan. Kami akan kembali dalam talian seketika lagi.'; ?>
            </p>
        </div>

        <div class="wireframe-box">
            <span>[SYSSTATUS: 503_SERVICE_UNAVAILABLE]</span><br>
            <span>[UPGRADE_IN_PROGRESS: TRUE]</span><br>
            <span>[ADMIN_ACCESS_ONLY: ACTIVE]</span>
        </div>

        <a href="login.php" class="btn btn-secondary w-full" style="height: 2.5rem; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 0.85rem; border-radius: 4px; font-weight: 700;">
            <i data-lucide="log-in" style="width: 16px; height: 16px; margin-right: 0.5rem;"></i>
            <?php echo getLang() === 'en' ? 'Administrator Login' : 'Log Masuk Pentadbir'; ?>
        </a>
    </div>

    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        lucide.createIcons();

        // Language Switcher Logic
        document.getElementById('langToggle')?.addEventListener('click', () => {
            const currentLang = document.cookie.split('; ').find(row => row.startsWith('lang='))?.split('=')[1] || 'en';
            const nextLang = currentLang === 'en' ? 'bm' : 'en';
            document.cookie = `lang=${nextLang}; path=/; max-age=${30 * 86400}`;
            const url = new URL(window.location.href);
            url.searchParams.set('lang', nextLang);
            window.location.href = url.toString();
        });
    </script>
</body>
</html>
