<?php
/**
 * Personal Bill Splitter - User Profile & Bank Manager
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
requireAuth();

// Validate CSRF for all POST actions in profile settings
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
    if (!validateCSRFToken($token)) {
        http_response_code(403);
        echo "<h1>403 Forbidden</h1><p>Invalid or missing CSRF token.</p>";
        exit;
    }
}

$userId = $_SESSION['user_id'];
$user = getCurrentUser();
$error = null;
$success = null;

// Ensure upload directories exist
$qrUploadDir = STORAGE_DIR . '/qrs';
if (!is_dir($qrUploadDir)) {
    mkdir($qrUploadDir, 0755, true);
}
$profileUploadDir = STORAGE_DIR . '/profiles';
if (!is_dir($profileUploadDir)) {
    mkdir($profileUploadDir, 0755, true);
}

// 1. Handle Profile Update (Display Name, Email, Profile Pic & QR)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $displayName = trim($_POST['display_name']);
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $qrType = trim($_POST['qr_type']);
    $effectiveQrType = $qrType;
    $qrValue = '';
    
    try {
        $qrImageName = $user['qr_image'];
        $profilePicName = $user['profile_pic'];
        
        // Validate Email if not empty
        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        }
        
        // Handle QR values based on type
        if ($qrType === 'scanned') {
            $qrValue = isset($_POST['scanned_qr_value']) ? trim($_POST['scanned_qr_value']) : '';
            $effectiveQrType = 'tng';
            if (empty($qrValue)) {
                $error = "Please upload and scan a QR code first.";
            }
        } else {
            $qrValue = isset($_POST['qr_value']) ? trim($_POST['qr_value']) : '';
        }

        if (!$error && $effectiveQrType === 'custom') {
            $qrValue = '';
        }
        
        // Handle profile picture upload if selected. Allow larger profile photos up to 30MB.
        if (!$error && isset($_FILES['profile_pic_file']) && $_FILES['profile_pic_file']['error'] !== UPLOAD_ERR_NO_FILE) {
            $validation = validateUploadedFile($_FILES['profile_pic_file'], 30 * 1024 * 1024);
            
            if ($validation['success']) {
                $fileExtension = $validation['extension'];
                if ($fileExtension === 'pdf') {
                    $error = "PDF is not a valid format for profile pictures. Please upload an image.";
                } else {
                    // Delete old file if exists
                    if (!empty($profilePicName) && file_exists($profileUploadDir . '/' . $profilePicName)) {
                        @unlink($profileUploadDir . '/' . $profilePicName);
                    }
                    
                    // Safe name definition
                    $newFileName = 'profile_' . $userId . '_' . time() . '.' . $fileExtension;
                    $destPath = $profileUploadDir . '/' . $newFileName;
                    
                    if (move_uploaded_file($_FILES['profile_pic_file']['tmp_name'], $destPath)) {
                        $profilePicName = $newFileName;
                    } else {
                        $error = "Failed to save uploaded profile picture.";
                    }
                }
            } else {
                $error = $validation['error'];
            }
        }

        // Handle QR file upload if Custom QR selected and uploaded
        if (!$error && $effectiveQrType === 'custom' && isset($_FILES['qr_image_file']) && $_FILES['qr_image_file']['error'] === UPLOAD_ERR_OK) {
            $validation = validateUploadedFile($_FILES['qr_image_file']);
            
            if ($validation['success']) {
                $fileExtension = $validation['extension'];
                if ($fileExtension === 'pdf') {
                    $error = "PDF is not a valid format for QR payment codes. Please upload an image.";
                } else {
                    // Delete old file if exists
                    if (!empty($qrImageName) && file_exists($qrUploadDir . '/' . $qrImageName)) {
                        @unlink($qrUploadDir . '/' . $qrImageName);
                    }
                    
                    // Safe name definition
                    $newFileName = 'user_' . $userId . '_' . time() . '.' . $fileExtension;
                    $destPath = $qrUploadDir . '/' . $newFileName;
                    
                    if (move_uploaded_file($_FILES['qr_image_file']['tmp_name'], $destPath)) {
                        $qrImageName = $newFileName;
                    } else {
                        $error = "Failed to save uploaded QR code image.";
                    }
                }
            } else {
                $error = $validation['error'];
            }
        }

        if (!$error && $effectiveQrType !== 'custom' && !empty($qrImageName)) {
            if (file_exists($qrUploadDir . '/' . $qrImageName)) {
                @unlink($qrUploadDir . '/' . $qrImageName);
            }
            $qrImageName = '';
        }

        if (!$error && $effectiveQrType === 'none') {
            $qrValue = '';
        }

        $bio = isset($_POST['bio']) ? trim($_POST['bio']) : '';
        $telegram = isset($_POST['telegram']) ? trim($_POST['telegram']) : '';
        // Remove @ if they wrote it
        if (strpos($telegram, '@') === 0) {
            $telegram = substr($telegram, 1);
        }
        $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';

        if (!$error) {
            $stmt = $db->prepare("UPDATE users SET display_name = ?, email = ?, profile_pic = ?, qr_type = ?, qr_value = ?, qr_image = ?, bio = ?, telegram = ?, phone = ? WHERE id = ?");
            $stmt->execute([$displayName, $email ?: null, $profilePicName ?: null, $effectiveQrType, $qrValue, $qrImageName ?: '', $bio ?: null, $telegram ?: null, $phone ?: null, $userId]);
            logActivity('update_profile', 'Updated profile display details, payment settings, bio, and contact links');
            $success = "Profile details updated successfully!";
            
            // Refresh local user state
            $user = getCurrentUser();
        }
    } catch (PDOException $e) {
        $error = "Database Error: " . $e->getMessage();
    }
}

// 2. Handle Change Password Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $currentPassword = isset($_POST['current_password']) ? $_POST['current_password'] : '';
    $newPassword = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirmNewPassword = isset($_POST['confirm_new_password']) ? $_POST['confirm_new_password'] : '';
    
    if (empty($currentPassword) || empty($newPassword) || empty($confirmNewPassword)) {
        $error = "Please fill in all password fields.";
    } elseif ($newPassword !== $confirmNewPassword) {
        $error = "New passwords do not match.";
    } elseif (strlen($newPassword) < 6) {
        $error = "New password must be at least 6 characters long.";
    } else {
        try {
            // Get current hashed password
            $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $hashedPassword = $stmt->fetchColumn();
            
            if (password_verify($currentPassword, $hashedPassword)) {
                $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmtUpdate = $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                $stmtUpdate->execute([$newHash, $userId]);
                logActivity('change_password', 'Updated user account password');
                $success = "Password updated successfully!";
            } else {
                $error = "Incorrect current password.";
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

// 2.5 Handle Self-Service Account Deletion Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_account') {
    $confirmPassword = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    
    if (empty($confirmPassword)) {
        $error = "Please enter your password to confirm account deletion.";
    } else {
        try {
            $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $hashedPassword = $stmt->fetchColumn();
            
            if (password_verify($confirmPassword, $hashedPassword)) {
                // Fetch profile pictures and QRs for deletion
                $stmtInfo = $db->prepare("SELECT profile_pic, qr_image FROM users WHERE id = ?");
                $stmtInfo->execute([$userId]);
                $targetUser = $stmtInfo->fetch();
                
                if ($targetUser) {
                    if (!empty($targetUser['profile_pic'])) {
                        @unlink(STORAGE_DIR . '/profiles/' . $targetUser['profile_pic']);
                    }
                    if (!empty($targetUser['qr_image'])) {
                        @unlink(STORAGE_DIR . '/qrs/' . $targetUser['qr_image']);
                    }
                }
                
                // Delete user from DB
                $stmtDel = $db->prepare("DELETE FROM users WHERE id = ?");
                $stmtDel->execute([$userId]);
                
                logActivity('delete_account', 'User deleted their own account self-service');
                
                // Destroy Session & cookies
                $_SESSION = array();
                if (ini_get("session.use_cookies")) {
                    $params = session_get_cookie_params();
                    setcookie(session_name(), '', time() - 42000,
                        $params["path"], $params["domain"],
                        $params["secure"], $params["httponly"]
                    );
                }
                session_destroy();
                
                header("Location: index.php");
                exit;
            } else {
                $error = "Incorrect password. Account deletion aborted.";
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

// 3. Handle Bank Manager Actions (Add, Delete, Set Preferred)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'add_bank') {
        $bankName = trim($_POST['bank_name']);
        $accountName = trim($_POST['account_name']);
        $accountNumber = trim($_POST['account_number']);
        
        if (!empty($bankName) && !empty($accountName) && !empty($accountNumber)) {
            try {
                // If it's the first bank, set it as preferred by default
                $stmtCount = $db->prepare("SELECT COUNT(*) FROM user_banks WHERE user_id = ?");
                $stmtCount->execute([$userId]);
                $count = intval($stmtCount->fetchColumn());
                $isPreferred = ($count === 0) ? 1 : 0;
                
                $stmt = $db->prepare("INSERT INTO user_banks (user_id, bank_name, account_name, account_number, is_preferred) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$userId, $bankName, $accountName, $accountNumber, $isPreferred]);
                $success = "Bank account added successfully!";
            } catch (PDOException $e) {
                $error = "Failed to add bank account: " . $e->getMessage();
            }
        } else {
            $error = "Please fill in all bank details.";
        }
    } elseif ($action === 'delete_bank') {
        $bankId = intval($_POST['bank_id']);
        try {
            // Check if deleting the preferred bank
            $stmt = $db->prepare("SELECT is_preferred FROM user_banks WHERE id = ? AND user_id = ?");
            $stmt->execute([$bankId, $userId]);
            $prefStatus = $stmt->fetchColumn();
            
            $stmt = $db->prepare("DELETE FROM user_banks WHERE id = ? AND user_id = ?");
            $stmt->execute([$bankId, $userId]);
            
            // If we deleted the preferred bank, make another one preferred
            if ($prefStatus) {
                $db->exec("UPDATE user_banks SET is_preferred = 1 WHERE user_id = {$userId} LIMIT 1");
            }
            $success = "Bank account deleted.";
        } catch (PDOException $e) {
            $error = "Failed to delete bank account.";
        }
    } elseif ($action === 'prefer_bank') {
        $bankId = intval($_POST['bank_id']);
        try {
            $db->beginTransaction();
            // Clear all preferred
            $stmt = $db->prepare("UPDATE user_banks SET is_preferred = 0 WHERE user_id = ?");
            $stmt->execute([$userId]);
            
            // Set target preferred
            $stmt = $db->prepare("UPDATE user_banks SET is_preferred = 1 WHERE id = ? AND user_id = ?");
            $stmt->execute([$bankId, $userId]);
            
            $db->commit();
            $success = "Preferred bank account updated.";
        } catch (PDOException $e) {
            $db->rollBack();
            $error = "Failed to update preferred bank account.";
        }
    }
}

// Fetch user banks list
$userBanks = [];
try {
    $stmt = $db->prepare("SELECT * FROM user_banks WHERE user_id = ? ORDER BY is_preferred DESC, created_at DESC");
    $stmt->execute([$userId]);
    $userBanks = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Failed to load bank accounts.";
}

// Public view link generator
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$publicProfileUrl = $protocol . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/profile_view.php?u=' . urlencode($user['username']);
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BillSplitter - Profile & Payment settings</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://unpkg.com">
    <link rel="icon" type="image/svg+xml" href="assets/icons/icon.svg">
    <link rel="apple-touch-icon" href="assets/icons/icon.svg">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#6366f1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .profile-container {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        .bank-card {
            background: var(--bg-glass);
            border: 1px solid var(--border-color);
            border-radius: 0.85rem;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all var(--transition-fast);
        }
        .bank-card.preferred {
            border-color: var(--color-primary);
            background: var(--color-primary-light);
        }
        .bank-info {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }
        .bank-card-actions {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }
        .public-link-card {
            background: rgba(16, 185, 129, 0.05);
            border: 1px dashed rgba(16, 185, 129, 0.2);
            padding: 1rem;
            border-radius: 0.85rem;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
        }
        .public-link-input-wrap {
            display: flex;
            gap: 0.5rem;
        }
        .public-link-input-wrap input {
            flex: 1;
            font-size: 0.8rem;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            padding: 0.5rem;
            border-radius: 0.5rem;
            outline: none;
        }
        .avatar-edit-wrapper:hover .avatar-overlay {
            opacity: 1 !important;
        }
        .qr-dropzone:hover {
            border-color: var(--color-primary) !important;
            background: rgba(99, 102, 241, 0.05) !important;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="logo">
            <?php if (!empty($user['profile_pic']) && file_exists(STORAGE_DIR . '/profiles/' . $user['profile_pic'])): ?>
                <img src="storage/profiles/<?php echo htmlspecialchars($user['profile_pic']); ?>" style="width: 24px; height: 24px; object-fit: cover; border-radius: 2px;" alt="User Avatar">
            <?php else: ?>
                <i data-lucide="user"></i>
            <?php endif; ?>
            <span><?php echo __('profile_details'); ?></span>
        </div>
        <div class="header-actions">
            <a href="dashboard.php" class="btn btn-secondary btn-sm" style="height: 2.25rem; font-size: 0.8rem;">
                <i data-lucide="layout-dashboard"></i> <?php echo __('dashboard'); ?>
            </a>
            <!-- Language Toggle Button -->
            <button id="langToggle" class="theme-toggle-btn" style="font-weight: 700; font-size: 0.8rem; font-family: var(--font-heading);" aria-label="Change Language">
                <?php echo getLang() === 'en' ? 'BM' : 'EN'; ?>
            </button>
            <a href="index.php" class="btn btn-primary btn-sm" style="height: 2.25rem; font-size: 0.8rem;">
                <i data-lucide="plus-circle"></i> <?php echo getLang() === 'en' ? 'New Split' : 'Bil Baru'; ?>
            </a>
        </div>
    </header>

    <main class="container">
        <?php renderGlobalAnnouncement(); ?>
        <div class="profile-container">
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i data-lucide="check-circle"></i> <span><?php echo htmlspecialchars($success); ?></span>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-warning">
                    <i data-lucide="alert-triangle"></i> <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <!-- Public Profile view link -->
            <div class="public-link-card">
                <span style="font-size: 0.75rem; font-weight: 700; color: #10b981; text-transform: uppercase; letter-spacing: 0.05em;"><?php echo getLang() === 'en' ? 'Share Your Payment Details' : 'Kongsi Maklumat Pembayaran Anda'; ?></span>
                <p style="font-size: 0.8rem; color: var(--text-muted); line-height: 1.4;"><?php echo getLang() === 'en' ? 'Copy this link to share your preferred bank account and payment QR codes with your friends.' : 'Salin pautan ini untuk berkongsi akaun bank pilihan dan kod QR pembayaran dengan rakan anda.'; ?></p>
                <div class="public-link-input-wrap">
                    <input type="text" id="publicLinkInput" value="<?php echo htmlspecialchars($publicProfileUrl); ?>" readonly>
                    <button id="copyPublicLinkBtn" class="btn btn-primary btn-sm" style="min-height:unset; padding:0 0.75rem; font-size:0.75rem; gap:0.25rem;">
                        <i data-lucide="copy" style="width:14px; height:14px;"></i> <?php echo __('copy'); ?>
                    </button>
                    <a href="<?php echo htmlspecialchars($publicProfileUrl); ?>" target="_blank" class="btn btn-secondary btn-sm" style="min-height:unset; padding:0 0.75rem; font-size:0.75rem;">
                        <i data-lucide="external-link" style="width:14px; height:14px;"></i> <?php echo getLang() === 'en' ? 'View' : 'Lihat'; ?>
                    </a>
                </div>
            </div>

            <!-- Profile Info Form -->
            <form action="profile.php" method="POST" enctype="multipart/form-data" class="card">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="action" value="update_profile">
                <h3 style="font-family:'Outfit'; font-size:1.15rem; margin-bottom:0.25rem;"><?php echo getLang() === 'en' ? 'Profile & QR Config' : 'Konfigurasi Profil & QR'; ?></h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1.25rem;"><?php echo getLang() === 'en' ? 'Configure your display name, email, avatar, and payment QR code details.' : 'Konfigurasikan nama paparan, e-mel, avatar, dan butiran kod QR pembayaran anda.'; ?></p>

                <!-- Profile Picture Uploader -->
                <div class="profile-picture-container" style="display:flex; flex-direction:column; align-items:center; margin-bottom:1.5rem; gap:0.5rem;">
                    <div class="avatar-edit-wrapper" style="position:relative; width:90px; height:90px; border:2px solid var(--border-color); cursor:pointer; overflow:hidden; border-radius: 4px;" onclick="document.getElementById('profile_pic_file').click();">
                        <?php if (!empty($user['profile_pic']) && file_exists(STORAGE_DIR . '/profiles/' . $user['profile_pic'])): ?>
                            <img id="profileAvatarPreview" src="storage/profiles/<?php echo htmlspecialchars($user['profile_pic']); ?>" style="width:100%; height:100%; object-fit:cover;" alt="Avatar">
                        <?php else: ?>
                            <div id="profileAvatarFallback" style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:var(--color-primary-light); color:var(--color-primary); font-family:'Outfit'; font-size:2.25rem; font-weight:700;">
                                <?php echo strtoupper(substr($user['display_name'] ?: $user['username'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        <div class="avatar-overlay" style="position:absolute; bottom:0; left:0; right:0; background:rgba(11,15,25,0.85); display:flex; align-items:center; justify-content:center; padding:0.25rem 0; font-size:0.65rem; font-weight:700; color:var(--color-primary); text-transform:uppercase; letter-spacing:0.05em; opacity:0; transition:opacity var(--transition-fast);">
                            <?php echo getLang() === 'en' ? 'Edit' : 'Sunting'; ?>
                        </div>
                    </div>
                    <input type="file" id="profile_pic_file" name="profile_pic_file" style="display:none;" accept="image/jpeg,image/png,image/webp,image/gif" onchange="previewProfilePic(this);">
                    <span style="font-size:0.75rem; color:var(--text-muted);"><?php echo getLang() === 'en' ? 'Tap photo to upload new picture (max 30MB)' : 'Ketik foto untuk muat naik gambar baru (maks 30MB)'; ?></span>
                </div>

                <div class="input-group mb-3">
                    <label for="username"><?php echo __('username'); ?> (@)</label>
                    <input type="text" id="username" class="input-field" value="<?php echo htmlspecialchars($user['username']); ?>" readonly style="opacity:0.65; cursor:not-allowed;">
                </div>

                <div class="input-group mb-3">
                    <label for="display_name"><?php echo __('display_name'); ?></label>
                    <input type="text" id="display_name" name="display_name" class="input-field" value="<?php echo htmlspecialchars($user['display_name'] ?: ''); ?>" placeholder="<?php echo getLang() === 'en' ? 'Enter display name used on split summary cards' : 'Masukkan nama paparan yang digunakan pada kad ringkasan bil'; ?>" required>
                </div>

                <div class="input-group mb-3">
                    <label for="email"><?php echo __('email_address'); ?></label>
                    <input type="email" id="email" name="email" class="input-field" value="<?php echo htmlspecialchars($user['email'] ?: ''); ?>" placeholder="<?php echo __('email_placeholder'); ?>">
                </div>

                <div class="input-group mb-3">
                    <label for="bio"><?php echo getLang() === 'en' ? 'Short Bio / Description' : 'Bio Pendek / Keterangan'; ?></label>
                    <textarea id="bio" name="bio" class="input-field" style="min-height:60px; resize:vertical; padding:0.5rem;" placeholder="<?php echo getLang() === 'en' ? 'Tell your friends something about yourself...' : 'Tulis sesuatu mengenai diri anda untuk rakan-rakan...'; ?>"><?php echo htmlspecialchars($user['bio'] ?: ''); ?></textarea>
                </div>

                <div class="input-group mb-3">
                    <label for="telegram"><?php echo getLang() === 'en' ? 'Telegram Username' : 'Nama Pengguna Telegram'; ?></label>
                    <input type="text" id="telegram" name="telegram" class="input-field" value="<?php echo htmlspecialchars($user['telegram'] ?: ''); ?>" placeholder="username (without @)">
                </div>

                <div class="input-group mb-3">
                    <label for="phone"><?php echo getLang() === 'en' ? 'WhatsApp / Phone Number' : 'Nombor WhatsApp / Telefon'; ?></label>
                    <input type="text" id="phone" name="phone" class="input-field" value="<?php echo htmlspecialchars($user['phone'] ?: ''); ?>" placeholder="+60123456789">
                </div>

                <div class="input-group mb-3">
                    <label for="qr_type"><?php echo getLang() === 'en' ? 'QR Code Type' : 'Jenis Kod QR'; ?></label>
                    <select id="qr_type" name="qr_type" class="input-field">
                        <option value="none" <?php echo $user['qr_type'] === 'none' ? 'selected' : ''; ?>><?php echo __('no_qr'); ?></option>
                        <option value="duitnow" <?php echo $user['qr_type'] === 'duitnow' ? 'selected' : ''; ?>><?php echo __('duitnow_phone'); ?></option>
                        <option value="tng" <?php echo $user['qr_type'] === 'tng' ? 'selected' : ''; ?>><?php echo __('tng_transfer'); ?></option>
                        <option value="scanned" <?php echo $user['qr_type'] === 'scanned' ? 'selected' : ''; ?>><?php echo __('recreated_qr'); ?></option>
                        <option value="custom" <?php echo $user['qr_type'] === 'custom' ? 'selected' : ''; ?>><?php echo __('custom_qr_image'); ?></option>
                    </select>
                </div>

                <div id="qr_value_group" class="input-group mb-3" style="display: none;">
                    <label id="qr_value_label" for="qr_value"><?php echo getLang() === 'en' ? 'QR Payment Details' : 'Butiran QR Pembayaran'; ?></label>
                    <input type="text" id="qr_value" name="qr_value" class="input-field" value="<?php echo htmlspecialchars($user['qr_value'] ?: ''); ?>">
                </div>

                <div id="qr_file_group" class="input-group mb-3" style="display: none;">
                    <label for="qr_image_file"><?php echo __('upload_new_qr'); ?></label>
                    <input type="file" id="qr_image_file" name="qr_image_file" class="input-field" accept="image/*">
                    <?php if (!empty($user['qr_image'])): ?>
                        <div style="margin-top:0.5rem; display:flex; align-items:center; gap:0.5rem;">
                            <span style="font-size:0.75rem; color:var(--text-muted);"><?php echo __('current_qr_file'); ?>: <?php echo htmlspecialchars($user['qr_image']); ?></span>
                            <img src="storage/qrs/<?php echo htmlspecialchars($user['qr_image']); ?>" style="max-height: 40px; border-radius: 4px; border:1px solid var(--border-color);" alt="QR Thumbnail">
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Recreated QR Scanner Field -->
                <div id="qr_scanner_group" class="input-group mb-3" style="display: none;">
                    <label><?php echo __('upload_qr_scan'); ?></label>
                    <p style="font-size:0.75rem; color:var(--text-muted); line-height:1.4; margin-bottom:0.75rem;"><?php echo __('scan_qr_desc'); ?></p>
                    
                    <div id="qrDropzone" class="qr-dropzone" style="border: 2px dashed var(--border-color); padding: 2rem 1rem; text-align: center; cursor: pointer; transition: all var(--transition-fast); border-radius: 4px;" onclick="document.getElementById('qr_scan_file').click();" ondragover="event.preventDefault(); this.style.borderColor='var(--color-primary)';" ondragleave="this.style.borderColor='var(--border-color)';" ondrop="handleQrDrop(event);">
                        <i data-lucide="qr-code" style="width:32px; height:32px; color:var(--text-muted); margin-bottom:0.5rem; display:inline-block;"></i>
                        <h5 style="font-size:0.85rem; margin-bottom:0.25rem; font-weight:600; color:var(--text-primary);"><?php echo getLang() === 'en' ? 'Drag & drop your QR image here or tap' : 'Seret & lepas imej QR anda di sini atau ketik'; ?></h5>
                        <p style="font-size:0.75rem; color:var(--text-muted);"><?php echo getLang() === 'en' ? 'Supports JPG, PNG, WEBP' : 'Menyokong JPG, PNG, WEBP'; ?></p>
                    </div>
                    <input type="file" id="qr_scan_file" style="display:none;" accept="image/*" onchange="decodeQrFile(this);">
                    
                    <!-- Hidden input to store imported/scanned QR payload for the re-import editor -->
                    <input type="hidden" id="scanned_qr_value" name="scanned_qr_value" value="<?php echo htmlspecialchars(in_array($user['qr_type'], ['scanned', 'tng'], true) ? $user['qr_value'] : ''); ?>">
                    
                    <!-- Scan Result Preview -->
                    <div id="qrScanResult" style="display:none; margin-top:1rem; padding:1rem; background:rgba(16,185,129,0.05); border:1px solid rgba(16,185,129,0.2); text-align:center;">
                        <span style="font-size:0.75rem; font-weight:700; color:#10b981; text-transform:uppercase;"><?php echo getLang() === 'en' ? 'Recreated Vector QR (Crisp & Clean)' : 'QR Vektor Dicipta Semula (Bersih & Jelas)'; ?></span>
                        <div id="editorQrPreview" style="margin:0.75rem auto; padding:0.5rem; background:#fff; width:130px; height:130px; display:flex; align-items:center; justify-content:center; border:1px solid var(--border-color);"></div>
                        <p id="decodedPayloadText" style="font-size:0.75rem; color:var(--text-muted); word-break:break-all; margin:0; font-family:monospace;"></p>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-full mt-2" style="height:2.75rem;"><?php echo getLang() === 'en' ? 'Save Profile Settings' : 'Simpan Tetapan Profil'; ?></button>
            </form>

            <!-- Change Password Section -->
            <form action="profile.php" method="POST" class="card">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="action" value="change_password">
                <h3 style="font-family:'Outfit'; font-size:1.15rem; margin-bottom:0.25rem;"><?php echo __('change_password'); ?></h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1.25rem;"><?php echo getLang() === 'en' ? 'Ensure your account stays secure by using a strong password.' : 'Pastikan akaun anda kekal selamat dengan menggunakan kata laluan yang kuat.'; ?></p>
                
                <div class="input-group mb-3">
                    <label for="current_password"><?php echo __('current_password'); ?></label>
                    <input type="password" id="current_password" name="current_password" class="input-field" required>
                </div>
                
                <div class="row-grid mb-3" style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                    <div class="input-group">
                        <label for="new_password"><?php echo __('new_password'); ?></label>
                        <input type="password" id="new_password" name="new_password" class="input-field" minlength="6" required>
                    </div>
                    <div class="input-group">
                        <label for="confirm_new_password"><?php echo __('confirm_new_password'); ?></label>
                        <input type="password" id="confirm_new_password" name="confirm_new_password" class="input-field" minlength="6" required>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-secondary w-full" style="height:2.5rem; min-height:unset;"><?php echo __('change_password'); ?></button>
            </form>

            <!-- Bank Manager Section -->
            <div class="card">
                <h3 style="font-family:'Outfit'; font-size:1.15rem; margin-bottom:0.25rem;"><?php echo __('bank_accounts'); ?></h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1.25rem;"><?php echo getLang() === 'en' ? 'Manage multiple bank accounts and select which bank you want others to transfer money to.' : 'Urus berbilang akaun bank dan pilih bank mana yang anda mahu orang lain pindahkan wang ke dalamnya.'; ?></p>

                <!-- List of current banks -->
                <div style="display:flex; flex-direction:column; gap:0.75rem; margin-bottom:1.5rem;">
                    <?php if (empty($userBanks)): ?>
                        <div style="text-align:center; padding:1.5rem; border:1px dashed var(--border-color); border-radius:0.75rem; color:var(--text-muted); font-size:0.85rem;">
                            <?php echo getLang() === 'en' ? 'No bank accounts added yet. Add one below.' : 'Tiada akaun bank ditambah lagi. Tambah satu di bawah.'; ?>
                        </div>
                    <?php else: ?>
                        <?php foreach ($userBanks as $bank): ?>
                            <div class="bank-card <?php echo $bank['is_preferred'] ? 'preferred' : ''; ?>">
                                <div class="bank-info">
                                    <div style="display:flex; align-items:center; gap:0.35rem;">
                                        <strong style="color:var(--text-primary); font-size:0.95rem;"><?php echo htmlspecialchars($bank['bank_name']); ?></strong>
                                        <?php if ($bank['is_preferred']): ?>
                                            <span style="background:var(--color-primary); color:#fff; font-size:0.65rem; font-weight:700; padding:0.1rem 0.35rem; border-radius:0.25rem; text-transform:uppercase;"><?php echo __('preferred'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <span style="font-size:0.85rem; color:var(--text-muted);"><?php echo htmlspecialchars($bank['account_number']); ?></span>
                                    <span style="font-size:0.75rem; color:var(--text-muted);"><?php echo __('account_name'); ?>: <?php echo htmlspecialchars($bank['account_name']); ?></span>
                                </div>
                                <div class="bank-card-actions">
                                    <?php if (!$bank['is_preferred']): ?>
                                        <form action="profile.php" method="POST" style="margin:0;">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                            <input type="hidden" name="action" value="prefer_bank">
                                            <input type="hidden" name="bank_id" value="<?php echo $bank['id']; ?>">
                                            <button type="submit" class="btn btn-secondary btn-sm" style="min-height:unset; height:2rem; font-size:0.75rem; padding:0 0.6rem;"><?php echo __('set_preferred'); ?></button>
                                        </form>
                                    <?php endif; ?>
                                    <form action="profile.php" method="POST" style="margin:0;" onsubmit="return confirm('<?php echo getLang() === 'en' ? 'Delete this bank account?' : 'Padam akaun bank ini?'; ?>')">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                        <input type="hidden" name="action" value="delete_bank">
                                        <input type="hidden" name="bank_id" value="<?php echo $bank['id']; ?>">
                                        <button type="submit" class="btn btn-secondary btn-sm btn-icon" style="color:var(--color-danger); border:none; background:none;">
                                            <i data-lucide="trash-2" style="width:16px; height:16px;"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Add new bank account form -->
                <form action="profile.php" method="POST" style="border-top:1px solid var(--border-color); padding-top:1.25rem;">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <input type="hidden" name="action" value="add_bank">
                    <h4 style="font-size:0.95rem; margin-bottom:0.75rem; color:var(--color-primary)"><?php echo __('add_bank_account'); ?></h4>
                    
                    <div class="input-group mb-3">
                        <label for="bank_name"><?php echo __('bank_name'); ?></label>
                        <select id="bank_name" name="bank_name" class="input-field" required>
                            <option value=""><?php echo getLang() === 'en' ? '-- Select Bank --' : '-- Pilih Bank --'; ?></option>
                            <option value="Maybank">Maybank</option>
                            <option value="CIMB Bank">CIMB Bank</option>
                            <option value="Public Bank">Public Bank</option>
                            <option value="RHB Bank">RHB Bank</option>
                            <option value="Hong Leong Bank">Hong Leong Bank</option>
                            <option value="AmBank">AmBank</option>
                            <option value="UOB Bank">UOB Bank</option>
                            <option value="Bank Islam">Bank Islam</option>
                            <option value="Touch 'n Go E-Wallet">Touch 'n Go E-Wallet</option>
                            <option value="Other">Other Bank</option>
                        </select>
                    </div>

                    <div class="row-grid mb-3" style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                        <div class="input-group">
                            <label for="account_number"><?php echo __('account_number'); ?></label>
                            <input type="text" id="account_number" name="account_number" class="input-field" placeholder="e.g. 16401234567" required>
                        </div>
                        <div class="input-group">
                            <label for="account_name"><?php echo __('account_name'); ?></label>
                            <input type="text" id="account_name" name="account_name" class="input-field" placeholder="e.g. John Doe" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-secondary w-full" style="height:2.5rem; min-height:unset;"><?php echo __('add'); ?></button>
                </form>
            </div>

            <!-- Delete Account Section (Danger Zone) -->
            <div class="card" style="border: 1px solid rgba(239, 68, 68, 0.2); background: rgba(239, 68, 68, 0.02); margin-top: 1.5rem;">
                <h3 style="font-family:'Outfit'; font-size:1.15rem; margin-bottom:0.25rem; color: var(--color-danger);"><i data-lucide="alert-triangle" style="width: 18px; height: 18px; display: inline-block; vertical-align: middle; margin-right: 0.25rem;"></i> <?php echo getLang() === 'en' ? 'Danger Zone: Delete Account' : 'Zon Bahaya: Padam Akaun'; ?></h3>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1.25rem;"><?php echo getLang() === 'en' ? 'Permanently delete your account, saved splits, bank profiles, and all uploaded assets. This action is irreversible.' : 'Padam akaun anda secara kekal, bil splits yang disimpan, profil bank, dan semua fail yang dimuat naik. Tindakan ini tidak boleh diundur.'; ?></p>
                
                <form action="profile.php" method="POST" onsubmit="return confirm('<?php echo getLang() === 'en' ? 'WARNING: Are you absolutely sure you want to permanently delete your account? This will wipe all your bills and details.' : 'AMARAN: Adakah anda benar-benar pasti mahu memadamkan akaun anda secara kekal? Tindakan ini akan memadamkan semua bil dan butiran anda.'; ?>')">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <input type="hidden" name="action" value="delete_account">
                    
                    <div class="input-group mb-3">
                        <label for="confirm_password"><?php echo getLang() === 'en' ? 'Enter Password to Confirm' : 'Masukkan Kata Laluan untuk Pengesahan'; ?></label>
                        <input type="password" id="confirm_password" name="confirm_password" class="input-field" required placeholder="<?php echo getLang() === 'en' ? 'Your login password' : 'Kata laluan log masuk anda'; ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-danger w-full" style="height:2.5rem; min-height:unset; background-color: var(--color-danger); border-color: var(--color-danger);"><?php echo getLang() === 'en' ? 'Permanently Delete Account' : 'Padam Akaun Secara Kekal'; ?></button>
                </form>
            </div>
        </div>
    </main>

    <!-- Library scripts -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script src="assets/js/utils.js"></script>
    <script>
        lucide.createIcons();

        // Language Switcher Logic
        document.getElementById('langToggle')?.addEventListener('click', () => {
            const currentLang = document.cookie.split('; ').find(row => row.startsWith('lang='))?.split('=')[1] || 'en';
            const nextLang = currentLang === 'en' ? 'bm' : 'en';
            document.cookie = `lang=${nextLang}; path=/; max-age=${30 * 86400}`;
            const url = new URL(window.location.href);
            url.searchParams.set('lang', nextLang);
            window.location.href = url.toString();
        });

        // 1. Copy Public Profile view link
        const copyPublicLinkBtn = document.getElementById('copyPublicLinkBtn');
        const publicLinkInput = document.getElementById('publicLinkInput');
        const copiedToastMsg = "<?php echo getLang() === 'en' ? 'Public profile link copied!' : 'Pautan profil awam disalin!'; ?>";
        
        if (copyPublicLinkBtn && publicLinkInput) {
            copyPublicLinkBtn.addEventListener('click', () => {
                publicLinkInput.select();
                document.execCommand('copy');
                Utils.showToast(copiedToastMsg, "success");
            });
        }

        // 2. Profile Avatar Preview
        function previewProfilePic(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('profileAvatarPreview');
                    const fallback = document.getElementById('profileAvatarFallback');
                    if (preview) {
                        preview.src = e.target.result;
                    } else if (fallback) {
                        const img = document.createElement('img');
                        img.id = 'profileAvatarPreview';
                        img.src = e.target.result;
                        img.style.width = '100%';
                        img.style.height = '100%';
                        img.style.objectFit = 'cover';
                        fallback.parentNode.replaceChild(img, fallback);
                    }
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        // 3. QR Decoder & Re-generator JavaScript
        function handleQrDrop(e) {
            e.preventDefault();
            const dropzone = document.getElementById('qrDropzone');
            dropzone.style.borderColor = 'var(--border-color)';
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                processQrFile(e.dataTransfer.files[0]);
            }
        }

        function decodeQrFile(input) {
            if (input.files && input.files[0]) {
                processQrFile(input.files[0]);
            }
        }

        const qrSuccessToast = "<?php echo __('qr_scan_success'); ?>";
        const qrFailedToast = "<?php echo __('qr_scan_failed'); ?>";

        function processQrFile(file) {
            if (!file.type.startsWith('image/')) {
                Utils.showToast("Please upload a valid image file.", "error");
                return;
            }
            
            Utils.showToast("<?php echo getLang() === 'en' ? 'Scanning QR code...' : 'Mengimbas kod QR...'; ?>", "info");

            const reader = new FileReader();
            reader.onload = function(e) {
                const img = new Image();
                img.onload = function() {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0, img.width, img.height);
                    
                    try {
                        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                        const code = jsQR(imageData.data, imageData.width, imageData.height);
                        
                        if (code) {
                            document.getElementById('scanned_qr_value').value = code.data;
                            document.getElementById('decodedPayloadText').textContent = code.data;
                            document.getElementById('qrScanResult').style.display = 'block';
                            
                            renderRecreatedQr(code.data);
                            Utils.showToast(qrSuccessToast, "success");
                        } else {
                            Utils.showToast(qrFailedToast, "error");
                        }
                    } catch (err) {
                        console.error("QR scanning error:", err);
                        Utils.showToast(qrFailedToast, "error");
                    }
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }

        function renderRecreatedQr(text) {
            const container = document.getElementById('editorQrPreview');
            if (!container) return;
            container.innerHTML = '';
            
            try {
                new QRCode(container, {
                    text: text,
                    width: 120,
                    height: 120,
                    colorDark : "#0b0f19",
                    colorLight : "#ffffff",
                    correctLevel : QRCode.CorrectLevel.M
                });
            } catch (err) {
                console.error("QR Code generation failed:", err);
            }
        }

        // 4. Control QR visibility settings based on QR type selection
        const qrTypeSelect = document.getElementById('qr_type');
        const qrValueGroup = document.getElementById('qr_value_group');
        const qrValueLabel = document.getElementById('qr_value_label');
        const qrValueInput = document.getElementById('qr_value');
        const qrFileGroup = document.getElementById('qr_file_group');
        const qrScannerGroup = document.getElementById('qr_scanner_group');
        
        const updateQrFields = () => {
            const val = qrTypeSelect.value;
            qrValueGroup.style.display = 'none';
            qrFileGroup.style.display = 'none';
            qrScannerGroup.style.display = 'none';
            
            if (val === 'none') {
                // Do nothing
            } else if (val === 'duitnow') {
                qrValueGroup.style.display = 'block';
                qrValueLabel.textContent = "<?php echo __('duitnow_phone'); ?>";
                qrValueInput.placeholder = 'e.g. 60123456789';
            } else if (val === 'tng') {
                qrValueGroup.style.display = 'block';
                qrValueLabel.textContent = "<?php echo __('tng_transfer'); ?>";
                qrValueInput.placeholder = 'e.g. https://payment.tngdigital.com.my/...';
            } else if (val === 'custom') {
                qrFileGroup.style.display = 'block';
            } else if (val === 'scanned') {
                qrScannerGroup.style.display = 'block';
                const savedVal = document.getElementById('scanned_qr_value').value;
                if (savedVal) {
                    document.getElementById('decodedPayloadText').textContent = savedVal;
                    document.getElementById('qrScanResult').style.display = 'block';
                    renderRecreatedQr(savedVal);
                }
            }
        };

        if (qrTypeSelect) {
            qrTypeSelect.addEventListener('change', updateQrFields);
            updateQrFields(); // Run initially
        }
    </script>
</body>
</html>
