<?php
/**
 * Personal Bill Splitter - User Login Page
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

// 1. Redirect to installer if DB not configured
if (!isDbConfigured() && file_exists('install.php')) {
    header('Location: install.php');
    exit;
}

// 2. Redirect to dashboard if already logged in
if (isAuthenticated()) {
    header('Location: dashboard.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!checkRateLimit('login', 15, 60)) {
        $error = "Too many login attempts. Please wait a minute and try again.";
    } else {
        $token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
        if (!validateCSRFToken($token)) {
            $error = "CSRF verification failed. Please refresh the page and try again.";
        } else {
            $username = trim($_POST['username']);
            $password = trim($_POST['password']);

            if (empty($username) || empty($password)) {
                $error = "Please enter both username and password.";
            } else {
                try {
                    if (!isDbConnected()) {
                        throw new Exception("Database connection is offline. Please check your DB details.");
                    }

                    $stmt = $db->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ?");
                    $stmt->execute([$username]);
                    $user = $stmt->fetch();

                    if ($user && password_verify($password, $user['password_hash'])) {
                        session_regenerate_id(true); // Prevent Session Fixation
                        
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['user_name'] = $user['username'];
                        $_SESSION['user_role'] = $user['role'];
                        
                        logActivity('user_login', 'User logged in successfully');
                        
                        // Redirect based on role or saved redirect url
                        if (isset($_SESSION['redirect_url'])) {
                            $redirect = $_SESSION['redirect_url'];
                            unset($_SESSION['redirect_url']);
                            header("Location: " . $redirect);
                        } else if ($user['role'] === 'admin') {
                            header('Location: admin.php');
                        } else {
                            header('Location: dashboard.php');
                        }
                        exit;
                    } else {
                        $error = "Invalid username or password.";
                    }
                } catch (Exception $e) {
                    $error = $e->getMessage();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BillSplitter - Login</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0b0f19;
            --bg-secondary: #131926;
            --bg-tertiary: #1e2638;
            --border-color: rgba(255, 255, 255, 0.08);
            --color-primary: #818cf8;
            --color-primary-hover: #6366f1;
            --text-primary: #f8fafc;
            --text-muted: #64748b;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: 'Inter', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 1.5rem;
        }
        .container {
            width: 100%;
            max-width: 420px;
        }
        .card {
            background: rgba(19, 25, 38, 0.75);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--border-color);
            border-radius: 4px;
            padding: 2.25rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.5);
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        .header {
            text-align: center;
        }
        .header h1 {
            font-family: 'Outfit', sans-serif;
            font-size: 1.75rem;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
            letter-spacing: -0.02em;
        }
        .header p {
            font-size: 0.85rem;
            color: var(--text-muted);
        }
        .input-group {
            display: flex;
            flex-direction: column;
            gap: 0.4rem;
        }
        .input-group label {
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 0.05em;
        }
        .input-field {
            width: 100%;
            font-family: inherit;
            font-size: 0.95rem;
            padding: 0.75rem 1rem;
            border-radius: 2px;
            border: 1px solid var(--border-color);
            background-color: var(--bg-secondary);
            color: var(--text-primary);
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .input-field:focus {
            border-color: var(--color-primary);
            box-shadow: 0 0 12px rgba(129, 140, 248, 0.4);
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background-color: var(--color-primary);
            color: #ffffff;
            font-size: 0.95rem;
            font-weight: 600;
            padding: 0.8rem 1.5rem;
            border-radius: 2px;
            border: none;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.2s, transform 0.2s, box-shadow 0.2s;
            text-decoration: none;
        }
        .btn:hover {
            background-color: var(--color-primary-hover);
            box-shadow: 0 0 12px rgba(129, 140, 248, 0.4);
        }
        .btn:active {
            transform: scale(0.98);
        }
        .alert {
            padding: 0.85rem 1.25rem;
            border-radius: 2px;
            font-size: 0.875rem;
            line-height: 1.4;
            background-color: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: #f87171;
        }
        .footer-text {
            font-size: 0.85rem;
            color: var(--text-muted);
            text-align: center;
            margin-top: 0.5rem;
        }
        .footer-text a {
            color: var(--color-primary);
            text-decoration: none;
            font-weight: 600;
        }
        .footer-text a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Floating Language Switcher -->
    <div style="position: fixed; top: 1.5rem; right: 1.5rem; z-index: 1000;">
        <button id="langToggle" style="background: rgba(19, 25, 38, 0.75); border: 1px solid var(--border-color); color: var(--text-primary); cursor: pointer; border-radius: 4px; padding: 0.5rem 0.75rem; font-weight: 700; font-size: 0.8rem; font-family: 'Outfit', sans-serif; transition: all 0.2s;" onmouseover="this.style.borderColor='var(--color-primary)'" onmouseout="this.style.borderColor='var(--border-color)'" aria-label="Change Language">
            <?php echo getLang() === 'en' ? 'BM' : 'EN'; ?>
        </button>
    </div>

    <div class="container">
        <form action="login.php" method="POST" class="card">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <div class="header">
                <h1><?php echo __('welcome_back'); ?></h1>
                <p><?php echo getLang() === 'en' ? 'Log in to split and manage bills' : 'Log masuk untuk membahagi dan mengurus bil'; ?></p>
            </div>

            <?php if ($error): ?>
                <div class="alert">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <div class="input-group">
                <label for="username"><?php echo __('username'); ?></label>
                <input type="text" id="username" name="username" class="input-field" placeholder="<?php echo __('username'); ?>" required autofocus>
            </div>

            <div class="input-group">
                <label for="password"><?php echo __('password'); ?></label>
                <input type="password" id="password" name="password" class="input-field" placeholder="<?php echo __('password'); ?>" required>
            </div>

            <button type="submit" class="btn"><?php echo __('login'); ?></button>
            
            <div class="footer-text">
                <?php echo __('dont_have_account'); ?> <a href="register.php"><?php echo __('register'); ?></a>
            </div>
        </form>
    </div>

    <script>
        document.getElementById('langToggle')?.addEventListener('click', () => {
            const currentLang = document.cookie.split('; ').find(row => row.startsWith('lang='))?.split('=')[1] || 'en';
            const nextLang = currentLang === 'en' ? 'bm' : 'en';
            document.cookie = `lang=${nextLang}; path=/; max-age=${30 * 86400}`;
            const url = new URL(window.location.href);
            url.searchParams.set('lang', nextLang);
            window.location.href = url.toString();
        });
    </script>
</body>
</html>
