/**
 * Scroll-triggered reveal: adds .visible when elements enter the viewport.
 */
export function initScrollReveal() {
  const elements = document.querySelectorAll(
    '.skill-card, .project-card, .case-study-card, .about-stats, .section-label, .section-title, .timeline-item, .contact-info-card, .contact-form-wrapper'
  );

  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    },
    { threshold: 0.1 }
  );

  elements.forEach(el => {
    el.classList.add('reveal');
    observer.observe(el);
  });
}
