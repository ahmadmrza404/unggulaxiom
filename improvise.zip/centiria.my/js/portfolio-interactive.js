/**
 * Controls dynamic UI filtering, form floating inputs, project showcase modals, 
 * collapsible timelines, dynamic counts, and toast notifications.
 */

export function initInteractivePortfolio() {
  
  // ==========================================
  // 1. TOAST NOTIFICATION UTILITY
  // ==========================================
  function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    
    const item = document.createElement('div');
    item.className = `toast-item ${type}`;
    
    let icon = '<i class="fas fa-check-circle"></i>';
    if (type === 'info') icon = '<i class="fas fa-info-circle"></i>';
    if (type === 'error') icon = '<i class="fas fa-exclamation-triangle"></i>';
    
    item.innerHTML = `${icon} <span>${message}</span>`;
    container.appendChild(item);
    
    // Auto-remove after 3.2s
    setTimeout(() => {
      item.classList.add('fade-out');
      item.addEventListener('animationend', () => {
        item.remove();
      });
    }, 3000);
  }

  // Intercept and show custom toasts from other modules
  document.addEventListener('show-toast', (e) => {
    showToast(e.detail.message, e.detail.type);
  });


  // ==========================================
  // 2. DYNAMIC SKILLS GRID FILTERING & COUNTS
  // ==========================================
  const skillsFilterBtns = document.querySelectorAll('.filter-btn');
  const skillCards = document.querySelectorAll('.skill-card');

  // Calculate matching counts dynamically on boot
  skillsFilterBtns.forEach(btn => {
    const filter = btn.getAttribute('data-filter');
    let count = 0;
    skillCards.forEach(card => {
      if (filter === 'all' || card.getAttribute('data-category') === filter) {
        count++;
      }
    });
    const originalText = btn.textContent;
    btn.innerHTML = `${originalText} <span style="font-size: 0.75rem; opacity: 0.8; font-weight: 900; margin-left: 2px;">(${count})</span>`;
    
    btn.addEventListener('click', () => {
      skillsFilterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      skillCards.forEach(card => {
        const category = card.getAttribute('data-category');
        if (filter === 'all' || category === filter) {
          card.classList.remove('fade-out');
          card.classList.add('fade-in');
        } else {
          card.classList.remove('fade-in');
          card.classList.add('fade-out');
        }
      });
    });
  });


  // ==========================================
  // 3. PROJECTS GRID FILTERING & COUNTS
  // ==========================================
  const projectFilterBtns = document.querySelectorAll('.project-filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  projectFilterBtns.forEach(btn => {
    const filter = btn.getAttribute('data-filter');
    let count = 0;
    projectCards.forEach(card => {
      if (filter === 'all' || card.getAttribute('data-category') === filter) {
        count++;
      }
    });
    const originalText = btn.textContent;
    btn.innerHTML = `${originalText} <span style="font-size: 0.75rem; opacity: 0.8; font-weight: 900; margin-left: 2px;">(${count})</span>`;

    btn.addEventListener('click', () => {
      projectFilterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      projectCards.forEach(card => {
        const category = card.getAttribute('data-category');
        if (filter === 'all' || category === filter) {
          card.classList.remove('fade-out');
          card.classList.add('fade-in');
        } else {
          card.classList.remove('fade-in');
          card.classList.add('fade-out');
        }
      });
    });
  });


  // ==========================================
  // 4. PROJECT DETAILS MODAL & SLIDER NAV
  // ==========================================
  // Use dynamic project details from content-loader if available
  const _projectDetails = window._projectDetails || {};

  const defaultProjectData = {
    vibeguard: {
      title: 'VibeGuard',
      category: 'DevSecOps CLI Tool',
      desc: 'A CLI-native adversarial QA daemon that installs as a Git pre-push hook. Extracts code diffs, sends them to an LLM for red-team analysis, fires live exploit payloads against the local dev server, and auto-generates security patches -- all before code reaches GitHub.',
      bullets: [
        'Built a 10-phase security pipeline with zero runtime dependencies (122 KB prod bundle).',
        'Engineered LLM-driven adversarial payload generation covering 14 vulnerability vectors with a deterministic fallback library of 70+ attack values.',
        'Designed self-healing patch engine with LCS-based unified diff generation and automated Jest/Bash regression test export.',
        'Integrated database state guard (SQLite/MySQL/PostgreSQL) with automatic snapshot and restore around adversarial testing.',
      ],
      demoLink: '#',
      githubLink: 'https://github.com/silentganja/vibeguard',
      fileName: 'pipeline.ts',
      code: [
        '// VibeGuard -- 10-phase adversarial pre-push pipeline',
        '// Installed as a git pre-push hook. Zero runtime deps.',
        'async function run(argv: string[]): Promise<void> {',
        '  // Phase 1: Diff extraction via git merge-base',
        '  const diff = await extractDiff();',
        '  // Phase 2: LLM adversarial analysis',
        '  const analysis = await analyzeWithLLM(diff);',
        '  // Phase 5: Generate exploit payloads (14 vectors)',
        '  const payloads = await generatePayloads(analysis);',
        '  // Phase 6: Fire payloads against local dev server',
        '  const results = await firePayloads(payloads);',
        '  // Phase 7: Self-healing patch generation',
        '  if (results.some(r => r.breached)) {',
        '    await generatePatches(results);',
        '    process.exit(1); // Block the push',
        '  }',
        '}',
      ].join('\n')
    },
    archmap: {
      title: 'Archmap',
      category: 'Static Analysis CLI Tool',
      desc: 'A zero-install static analysis tool that reverse-engineers the true module boundaries of a codebase by analyzing its import dependency graph. Uses Louvain community detection to find natural clusters, then compares them against the folder structure to surface boundary violations, sprawl, and restructure suggestions.',
      bullets: [
        'Implemented Louvain community detection algorithm with deterministic seeded PRNG for reproducible module discovery across TypeScript, JavaScript, Python, Go, and Rust codebases.',
        'Built full TypeScript Compiler API AST parser to extract all import/export forms (default, named, namespace, re-exports, type-only) for accurate dependency graph construction.',
        'Engineered Git co-change analysis (--git flag) to surface hidden coupling invisible to static import analysis, computing Jaccard similarity and surprise scores across 500 commits.',
        'Designed extensible multi-language parser registry with a shared LanguageParser interface, enabling new language support via a single file.',
      ],
      demoLink: '#',
      githubLink: 'https://github.com/silentganja/archmap',
      fileName: 'graph.ts',
      code: [
        '// Louvain community detection on the co-import graph',
        'export function detectCommunities(graph: DependencyGraph): Module[] {',
        '  // Phase 1: Initialize each file as its own community',
        '  let communities = initCommunities(graph.nodes);',
        '  // Phase 2: Iterative modularity optimization',
        '  for (let pass = 0; pass < MAX_PASSES; pass++) {',
        '    const shuffled = deterministicShuffle(graph.nodes, SEED);',
        '    let moved = 0;',
        '    for (const node of shuffled) {',
        '      const best = findBestCommunity(node, communities, graph);',
        '      if (best.improves > 0) { moveNode(node, best.id, communities); moved++; }',
        '    }',
        '    if (moved === 0) break; // Converged',
        '  }',
        '  return buildModules(communities, graph);',
        '}',
      ].join('\n')
    },
    unggul: {
      title: 'Unggul Axiom Hub',
      category: 'Full-Stack Enterprise Platform',
      desc: 'A sovereign enterprise cloud storage and collaboration platform purpose-built for environments where data classification, audit integrity, and access control are critical. Features a Rust/Actix-Web backend with 75+ endpoints, Next.js 16 frontend with 12-tab admin console, and full CI/CD to AWS Lightsail.',
      bullets: [
        'Architected a dynamic, database-driven RBAC engine with 19 atomic permission keys resolved via a UNION query across direct overrides, base roles, and group memberships -- zero code changes to add permissions.',
        'Engineered dual-signature governance workflow with 7 operation types, classification direction validation, undo capability, batch operations, and self-approval prevention -- all wrapped in PostgreSQL FOR UPDATE transactions.',
        'Implemented AES-256-GCM file encryption at rest with on-the-fly decryption, Argon2id password hashing, WebAuthn/FIDO2 passkeys, and JWT refresh token rotation.',
        'Built full CI/CD pipeline: GitHub Actions -> Docker multi-stage builds -> AWS ECR -> Lightsail deploy with zero-downtime rolling restart, authenticating via OIDC.',
      ],
      demoLink: 'https://hub.unggulaxiom.com',
      githubLink: 'https://github.com/silentganja/unggul-axiom-hub',
      fileName: 'governance.rs',
      code: [
        '// Dual-signature governance approval workflow',
        'pub async fn approve_request(',
        '    pool: &PgPool,',
        '    request_id: Uuid,',
        '    approver: &User,',
        '    justification: &str,',
        ') -> AppResult<GovernanceResponse> {',
        '    let mut tx = pool.begin().await?;',
        '    // Lock the request row to prevent TOCTOU',
        '    let request = sqlx::query_as!(GovernanceRequest,',
        '        "SELECT * FROM governance_requests WHERE id = $1 FOR UPDATE",',
        '        request_id',
        '    ).fetch_optional(&mut *tx).await?;',
        '    // Prevent self-approval',
        '    if request.requester_id == approver.id {',
        '        return Err(AppError::Forbidden);',
        '    }',
        '    // Execute the governed action',
        '    execute_governed_action(&mut tx, &request).await?;',
        '    tx.commit().await?;',
        '    notify_user_via_sse(&request.requester_id, "approved").await;',
        '    Ok(response)',
        '}',
      ].join('\n')
    }
  };

  // Merge dynamic details over defaults, including any newly added projects
  const projectData = {};
  Object.keys(defaultProjectData).forEach(function(key) {
    projectData[key] = Object.assign({}, defaultProjectData[key]);
  });
  Object.keys(_projectDetails).forEach(function(key) {
    if (projectData[key]) {
      projectData[key] = Object.assign(projectData[key], _projectDetails[key]);
    } else {
      projectData[key] = Object.assign({}, _projectDetails[key]);
    }
  });

  const projectKeys = Object.keys(projectData);

  const projectModal = document.getElementById('projectModal');
  const modalBody = document.getElementById('modalBody');
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  const modalOverlay = document.getElementById('modalOverlay');
  const detailBtns = document.querySelectorAll('.project-details-btn');

  function openModal(projectKey) {
    const data = projectData[projectKey];
    if (!data) return;

    const bulletsHTML = data.bullets.map(b => `<li>${b}</li>`).join('');
    const currentIndex = projectKeys.indexOf(projectKey);
    const prevKey = projectKeys[(currentIndex - 1 + projectKeys.length) % projectKeys.length];
    const nextKey = projectKeys[(currentIndex + 1) % projectKeys.length];

    // Convert code to syntax-highlighted HTML
    const codeHTML = (data.code || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    modalBody.innerHTML = `
      <div class="modal-body-grid">
        <div class="modal-details animate-fade-in">
          <span class="timeline-date">${data.category}</span>
          <h2>${data.title}</h2>
          <p class="timeline-company">${data.desc}</p>

          <h4>Key Achievements</h4>
          <ul class="modal-bullets">
            ${bulletsHTML}
          </ul>

          <div class="modal-actions">
            <a href="${data.demoLink}" class="btn btn-primary"><i class="fas fa-external-link-alt"></i> Live Demo</a>
            <a href="${data.githubLink}" class="btn btn-outline"><i class="fab fa-github"></i> Source Code</a>
          </div>
        </div>

        <div class="modal-code-preview-wrapper animate-fade-in">
          <h4>Code Highlight</h4>
          <div class="modal-code-preview">
            <div class="code-preview-header">
              <span><i class="fas fa-file-code"></i> ${data.fileName}</span>
              <span class="text-muted">read-only</span>
            </div>
            <div class="code-preview-body">
              <pre class="code-block"><code>${codeHTML}</code></pre>
            </div>
          </div>
        </div>
      </div>

      <!-- Nav Slider controls -->
      <div class="modal-nav-container">
        <button class="modal-nav-btn prev" data-target="${prevKey}" aria-label="Previous Project">
          <i class="fas fa-chevron-left"></i>
        </button>
        <button class="modal-nav-btn next" data-target="${nextKey}" aria-label="Next Project">
          <i class="fas fa-chevron-right"></i>
        </button>
      </div>
    `;

    // Wire up slider navigation events
    const prevBtn = modalBody.querySelector('.modal-nav-btn.prev');
    const nextBtn = modalBody.querySelector('.modal-nav-btn.next');
    if (prevBtn) {
      prevBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openModal(prevKey);
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openModal(nextKey);
      });
    }

    projectModal.classList.add('active');
    document.body.style.overflow = 'hidden';

    // Focus trap: move focus into the modal
    const closeBtn = document.getElementById('modalCloseBtn');
    if (closeBtn) {
      closeBtn.focus();
    }
    // Store the element that had focus before modal opened
    projectModal._previouslyFocused = document.activeElement !== closeBtn ? document.activeElement : null;
  }

  function closeModal() {
    projectModal.classList.remove('active');
    document.body.style.overflow = '';

    // Restore focus to the previously focused element
    if (projectModal._previouslyFocused && typeof projectModal._previouslyFocused.focus === 'function') {
      projectModal._previouslyFocused.focus();
      projectModal._previouslyFocused = null;
    }
  }

  // Focus trap: keep focus inside modal while open
  projectModal.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab' || !projectModal.classList.contains('active')) return;

    const focusableSelectors = [
      'button:not([disabled])',
      'a[href]',
      'input:not([disabled])',
      'textarea:not([disabled])',
      '[tabindex]:not([tabindex="-1"])',
    ];
    const focusable = projectModal.querySelectorAll(focusableSelectors.join(','));
    if (focusable.length === 0) return;

    const firstFocusable = focusable[0];
    const lastFocusable = focusable[focusable.length - 1];

    if (e.shiftKey) {
      if (document.activeElement === firstFocusable) {
        e.preventDefault();
        lastFocusable.focus();
      }
    } else {
      if (document.activeElement === lastFocusable) {
        e.preventDefault();
        firstFocusable.focus();
      }
    }
  });

  detailBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const projectKey = btn.getAttribute('data-project');
      openModal(projectKey);
    });
  });

  if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeModal);
  if (modalOverlay) modalOverlay.addEventListener('click', closeModal);

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && projectModal.classList.contains('active')) {
      closeModal();
    }
  });


  // ==========================================
  // 5. COLLAPSIBLE EXPERIENCE TIMELINE CARDS
  // ==========================================
  const timelineContents = document.querySelectorAll('.timeline-content');
  timelineContents.forEach(content => {
    const bullets = content.querySelector('.timeline-bullets');
    if (bullets) {
      // Create and inject the blocky expansion button
      const btn = document.createElement('button');
      btn.className = 'timeline-expand-btn';
      btn.innerHTML = 'Show Details <i class="fas fa-chevron-down"></i>';
      content.appendChild(btn);

      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        content.classList.toggle('expanded');
        const isExpanded = content.classList.contains('expanded');
        btn.innerHTML = isExpanded 
          ? 'Hide Details <i class="fas fa-chevron-up"></i>' 
          : 'Show Details <i class="fas fa-chevron-down"></i>';
      });
    }
  });


  // ==========================================
  // 6. INTERACTIVE CLIPBOARD COPIES & TOASTS
  // ==========================================
  // Copy direct connections cards details
  const contactCards = document.querySelectorAll('.contact-info-card');
  contactCards.forEach(card => {
    card.style.cursor = 'pointer';
    card.addEventListener('click', () => {
      const p = card.querySelector('.info-card-text p');
      if (!p) return;
      const text = p.textContent.trim();
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        navigator.clipboard.writeText(text).then(() => {
          showToast(`Copied details: "${text}"`, 'success');
        }).catch(() => {
          showToast('Clipboard copy failed!', 'error');
        });
      } else {
        showToast('Clipboard not available in this browser', 'error');
      }
    });
  });

  // ==========================================
  // 7. CASE STUDY CARD INNER TABS
  // ==========================================
  const caseTabBtns = document.querySelectorAll('.case-tab-btn');
  caseTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const card = btn.closest('.case-study-card');
      if (!card) return;

      const targetTab = btn.getAttribute('data-tab');

      // Deactivate all buttons in this card
      card.querySelectorAll('.case-tab-btn').forEach(b => b.classList.remove('active'));
      // Activate clicked button
      btn.classList.add('active');

      // Deactivate all panels in this card
      card.querySelectorAll('.case-panel').forEach(p => p.classList.remove('active'));
      // Activate target panel in this card
      const targetPanel = card.querySelector(`.case-panel[data-panel="${targetTab}"]`);
      if (targetPanel) {
        targetPanel.classList.add('active');
      }
    });
  });

  // Intercept placeholder links clicks to prevent page jump
  document.querySelectorAll('a[href="#"]:not(.logo):not(.nav-link)').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const label = link.getAttribute('aria-label') || link.textContent.trim() || 'Link';
      showToast(`"${label}" is currently a placeholder`, 'info');
    });
  });

  // ==========================================
  // 8. SCROLL TO TOP BUTTON
  // ==========================================
  const scrollToTopBtn = document.getElementById('scrollToTop');
  if (scrollToTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 500) {
        scrollToTopBtn.classList.add('show');
      } else {
        scrollToTopBtn.classList.remove('show');
      }
    });

    scrollToTopBtn.addEventListener('click', () => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }
}

