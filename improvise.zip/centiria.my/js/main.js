/**
 * Main entry point — imports and initializes all modules.
 */

import { initTheme } from './theme.js';
import { initNavbar } from './navbar.js';
import { startTypewriter } from './typewriter.js';
import { initScrollReveal } from './reveal.js';
import { initCounters } from './counters.js';
import { initParallax } from './parallax.js';
import { initInteractivePortfolio } from './portfolio-interactive.js';
function initAll() {
  initTheme();
  initNavbar();
  initScrollReveal();
  initCounters();
  initParallax();
  initInteractivePortfolio();

  // Set dynamic copyright year if not already populated by content-loader
  const footerYear = document.getElementById('footerYear');
  if (footerYear && !footerYear.textContent.trim()) {
    footerYear.textContent = new Date().getFullYear();
  }

  const typewriterEl = document.getElementById('typewriter');
  if (typewriterEl) {
    // Try to load roles from content-loader data attribute (dynamic/from admin panel)
    let roles = [];
    try {
      if (typewriterEl.dataset.roles) {
        roles = JSON.parse(typewriterEl.dataset.roles);
      }
    } catch (e) { /* fallback */ }

    // Filter out any empty/invalid values from localStorage overrides
    if (Array.isArray(roles)) {
      roles = roles.filter(role => role && typeof role === 'string' && role.trim() !== '');
    } else {
      roles = [];
    }

    // Fallback to hardcoded defaults
    if (!roles || roles.length === 0) {
      roles = [
        'Full-Stack Developer',
        'UI/UX Design Enthusiast',
        'Scalable Web Architect',
      ];
    }

    const preloader = document.getElementById('preloader');
    const isLoaded = !preloader || preloader.classList.contains('loaded');
    if (isLoaded) {
      startTypewriter(typewriterEl, roles);
    } else {
      document.addEventListener('preloader-done', () => {
        startTypewriter(typewriterEl, roles);
      });
    }
  }
}

// Prevent race condition if DOMContentLoaded fired before script fully loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAll);
} else {
  initAll();
}
