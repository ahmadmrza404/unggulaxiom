/**
 * Animated stat counters — count up to data-target when scrolled into view.
 */

function animateCounter(element, target) {
  let current = 0;
  const increment = target / 40;
  const stepTime = Math.floor(1500 / 40);

  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      element.textContent = target + '+';
      clearInterval(timer);
    } else {
      element.textContent = Math.floor(current);
    }
  }, stepTime);
}

export function initCounters() {
  const counters = document.querySelectorAll('.stat-number');

  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const counter = entry.target;
          const target = parseInt(counter.getAttribute('data-target'), 10);
          if (Number.isNaN(target) || target <= 0) {
            observer.unobserve(counter);
            return;
          }
          animateCounter(counter, target);
          observer.unobserve(counter);
        }
      });
    },
    { threshold: 0.5 }
  );

  counters.forEach(counter => observer.observe(counter));
}
