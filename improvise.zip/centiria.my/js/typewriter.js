/**
 * Looping typewriter effect. Types each word, deletes it, then moves on.
 * Uses IntersectionObserver to pause when offscreen.
 */
export function startTypewriter(element, words, startDelay = 1200) {
  if (!element || !words || words.length === 0) return;

  let wordIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  let isVisible = true;
  let timeoutId = null;

  // Pause animation when element is not visible
  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        isVisible = entry.isIntersecting;
        if (isVisible && !timeoutId) {
          // Resume from where we left off
          tick();
        }
      });
    },
    { threshold: 0.1 }
  );
  observer.observe(element);

  function tick() {
    if (!isVisible) {
      timeoutId = null;
      return;
    }

    const currentWord = words[wordIndex];

    element.textContent = currentWord.substring(
      0,
      isDeleting ? charIndex - 1 : charIndex + 1
    );
    charIndex += isDeleting ? -1 : 1;

    let speed = isDeleting ? 50 : 100;

    if (!isDeleting && charIndex === currentWord.length) {
      speed = 2000; // pause at full word
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      wordIndex = (wordIndex + 1) % words.length;
      speed = 500; // pause before next word
    }

    timeoutId = setTimeout(tick, speed);
  }

  timeoutId = setTimeout(tick, startDelay);
}
