/**
 * Navbar: scroll effect, mobile hamburger, active-section tracking.
 */
export function initNavbar() {
  const navbar = document.getElementById('navbar');
  const hamburger = document.getElementById('hamburger');
  const navLinksEl = document.getElementById('navLinks');
  const navLinks = document.querySelectorAll('.nav-link');

  /* ---- Create mobile menu overlay ---- */
  const overlay = document.createElement('div');
  overlay.className = 'nav-mobile-overlay';
  overlay.setAttribute('aria-hidden', 'true');
  document.body.appendChild(overlay);

  let menuOpen = false;

  function openMenu() {
    menuOpen = true;
    hamburger.classList.add('active');
    navLinksEl.classList.add('active');
    hamburger.setAttribute('aria-expanded', 'true');
    overlay.classList.add('active');
    overlay.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    menuOpen = false;
    hamburger.classList.remove('active');
    navLinksEl.classList.remove('active');
    hamburger.setAttribute('aria-expanded', 'false');
    overlay.classList.remove('active');
    overlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  /* ---- scroll → background blur ---- */
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  /* ---- hamburger toggle ---- */
  hamburger.setAttribute('aria-expanded', 'false');
  hamburger.setAttribute('aria-label', 'Toggle navigation menu');
  hamburger.addEventListener('click', () => {
    if (menuOpen) {
      closeMenu();
    } else {
      openMenu();
    }
  });

  /* ---- close menu on overlay click ---- */
  overlay.addEventListener('click', closeMenu);

  /* ---- close menu on Escape key ---- */
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && menuOpen) {
      closeMenu();
    }
  });

  /* ---- close menu on link click ---- */
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      closeMenu();
    });
  });

  /* ---- active section tracking ---- */
  const sections = document.querySelectorAll('section[id]');

  window.addEventListener('scroll', () => {
    let current = '';

    // Check if scrolled to bottom of the page
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 60) {
      current = 'contact';
    } else {
      sections.forEach(section => {
        if (window.scrollY >= section.offsetTop - 150) {
          current = section.getAttribute('id');
        }
      });
    }

    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  });
}
