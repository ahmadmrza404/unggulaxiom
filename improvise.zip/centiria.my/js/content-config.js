/**
 * content-config.js — Shared Content Management Layer
 * 
 * Provides default content and localStorage persistence.
 * Used by both the main portfolio (index.html) and admin dashboard.
 * 
 * All content is hardcoded with defaults; admin panel saves overrides to localStorage.
 */

const ContentManager = {
  // ==========================================
  // STORAGE KEY
  // ==========================================
  STORAGE_KEY: 'portfolio_content',

  // ==========================================
  // DEFAULT CONTENT — matches the original HTML
  // ==========================================
  defaults: {
  "hero": {
    "badge": "Available for Full-time Roles",
    "title": "Hi, I'm <span class=\"gradient-text\">Ahmad Mirza</span><br />",
    "subtitle": "I build performant, user-focused web applications with modern technologies. Specializing in React, Node.js, and cloud-native architectures.",
    "typewriterRoles": [
      "Full-Stack Developer",
      "UI/UX Design Enthusiast",
      "Scalable Web Architect"
    ],
    "socialLinks": {
      "github": "https://github.com/ahmadmrzaa",
      "linkedin": "https://www.linkedin.com/in/ahmad-mirza-0b606b278/"
    }
  },
  "about": {
    "label": "About Me",
    "title": "Turning ideas into <span class=\"gradient-text\">digital experiences</span>",
    "paragraphs": [
      "I'm a full-stack dev with 3+ years of learning and researching through self-learning. My journey started with discovering SQL injection on a school portal. That moment of curiosity spiraled into a deep obsession with how systems work, how they break, and how to build them right.",
      "When I'm not coding, you'll find me exploring new frameworks, contributing to open-source projects, or writing technical articles. I believe clean code and great UX go hand in hand."
    ],
    "stats": [
      {
        "label": "Years Deep-Diving the Web",
        "target": 6
      },
      {
        "label": "Projects Delivered",
        "target": 3
      },
      {
        "label": "Happy Clients",
        "target": 3
      }
    ]
  },
  "experience": {
    "label": "My Journey",
    "title": "Professional <span class=\"gradient-text\">Experience</span>",
    "items": [
      {
        "side": "left",
        "date": "Jan 2025 - present",
        "role": "System Architect",
        "company": "Unggul Bronto Sdn Bhd",
        "description": "Integrated Korean AI and IoT poultry farming technologies into the Unggul system to streamline the supply chain and maintain JAKIM Halal compliance.",
        "bullets": [
          "Led the integration of advanced Korean AI poultry farming models and IoT sensor networks into the Unggul enterprise system to streamline supply chain operations. ",
          "Collaborated as a Technical Partner to design system architectures that maintain strict JAKIM Halal compliance standards across agricultural workflows."
        ],
        "tags": [
          "System Architect",
          "Automation",
          "AI & IoT"
        ]
      },
      {
        "side": "left",
        "date": "Nov 2023 - May 2024",
        "role": "Surgical Dental Assistant",
        "company": "KLINIK PERGIGIAN AMALMEDIK",
        "description": "Part-time role supporting dental procedures and clinic operations in a fast-paced clinical environment.",
        "bullets": [
          "Ensured a seamless registration process, enhancing patient experience and clinic efficiency.",
          "Assisted the dentist in various procedures, from scaling to surgical interventions, demonstrating versatility and skill.",
          "Developed a strong understanding of dental practices and patient care, contributing to a supportive clinic environment."
        ],
        "tags": [
          "Patient Care",
          "Clinical Support",
          "Dental Procedures",
          "Team Collaboration"
        ]
      },
      {
        "side": "right",
        "date": "Feb 2022 - Jun 2025",
        "role": "Bachelor of Technology Creative",
        "company": "Universiti Malaysia Kelantan (UMK)",
        "description": "Specialising in the intersection of IT, Web Design, and Business Management at Universiti Malaysia Kelantan.",
        "bullets": [
          "Combined technical IT skills with creative web design principles and business strategy.",
          "Developed projects bridging technology and creative media for real-world applications."
        ],
        "tags": [
          "Web Design",
          "IT",
          "Business Management",
          "Creative Technology"
        ]
      }
    ]
  },
  "skills": {
    "label": "Skills & Expertise",
    "title": "Technologies I <span class=\"gradient-text\">work with</span>",
    "categories": [
      "all",
      "frontend",
      "backend",
      "databases",
      "devops",
      "security"
    ],
    "items": [
      {
        "category": "frontend",
        "icon": "fab fa-js",
        "title": "TypeScript",
        "desc": "Static types, generics, type guards, utility types, async/await, ES6+ module systems",
        "brandColor": "var(--brand-typescript)"
      },
      {
        "category": "frontend",
        "icon": "fab fa-react",
        "title": "Next.js & React",
        "desc": "App Router, Server Components, SSR/SSG, state management, custom hooks, SPAs",
        "brandColor": "var(--brand-react)"
      },
      {
        "category": "frontend",
        "icon": "fab fa-html5",
        "title": "HTML & CSS",
        "desc": "Semantic HTML5, CSS3, Flexbox, Grid, responsive design, cross-browser compatibility",
        "brandColor": "var(--brand-html)"
      },
      {
        "category": "backend",
        "icon": "fab fa-node-js",
        "title": "Node.js",
        "desc": "RESTful APIs, CLI tools, file system scripting, process automation, Git hooks",
        "brandColor": "var(--brand-node)"
      },
      {
        "category": "backend",
        "icon": "fab fa-rust",
        "title": "Rust & Actix-Web",
        "desc": "Type-safe REST APIs, middleware chains, async runtime, database drivers, error handling",
        "brandColor": "var(--brand-rust)"
      },
      {
        "category": "backend",
        "icon": "fab fa-php",
        "title": "PHP",
        "desc": "Server-side scripting, form handling, session management, MySQL integration",
        "brandColor": "var(--brand-php)"
      },
      {
        "category": "security",
        "icon": "fas fa-shield-alt",
        "title": "Security Engineering",
        "desc": "JWT auth, WebAuthn passkeys, AES-256-GCM encryption, Argon2id hashing, OIDC SSO",
        "brandColor": "var(--brand-security)"
      },
      {
        "category": "databases",
        "icon": "fas fa-database",
        "title": "PostgreSQL, MySQL & Redis",
        "desc": "Relational schema design, ACID transactions, row-level locking, caching strategies, query tuning",
        "brandColor": "var(--brand-database)"
      },
      {
        "category": "devops",
        "icon": "fab fa-docker",
        "title": "Docker",
        "desc": "Multi-stage builds, container orchestration, Docker Compose, image optimization",
        "brandColor": "var(--brand-docker)"
      },
      {
        "category": "devops",
        "icon": "fab fa-aws",
        "title": "AWS",
        "desc": "ECR registry, Lightsail deployments, S3 storage, IAM policies, zero-downtime rolling deploys",
        "brandColor": "var(--brand-aws)"
      },
      {
        "category": "devops",
        "icon": "fab fa-git-alt",
        "title": "Git & CI/CD",
        "desc": "GitHub Actions pipelines, OIDC authentication, Git hooks, branching strategies, code review",
        "brandColor": "var(--brand-git)"
      }
    ]
  },
  "projects": {
    "label": "Portfolio",
    "title": "Featured <span class=\"gradient-text\">Projects</span>",
    "categories": [
      "all",
      "fullstack",
      "frontend",
      "backend"
    ],
    "items": [
      {
        "category": "backend",
        "gradient": "linear-gradient(135deg, #ff416c, #ff4b2b)",
        "icon": "fas fa-shield-alt",
        "tags": [
          "TypeScript",
          "Node.js",
          "LLM",
          "Security"
        ],
        "title": "VibeGuard",
        "description": "CLI-native adversarial QA daemon that red-teams your code with AI before it reaches GitHub.",
        "githubLink": "https://github.com/ahmadmrzaa/vibeguard",
        "demoLink": "#",
        "detailsKey": "vibeguard"
      },
      {
        "category": "backend",
        "gradient": "linear-gradient(135deg, #11998e, #38ef7d)",
        "icon": "fas fa-project-diagram",
        "tags": [
          "TypeScript",
          "Node.js",
          "Code Analysis"
        ],
        "title": "Archmap",
        "description": "Static analysis CLI that discovers real module boundaries via dependency graph community detection.",
        "githubLink": "https://github.com/ahmadmrza/archmap",
        "demoLink": "#",
        "detailsKey": "archmap"
      },
      {
        "category": "fullstack",
        "gradient": "linear-gradient(135deg, #0f2027, #203a43, #2c5364)",
        "icon": "fas fa-cloud-upload-alt",
        "tags": [
          "Rust",
          "Next.js",
          "PostgreSQL",
          "Redis"
        ],
        "title": "Unggul Axiom Hub",
        "description": "Sovereign enterprise cloud storage platform with dynamic RBAC, classification-based access control, and dual-signature governance.",
        "githubLink": "https://github.com/ahmadmrzaa/unggul-axiom-hub",
        "demoLink": "https://hub.unggulaxiom.com",
        "detailsKey": "unggul"
      }
    ],
    "details": {
      "vibeguard": {
        "title": "VibeGuard",
        "category": "DevSecOps CLI Tool",
        "desc": "A CLI-native adversarial QA daemon that installs as a Git pre-push hook. Extracts code diffs, sends them to an LLM for red-team analysis, fires live exploit payloads against the local dev server, and auto-generates security patches, all before code reaches GitHub.",
        "bullets": [
          "Built a 10-phase security pipeline with zero runtime dependencies (122 KB prod bundle).",
          "Engineered LLM-driven adversarial payload generation covering 14 vulnerability vectors with a deterministic fallback library of 70+ attack values.",
          "Designed self-healing patch engine with LCS-based unified diff generation and automated Jest/Bash regression test export.",
          "Integrated database state guard (SQLite/MySQL/PostgreSQL) with automatic snapshot and restore around adversarial testing."
        ],
        "demoLink": "#",
        "githubLink": "https://github.com/ahmadmrzaa/vibeguard",
        "fileName": "pipeline.ts",
        "code": "// VibeGuard - 10-phase adversarial pre-push pipeline\n// Installed as a git pre-push hook. Zero runtime deps.\nasync function run(argv: string[]): Promise<void> {\n  // Phase 1: Diff extraction via git merge-base\n  const diff = await extractDiff();\n  // Phase 2: LLM adversarial analysis\n  const analysis = await analyzeWithLLM(diff);\n  // Phase 5: Generate exploit payloads (14 vectors)\n  const payloads = await generatePayloads(analysis);\n  // Phase 6: Fire payloads against local dev server\n  const results = await firePayloads(payloads);\n  // Phase 7: Self-healing patch generation\n  if (results.some(r => r.breached)) {\n    await generatePatches(results);\n    process.exit(1); // Block the push\n  }\n}"
      },
      "archmap": {
        "title": "Archmap",
        "category": "Static Analysis CLI Tool",
        "desc": "A zero-install static analysis tool that reverse-engineers the true module boundaries of a codebase by analyzing its import dependency graph. Uses Louvain community detection to find natural clusters, then compares them against the folder structure to surface boundary violations, sprawl, and restructure suggestions.",
        "bullets": [
          "Implemented Louvain community detection algorithm with deterministic seeded PRNG for reproducible module discovery across TypeScript, JavaScript, Python, Go, and Rust codebases.",
          "Built full TypeScript Compiler API AST parser to extract all import/export forms (default, named, namespace, re-exports, type-only) for accurate dependency graph construction.",
          "Engineered Git co-change analysis (--git flag) to surface hidden coupling invisible to static import analysis, computing Jaccard similarity and surprise scores across 500 commits.",
          "Designed extensible multi-language parser registry with a shared LanguageParser interface, enabling new language support via a single file."
        ],
        "demoLink": "#",
        "githubLink": "https://github.com/ahmadmrza/archmap",
        "fileName": "graph.ts",
        "code": "// Louvain community detection on the co-import graph\nexport function detectCommunities(graph: DependencyGraph): Module[] {\n  // Phase 1: Initialize each file as its own community\n  let communities = initCommunities(graph.nodes);\n  // Phase 2: Iterative modularity optimization\n  for (let pass = 0; pass < MAX_PASSES; pass++) {\n    const shuffled = deterministicShuffle(graph.nodes, SEED);\n    let moved = 0;\n    for (const node of shuffled) {\n      const best = findBestCommunity(node, communities, graph);\n      if (best.improves > 0) { moveNode(node, best.id, communities); moved++; }\n    }\n    if (moved === 0) break; // Converged\n  }\n  return buildModules(communities, graph);\n}"
      },
      "unggul": {
        "title": "Unggul Axiom Hub",
        "category": "Full-Stack Enterprise Platform",
        "desc": "A sovereign enterprise cloud storage and collaboration platform purpose-built for environments where data classification, audit integrity, and access control are critical. Features a Rust/Actix-Web backend with 75+ endpoints, Next.js 16 frontend with 12-tab admin console, and full CI/CD to AWS Lightsail.",
        "bullets": [
          "Architected a dynamic, database-driven RBAC engine with 19 atomic permission keys resolved via a UNION query across direct overrides, base roles, and group memberships, with zero code changes to add permissions.",
          "Engineered dual-signature governance workflow with 7 operation types, classification direction validation, undo capability, batch operations, and self-approval prevention, all wrapped in PostgreSQL FOR UPDATE transactions.",
          "Implemented AES-256-GCM file encryption at rest with on-the-fly decryption, Argon2id password hashing, WebAuthn/FIDO2 passkeys, and JWT refresh token rotation.",
          "Built full CI/CD pipeline: GitHub Actions → Docker multi-stage builds → AWS ECR → Lightsail deploy with zero-downtime rolling restart, authenticating via OIDC."
        ],
        "demoLink": "https://hub.unggulaxiom.com",
        "githubLink": "https://github.com/ahmadmrzaa/unggul-axiom-hub",
        "fileName": "governance.rs",
        "code": "// Dual-signature governance approval workflow\npub async fn approve_request(\n    pool: &PgPool,\n    request_id: Uuid,\n    approver: &User,\n    justification: &str,\n) -> AppResult<GovernanceResponse> {\n    let mut tx = pool.begin().await?;\n    // Lock the request row to prevent TOCTOU\n    let request = sqlx::query_as!(GovernanceRequest,\n        \"SELECT * FROM governance_requests WHERE id = $1 FOR UPDATE\",\n        request_id\n    ).fetch_optional(&mut *tx).await?;\n    // Prevent self-approval\n    if request.requester_id == approver.id {\n        return Err(AppError::Forbidden);\n    }\n    // Execute the governed action\n    execute_governed_action(&mut tx, &request).await?;\n    tx.commit().await?;\n    notify_user_via_sse(&request.requester_id, \"approved\").await;\n    Ok(response)\n}"
      }
    }
  },
  "caseStudies": {
    "label": "Deep Dives",
    "title": "Engineering <span class=\"gradient-text\">Case Studies</span>",
    "items": [
      {
        "id": "vibeguard-ai",
        "title": "VibeGuard",
        "subtitle": "An automated security tool that tests your code for safety vulnerabilities right before you push to GitHub.",
        "badge": "DevSecOps CLI",
        "brandColor": "var(--accent-3)",
        "metrics": [
          {
            "value": "122 KB",
            "label": "Zero-Dep Bundle"
          },
          {
            "value": "14",
            "label": "Vulnerability Vectors"
          },
          {
            "value": "10-Phase",
            "label": "Hook Pipeline"
          }
        ],
        "challenge": "Manual security audits and remote CI/CD checks slow down feature releases, raise cloud API costs, and expose code to privacy risks. Traditional static scanners also produce high false-positive rates because they check rules rather than testing active exploitability. We needed a secure, zero-cost pre-push hook that runs locally, intercepts code changes privately, and validates security vulnerabilities on the fly.",
        "solution": "Developed a zero-dependency CLI engine in TypeScript that automates local vulnerability testing. Before a push completes, VibeGuard extracts code changes relative to the branch merge-base, filters out comments/noise, and auto-starts the local dev server. It then prompts a local, unfiltered LLM (via Ollama) to generate context-aware test payloads, executing them in parallel with a concurrency cap of 3 to prevent self-DoS on lightweight local runtimes.",
        "impact": "Slashed the vulnerability feedback loop from 15 minutes in cloud CI/CD pipelines to under 12 seconds locally, ensuring absolute code privacy. It successfully blocked critical vulnerabilities (SQL Injection, IDOR, SSRF) from reaching production, resulting in zero credential leaks and significantly reducing developer friction.",
        "takeaway": {
          "title": "Deterministic Fallbacks Guard AI Reliability",
          "text": "While local AI models (like Llama 3 or Mistral) are excellent at analyzing code context and drafting intelligent exploit payloads, they can be slow or fail to respond under low-resource environments. We hardened our CLI by building a deterministic fallback database of 70+ static exploit payloads across 14 vulnerability vectors, ensuring VibeGuard runs reliably even if the AI model is safety-filtered or offline.",
          "lesson": "Always design automated AI pipelines with robust, local fallback heuristics to guarantee execution reliability and avoid blocking developer workflows."
        }
      },
      {
        "id": "archmap-analysis",
        "title": "Archmap",
        "subtitle": "A code architecture tool that maps how files in your project depend on each other and suggests ways to organize them.",
        "badge": "Code Analysis CLI",
        "brandColor": "var(--accent-4)",
        "metrics": [
          {
            "value": "Louvain",
            "label": "Community Detection"
          },
          {
            "value": "5",
            "label": "Languages Supported"
          },
          {
            "value": "< 4s",
            "label": "AST Analysis Time"
          }
        ],
        "challenge": "As codebases grow organically, folder structures become outdated, leading to tightly-coupled files scattered across different directories. This hidden architectural debt makes code hard to maintain, slow to build, and risky to refactor. Engineers lack a simple, automated way to extract real import boundaries and identify implicit file coupling that bypasses static import trees.",
        "solution": "Built a multi-language CLI tool in TypeScript. It parses JavaScript/TypeScript using the TypeScript Compiler API AST and parses Python/Go/Rust via line-based sentinels to construct a directed dependency graph. The engine applies the Louvain community detection algorithm with a deterministic seeded PRNG for reproducible clustering. It then scans Git logs to calculate Jaccard similarity and surprise scores across 500+ commits, mapping hidden developer co-change patterns.",
        "impact": "Empowered engineering teams to audit legacy monoliths instantly and identify circular dependencies and sprawling utility files. By suggesting clear \"split, merge, or extract\" actions, Archmap helped teams refactor directory structures, reducing boundary violations and overall code complexity by up to 40%.",
        "takeaway": {
          "title": "Git History Reveals Hidden Coupling",
          "text": "Static code imports only tell half the story. Files might not import each other directly, but if they change together in 80% of commits, they share implicit contracts, conventions, or logic. By cross-referencing static import graphs with historic git commit patterns, we can locate these hidden architectural smells that traditional code analysis tools miss entirely.",
          "lesson": "Pair static structural analysis with developer behavioral data (git logs) to capture the true, organic coupling in a codebase."
        }
      },
      {
        "id": "unggul-axiom",
        "title": "Unggul Axiom Hub",
        "subtitle": "A secure enterprise file storage and sharing platform built for classified documents and strict approvals.",
        "badge": "Enterprise Storage",
        "brandColor": "var(--accent-1)",
        "metrics": [
          {
            "value": "19",
            "label": "Granular Permissions"
          },
          {
            "value": "75+",
            "label": "Backend Endpoints"
          },
          {
            "value": "< 10ms",
            "label": "p95 Latency (Rust)"
          }
        ],
        "challenge": "Enterprise collaboration platforms handling classified files demand absolute compliance, secure access delegation, and strict dual-signature approvals. Under high concurrent write volumes, typical validation checks suffer from timing exploits like TOCTOU (Time-of-Check to Time-of-Use) and database deadlocks. The challenge was building an auditable, high-security storage gateway that maintains sub-10ms latencies under heavy database read/write stress.",
        "solution": "Architected a security-hardened backend in Rust using Actix-Web and raw SQL queries (via SQLx) for transparent query tuning. We designed a dynamic, database-driven RBAC engine that resolves user permissions, groups, and role hierarchies in a single database UNION query. The governance workflow prevents concurrency exploits by locking pending request records exclusively using PostgreSQL row-level locks (SELECT FOR UPDATE) inside transactions.",
        "impact": "Created a fully functioning sovereign cloud storage system running live at hub.unggulaxiom.com. It secures classified documents at rest via AES-256-GCM encryption, hashes credentials with Argon2id, and supports WebAuthn/FIDO2 passkeys. The platform delivers instant updates via Server-Sent Events (SSE) while keeping p95 latency under 10ms.",
        "takeaway": {
          "title": "Prevent TOCTOU Exploits via Row-Level Database Locks",
          "text": "Multi-user approval workflows are highly vulnerable to timing exploits: a user might approve a request while another concurrently modifies the file metadata. We solved this by locking the target row exclusively in the database during verification. This blocks concurrent processes from modifying the record until the transaction commits, ensuring absolute state consistency.",
          "lesson": "When engineering high-risk security workflows, state checks must be transaction-isolated at the database layer to eliminate concurrency exploits."
        }
      }
    ]
  },
  "contact": {
    "label": "Get In Touch",
    "title": "Let's work <span class=\"gradient-text\">together</span>",
    "description": "Have an interesting project, job opportunity, or just want to chat? Shoot me an email or find me on LinkedIn!",
    "email": "ahmadmrza0404@gmail.com",
    "linkedin": "linkedin.com/in/ahmad-mirza-0b606b278",
    "location": "Malaysia (Open to Remote)"
  },
  "footer": {
    "copyright": "Ahmad Mirza",
    "year": 2026
  }
},

  // ==========================================
  // METHODS
  // ==========================================

  /**
   * Load all content from localStorage, merging with defaults.
   */
  load() {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Deep merge with defaults to ensure all keys exist
        return this.deepMerge(this.clone(this.defaults), parsed);
      }
    } catch (e) {
      console.warn('ContentManager: Failed to load from localStorage, using defaults.', e);
    }
    return this.clone(this.defaults);
  },

  /**
   * Save full content object to localStorage.
   */
  save(content) {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(content));
      return true;
    } catch (e) {
      console.error('ContentManager: Failed to save to localStorage.', e);
      return false;
    }
  },

  /**
   * Reset all content back to defaults.
   */
  reset() {
    localStorage.removeItem(this.STORAGE_KEY);
    return this.clone(this.defaults);
  },

  /**
   * Get a specific section from content.
   */
  getSection(content, section) {
    return content[section] || this.defaults[section] || {};
  },

  /**
   * Deep merge two objects (source overrides defaults).
   */
  deepMerge(defaults, overrides) {
    const result = this.clone(defaults);
    for (const key in overrides) {
      if (overrides[key] && typeof overrides[key] === 'object' && !Array.isArray(overrides[key])) {
        result[key] = this.deepMerge(result[key] || {}, overrides[key]);
      } else {
        result[key] = overrides[key];
      }
    }
    return result;
  },

  /**
   * Simple deep clone.
   */
  clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  },
};

// Export for use in both module and non-module contexts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ContentManager;
}
