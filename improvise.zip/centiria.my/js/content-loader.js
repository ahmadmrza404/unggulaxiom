/**
 * content-loader.js — Dynamic Content Loader for Portfolio
 *
 * Loads content from ContentManager (localStorage) and updates the DOM.
 * Falls back to static HTML if no stored content exists.
 *
 * IMPORTANT: Runs synchronously (immediately) since it's placed at the
 * end of <body>. This ensures the DOM is updated BEFORE main.js (ES module)
 * initializes interactive features like scroll-reveal and filter listeners.
 */

(function () {
  'use strict';

  var content = ContentManager.load();

  function applyContent() {
    // ==========================================
    // HERO SECTION
    // ==========================================
    var h = content.hero;

    // Badge
    var badge = document.querySelector('.hero-badge');
    if (badge && h.badge) {
      badge.textContent = h.badge;
    }

    // Hero title - replace the gradient text span content
    var titleSpan = document.querySelector('.hero-title .gradient-text');
    if (titleSpan) {
      // Extract name from "Hi, I'm <span>Name</span>"
      var match = h.title ? h.title.match(/<span[^>]*>([^<]+)<\/span>/) : null;
      if (match) {
        titleSpan.textContent = match[1];
      }
    }

    // Hero subtitle
    var subtitle = document.querySelector('.hero-subtitle');
    if (subtitle && h.subtitle) {
      subtitle.textContent = h.subtitle;
    }

    // Typewriter roles - update if injected later
    var typewriterEl = document.getElementById('typewriter');
    if (typewriterEl && h.typewriterRoles && h.typewriterRoles.length > 0) {
      // Store roles as data attribute for the typewriter module
      typewriterEl.dataset.roles = JSON.stringify(h.typewriterRoles);
    }

    // Hero social links
    if (h.socialLinks) {
      var heroSocials = document.querySelectorAll('.hero-socials a');
      if (heroSocials[0] && h.socialLinks.github) heroSocials[0].href = h.socialLinks.github;
      if (heroSocials[1] && h.socialLinks.linkedin) heroSocials[1].href = h.socialLinks.linkedin;
    }

    // ==========================================
    // ABOUT SECTION
    // ==========================================
    var a = content.about;

    // Section label
    var aboutLabel = document.querySelector('#about .section-label');
    if (aboutLabel && a.label) {
      aboutLabel.textContent = a.label;
    }

    // Section title
    var aboutTitle = document.querySelector('#about .section-title');
    if (aboutTitle && a.title) {
      aboutTitle.innerHTML = a.title;
    }

    // Paragraphs - dynamically create more if admin added extras
    var aboutText = document.querySelector('.about-text');
    var aboutParagraphs = document.querySelectorAll('.about-paragraph');
    if (a.paragraphs && a.paragraphs.length > 0) {
      // First, populate existing paragraph elements
      aboutParagraphs.forEach(function (p, idx) {
        if (idx < a.paragraphs.length) {
          p.textContent = a.paragraphs[idx];
          p.style.display = '';
        }
      });
      // Hide extra static paragraphs if we have fewer from admin
      for (var i = a.paragraphs.length; i < aboutParagraphs.length; i++) {
        aboutParagraphs[i].style.display = 'none';
      }
      // Create new paragraph elements if admin has more than static HTML
      if (a.paragraphs.length > aboutParagraphs.length && aboutText) {
        // Find the about-stats element to insert before it
        var aboutStatsEl = aboutText.querySelector('.about-stats');
        for (var j = aboutParagraphs.length; j < a.paragraphs.length; j++) {
          var newP = document.createElement('p');
          newP.className = 'about-paragraph';
          newP.textContent = a.paragraphs[j];
          if (aboutStatsEl) {
            aboutText.insertBefore(newP, aboutStatsEl);
          } else {
            aboutText.appendChild(newP);
          }
        }
      }
    }

    // Stats
    var statEls = document.querySelectorAll('.stat');
    if (a.stats && a.stats.length > 0) {
      statEls.forEach(function (stat, idx) {
        if (idx < a.stats.length) {
          var numEl = stat.querySelector('.stat-number');
          var labelEl = stat.querySelector('.stat-label');
          if (numEl) numEl.dataset.target = a.stats[idx].target;
          if (labelEl) labelEl.textContent = a.stats[idx].label;
        }
      });
    }

    // ==========================================
    // EXPERIENCE SECTION
    // ==========================================
    var e = content.experience;

    var expLabel = document.querySelector('#experience .section-label');
    if (expLabel && e.label) {
      expLabel.textContent = e.label;
    }

    var expTitle = document.querySelector('#experience .section-title');
    if (expTitle && e.title) {
      expTitle.innerHTML = e.title;
    }

    // Timeline items - regenerate from content
    var timeline = document.querySelector('.timeline');
    if (timeline && e.items && e.items.length > 0) {
      // Keep the timeline-line
      var timelineLine = timeline.querySelector('.timeline-line');
      timeline.innerHTML = '';
      if (timelineLine) timeline.appendChild(timelineLine);

      e.items.forEach(function (item, idx) {
              var div = document.createElement('div');
              div.className = 'timeline-item ' + (item.side || 'left') + ' reveal';

              var dotIcon = 'fas fa-briefcase';
              if (item.company && item.company.toLowerCase().indexOf('universiti') > -1) dotIcon = 'fas fa-graduation-cap';

        var bulletsHTML = '';
        if (item.bullets && item.bullets.length > 0) {
          bulletsHTML = '<ul class="timeline-bullets">' +
            item.bullets.map(function (b) { return '<li>' + escapeHtml(b) + '</li>'; }).join('') +
            '</ul>';
        }

        var tagsHTML = '';
        if (item.tags && item.tags.length > 0) {
          tagsHTML = '<div class="timeline-tags">' +
            item.tags.map(function (t) { return '<span>' + escapeHtml(t) + '</span>'; }).join('') +
            '</div>';
        }

        div.innerHTML =
          '<div class="timeline-dot"><i class="' + dotIcon + '"></i></div>' +
          '<div class="timeline-content glass-panel">' +
          '  <span class="timeline-date">' + escapeHtml(item.date || '') + '</span>' +
          '  <h3>' + escapeHtml(item.role || '') + '</h3>' +
          '  <span class="timeline-company">' + escapeHtml(item.company || '') + '</span>' +
          '  <p>' + escapeHtml(item.description || '') + '</p>' +
          bulletsHTML +
          tagsHTML +
          '</div>';

        timeline.appendChild(div);
      });
    }

    // ==========================================
    // SKILLS SECTION
    // ==========================================
    var s = content.skills;

    var skillsLabel = document.querySelector('#skills .section-label');
    if (skillsLabel && s.label) {
      skillsLabel.textContent = s.label;
    }

    var skillsTitle = document.querySelector('#skills .section-title');
    if (skillsTitle && s.title) {
      skillsTitle.innerHTML = s.title;
    }

    // Skills grid - regenerate
    var skillsGrid = document.getElementById('skillsGrid');
    if (skillsGrid && s.items && s.items.length > 0) {
      skillsGrid.innerHTML = '';
      s.items.forEach(function (item) {
        var card = document.createElement('div');
        card.className = 'skill-card glass-panel reveal';
        card.dataset.category = item.category || 'frontend';
        card.style.setProperty('--brand-color', item.brandColor || 'var(--brand-react)');
        card.innerHTML =
          '<div class="skill-icon"><i class="' + (item.icon || 'fas fa-code') + '"></i></div>' +
          '<h3>' + escapeHtml(item.title || '') + '</h3>' +
          '<p class="skill-desc">' + escapeHtml(item.desc || '') + '</p>';
        skillsGrid.appendChild(card);
      });
    }

    // ==========================================
    // PROJECTS SECTION
    // ==========================================
    var p = content.projects;

    var projLabel = document.querySelector('#projects .section-label');
    if (projLabel && p.label) {
      projLabel.textContent = p.label;
    }

    var projTitle = document.querySelector('#projects .section-title');
    if (projTitle && p.title) {
      projTitle.innerHTML = p.title;
    }

    // Projects grid - regenerate
    var projectsGrid = document.getElementById('projectsGrid');
    if (projectsGrid && p.items && p.items.length > 0) {
      projectsGrid.innerHTML = '';
      p.items.forEach(function (item, idx) {
        var card = document.createElement('div');
        card.className = 'project-card glass-panel reveal';
        card.dataset.category = item.category || 'fullstack';

        var tagsHTML = '';
        if (item.tags && item.tags.length > 0) {
          tagsHTML = item.tags.map(function (t) { return '<span>' + escapeHtml(t) + '</span>'; }).join('');
        }

        var detailsKey = item.detailsKey || ('project-' + idx);

        card.innerHTML =
          '<div class="project-image" style="background: ' + (item.gradient || 'linear-gradient(135deg, #667eea, #764ba2)') + ';">' +
          '  <i class="' + (item.icon || 'fas fa-code') + '"></i>' +
          '</div>' +
          '<div class="project-info">' +
          '  <div class="project-tags">' + tagsHTML + '</div>' +
          '  <h3>' + escapeHtml(item.title || '') + '</h3>' +
          '  <p>' + escapeHtml(item.description || '') + '</p>' +
          '  <div class="project-action-links">' +
          '    <button class="project-details-btn btn btn-outline" data-project="' + detailsKey + '"><i class="fas fa-info-circle"></i> Details</button>' +
          '    <div class="project-links">' +
          '      <a href="' + escapeHtml(item.githubLink || '#') + '" class="project-link" aria-label="Github"><i class="fab fa-github"></i></a>' +
          '      <a href="' + escapeHtml(item.demoLink || '#') + '" class="project-link" aria-label="Live Demo"><i class="fas fa-external-link-alt"></i></a>' +
          '    </div>' +
          '  </div>' +
          '</div>';

        projectsGrid.appendChild(card);
      });
    }

    // ==========================================
    // PROJECT MODAL DATA
    // ==========================================
    // Store project details on window for modal to access
    if (p.details) {
      window._projectDetails = p.details;
    }

    // ==========================================
    // CASE STUDIES SECTION
    // ==========================================
    var cs = content.caseStudies;
    if (cs) {
      var csLabel = document.querySelector('#case-studies .section-label');
      if (csLabel && cs.label) {
        csLabel.textContent = cs.label;
      }

      var csTitle = document.querySelector('#case-studies .section-title');
      if (csTitle && cs.title) {
        csTitle.innerHTML = cs.title;
      }

      var caseStudiesGrid = document.getElementById('caseStudiesGrid');
      if (caseStudiesGrid && cs.items && cs.items.length > 0) {
        caseStudiesGrid.innerHTML = '';
        cs.items.forEach(function (item) {
          var card = document.createElement('div');
          card.className = 'case-study-card glass-panel reveal';
          card.style.setProperty('--brand-color', item.brandColor || 'var(--accent-1)');

          var metricsHTML = '';
          if (item.metrics && item.metrics.length > 0) {
            metricsHTML = '<div class="case-study-metrics">' +
              item.metrics.map(function (m) {
                return '<div class="metric-box">' +
                  '  <div class="metric-value">' + escapeHtml(m.value) + '</div>' +
                  '  <div class="metric-label">' + escapeHtml(m.label) + '</div>' +
                  '</div>';
              }).join('') +
              '</div>';
          }

          card.innerHTML =
            '<div class="case-study-header">' +
            '  <span class="case-study-badge" style="background: ' + (item.brandColor || 'var(--accent-1)') + ';">' + escapeHtml(item.badge || '') + '</span>' +
            '  <h3>' + escapeHtml(item.title || '') + '</h3>' +
            '  <p class="case-study-subtitle">' + escapeHtml(item.subtitle || '') + '</p>' +
            '</div>' +
            metricsHTML +
            '<div class="case-study-tabs">' +
            '  <button class="case-tab-btn active" data-tab="challenge" data-case="' + escapeHtml(item.id) + '">Challenge</button>' +
            '  <button class="case-tab-btn" data-tab="solution" data-case="' + escapeHtml(item.id) + '">Solution</button>' +
            '  <button class="case-tab-btn" data-tab="impact" data-case="' + escapeHtml(item.id) + '">Impact</button>' +
            '  <button class="case-tab-btn" data-tab="takeaway" data-case="' + escapeHtml(item.id) + '">Takeaway</button>' +
            '</div>' +
            '<div class="case-study-content">' +
            '  <div class="case-panel active" data-panel="challenge" data-case="' + escapeHtml(item.id) + '">' +
            '    <p>' + escapeHtml(item.challenge || '') + '</p>' +
            '  </div>' +
            '  <div class="case-panel" data-panel="solution" data-case="' + escapeHtml(item.id) + '">' +
            '    <p>' + escapeHtml(item.solution || '') + '</p>' +
            '  </div>' +
            '  <div class="case-panel" data-panel="impact" data-case="' + escapeHtml(item.id) + '">' +
            '    <p>' + escapeHtml(item.impact || '') + '</p>' +
            '  </div>' +
            '  <div class="case-panel" data-panel="takeaway" data-case="' + escapeHtml(item.id) + '">' +
            '    <div class="takeaway-wrapper">' +
            '      <div class="takeaway-header">' +
            '        <span><i class="fas fa-lightbulb"></i> Key Takeaway</span>' +
            '      </div>' +
            '      <div class="takeaway-body">' +
            '        <h4>' + escapeHtml(item.takeaway ? item.takeaway.title : '') + '</h4>' +
            '        <p>' + escapeHtml(item.takeaway ? item.takeaway.text : '') + '</p>' +
            '        <div class="takeaway-lesson">' +
            '          <strong>Core Principle:</strong> ' + escapeHtml(item.takeaway ? item.takeaway.lesson : '') +
            '        </div>' +
            '      </div>' +
            '    </div>' +
            '  </div>' +
            '</div>';

          caseStudiesGrid.appendChild(card);
        });
      }
    }

    // ==========================================
    // CONTACT SECTION
    // ==========================================
    var c = content.contact;

    var contactLabel = document.querySelector('#contact .section-label');
    if (contactLabel && c.label) {
      contactLabel.textContent = c.label;
    }

    var contactTitle = document.querySelector('#contact .section-title');
    if (contactTitle && c.title) {
      contactTitle.innerHTML = c.title;
    }

    var contactDesc = document.querySelector('.contact-card-desc');
    if (contactDesc && c.description) {
      contactDesc.textContent = c.description;
    }

    // Contact info cards
    var infoCardTexts = document.querySelectorAll('.info-card-text p');
    if (infoCardTexts.length >= 3) {
      if (c.email) infoCardTexts[0].textContent = c.email;
      if (c.linkedin) infoCardTexts[1].textContent = c.linkedin;
      if (c.location) infoCardTexts[2].textContent = c.location;
    }

    // ==========================================
    // FOOTER
    // ==========================================
    var f = content.footer;
    var footerP = document.querySelector('.footer-content p');
    if (footerP && f.copyright) {
      var year = f.year || new Date().getFullYear();
      footerP.innerHTML = '&copy; <span id="footerYear">' + year + '</span> ' + escapeHtml(f.copyright) + '. Built with <i class="fas fa-heart" style="color: #f5576c;"></i>';
    }

    // Footer social links
    var heroContent = content.hero;
    if (heroContent && heroContent.socialLinks) {
      var footerSocials = document.querySelectorAll('.footer-links a');
      if (footerSocials[0] && heroContent.socialLinks.github) footerSocials[0].href = heroContent.socialLinks.github;
      if (footerSocials[1] && heroContent.socialLinks.linkedin) footerSocials[1].href = heroContent.socialLinks.linkedin;
    }
  }

  // ==========================================
  // HELPER: escape HTML
  // ==========================================
  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  // ==========================================
  // Run synchronously — IMPORTANT: must run BEFORE main.js (ES module)
  // This script is at the end of <body>, so all DOM elements are available.
  // ==========================================
  applyContent();

  // Also expose run function for re-use (e.g., after admin import)
  window.reloadContent = applyContent;

})();
