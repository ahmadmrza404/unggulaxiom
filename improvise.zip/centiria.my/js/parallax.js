/**
 * Subtle hero parallax — background position shifts with mouse.
 * Throttled and scoped to only run when hero is in viewport.
 */
export function initParallax() {
  const hero = document.querySelector('.hero');
  if (!hero) return;

  let ticking = false;

  window.addEventListener('mousemove', e => {
    if (ticking) return;
    ticking = true;

    requestAnimationFrame(() => {
      // Only process if hero is in or near the viewport
      const rect = hero.getBoundingClientRect();
      if (rect.bottom > 0 && rect.top < window.innerHeight) {
        const x = (e.clientX / window.innerWidth - 0.5) * 20;
        const y = (e.clientY / window.innerHeight - 0.5) * 20;
        hero.style.backgroundPosition = `${50 + x}% ${50 + y}%`;
      }
      ticking = false;
    });
  });
}
