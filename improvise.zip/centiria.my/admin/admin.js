/**
 * admin.js — Portfolio Admin Console Controller (Upgraded UI/UX Edition)
 * 
 * Handles client-side SHA-256 login, sidebar navigation, dynamic card reordering/collapsing,
 * live icon previews, and content-config.js generation.
 */

(function () {
  'use strict';

  // ==========================================
  // CONFIG & STATE
  // ==========================================
  const SECURE_USER = 'mirza';
  // SHA-256 hash of "396500"
  const SECURE_PASS_HASH = '1ac9f4d536cfe2a9a2010ba37a8b9682cae1c7b33449464149360ef5c12a9d9d';
  
  let currentContent = {};

  // ==========================================
  // SHA-256 CRYPTO HELPER
  // ==========================================
  async function computeSHA256(str) {
    const buffer = new TextEncoder().encode(str);
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  // ==========================================
  // TOAST NOTIFICATIONS
  // ==========================================
  function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    const item = document.createElement('div');
    item.className = `toast-item ${type}`;
    let icon = '<i class="fas fa-check-circle"></i>';
    if (type === 'info') icon = '<i class="fas fa-info-circle"></i>';
    if (type === 'error') icon = '<i class="fas fa-exclamation-triangle"></i>';
    
    item.innerHTML = `${icon} <span>${message}</span>`;
    container.appendChild(item);
    
    setTimeout(() => {
      item.classList.add('fade-out');
      item.addEventListener('animationend', () => {
        item.remove();
      });
    }, 3200);
  }

  // ==========================================
  // AUTHENTICATION GUARD
  // ==========================================
  const loginOverlay = document.getElementById('loginOverlay');
  const loginForm = document.getElementById('loginForm');
  const btnLogout = document.getElementById('btnLogout');

  function checkSession() {
    if (sessionStorage.getItem('portfolio_admin_auth') === 'true') {
      loginOverlay.classList.add('hidden');
    } else {
      loginOverlay.classList.remove('hidden');
    }
  }

  const loginBootLog = document.getElementById('loginBootLog');
  function addBootLine(text, delay = 0) {
    return new Promise(resolve => {
      setTimeout(() => {
        if (loginBootLog) {
          const line = document.createElement('div');
          line.className = 'boot-line';
          line.textContent = `> ${text}`;
          loginBootLog.appendChild(line);
          loginBootLog.scrollTop = loginBootLog.scrollHeight;
        }
        resolve();
      }, delay);
    });
  }

  if (loginForm) {
    // Password Toggle Button
    const btnTogglePassword = document.getElementById('btnTogglePassword');
    const passwordInputEl = document.getElementById('password');
    if (btnTogglePassword && passwordInputEl) {
      btnTogglePassword.addEventListener('click', () => {
        const type = passwordInputEl.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInputEl.setAttribute('type', type);
        const icon = btnTogglePassword.querySelector('i');
        if (icon) {
          icon.className = type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
        }
      });
    }

    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const usernameInput = document.getElementById('username').value.trim();
      const passwordInput = passwordInputEl.value.trim();
      
      if (loginBootLog) loginBootLog.innerHTML = '';
      await addBootLine('INITIATING AUTHENTICATION MODULE...', 40);
      await addBootLine('CONNECTING TO LOCALPORT ENCRYPTOR...', 100);
      
      const passHash = await computeSHA256(passwordInput);
      
      await addBootLine(`VAL_USER: "${usernameInput}"`, 60);
      await addBootLine('COMPUTING HASH SIGNATURE...', 100);
      
      if (usernameInput === SECURE_USER && passHash === SECURE_PASS_HASH) {
        await addBootLine('SIG MATCH DETECTED.', 60);
        await addBootLine('DECRYPTING SYSTEM CONTAINER...', 100);
        await addBootLine('BOOT COMPLETE! REDIRECTING TO DASHBOARD.', 60);
        
        setTimeout(() => {
          sessionStorage.setItem('portfolio_admin_auth', 'true');
          loginOverlay.classList.add('hidden');
          showToast('Authentication Successful!', 'success');
          loadDashboardContent();
        }, 150);
      } else {
        await addBootLine('ERROR: DECRYPTION SIGNATURE MISMATCH.', 80);
        await addBootLine('ACCESS DENIED.', 40);
        showToast('Invalid Username or Password!', 'error');
      }
    });
  }

  if (btnLogout) {
    btnLogout.addEventListener('click', () => {
      sessionStorage.removeItem('portfolio_admin_auth');
      checkSession();
      showToast('Logged out successfully.', 'info');
    });
  }

  // Check login on load
  checkSession();

  // ==========================================
  // NAVIGATION: PRIMARY TABS & SIDEBAR SUB-TABS
  // ==========================================
  const tabBtns = document.querySelectorAll('.admin-tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetPanel = btn.getAttribute('data-target-panel');
      
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      if (targetPanel === 'jsonPanel') {
        const formData = gatherFormData();
        document.getElementById('jsonTextarea').value = JSON.stringify(formData, null, 2);
      } else {
        const jsonText = document.getElementById('jsonTextarea').value;
        try {
          const parsed = JSON.parse(jsonText);
          currentContent = parsed;
          mapContentToForm(parsed);
          updateSidebarCounts();
        } catch (e) {
          showToast('Warning: Invalid JSON in textarea! Fix it before switching tabs.', 'error');
          tabBtns.forEach(b => b.classList.remove('active'));
          document.querySelector('[data-target-panel="jsonPanel"]').classList.add('active');
          return;
        }
      }
      
      tabPanels.forEach(p => p.classList.remove('active'));
      document.getElementById(targetPanel).classList.add('active');
    });
  });

  // Sidebar Form Sections Sub-Tabs
  const sidebarBtns = document.querySelectorAll('.sidebar-nav-btn');
  const sectionPanels = document.querySelectorAll('.form-section-panel');

  sidebarBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetSection = btn.getAttribute('data-target-section');

      sidebarBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      sectionPanels.forEach(p => p.classList.remove('active'));
      document.getElementById(targetSection).classList.add('active');

      // Scroll form area to top smoothly on section switch
      document.querySelector('.form-content-area').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
  });

  // ==========================================
  // THEME TOGGLE LISTENER
  // ==========================================
  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'dark';
      const next = current === 'light' ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('theme', next);
    });
  }

  // ==========================================
  // FORM BINDINGS & COMPONENT RENDERERS
  // ==========================================
  
  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function loadDashboardContent() {
    currentContent = ContentManager.load();
    mapContentToForm(currentContent);
    document.getElementById('jsonTextarea').value = JSON.stringify(currentContent, null, 2);
    updateSidebarCounts();
  }

  // ---- Map Content JSON to Visual Inputs ----
  function mapContentToForm(c) {
    if (!c) return;

    // Hero
    document.getElementById('heroBadge').value = c.hero.badge || '';
    document.getElementById('heroTitle').value = c.hero.title || '';
    document.getElementById('heroSubtitle').value = c.hero.subtitle || '';
    document.getElementById('heroGithub').value = c.hero.socialLinks?.github || '';
    document.getElementById('heroLinkedin').value = c.hero.socialLinks?.linkedin || '';
    
    renderStringArrayBuilder('typewriterListContainer', c.hero.typewriterRoles || [], 'Add Role');

    // About
    document.getElementById('aboutLabel').value = c.about.label || '';
    document.getElementById('aboutTitle').value = c.about.title || '';
    renderStringArrayBuilder('aboutParagraphsContainer', c.about.paragraphs || [], 'Add Biography Paragraph');
    renderStatsBuilder(c.about.stats || []);

    // Experience timeline
    renderExperienceBuilder(c.experience.items || []);
    document.getElementById('expLabel').value = c.experience.label || '';
    document.getElementById('expTitle').value = c.experience.title || '';

    // Skills
    renderSkillsBuilder(c.skills.items || []);
    document.getElementById('skillsLabel').value = c.skills.label || '';
    document.getElementById('skillsTitle').value = c.skills.title || '';

    // Projects
    renderProjectsBuilder(c.projects.items || [], c.projects.details || {});
    document.getElementById('projectsLabel').value = c.projects.label || '';
    document.getElementById('projectsTitle').value = c.projects.title || '';

    // Case Studies
    renderCaseStudiesBuilder(c.caseStudies?.items || []);
    document.getElementById('csLabel').value = c.caseStudies?.label || '';
    document.getElementById('csTitle').value = c.caseStudies?.title || '';

    // Contact
    document.getElementById('contactLabel').value = c.contact.label || '';
    document.getElementById('contactTitle').value = c.contact.title || '';
    document.getElementById('contactDesc').value = c.contact.description || '';
    document.getElementById('contactEmail').value = c.contact.email || '';
    document.getElementById('contactLinkedin').value = c.contact.linkedin || '';
    document.getElementById('contactLocation').value = c.contact.location || '';

    // Footer
    document.getElementById('footerCopyright').value = c.footer.copyright || '';
    document.getElementById('footerYearField').value = c.footer.year || new Date().getFullYear();
  }

  // ---- Shared Helper for dynamic List of plain Strings ----
  function renderStringArrayBuilder(containerId, items, addLabel) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = '';

    items.forEach(item => {
      const row = document.createElement('div');
      row.className = 'item-row';
      row.innerHTML = `
        <input type="text" class="form-control string-array-input" value="${escapeHtml(item)}" required />
        <button type="button" class="btn-remove remove-string-item"><i class="fas fa-trash-alt"></i></button>
      `;
      container.appendChild(row);
      row.querySelector('.remove-string-item').addEventListener('click', () => row.remove());
    });

    const addBtn = document.createElement('button');
    addBtn.type = 'button';
    addBtn.className = 'btn-add';
    addBtn.innerHTML = `<i class="fas fa-plus"></i> ${addLabel}`;
    addBtn.addEventListener('click', () => {
      const row = document.createElement('div');
      row.className = 'item-row';
      row.innerHTML = `
        <input type="text" class="form-control string-array-input" value="" required />
        <button type="button" class="btn-remove remove-string-item"><i class="fas fa-trash-alt"></i></button>
      `;
      container.insertBefore(row, addBtn);
      row.querySelector('.remove-string-item').addEventListener('click', () => row.remove());
    });
    container.appendChild(addBtn);
  }

  // ---- About Stats Editor ----
  function renderStatsBuilder(stats) {
    const container = document.getElementById('aboutStatsContainer');
    if (!container) return;
    container.innerHTML = '';

    stats.forEach(stat => {
      const row = document.createElement('div');
      row.className = 'item-row';
      row.innerHTML = `
        <input type="text" class="form-control stat-label-input" placeholder="Label..." value="${escapeHtml(stat.label)}" required style="flex: 2;" />
        <input type="number" class="form-control stat-target-input" placeholder="Value..." value="${stat.target}" required style="flex: 1;" />
        <button type="button" class="btn-remove remove-stat-item"><i class="fas fa-trash-alt"></i></button>
      `;
      container.appendChild(row);
      row.querySelector('.remove-stat-item').addEventListener('click', () => row.remove());
    });

    const addBtn = document.createElement('button');
    addBtn.type = 'button';
    addBtn.className = 'btn-add';
    addBtn.innerHTML = '<i class="fas fa-plus"></i> Add Stat';
    addBtn.addEventListener('click', () => {
      const row = document.createElement('div');
      row.className = 'item-row';
      row.innerHTML = `
        <input type="text" class="form-control stat-label-input" placeholder="Label..." value="" required style="flex: 2;" />
        <input type="number" class="form-control stat-target-input" placeholder="Value..." value="0" required style="flex: 1;" />
        <button type="button" class="btn-remove remove-stat-item"><i class="fas fa-trash-alt"></i></button>
      `;
      container.insertBefore(row, addBtn);
      row.querySelector('.remove-stat-item').addEventListener('click', () => row.remove());
    });
    container.appendChild(addBtn);
  }

  // ==========================================
  // REORDERING & COLLAPSIBILITY CORE CONTROLLERS
  // ==========================================
  
  function updateSidebarCounts() {
    const expCount = document.querySelectorAll('#experienceItemsContainer .exp-card').length;
    const skillCount = document.querySelectorAll('#skillsItemsContainer .skill-card-builder').length;
    const projCount = document.querySelectorAll('#projectsItemsContainer .project-card-builder').length;
    const csCount = document.querySelectorAll('#caseStudiesItemsContainer .cs-card-builder').length;

    const expBadge = document.getElementById('badge-experience');
    const skillBadge = document.getElementById('badge-skills');
    const projBadge = document.getElementById('badge-projects');
    const csBadge = document.getElementById('badge-case-studies');

    if (expBadge) expBadge.textContent = expCount;
    if (skillBadge) skillBadge.textContent = skillCount;
    if (projBadge) projBadge.textContent = projCount;
    if (csBadge) csBadge.textContent = csCount;
  }

  function triggerSwapPulse(card) {
    card.classList.remove('pulse-reordered');
    void card.offsetWidth; // Trigger reflow
    card.classList.add('pulse-reordered');
    card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    setTimeout(() => {
      card.classList.remove('pulse-reordered');
    }, 850);
  }

  function attachCardHeaderControllers(card) {
    const header = card.querySelector('.card-header-bar');
    
    // Toggle Collapse on Header Click
    header.addEventListener('click', (e) => {
      // Ignore click if user clicks direct action buttons inside header
      if (e.target.closest('.btn-micro-action')) return;
      card.classList.toggle('collapsed');
    });

    // Expand/Collapse Button
    card.querySelector('.btn-collapse')?.addEventListener('click', () => {
      card.classList.toggle('collapsed');
    });

    // Move Up
    card.querySelector('.btn-reorder-up')?.addEventListener('click', () => {
      const prev = card.previousElementSibling;
      if (prev && prev.classList.contains('object-card-item')) {
        card.parentNode.insertBefore(card, prev);
        triggerSwapPulse(card);
        showToast('Item moved up.', 'info');
      }
    });

    // Move Down
    card.querySelector('.btn-reorder-down')?.addEventListener('click', () => {
      const next = card.nextElementSibling;
      if (next && next.classList.contains('object-card-item')) {
        // insertAfter helper logic: insert card after the next card
        card.parentNode.insertBefore(card, next.nextSibling);
        triggerSwapPulse(card);
        showToast('Item moved down.', 'info');
      }
    });
  }

  // ==========================================
  // DYNAMIC COMPONENT BUILDERS
  // ==========================================

  // ---- Experience (Timeline) Builder ----
  function renderExperienceBuilder(items) {
    const container = document.getElementById('experienceItemsContainer');
    if (!container) return;
    container.innerHTML = '';

    items.forEach((item, idx) => {
      addExperienceCard(container, item, idx > 0); // Collapse all but the first card by default
    });
  }

  function addExperienceCard(container, item = {}, collapsed = false) {
    const card = document.createElement('div');
    card.className = `object-card-item exp-card ${collapsed ? 'collapsed' : ''}`;
    
    const bulletsText = (item.bullets || []).join('\n');
    const tagsText = (item.tags || []).join(', ');

    const roleName = item.role || 'New Timeline Event';
    const compName = item.company ? ` at ${item.company}` : '';
    const initialTitle = `${roleName}${compName}`;

    card.innerHTML = `
      <div class="card-header-bar">
        <div class="card-title-info">
          <span class="live-preview-icon"><i class="fas fa-briefcase"></i></span>
          <span class="card-title-text">${escapeHtml(initialTitle)}</span>
        </div>
        <div class="card-action-btns">
          <button type="button" class="btn-micro-action btn-reorder-up" title="Move Up"><i class="fas fa-arrow-up"></i></button>
          <button type="button" class="btn-micro-action btn-reorder-down" title="Move Down"><i class="fas fa-arrow-down"></i></button>
          <button type="button" class="btn-micro-action btn-collapse" title="Collapse/Expand"><i class="fas fa-chevron-down"></i></button>
          <button type="button" class="btn-micro-action btn-card-delete remove-exp-card" title="Delete"><i class="fas fa-trash-alt"></i></button>
        </div>
      </div>
      <div class="card-body-content">
        <div class="card-editor-layout">
          <!-- Fields Column -->
          <div class="card-fields-pane">
            <div class="form-grid">
              <div class="form-group">
                <label>Position Side</label>
                <select class="form-control exp-side">
                  <option value="left" ${item.side === 'left' ? 'selected' : ''}>Left Side (Typical Jobs)</option>
                  <option value="right" ${item.side === 'right' ? 'selected' : ''}>Right Side (Typical Education)</option>
                </select>
              </div>
              <div class="form-group">
                <label>Date Period</label>
                <input type="text" class="form-control exp-date" placeholder="e.g. Feb 2022 - Jun 2025" value="${escapeHtml(item.date)}" required />
              </div>
              <div class="form-group">
                <label>Role/Title</label>
                <input type="text" class="form-control exp-role" placeholder="e.g. Software Engineer" value="${escapeHtml(item.role)}" required />
              </div>
              <div class="form-group">
                <label>Company/Institution</label>
                <input type="text" class="form-control exp-company" placeholder="e.g. Acme Corp" value="${escapeHtml(item.company)}" required />
              </div>
              <div class="form-group full-width">
                <label>Summary Description</label>
                <textarea class="form-control exp-desc" placeholder="Brief summary of duties..." required>${escapeHtml(item.description)}</textarea>
              </div>
              <div class="form-group">
                <label>Key Achievements (One per line)</label>
                <textarea class="form-control exp-bullets" placeholder="Enter key metrics, achievements..." rows="4">${escapeHtml(bulletsText)}</textarea>
              </div>
              <div class="form-group">
                <label>Technologies Tags (Comma-separated)</label>
                <input type="text" class="form-control exp-tags" placeholder="React, Node.js, REST" value="${escapeHtml(tagsText)}" />
              </div>
            </div>
          </div>
          <!-- Live Preview Column -->
          <div class="card-preview-pane">
            <div class="card-preview-title"><i class="fas fa-eye"></i> Live Timeline Preview</div>
            <div class="card-preview-canvas">
              <div class="timeline-item ${item.side || 'left'}">
                <div class="timeline-content glass-panel" style="display: block; opacity: 1;">
                  <span class="timeline-date">${escapeHtml(item.date || '')}</span>
                  <h3>${escapeHtml(item.role || '')}</h3>
                  <span class="timeline-company">${escapeHtml(item.company || '')}</span>
                  <p class="timeline-desc-preview">${escapeHtml(item.description || '')}</p>
                  <ul class="timeline-bullets-preview">
                    ${(item.bullets || []).map(b => `<li>${escapeHtml(b)}</li>`).join('')}
                  </ul>
                  <div class="timeline-tags-preview">
                    ${(item.tags || []).map(t => `<span>${escapeHtml(t)}</span>`).join('')}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    container.appendChild(card);
    attachCardHeaderControllers(card);
    card.querySelector('.remove-exp-card').addEventListener('click', () => {
      card.remove();
      updateSidebarCounts();
    });

    // Real-time Preview bindings
    const sideSelect = card.querySelector('.exp-side');
    const dateInput = card.querySelector('.exp-date');
    const roleInput = card.querySelector('.exp-role');
    const companyInput = card.querySelector('.exp-company');
    const descInput = card.querySelector('.exp-desc');
    const bulletsInput = card.querySelector('.exp-bullets');
    const tagsInput = card.querySelector('.exp-tags');

    // Preview elements
    const previewWrapper = card.querySelector('.timeline-item');
    const previewDate = card.querySelector('.timeline-date');
    const previewRole = card.querySelector('.timeline-content h3');
    const previewCompany = card.querySelector('.timeline-company');
    const previewDesc = card.querySelector('.timeline-desc-preview');
    const previewBullets = card.querySelector('.timeline-bullets-preview');
    const previewTags = card.querySelector('.timeline-tags-preview');

    const titleText = card.querySelector('.card-title-text');
    const previewIcon = card.querySelector('.live-preview-icon');

    function updatePreview() {
      previewWrapper.className = `timeline-item ${sideSelect.value}`;
      previewDate.textContent = dateInput.value.trim() || 'Date Period';
      
      const roleVal = roleInput.value.trim() || 'New Timeline Event';
      const compVal = companyInput.value.trim();
      
      previewRole.textContent = roleVal;
      previewCompany.textContent = compVal || 'Company Name';
      previewDesc.textContent = descInput.value.trim() || 'Description details...';

      titleText.textContent = `${roleVal}${compVal ? ' at ' + compVal : ''}`;

      const query = compVal.toLowerCase();
      if (query.indexOf('universiti') > -1 || query.indexOf('college') > -1 || query.indexOf('school') > -1) {
        previewIcon.innerHTML = '<i class="fas fa-graduation-cap"></i>';
      } else {
        previewIcon.innerHTML = '<i class="fas fa-briefcase"></i>';
      }

      const bullets = bulletsInput.value.trim().split('\n').filter(b => b.trim() !== '');
      previewBullets.innerHTML = bullets.map(b => `<li>${escapeHtml(b)}</li>`).join('');

      const tags = tagsInput.value.split(',').map(t => t.trim()).filter(t => t !== '');
      previewTags.innerHTML = tags.map(t => `<span>${escapeHtml(t)}</span>`).join('');
    }

    sideSelect.addEventListener('change', updatePreview);
    dateInput.addEventListener('input', updatePreview);
    roleInput.addEventListener('input', updatePreview);
    companyInput.addEventListener('input', updatePreview);
    descInput.addEventListener('input', updatePreview);
    bulletsInput.addEventListener('input', updatePreview);
    tagsInput.addEventListener('input', updatePreview);
  }

  document.getElementById('btnAddExperience')?.addEventListener('click', () => {
    const container = document.getElementById('experienceItemsContainer');
    addExperienceCard(container, { side: 'left', date: '', role: '', company: '', description: '', bullets: [], tags: [] }, false);
    updateSidebarCounts();
    showToast('Empty timeline card added.', 'info');
  });  // ---- Skills Directory Builder ----
  function renderSkillsBuilder(items) {
    const container = document.getElementById('skillsItemsContainer');
    if (!container) return;
    container.innerHTML = '';

    items.forEach((item, idx) => {
      addSkillCard(container, item, idx > 0);
    });
  }

  function addSkillCard(container, item = {}, collapsed = false) {
    const card = document.createElement('div');
    card.className = `object-card-item skill-card-builder ${collapsed ? 'collapsed' : ''}`;

    const skillName = item.title || 'New Skill';

    card.innerHTML = `
      <div class="card-header-bar">
        <div class="card-title-info">
          <span class="live-preview-icon"><i class="${item.icon || 'fas fa-code'}"></i></span>
          <span class="card-title-text">${escapeHtml(skillName)}</span>
        </div>
        <div class="card-action-btns">
          <button type="button" class="btn-micro-action btn-reorder-up" title="Move Up"><i class="fas fa-arrow-up"></i></button>
          <button type="button" class="btn-micro-action btn-reorder-down" title="Move Down"><i class="fas fa-arrow-down"></i></button>
          <button type="button" class="btn-micro-action btn-collapse" title="Collapse/Expand"><i class="fas fa-chevron-down"></i></button>
          <button type="button" class="btn-micro-action btn-card-delete remove-skill-card" title="Delete"><i class="fas fa-trash-alt"></i></button>
        </div>
      </div>
      <div class="card-body-content">
        <div class="card-editor-layout">
          <!-- Fields Column -->
          <div class="card-fields-pane">
            <div class="form-grid">
              <div class="form-group">
                <label>Category Group</label>
                <select class="form-control skill-category">
                  <option value="frontend" ${item.category === 'frontend' ? 'selected' : ''}>Frontend</option>
                  <option value="backend" ${item.category === 'backend' ? 'selected' : ''}>Backend</option>
                  <option value="databases" ${item.category === 'databases' ? 'selected' : ''}>Databases</option>
                  <option value="devops" ${item.category === 'devops' ? 'selected' : ''}>DevOps</option>
                  <option value="security" ${item.category === 'security' ? 'selected' : ''}>Security</option>
                </select>
              </div>
              <div class="form-group">
                <label>FontAwesome Icon Class</label>
                <input type="text" class="form-control skill-icon" placeholder="e.g. fab fa-react" value="${escapeHtml(item.icon)}" required />
              </div>
              <div class="form-group">
                <label>Skill Name</label>
                <input type="text" class="form-control skill-title" placeholder="e.g. React" value="${escapeHtml(item.title)}" required />
              </div>
              <div class="form-group">
                <label>Accent Brand Color (Hex / CSS var)</label>
                <input type="text" class="form-control skill-brandColor" placeholder="e.g. var(--brand-react)" value="${escapeHtml(item.brandColor)}" required />
                <div class="preset-picker-group">
                  <button type="button" class="preset-btn skill-preset-btn" data-color="var(--accent-1)" style="border-color: var(--accent-1); color: var(--accent-1);"><i class="fas fa-palette"></i> Blue</button>
                  <button type="button" class="preset-btn skill-preset-btn" data-color="var(--accent-2)" style="border-color: var(--accent-2); color: var(--accent-2);"><i class="fas fa-palette"></i> Yellow</button>
                  <button type="button" class="preset-btn skill-preset-btn" data-color="var(--accent-3)" style="border-color: var(--accent-3); color: var(--accent-3);"><i class="fas fa-palette"></i> Pink</button>
                  <button type="button" class="preset-btn skill-preset-btn" data-color="var(--accent-4)" style="border-color: var(--accent-4); color: var(--accent-4);"><i class="fas fa-palette"></i> Green</button>
                  <button type="button" class="preset-btn skill-preset-btn" data-color="#06b6d4" style="border-color: #06b6d4; color: #06b6d4;"><i class="fab fa-react"></i> React</button>
                  <button type="button" class="preset-btn skill-preset-btn" data-color="#22c55e" style="border-color: #22c55e; color: #22c55e;"><i class="fab fa-node-js"></i> Node</button>
                  <button type="button" class="preset-btn skill-preset-btn" data-color="#f59e0b" style="border-color: #f59e0b; color: #f59e0b;"><i class="fas fa-lock"></i> Amber</button>
                </div>
              </div>
              <div class="form-group full-width">
                <label>Skill Description Details</label>
                <input type="text" class="form-control skill-desc" placeholder="Generics, hooks, performance details..." value="${escapeHtml(item.desc)}" required />
              </div>
            </div>
          </div>
          <!-- Live Preview Column -->
          <div class="card-preview-pane">
            <div class="card-preview-title"><i class="fas fa-eye"></i> Live Skill Card Preview</div>
            <div class="card-preview-canvas">
              <div class="skill-card glass-panel" style="--brand-color: ${item.brandColor || 'var(--brand-react)'};">
                <div class="skill-icon"><i class="${item.icon || 'fas fa-code'}"></i></div>
                <h3>${escapeHtml(item.title || 'React')}</h3>
                <p class="skill-desc">${escapeHtml(item.desc || 'Hook APIs and component optimization.')}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    container.appendChild(card);
    attachCardHeaderControllers(card);
    card.querySelector('.remove-skill-card').addEventListener('click', () => {
      card.remove();
      updateSidebarCounts();
    });

    // Real-time Preview bindings
    const iconInput = card.querySelector('.skill-icon');
    const titleInput = card.querySelector('.skill-title');
    const colorInput = card.querySelector('.skill-brandColor');
    const descInput = card.querySelector('.skill-desc');

    const previewCard = card.querySelector('.skill-card');
    const previewIcon = card.querySelector('.skill-icon i');
    const previewTitle = card.querySelector('.skill-card h3');
    const previewDesc = card.querySelector('.skill-card .skill-desc');
    const titleText = card.querySelector('.card-title-text');
    const headerIcon = card.querySelector('.live-preview-icon');

    function updatePreview() {
      const colorVal = colorInput.value.trim() || 'var(--brand-react)';
      const iconVal = iconInput.value.trim() || 'fas fa-code';
      const titleVal = titleInput.value.trim() || 'New Skill';
      const descVal = descInput.value.trim() || 'Skill description...';

      previewCard.style.setProperty('--brand-color', colorVal);
      previewIcon.className = iconVal;
      previewTitle.textContent = titleVal;
      previewDesc.textContent = descVal;

      titleText.textContent = titleVal;
      headerIcon.innerHTML = `<i class="${iconVal}"></i>`;
    }

    iconInput.addEventListener('input', updatePreview);
    titleInput.addEventListener('input', updatePreview);
    colorInput.addEventListener('input', updatePreview);
    descInput.addEventListener('input', updatePreview);

    // Preset Pickers logic
    card.querySelectorAll('.skill-preset-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const color = btn.getAttribute('data-color');
        colorInput.value = color;
        updatePreview();
        showToast(`Color preset applied!`, 'info');
      });
    });
  }

  document.getElementById('btnAddSkill')?.addEventListener('click', () => {
    const container = document.getElementById('skillsItemsContainer');
    addSkillCard(container, { category: 'frontend', icon: 'fas fa-code', title: '', brandColor: 'var(--accent-1)', desc: '' }, false);
    updateSidebarCounts();
    showToast('Empty skill card added.', 'info');
  });

  // ---- Featured Projects Builder ----
  function renderProjectsBuilder(items, detailsMap) {
    const container = document.getElementById('projectsItemsContainer');
    if (!container) return;
    container.innerHTML = '';

    items.forEach((item, idx) => {
      const dKey = item.detailsKey || '';
      const detail = detailsMap[dKey] || {};
      addProjectCard(container, item, detail, idx > 0);
    });
  }

  function addProjectCard(container, item = {}, detail = {}, collapsed = false) {
    const card = document.createElement('div');
    card.className = `object-card-item project-card-builder ${collapsed ? 'collapsed' : ''}`;
    
    const tagsText = (item.tags || []).join(', ');
    const detailBullets = (detail.bullets || []).join('\n');

    const projName = item.title || 'New Project';

    card.innerHTML = `
      <div class="card-header-bar">
        <div class="card-title-info">
          <span class="live-preview-icon"><i class="${item.icon || 'fas fa-folder'}"></i></span>
          <span class="card-title-text">${escapeHtml(projName)}</span>
        </div>
        <div class="card-action-btns">
          <button type="button" class="btn-micro-action btn-reorder-up" title="Move Up"><i class="fas fa-arrow-up"></i></button>
          <button type="button" class="btn-micro-action btn-reorder-down" title="Move Down"><i class="fas fa-arrow-down"></i></button>
          <button type="button" class="btn-micro-action btn-collapse" title="Collapse/Expand"><i class="fas fa-chevron-down"></i></button>
          <button type="button" class="btn-micro-action btn-card-delete remove-proj-card" title="Delete"><i class="fas fa-trash-alt"></i></button>
        </div>
      </div>
      <div class="card-body-content">
        <div class="card-editor-layout">
          <!-- Fields Column -->
          <div class="card-fields-pane">
            <div class="form-grid">
              <div class="form-group">
                <label>Grid Filter Category</label>
                <select class="form-control proj-category">
                  <option value="fullstack" ${item.category === 'fullstack' ? 'selected' : ''}>Full-Stack</option>
                  <option value="frontend" ${item.category === 'frontend' ? 'selected' : ''}>Frontend</option>
                  <option value="backend" ${item.category === 'backend' ? 'selected' : ''}>Backend</option>
                </select>
              </div>
              <div class="form-group">
                <label>Card Background Gradient</label>
                <input type="text" class="form-control proj-gradient" placeholder="e.g. linear-gradient(135deg, #119, #38e)" value="${escapeHtml(item.gradient)}" required />
                <div class="preset-picker-group">
                  <button type="button" class="preset-btn proj-preset-gradient-btn" data-gradient="linear-gradient(135deg, #3b82f6, #1d4ed8)" style="background: linear-gradient(135deg, #3b82f6, #1d4ed8); color: #fff;">Cobalt</button>
                  <button type="button" class="preset-btn proj-preset-gradient-btn" data-gradient="linear-gradient(135deg, #f472b6, #db2777)" style="background: linear-gradient(135deg, #f472b6, #db2777); color: #fff;">Coral</button>
                  <button type="button" class="preset-btn proj-preset-gradient-btn" data-gradient="linear-gradient(135deg, #4ade80, #047857)" style="background: linear-gradient(135deg, #4ade80, #047857); color: #fff;">Acid</button>
                  <button type="button" class="preset-btn proj-preset-gradient-btn" data-gradient="linear-gradient(135deg, #a855f7, #6366f1)" style="background: linear-gradient(135deg, #a855f7, #6366f1); color: #fff;">Cyber</button>
                  <button type="button" class="preset-btn proj-preset-gradient-btn" data-gradient="linear-gradient(135deg, #facc15, #ca8a04)" style="background: linear-gradient(135deg, #facc15, #ca8a04); color: #000;">Canary</button>
                  <button type="button" class="preset-btn proj-preset-gradient-btn" data-gradient="linear-gradient(135deg, #1f2937, #111827)" style="background: linear-gradient(135deg, #1f2937, #111827); color: #fff;">Dark</button>
                </div>
              </div>
              <div class="form-group">
                <label>Card Center Icon Class</label>
                <input type="text" class="form-control proj-icon" placeholder="e.g. fas fa-shield-alt" value="${escapeHtml(item.icon)}" required />
              </div>
              <div class="form-group">
                <label>Card Main Title</label>
                <input type="text" class="form-control proj-title" placeholder="e.g. VibeGuard" value="${escapeHtml(item.title)}" required />
              </div>
              <div class="form-group">
                <label>Card Tech Tags (Comma-separated)</label>
                <input type="text" class="form-control proj-tags" placeholder="TypeScript, Node.js" value="${escapeHtml(tagsText)}" />
              </div>
              <div class="form-group">
                <label>Direct Source Link</label>
                <input type="url" class="form-control proj-github" placeholder="Github repo url..." value="${escapeHtml(item.githubLink)}" required />
              </div>
              <div class="form-group">
                <label>Direct Live Demo Link</label>
                <input type="text" class="form-control proj-demo" placeholder="Live site or #..." value="${escapeHtml(item.demoLink)}" required />
              </div>
              <div class="form-group">
                <label>Details Association Key (Unique ID)</label>
                <input type="text" class="form-control proj-key" placeholder="e.g. vibeguard" value="${escapeHtml(item.detailsKey || '')}" required />
              </div>
              <div class="form-group full-width">
                <label>Card Short Description</label>
                <input type="text" class="form-control proj-description" placeholder="One sentence CLI summary..." value="${escapeHtml(item.description)}" required />
              </div>
    
              <!-- Collapsible Modal Details Block -->
              <div class="form-group full-width">
                <h4 style="margin-top: 10px; font-weight: 800; font-size: 0.85rem; text-transform: uppercase; border-top: 2px dashed rgba(0,0,0,0.15); padding-top: 15px;"><i class="fas fa-window-maximize"></i> Detail Modal Content</h4>
                <div class="sub-field-group">
                  <div class="form-group">
                    <label>Modal Category Tagline</label>
                    <input type="text" class="form-control modal-category" placeholder="e.g. DevSecOps CLI Tool" value="${escapeHtml(detail.category || '')}" />
                  </div>
                  <div class="form-group">
                    <label>Modal Long Description</label>
                    <textarea class="form-control modal-desc" placeholder="Write paragraphs describing the project details..." rows="3">${escapeHtml(detail.desc || '')}</textarea>
                  </div>
                  <div class="form-group">
                    <label>Modal Key Achievements (One per line)</label>
                    <textarea class="form-control modal-bullets" placeholder="Enter key bullets..." rows="4">${escapeHtml(detailBullets)}</textarea>
                  </div>
                  <div class="form-grid" style="grid-template-columns: 1fr 1fr; gap: 16px; margin: 0; width: 100%;">
                    <div class="form-group">
                      <label>Modal Code File Name</label>
                      <input type="text" class="form-control modal-fileName" placeholder="e.g. pipeline.ts" value="${escapeHtml(detail.fileName || '')}" />
                    </div>
                    <div class="form-group">
                      <label>Modal Live Demo Link (Modal override)</label>
                      <input type="text" class="form-control modal-demoLink" placeholder="e.g. https://..." value="${escapeHtml(detail.demoLink || '')}" />
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Modal Code Highlight Snippet</label>
                    <textarea class="form-control modal-code" placeholder="// Code goes here..." rows="8" style="font-family: 'Fira Code', monospace; font-size: 0.85rem;">${escapeHtml(detail.code || '')}</textarea>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Live Preview Column -->
          <div class="card-preview-pane">
            <div class="card-preview-title"><i class="fas fa-eye"></i> Live Project Card Preview</div>
            <div class="card-preview-canvas">
              <div class="project-card glass-panel">
                <div class="project-image" style="background: ${item.gradient || 'linear-gradient(135deg, #119, #38e)'};">
                  <i class="${item.icon || 'fas fa-folder'}"></i>
                </div>
                <div class="project-info">
                  <div class="project-tags">
                    ${(item.tags || []).map(t => `<span>${escapeHtml(t)}</span>`).join('')}
                  </div>
                  <h3>${escapeHtml(item.title || 'Project Name')}</h3>
                  <p>${escapeHtml(item.description || 'Project description summary...')}</p>
                  <div class="project-action-links" style="pointer-events: none;">
                    <button class="project-details-btn btn btn-outline"><i class="fas fa-info-circle"></i> Details</button>
                    <div class="project-links">
                      <span class="project-link"><i class="fab fa-github"></i></span>
                      <span class="project-link"><i class="fas fa-external-link-alt"></i></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
 
    container.appendChild(card);
    attachCardHeaderControllers(card);
    card.querySelector('.remove-proj-card').addEventListener('click', () => {
      card.remove();
      updateSidebarCounts();
    });

    // Real-time Preview bindings
    const gradInput = card.querySelector('.proj-gradient');
    const iconInput = card.querySelector('.proj-icon');
    const titleInput = card.querySelector('.proj-title');
    const tagsInput = card.querySelector('.proj-tags');
    const descInput = card.querySelector('.proj-description');

    const previewImage = card.querySelector('.project-image');
    const previewIcon = card.querySelector('.project-image i');
    const previewTitle = card.querySelector('.project-info h3');
    const previewTags = card.querySelector('.project-tags');
    const previewDesc = card.querySelector('.project-info p');
    const titleText = card.querySelector('.card-title-text');
    const headerIcon = card.querySelector('.live-preview-icon');

    function updatePreview() {
      const gradVal = gradInput.value.trim() || 'linear-gradient(135deg, #119, #38e)';
      const iconVal = iconInput.value.trim() || 'fas fa-folder';
      const titleVal = titleInput.value.trim() || 'New Project';
      const descVal = descInput.value.trim() || 'Project description summary...';

      previewImage.style.background = gradVal;
      previewIcon.className = iconVal;
      previewTitle.textContent = titleVal;
      previewDesc.textContent = descVal;

      titleText.textContent = titleVal;
      headerIcon.className = iconVal;

      // Tags
      const tags = tagsInput.value.split(',').map(t => t.trim()).filter(t => t !== '');
      previewTags.innerHTML = tags.map(t => `<span>${escapeHtml(t)}</span>`).join('');
    }

    gradInput.addEventListener('input', updatePreview);
    iconInput.addEventListener('input', updatePreview);
    titleInput.addEventListener('input', updatePreview);
    tagsInput.addEventListener('input', updatePreview);
    descInput.addEventListener('input', updatePreview);

    // Preset Pickers logic
    card.querySelectorAll('.proj-preset-gradient-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const grad = btn.getAttribute('data-gradient');
        gradInput.value = grad;
        updatePreview();
        showToast(`Gradient preset applied!`, 'info');
      });
    });
  }

  document.getElementById('btnAddProject')?.addEventListener('click', () => {
    const container = document.getElementById('projectsItemsContainer');
    addProjectCard(container, 
      { category: 'fullstack', gradient: 'linear-gradient(135deg, #0f2027, #2c5364)', icon: 'fas fa-code', tags: [], title: '', githubLink: '#', demoLink: '#', detailsKey: '', description: '' },
      { category: '', desc: '', bullets: [], fileName: 'index.js', code: '', demoLink: '#', githubLink: '#' },
      false
    );
    updateSidebarCounts();
    showToast('Empty project card added.', 'info');
  });

  // ---- Case Studies Builder ----
  function renderCaseStudiesBuilder(items) {
    const container = document.getElementById('caseStudiesItemsContainer');
    if (!container) return;
    container.innerHTML = '';

    items.forEach((item, idx) => {
      addCaseStudyCard(container, item, idx > 0);
    });
  }

  function addCaseStudyCard(container, item = {}, collapsed = false) {
    const card = document.createElement('div');
    card.className = `object-card-item cs-card-builder ${collapsed ? 'collapsed' : ''}`;
    
    // metrics array text
    const metricsHTML = (item.metrics || []).map((m, idx) => `
      <div class="item-row metric-row" style="margin-bottom: 8px;">
        <input type="text" class="form-control metric-value-input" placeholder="Value" value="${escapeHtml(m.value)}" required style="flex:1;" />
        <input type="text" class="form-control metric-label-input" placeholder="Label" value="${escapeHtml(m.label)}" required style="flex:2;" />
        <button type="button" class="btn-remove remove-metric-btn" style="height:38px; width:38px; padding:0;"><i class="fas fa-trash-alt"></i></button>
      </div>
    `).join('');

    const csName = item.title || 'New Case Study';

    card.innerHTML = `
      <div class="card-header-bar">
        <div class="card-title-info">
          <span class="live-preview-icon"><i class="fas fa-microscope"></i></span>
          <span class="card-title-text">${escapeHtml(csName)}</span>
        </div>
        <div class="card-action-btns">
          <button type="button" class="btn-micro-action btn-reorder-up" title="Move Up"><i class="fas fa-arrow-up"></i></button>
          <button type="button" class="btn-micro-action btn-reorder-down" title="Move Down"><i class="fas fa-arrow-down"></i></button>
          <button type="button" class="btn-micro-action btn-collapse" title="Collapse/Expand"><i class="fas fa-chevron-down"></i></button>
          <button type="button" class="btn-micro-action btn-card-delete remove-cs-card" title="Delete"><i class="fas fa-trash-alt"></i></button>
        </div>
      </div>
      <div class="card-body-content">
        <div class="card-editor-layout">
          <!-- Fields Column -->
          <div class="card-fields-pane">
            <div class="form-grid">
              <div class="form-group">
                <label>Unique ID (letters/hyphens)</label>
                <input type="text" class="form-control cs-id" placeholder="e.g. vibeguard-ai" value="${escapeHtml(item.id)}" required />
              </div>
              <div class="form-group">
                <label>Brand Tagline Badge</label>
                <input type="text" class="form-control cs-badge" placeholder="e.g. DevSecOps CLI" value="${escapeHtml(item.badge)}" required />
              </div>
              <div class="form-group">
                <label>Title</label>
                <input type="text" class="form-control cs-title" placeholder="e.g. VibeGuard" value="${escapeHtml(item.title)}" required />
              </div>
              <div class="form-group">
                <label>Accent Brand Color (Variable/Hex)</label>
                <input type="text" class="form-control cs-brandColor" placeholder="e.g. var(--accent-3)" value="${escapeHtml(item.brandColor)}" required />
                <div class="preset-picker-group">
                  <button type="button" class="preset-btn cs-preset-btn" data-color="var(--accent-1)" style="border-color: var(--accent-1); color: var(--accent-1);"><i class="fas fa-palette"></i> Blue</button>
                  <button type="button" class="preset-btn cs-preset-btn" data-color="var(--accent-2)" style="border-color: var(--accent-2); color: var(--accent-2);"><i class="fas fa-palette"></i> Yellow</button>
                  <button type="button" class="preset-btn cs-preset-btn" data-color="var(--accent-3)" style="border-color: var(--accent-3); color: var(--accent-3);"><i class="fas fa-palette"></i> Pink</button>
                  <button type="button" class="preset-btn cs-preset-btn" data-color="var(--accent-4)" style="border-color: var(--accent-4); color: var(--accent-4);"><i class="fas fa-palette"></i> Green</button>
                </div>
              </div>
              <div class="form-group full-width">
                <label>Subtitle Description Summary</label>
                <input type="text" class="form-control cs-subtitle" placeholder="Short description of the case study goals..." value="${escapeHtml(item.subtitle)}" required />
              </div>
    
              <!-- Metrics Builder -->
              <div class="form-group">
                <label>Metric Key-Value Boxes (Max 3 recommended)</label>
                <div class="item-list-container cs-metrics-list">
                  ${metricsHTML}
                </div>
                <button type="button" class="btn-add btn-add-metric" style="margin-top: 8px;"><i class="fas fa-plus"></i> Add Metric</button>
              </div>
    
              <!-- Tabs Content Textareas -->
              <div class="form-grid" style="grid-template-columns: 1fr; gap: 16px; margin: 0; width: 100%;">
                <div class="form-group">
                  <label>Challenge Details</label>
                  <textarea class="form-control cs-challenge" rows="3" required>${escapeHtml(item.challenge)}</textarea>
                </div>
                <div class="form-group">
                  <label>Solution Details</label>
                  <textarea class="form-control cs-solution" rows="3" required>${escapeHtml(item.solution)}</textarea>
                </div>
                <div class="form-group">
                  <label>Impact Details</label>
                  <textarea class="form-control cs-impact" rows="3" required>${escapeHtml(item.impact)}</textarea>
                </div>
              </div>
    
              <!-- Takeaway Object fields -->
              <div class="form-group full-width" style="border-top: 2px dashed rgba(0,0,0,0.15); padding-top: 15px; margin-top: 10px;">
                <label style="font-weight: 800; font-size: 0.85rem;"><i class="fas fa-lightbulb"></i> Tab Takeaway Details</label>
                <div class="sub-field-group">
                  <div class="form-group">
                    <label>Takeaway Headline Title</label>
                    <input type="text" class="form-control cs-takeaway-title" placeholder="Takeaway headline..." value="${escapeHtml(item.takeaway?.title || '')}" required />
                  </div>
                  <div class="form-group">
                    <label>Takeaway Core Paragraph Text</label>
                    <textarea class="form-control cs-takeaway-text" rows="3" required>${escapeHtml(item.takeaway?.text || '')}</textarea>
                  </div>
                  <div class="form-group">
                    <label>Core Principle / Lesson Learned</label>
                    <input type="text" class="form-control cs-takeaway-lesson" placeholder="Core lesson principle..." value="${escapeHtml(item.takeaway?.lesson || '')}" required />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Live Preview Column -->
          <div class="card-preview-pane">
            <div class="card-preview-title"><i class="fas fa-eye"></i> Live Case Study Preview</div>
            <div class="card-preview-canvas">
              <div class="case-study-card glass-panel" style="--brand-color: ${item.brandColor || 'var(--accent-1)'};">
                <div class="case-study-badge">${escapeHtml(item.badge || 'BADGE')}</div>
                <h3>${escapeHtml(item.title || 'Case Study Title')}</h3>
                <p>${escapeHtml(item.subtitle || 'Subtitle description details...')}</p>
                <div class="case-study-metrics-preview" style="display: flex; gap: 10px; margin-top: 16px; width: 100%;">
                  ${(item.metrics || []).map(m => `
                    <div class="metric-box" style="flex: 1; border: 2px solid #000; padding: 8px; text-align: center; background: var(--bg-secondary); box-shadow: 2px 2px 0 #000;">
                      <div class="metric-value" style="font-size: 1.1rem; font-weight: 900; color: var(--brand-color);">${escapeHtml(m.value)}</div>
                      <div class="metric-label" style="font-size: 0.65rem; text-transform: uppercase; font-weight: 800; color: var(--text-muted); margin-top: 2px;">${escapeHtml(m.label)}</div>
                    </div>
                  `).join('')}
                </div>
                <div style="margin-top: 20px; border-top: 2px solid #000; padding-top: 15px; font-weight: 800; font-size: 0.72rem; text-transform: uppercase; display: flex; align-items: center; justify-content: space-between; color: var(--text-muted);">
                  <span>Challenge & Solution</span>
                  <i class="fas fa-chevron-right"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    container.appendChild(card);
    attachCardHeaderControllers(card);
    card.querySelector('.remove-cs-card').addEventListener('click', () => {
      card.remove();
      updateSidebarCounts();
    });
    
    // Real-time Preview bindings
    const badgeInput = card.querySelector('.cs-badge');
    const titleInput = card.querySelector('.cs-title');
    const colorInput = card.querySelector('.cs-brandColor');
    const subtitleInput = card.querySelector('.cs-subtitle');

    const previewCard = card.querySelector('.case-study-card');
    const previewBadge = card.querySelector('.case-study-badge');
    const previewTitle = card.querySelector('.case-study-card h3');
    const previewSubtitle = card.querySelector('.case-study-card p');
    const previewMetrics = card.querySelector('.case-study-metrics-preview');
    const titleText = card.querySelector('.card-title-text');

    function updatePreview() {
      const colorVal = colorInput.value.trim() || 'var(--accent-1)';
      const badgeVal = badgeInput.value.trim() || 'BADGE';
      const titleVal = titleInput.value.trim() || 'New Case Study';
      const subtitleVal = subtitleInput.value.trim() || 'Subtitle description details...';

      previewCard.style.setProperty('--brand-color', colorVal);
      previewBadge.textContent = badgeVal;
      previewTitle.textContent = titleVal;
      previewSubtitle.textContent = subtitleVal;

      titleText.textContent = titleVal;

      // Gather metrics live
      const metricRows = card.querySelectorAll('.metric-row');
      let metricsHTML = '';
      metricRows.forEach(row => {
        const val = row.querySelector('.metric-value-input').value.trim();
        const lbl = row.querySelector('.metric-label-input').value.trim();
        if (val || lbl) {
          metricsHTML += `
            <div class="metric-box" style="flex: 1; border: 2px solid #000; padding: 8px; text-align: center; background: var(--bg-secondary); box-shadow: 2px 2px 0 #000;">
              <div class="metric-value" style="font-size: 1.1rem; font-weight: 900; color: var(--brand-color);">${escapeHtml(val || '0')}</div>
              <div class="metric-label" style="font-size: 0.65rem; text-transform: uppercase; font-weight: 800; color: var(--text-muted); margin-top: 2px;">${escapeHtml(lbl || 'Metric')}</div>
            </div>
          `;
        }
      });
      previewMetrics.innerHTML = metricsHTML;
    }

    badgeInput.addEventListener('input', updatePreview);
    titleInput.addEventListener('input', updatePreview);
    colorInput.addEventListener('input', updatePreview);
    subtitleInput.addEventListener('input', updatePreview);

    // Watch dynamic metrics additions/removals
    card.querySelector('.btn-add-metric').addEventListener('click', () => {
      setTimeout(() => {
        const rows = card.querySelectorAll('.metric-row');
        const lastRow = rows[rows.length - 1];
        if (lastRow) {
          lastRow.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', updatePreview);
          });
          lastRow.querySelector('.remove-metric-btn').addEventListener('click', () => {
            setTimeout(updatePreview, 50);
          });
        }
        updatePreview();
      }, 50);
    });

    card.querySelectorAll('.metric-row').forEach(row => {
      row.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', updatePreview);
      });
      row.querySelector('.remove-metric-btn').addEventListener('click', () => {
        setTimeout(updatePreview, 50);
      });
    });

    // Preset Pickers logic
    card.querySelectorAll('.cs-preset-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const color = btn.getAttribute('data-color');
        colorInput.value = color;
        updatePreview();
        showToast(`Color preset applied!`, 'info');
      });
    });
  }

  document.getElementById('btnAddCaseStudy')?.addEventListener('click', () => {
    const container = document.getElementById('caseStudiesItemsContainer');
    addCaseStudyCard(container, { id: '', badge: '', title: '', brandColor: 'var(--accent-1)', subtitle: '', metrics: [], challenge: '', solution: '', impact: '', takeaway: { title: '', text: '', lesson: '' } }, false);
    updateSidebarCounts();
    showToast('Empty case study card added.', 'info');
  });

  // ==========================================
  // GATHER DATA & SAVE / EXPORT
  // ==========================================

  // ---- Read all DOM inputs and construct JSON object ----
  function gatherFormData() {
    const data = {};

    // Hero
    data.hero = {
      badge: document.getElementById('heroBadge').value,
      title: document.getElementById('heroTitle').value,
      subtitle: document.getElementById('heroSubtitle').value,
      typewriterRoles: Array.from(document.querySelectorAll('#typewriterListContainer .string-array-input')).map(input => input.value.trim()),
      socialLinks: {
        github: document.getElementById('heroGithub').value,
        linkedin: document.getElementById('heroLinkedin').value,
      }
    };

    // About
    data.about = {
      label: document.getElementById('aboutLabel').value,
      title: document.getElementById('aboutTitle').value,
      paragraphs: Array.from(document.querySelectorAll('#aboutParagraphsContainer .string-array-input')).map(input => input.value.trim()),
      stats: Array.from(document.querySelectorAll('#aboutStatsContainer .item-row')).map(row => {
        return {
          label: row.querySelector('.stat-label-input').value.trim(),
          target: parseInt(row.querySelector('.stat-target-input').value) || 0
        };
      })
    };

    // Experience
    data.experience = {
      label: document.getElementById('expLabel').value,
      title: document.getElementById('expTitle').value,
      items: Array.from(document.querySelectorAll('#experienceItemsContainer .exp-card')).map(card => {
        return {
          side: card.querySelector('.exp-side').value,
          date: card.querySelector('.exp-date').value.trim(),
          role: card.querySelector('.exp-role').value.trim(),
          company: card.querySelector('.exp-company').value.trim(),
          description: card.querySelector('.exp-desc').value.trim(),
          bullets: card.querySelector('.exp-bullets').value.trim().split('\n').filter(b => b.trim() !== ''),
          tags: card.querySelector('.exp-tags').value.split(',').map(t => t.trim()).filter(t => t !== '')
        };
      })
    };

    // Skills
    data.skills = {
      label: document.getElementById('skillsLabel').value,
      title: document.getElementById('skillsTitle').value,
      categories: ['all', 'frontend', 'backend', 'databases', 'devops', 'security'],
      items: Array.from(document.querySelectorAll('#skillsItemsContainer .skill-card-builder')).map(card => {
        return {
          category: card.querySelector('.skill-category').value,
          icon: card.querySelector('.skill-icon').value.trim(),
          title: card.querySelector('.skill-title').value.trim(),
          desc: card.querySelector('.skill-desc').value.trim(),
          brandColor: card.querySelector('.skill-brandColor').value.trim()
        };
      })
    };

    // Projects & Details mapping
    const projectsList = Array.from(document.querySelectorAll('#projectsItemsContainer .project-card-builder'));
    const pItems = [];
    const pDetails = {};

    projectsList.forEach(card => {
      const detailsKey = card.querySelector('.proj-key').value.trim();
      
      const itemObj = {
        category: card.querySelector('.proj-category').value,
        gradient: card.querySelector('.proj-gradient').value.trim(),
        icon: card.querySelector('.proj-icon').value.trim(),
        tags: card.querySelector('.proj-tags').value.split(',').map(t => t.trim()).filter(t => t !== ''),
        title: card.querySelector('.proj-title').value.trim(),
        description: card.querySelector('.proj-description').value.trim(),
        githubLink: card.querySelector('.proj-github').value.trim(),
        demoLink: card.querySelector('.proj-demo').value.trim(),
        detailsKey: detailsKey
      };
      
      pItems.push(itemObj);

      if (detailsKey) {
        pDetails[detailsKey] = {
          title: itemObj.title,
          category: card.querySelector('.modal-category').value.trim(),
          desc: card.querySelector('.modal-desc').value.trim(),
          bullets: card.querySelector('.modal-bullets').value.trim().split('\n').filter(b => b.trim() !== ''),
          demoLink: card.querySelector('.modal-demoLink').value.trim() || itemObj.demoLink,
          githubLink: itemObj.githubLink,
          fileName: card.querySelector('.modal-fileName').value.trim() || 'index.js',
          code: card.querySelector('.modal-code').value.trim()
        };
      }
    });

    data.projects = {
      label: document.getElementById('projectsLabel').value,
      title: document.getElementById('projectsTitle').value,
      categories: ['all', 'fullstack', 'frontend', 'backend'],
      items: pItems,
      details: pDetails
    };

    // Case Studies
    data.caseStudies = {
      label: document.getElementById('csLabel').value,
      title: document.getElementById('csTitle').value,
      items: Array.from(document.querySelectorAll('#caseStudiesItemsContainer .cs-card-builder')).map(card => {
        return {
          id: card.querySelector('.cs-id').value.trim(),
          title: card.querySelector('.cs-title').value.trim(),
          subtitle: card.querySelector('.cs-subtitle').value.trim(),
          badge: card.querySelector('.cs-badge').value.trim(),
          brandColor: card.querySelector('.cs-brandColor').value.trim(),
          metrics: Array.from(card.querySelectorAll('.metric-row')).map(row => {
            return {
              value: row.querySelector('.metric-value-input').value.trim(),
              label: row.querySelector('.metric-label-input').value.trim()
            };
          }),
          challenge: card.querySelector('.cs-challenge').value.trim(),
          solution: card.querySelector('.cs-solution').value.trim(),
          impact: card.querySelector('.cs-impact').value.trim(),
          takeaway: {
            title: card.querySelector('.cs-takeaway-title').value.trim(),
            text: card.querySelector('.cs-takeaway-text').value.trim(),
            lesson: card.querySelector('.cs-takeaway-lesson').value.trim(),
          }
        };
      })
    };

    // Contact
    data.contact = {
      label: document.getElementById('contactLabel').value,
      title: document.getElementById('contactTitle').value,
      description: document.getElementById('contactDesc').value,
      email: document.getElementById('contactEmail').value.trim(),
      linkedin: document.getElementById('contactLinkedin').value.trim(),
      location: document.getElementById('contactLocation').value.trim(),
    };

    // Footer
    data.footer = {
      copyright: document.getElementById('footerCopyright').value.trim(),
      year: parseInt(document.getElementById('footerYearField').value) || new Date().getFullYear(),
    };

    return data;
  }

  // ---- Save Button Click ----
  document.getElementById('btnSave')?.addEventListener('click', () => {
    let data;
    const activeTab = document.querySelector('.admin-tab-btn.active').getAttribute('data-target-panel');
    
    if (activeTab === 'jsonPanel') {
      const jsonText = document.getElementById('jsonTextarea').value;
      try {
        data = JSON.parse(jsonText);
        currentContent = data;
        mapContentToForm(data);
      } catch (e) {
        showToast('JSON syntax error! Review raw edits before saving.', 'error');
        return;
      }
    } else {
      data = gatherFormData();
      currentContent = data;
      document.getElementById('jsonTextarea').value = JSON.stringify(data, null, 2);
    }

    const saved = ContentManager.save(data);
    if (saved) {
      showToast('Configuration saved to localStorage successfully!', 'success');
      if (window.opener && window.opener.reloadContent) {
        window.opener.reloadContent();
      }
    } else {
      showToast('Error saving configuration.', 'error');
    }
  });

  // ---- Reset Button Click ----
  document.getElementById('btnReset')?.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear all overrides? This resets everything to the hardcoded defaults.')) {
      const content = ContentManager.reset();
      currentContent = content;
      mapContentToForm(content);
      updateSidebarCounts();
      document.getElementById('jsonTextarea').value = JSON.stringify(content, null, 2);
      showToast('Configuration reset to defaults.', 'info');
      if (window.opener && window.opener.reloadContent) {
        window.opener.reloadContent();
      }
    }
  });

  // ---- Export Button Click ----
  document.getElementById('btnExport')?.addEventListener('click', () => {
    let data;
    const activeTab = document.querySelector('.admin-tab-btn.active').getAttribute('data-target-panel');
    
    if (activeTab === 'jsonPanel') {
      const jsonText = document.getElementById('jsonTextarea').value;
      try {
        data = JSON.parse(jsonText);
      } catch (e) {
        showToast('Cannot export! Fix JSON syntax error first.', 'error');
        return;
      }
    } else {
      data = gatherFormData();
    }

    const fileContent = `/**
 * content-config.js — Shared Content Management Layer
 * 
 * Provides default content and localStorage persistence.
 * Used by both the main portfolio (index.html) and admin dashboard.
 * 
 * All content is hardcoded with defaults; admin panel saves overrides to localStorage.
 */

const ContentManager = {
  // ==========================================
  // STORAGE KEY
  // ==========================================
  STORAGE_KEY: 'portfolio_content',

  // ==========================================
  // DEFAULT CONTENT — matches the original HTML
  // ==========================================
  defaults: ${JSON.stringify(data, null, 2)},

  // ==========================================
  // METHODS
  // ==========================================

  /**
   * Load all content from localStorage, merging with defaults.
   */
  load() {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Deep merge with defaults to ensure all keys exist
        return this.deepMerge(this.clone(this.defaults), parsed);
      }
    } catch (e) {
      console.warn('ContentManager: Failed to load from localStorage, using defaults.', e);
    }
    return this.clone(this.defaults);
  },

  /**
   * Save full content object to localStorage.
   */
  save(content) {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(content));
      return true;
    } catch (e) {
      console.error('ContentManager: Failed to save to localStorage.', e);
      return false;
    }
  },

  /**
   * Reset all content back to defaults.
   */
  reset() {
    localStorage.removeItem(this.STORAGE_KEY);
    return this.clone(this.defaults);
  },

  /**
   * Get a specific section from content.
   */
  getSection(content, section) {
    return content[section] || this.defaults[section] || {};
  },

  /**
   * Deep merge two objects (source overrides defaults).
   */
  deepMerge(defaults, overrides) {
    const result = this.clone(defaults);
    for (const key in overrides) {
      if (overrides[key] && typeof overrides[key] === 'object' && !Array.isArray(overrides[key])) {
        result[key] = this.deepMerge(result[key] || {}, overrides[key]);
      } else {
        result[key] = overrides[key];
      }
    }
    return result;
  },

  /**
   * Simple deep clone.
   */
  clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  },
};

// Export for use in both module and non-module contexts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ContentManager;
}
`;

    const blob = new Blob([fileContent], { type: 'application/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'content-config.js';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Download started! Copy this file to "js/content-config.js" and commit to make changes public.', 'success');
  });

  // Initialize
  if (sessionStorage.getItem('portfolio_admin_auth') === 'true') {
    loadDashboardContent();
  }

})();
